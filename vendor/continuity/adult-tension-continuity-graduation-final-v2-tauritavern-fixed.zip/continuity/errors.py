from __future__ import annotations

class ContinuityError(RuntimeError): pass
class ValidationError(ContinuityError): pass
class AuthorityError(ContinuityError): pass
class MigrationError(ContinuityError): pass
class HistoryIntegrityError(ContinuityError): pass
class JournalTransitionError(ContinuityError): pass
class RuntimeReadOnlyError(ContinuityError): pass
class UnsupportedOperationError(ContinuityError): pass
class ManifestError(ContinuityError): pass
