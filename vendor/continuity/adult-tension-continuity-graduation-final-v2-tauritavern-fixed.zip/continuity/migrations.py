from __future__ import annotations
import sqlite3
from .constants import MIGRATION_VERSION, SCHEMA_VERSION
from .errors import MigrationError
from .transactions.schema import (
    PHASE3_SCHEMA_META_KEY,
    phase3_ddl_statements,
)

DDL = '''
CREATE TABLE schema_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE continuity_transactions (continuity_tx_id TEXT PRIMARY KEY, operation TEXT NOT NULL, observed_runtime_pre_hash TEXT, observed_runtime_post_hash TEXT, sidecar_state TEXT NOT NULL, created_at TEXT NOT NULL, committed_at TEXT, failure_reason TEXT);
CREATE TABLE checkpoints (continuity_checkpoint_id TEXT PRIMARY KEY, continuity_tx_id TEXT NOT NULL REFERENCES continuity_transactions(continuity_tx_id), observed_runtime_hash TEXT NOT NULL, turn INTEGER, sidecar_tx_seq INTEGER NOT NULL, validation_state TEXT NOT NULL);
CREATE TABLE entities (entity_id TEXT PRIMARY KEY, branch_id TEXT NOT NULL DEFAULT 'default', kind TEXT NOT NULL, runtime_external_ref TEXT UNIQUE, identity_status TEXT NOT NULL, anchors_json TEXT NOT NULL, explicit_non_capabilities_json TEXT NOT NULL);
CREATE TABLE entity_aliases (alias_id TEXT PRIMARY KEY, entity_id TEXT NOT NULL REFERENCES entities(entity_id), alias TEXT NOT NULL, status TEXT NOT NULL, provenance_json TEXT NOT NULL, UNIQUE(entity_id,alias));
CREATE TABLE facts (fact_id TEXT PRIMARY KEY, branch_id TEXT NOT NULL DEFAULT 'default', subject_ref TEXT NOT NULL, predicate TEXT NOT NULL, object_json TEXT NOT NULL, plane TEXT NOT NULL, admission_state TEXT NOT NULL, truth_status TEXT NOT NULL, valid_from_turn INTEGER, invalid_at_turn INTEGER, recorded_at_turn INTEGER NOT NULL, recorded_at TEXT NOT NULL, provenance_json TEXT NOT NULL, classification TEXT NOT NULL);
CREATE TABLE fact_supersessions (old_fact_id TEXT NOT NULL REFERENCES facts(fact_id), new_fact_id TEXT NOT NULL REFERENCES facts(fact_id), continuity_tx_id TEXT NOT NULL REFERENCES continuity_transactions(continuity_tx_id), PRIMARY KEY(old_fact_id,new_fact_id));
CREATE TABLE knowledge (knowledge_id TEXT PRIMARY KEY, branch_id TEXT NOT NULL DEFAULT 'default', subject_ref TEXT NOT NULL, proposition_ref TEXT NOT NULL, state TEXT NOT NULL, plane TEXT NOT NULL, source TEXT NOT NULL, promotion_basis TEXT NOT NULL, turn INTEGER NOT NULL, provenance_json TEXT NOT NULL);
CREATE TABLE relationships (relationship_id TEXT PRIMARY KEY, branch_id TEXT NOT NULL DEFAULT 'default', source_ref TEXT NOT NULL, target_ref TEXT NOT NULL, runtime_refs_json TEXT NOT NULL, public_surface TEXT, actual_relation TEXT, phase TEXT, provenance_json TEXT NOT NULL);
CREATE TABLE relationship_dimensions (dimension_id TEXT PRIMARY KEY, relationship_id TEXT NOT NULL REFERENCES relationships(relationship_id), name TEXT NOT NULL, value_json TEXT NOT NULL, classification TEXT NOT NULL, UNIQUE(relationship_id,name));
CREATE TABLE commitments (commitment_id TEXT PRIMARY KEY, branch_id TEXT NOT NULL DEFAULT 'default', kind TEXT NOT NULL, issuer_ref TEXT NOT NULL, beneficiary_refs_json TEXT NOT NULL, content TEXT NOT NULL, status TEXT NOT NULL, runtime_event_ref TEXT, provenance_json TEXT NOT NULL);
CREATE TABLE threads (thread_id TEXT PRIMARY KEY, branch_id TEXT NOT NULL DEFAULT 'default', status TEXT NOT NULL, author_state TEXT, objective_state TEXT, player_visible_state TEXT, reveal_gate_json TEXT NOT NULL, presentation_json TEXT NOT NULL, provenance_json TEXT NOT NULL);
CREATE TABLE thread_requires (require_id TEXT PRIMARY KEY, thread_id TEXT NOT NULL REFERENCES threads(thread_id), ref TEXT NOT NULL, expected_state TEXT NOT NULL, plane TEXT NOT NULL);
CREATE TABLE thread_links (link_id TEXT PRIMARY KEY, thread_id TEXT NOT NULL REFERENCES threads(thread_id), other_thread_ref TEXT NOT NULL, status TEXT NOT NULL, confidence REAL NOT NULL);
CREATE TABLE thread_anti_merge (anti_merge_id TEXT PRIMARY KEY, thread_id TEXT NOT NULL REFERENCES threads(thread_id), blocked_ref TEXT NOT NULL, reason TEXT NOT NULL);
CREATE TABLE episodes (episode_id TEXT PRIMARY KEY, continuity_tx_id TEXT REFERENCES continuity_transactions(continuity_tx_id), branch_id TEXT NOT NULL, runtime_pre_hash TEXT, runtime_post_hash TEXT, history_pointer TEXT, checksum TEXT NOT NULL);
CREATE TABLE episode_fact_links (episode_id TEXT NOT NULL REFERENCES episodes(episode_id), fact_id TEXT NOT NULL REFERENCES facts(fact_id), PRIMARY KEY(episode_id,fact_id));
CREATE TABLE episode_entity_links (episode_id TEXT NOT NULL REFERENCES episodes(episode_id), entity_id TEXT NOT NULL REFERENCES entities(entity_id), PRIMARY KEY(episode_id,entity_id));
CREATE TABLE retrieval_traces (trace_id TEXT PRIMARY KEY, pack_id TEXT NOT NULL, item_id TEXT NOT NULL, trace_json TEXT NOT NULL, classification TEXT NOT NULL);
CREATE TABLE admission_candidates (candidate_id TEXT PRIMARY KEY, kind TEXT NOT NULL, payload_json TEXT NOT NULL, classification TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE admission_decisions (decision_id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL REFERENCES admission_candidates(candidate_id), decision TEXT NOT NULL, basis TEXT NOT NULL, decided_at TEXT NOT NULL);
'''

BRANCHED_TABLES = ("entities", "facts", "knowledge", "relationships", "commitments", "threads")


def _upgrade_1_to_2(conn: sqlite3.Connection) -> None:
    for table in BRANCHED_TABLES:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN branch_id TEXT NOT NULL DEFAULT 'default'")


def migrate(conn: sqlite3.Connection) -> None:
    try:
        conn.execute('BEGIN')
        conn.execute('PRAGMA foreign_keys=ON')
        exists = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='schema_meta'").fetchone()
        if exists:
            row = conn.execute("SELECT value FROM schema_meta WHERE key='migration_version'").fetchone()
            version = int(row[0]) if row is not None else None
            if version is None or version > MIGRATION_VERSION:
                raise MigrationError('unsupported or incomplete migration version')
            if version < MIGRATION_VERSION:
                if version == 1 and MIGRATION_VERSION == 2:
                    _upgrade_1_to_2(conn)
                else:
                    raise MigrationError(f'no migration path from version {version}')
                conn.execute("UPDATE schema_meta SET value=? WHERE key='migration_version'", (str(MIGRATION_VERSION),))
        else:
            for statement in (item.strip() for item in DDL.split(';')):
                if statement:
                    conn.execute(statement)
            conn.executemany(
                'INSERT INTO schema_meta(key,value) VALUES(?,?)',
                [('schema_version', str(SCHEMA_VERSION)), ('migration_version', str(MIGRATION_VERSION))],
            )
        ensure_phase3_schema(conn)
        conn.commit()
    except Exception as exc:
        conn.rollback()
        if isinstance(exc, MigrationError):
            raise
        raise MigrationError(str(exc)) from exc


def ensure_phase3_schema(conn: sqlite3.Connection) -> None:
    """Idempotently create the Phase 3A saga tables (additive only).

    This never rewrites an old migration and never touches existing Phase 1 /
    2A / 2B tables or data.  Migration rerun safety = CREATE TABLE IF NOT EXISTS
    + recorded own schema-meta marker.  Runs inside the caller's transaction.
    """
    for statement in phase3_ddl_statements():
        conn.execute(statement)
    # create the derived index set (idempotent)
    from .transactions.schema import PHASE3_INDEX_DDL
    for item in (x.strip() for x in PHASE3_INDEX_DDL.split(';')):
        if item:
            conn.execute(item)
    row = conn.execute(
        "SELECT value FROM schema_meta WHERE key=?", (PHASE3_SCHEMA_META_KEY,)).fetchone()
    if row is None:
        conn.execute(
            "INSERT INTO schema_meta(key,value) VALUES(?,?)",
            (PHASE3_SCHEMA_META_KEY, "1"))
        conn.execute(
            "INSERT INTO schema_meta(key,value) VALUES(?,?)",
            ("phase3_builder_version", "phase3-safe-saga-v1"))
