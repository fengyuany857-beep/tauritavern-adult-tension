"""Phase 1 constants. Runtime hashes are observations, never revisions."""
from __future__ import annotations
from enum import Enum

SCHEMA_VERSION = 1
MIGRATION_VERSION = 2
BUILDER_VERSION = "phase1-1.0.0"
AUDITED_VENDOR_HEAD = "cbfdc623fccc91247cbb37783757fc157406c2a5"

class Classification(str, Enum):
    AUTHORITY = "AUTHORITY"
    AUTHORITY_REFERENCE = "AUTHORITY_REFERENCE"
    HISTORICAL_EVIDENCE = "HISTORICAL_EVIDENCE"
    CANDIDATE = "CANDIDATE"
    DERIVED_REBUILDABLE = "DERIVED_REBUILDABLE"

class TruthStatus(str, Enum):
    ACTIVE = "ACTIVE"
    ACTIVE_INTERPRETATION = "ACTIVE_INTERPRETATION"
    HISTORICAL_FACT = "HISTORICAL_FACT"
    SUPERSEDED = "SUPERSEDED"
    UNRESOLVED = "UNRESOLVED"
    PENDING = "PENDING"
    AUTHOR_PLAN = "AUTHOR_PLAN"

class AdmissionState(str, Enum):
    CANDIDATE = "CANDIDATE"
    COMMITTED = "COMMITTED"
    REJECTED = "REJECTED"

class Plane(str, Enum):
    AUTHOR = "AUTHOR"
    OBJECTIVE = "OBJECTIVE"
    PLAYER_VISIBLE = "PLAYER_VISIBLE"
    CHARACTER = "CHARACTER"
    PRESENTATION = "PRESENTATION"

class KnowledgeState(str, Enum):
    DOES_NOT_KNOW = "does_not_know"
    PARTIAL = "partial"
    SUSPECTS = "suspects"
    KNOWS = "knows"
    FALSE_BELIEF = "false_belief"

class JournalState(str, Enum):
    PREPARED = "PREPARED"
    RUNTIME_WRITE_NOT_ATTEMPTED = "RUNTIME_WRITE_NOT_ATTEMPTED"
    RUNTIME_OUTCOME_UNKNOWN = "RUNTIME_OUTCOME_UNKNOWN"
    RUNTIME_OBSERVED_CHANGED = "RUNTIME_OBSERVED_CHANGED"
    CONTINUITY_PENDING = "CONTINUITY_PENDING"
    COMMITTED = "COMMITTED"
    NEEDS_RECOVERY = "NEEDS_RECOVERY"
    ABORTED = "ABORTED"
    MANUAL_REVIEW = "MANUAL_REVIEW"

RUNTIME_OWNED_PREFIXES = frozenset({
    "meta", "world", "boundaries", "consent", "grant", "grants", "boundary", "safety", "sexuality_profile", "intimacy", "player", "npcs", "relationships",
    "events", "checkpoint", "resolved_summary", "current_node", "retcons",
})
JOURNAL_TRANSITIONS = {
    JournalState.PREPARED: {JournalState.RUNTIME_WRITE_NOT_ATTEMPTED, JournalState.RUNTIME_OUTCOME_UNKNOWN, JournalState.RUNTIME_OBSERVED_CHANGED, JournalState.ABORTED},
    JournalState.RUNTIME_WRITE_NOT_ATTEMPTED: {JournalState.ABORTED},
    JournalState.RUNTIME_OUTCOME_UNKNOWN: {JournalState.RUNTIME_OBSERVED_CHANGED, JournalState.MANUAL_REVIEW, JournalState.ABORTED},
    JournalState.RUNTIME_OBSERVED_CHANGED: {JournalState.CONTINUITY_PENDING, JournalState.NEEDS_RECOVERY, JournalState.MANUAL_REVIEW},
    JournalState.CONTINUITY_PENDING: {JournalState.COMMITTED, JournalState.NEEDS_RECOVERY, JournalState.MANUAL_REVIEW},
    JournalState.NEEDS_RECOVERY: {JournalState.CONTINUITY_PENDING, JournalState.COMMITTED, JournalState.MANUAL_REVIEW},
    JournalState.ABORTED: set(), JournalState.COMMITTED: set(), JournalState.MANUAL_REVIEW: set(),
}
