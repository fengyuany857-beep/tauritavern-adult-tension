"""Phase 3A continuity transaction foundation (safe saga, read-only w.r.t runtime).

Public entry points:
- preconditions.prepare_transaction (live) and .verify_prewrite_precondition (P8)
- runtime_observation.read_observation / prepare pure-candidate generation
- journal.JournalDao (durable journal + lifecycle rule harness)
- contracts / digests / schema
"""
from .contracts import (
    TransactionState,
    RuntimeOutcomeClass,
    ContinuitySyncState,
    PreconditionStatus,
    RecoveryDisposition,
    ManualReviewFlag,
    TransactionConclusion,
    TransactionOutcome,
)
from .preconditions import (
    PreparedEvidence,
    prepare_transaction,
    verify_prewrite_precondition,
    require_concrete_patch,
    generate_expected_candidate,
)
from .runtime_observation import (
    RuntimeIdentity,
    RuntimeObservation,
    read_observation,
)
from .journal import JournalDao
from . import errors as tx_errors
from . import contracts as tx_contracts

__all__ = [
    "TransactionState", "RuntimeOutcomeClass", "ContinuitySyncState",
    "PreconditionStatus", "RecoveryDisposition", "ManualReviewFlag",
    "TransactionConclusion", "TransactionOutcome",
    "PreparedEvidence", "prepare_transaction", "verify_prewrite_precondition",
    "require_concrete_patch",
    "RuntimeIdentity", "RuntimeObservation", "read_observation",
    "generate_expected_candidate", "JournalDao",
]
