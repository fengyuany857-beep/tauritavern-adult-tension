"""Phase 3A transaction error taxonomy.

Finite, explicit error classes (protocol §15).  Error-class strings / stable
classes drive control-flow instead of arbitrary string matching.
"""
from __future__ import annotations
import enum
from ..errors import ContinuityError


class TxErrorCode(str, enum.Enum):
    RUNTIME_NOT_FOUND = "RUNTIME_NOT_FOUND"
    RUNTIME_UNREADABLE = "RUNTIME_UNREADABLE"
    RUNTIME_NO_REGULAR_FILE = "RUNTIME_NO_REGULAR_FILE"
    RUNTIME_SYMLINK_REJECTED = "RUNTIME_SYMLINK_REJECTED"
    RUNTIME_PARSE_ERROR = "RUNTIME_PARSE_ERROR"
    RUNTIME_VALIDATION_ERROR = "RUNTIME_VALIDATION_ERROR"
    CANDIDATE_VALIDATION_ERROR = "CANDIDATE_VALIDATION_ERROR"
    PRECONDITION_HASH_MISMATCH = "PRECONDITION_HASH_MISMATCH"
    DB_ERROR = "DB_ERROR"
    SPEC_CONFLICT = "SPEC_CONFLICT"
    UNSUPPORTED_NAMED_SLOT = "UNSUPPORTED_NAMED_SLOT"
    UNSUPPORTED_RUNTIME_IDENTITY = "UNSUPPORTED_RUNTIME_IDENTITY"
    UNSUPPORTED_FEATURE = "UNSUPPORTED_FEATURE"
    INVALID_TRANSITION = "INVALID_TRANSITION"
    DUPLICATE_ATTEMPT = "DUPLICATE_ATTEMPT"
    EVIDENCE_INSUFFICIENT = "EVIDENCE_INSUFFICIENT"
    PATCH_REQUIRED = "PATCH_REQUIRED"
    PLAYER_SOVEREIGNTY_VIOLATION = "PLAYER_SOVEREIGNTY_VIOLATION"
    ADULT_AUTHORITY_VIOLATION = "ADULT_AUTHORITY_VIOLATION"
    INPUT_CONTRACT_VIOLATION = "INPUT_CONTRACT_VIOLATION"
    UNKNOWN_TX = "UNKNOWN_TX"
    UNSUPPORTED_DIGEST = "UNSUPPORTED_DIGEST"
    INVALID_ARGUMENT = "INVALID_ARGUMENT"
    DUPLICATE_TX = "DUPLICATE_TX"
    UNSUPPORTED_DIRECTORY_FSYNC = "UNSUPPORTED_DIRECTORY_FSYNC"


class TxError(ContinuityError):
    """Base for all Phase 3A transaction errors.  code is a stable finite class."""
    code = TxErrorCode.DB_ERROR

    def __init__(self, message: str, *, code: "TxErrorCode | None" = None):
        super().__init__(message)
        self.message = message
        if code is not None:
            self.code = code

    @property
    def class_label(self) -> str:
        return self.code.value


# --------------------------------------------------------------------------- #
# Concrete stable failure classes (one per meaningful failure mode).
# --------------------------------------------------------------------------- #
class RuntimeNotFound(TxError):
    code = TxErrorCode.RUNTIME_NOT_FOUND


class RuntimeUnreadable(TxError):
    code = TxErrorCode.RUNTIME_UNREADABLE


class RuntimeNoRegularFile(TxError):
    code = TxErrorCode.RUNTIME_NO_REGULAR_FILE


class RuntimeSymlinkRejected(TxError):
    code = TxErrorCode.RUNTIME_SYMLINK_REJECTED


class RuntimeParseError(TxError):
    code = TxErrorCode.RUNTIME_PARSE_ERROR


class RuntimeValidationError(TxError):
    code = TxErrorCode.RUNTIME_VALIDATION_ERROR


class CandidateValidationError(TxError):
    code = TxErrorCode.CANDIDATE_VALIDATION_ERROR


class PreconditionHashMismatch(TxError):
    code = TxErrorCode.PRECONDITION_HASH_MISMATCH


class TxDBError(TxError):
    code = TxErrorCode.DB_ERROR


class SpecConflict(TxError):
    code = TxErrorCode.SPEC_CONFLICT


class UnsupportedNamedSlot(TxError):
    code = TxErrorCode.UNSUPPORTED_NAMED_SLOT


class UnsupportedRuntimeIdentity(TxError):
    code = TxErrorCode.UNSUPPORTED_RUNTIME_IDENTITY


class UnsupportedFeature(TxError):
    code = TxErrorCode.UNSUPPORTED_FEATURE


class InvalidTransition(TxError):
    code = TxErrorCode.INVALID_TRANSITION


class DuplicateAttempt(TxError):
    code = TxErrorCode.DUPLICATE_ATTEMPT


class EvidenceInsufficient(TxError):
    code = TxErrorCode.EVIDENCE_INSUFFICIENT


class PatchRequired(TxError):
    code = TxErrorCode.PATCH_REQUIRED


class PlayerSovereigntyViolation(TxError):
    code = TxErrorCode.PLAYER_SOVEREIGNTY_VIOLATION


class AdultAuthorityViolation(TxError):
    code = TxErrorCode.ADULT_AUTHORITY_VIOLATION


class InputContractViolation(TxError):
    code = TxErrorCode.INPUT_CONTRACT_VIOLATION


class UnknownTx(TxError):
    code = TxErrorCode.UNKNOWN_TX


class UnsupportedDigest(TxError):
    code = TxErrorCode.UNSUPPORTED_DIGEST


class InvalidArgument(TxError):
    code = TxErrorCode.INVALID_ARGUMENT


class DuplicateTx(TxError):
    code = TxErrorCode.DUPLICATE_TX


class UnsupportedDirectoryFsync(TxError):
    code = TxErrorCode.UNSUPPORTED_DIRECTORY_FSYNC
