"""Phase 3A transaction journal schema (additive; protocol §17).

These tables are journal / operational-recovery metadata for the continuity
saga.  They are NOT world truth and never autonomously produce Canon/historical
facts.  Full current adult-permission payload is never stored here: the journal
keeps hashes, digests, refs, bounded non-sensitive structural evidence and
bounded provenance.

Intentional boundaries (protocol):
- continuity_tx_id is UNIQUE -> PRIMARY KEY of transaction_journal.
- attempt_count is restricted to 0..1 (one runtime mutation attempt maximum).
- manual-review metadata stores a bounded evidence summary + safe-action codes,
  never a chain-of-thought field.
"""
from __future__ import annotations

SAGA_TRANSACTIONS_DDL = """
CREATE TABLE IF NOT EXISTS transaction_journal (
  continuity_tx_id        TEXT PRIMARY KEY,
  protocol_version        TEXT NOT NULL,
  state                   TEXT NOT NULL,
  created_at              TEXT NOT NULL,
  updated_at              TEXT NOT NULL,
  branch_id               TEXT NOT NULL,
  operation               TEXT NOT NULL,
  runtime_identity        TEXT NOT NULL,
  runtime_path_ref        TEXT NOT NULL,
  runtime_pre_sha256      TEXT NOT NULL,
  runtime_pre_semantic_digest TEXT NOT NULL,
  runtime_expected_sha256 TEXT,
  runtime_expected_semantic_digest TEXT,
  runtime_post_observed_sha256 TEXT,
  runtime_post_semantic_digest  TEXT,
  patch_digest            TEXT NOT NULL,
  canonicalisation_version TEXT NOT NULL,
  adapter_fingerprint     TEXT,
  serializer_fingerprint  TEXT,
  attempt_count           INTEGER NOT NULL DEFAULT 0 CHECK(attempt_count IN (0,1)),
  runtime_attempt_started_at TEXT,
  runtime_attempt_finished_at TEXT,
  runtime_outcome_class   TEXT,
  durability_status       TEXT,
  continuity_sync_state   TEXT,
  last_error_class        TEXT,
  last_error_detail       TEXT,
  manual_review_required  INTEGER NOT NULL DEFAULT 0,
  manual_review_json      TEXT,
  recovery_attempt_count  INTEGER NOT NULL DEFAULT 0,
  request_provenance_json TEXT,
  source_provenance_json  TEXT,
  expected_candidate_digest TEXT,
  precondition_status     TEXT,
  staged_sync_digest      TEXT,
  committed_at            TEXT
);
"""

TRANSACTION_STATE_EVENTS_DDL = """
CREATE TABLE IF NOT EXISTS transaction_state_events (
  event_id         INTEGER PRIMARY KEY AUTOINCREMENT,
  continuity_tx_id TEXT NOT NULL REFERENCES transaction_journal(continuity_tx_id),
  ordinal          INTEGER NOT NULL,
  from_state       TEXT NOT NULL,
  to_state         TEXT NOT NULL,
  at_time          TEXT NOT NULL,
  evidence_digest  TEXT,
  UNIQUE (continuity_tx_id, ordinal)
);
"""

CONTINUITY_SYNC_EXECUTIONS_DDL = """
CREATE TABLE IF NOT EXISTS continuity_sync_executions (
  continuity_tx_id TEXT PRIMARY KEY REFERENCES transaction_journal(continuity_tx_id),
  payload_digest   TEXT NOT NULL,
  started_at       TEXT,
  synced_at        TEXT
);
"""

CONTINUITY_EFFECT_MARKERS_DDL = """
CREATE TABLE IF NOT EXISTS continuity_effect_markers (
  continuity_tx_id TEXT NOT NULL REFERENCES transaction_journal(continuity_tx_id),
  effect_kind      TEXT NOT NULL,
  effect_key       TEXT NOT NULL,
  payload_digest   TEXT,
  PRIMARY KEY (continuity_tx_id, effect_kind, effect_key)
);
"""

HISTORY_OUTBOX_DDL = """
CREATE TABLE IF NOT EXISTS history_outbox (
  outbox_id        TEXT PRIMARY KEY,
  continuity_tx_id TEXT NOT NULL REFERENCES transaction_journal(continuity_tx_id),
  envelope_kind    TEXT NOT NULL,
  envelope_id      TEXT NOT NULL,
  payload_json     TEXT,
  checksum         TEXT,
  state            TEXT NOT NULL,
  created_at       TEXT NOT NULL,
  delivered_at     TEXT,
  UNIQUE (continuity_tx_id, envelope_kind),
  UNIQUE (envelope_id)
);
"""

RECOVERY_OBSERVATIONS_DDL = """
CREATE TABLE IF NOT EXISTS recovery_observations (
  observation_id     TEXT PRIMARY KEY,
  continuity_tx_id   TEXT NOT NULL REFERENCES transaction_journal(continuity_tx_id),
  observed_at        TEXT NOT NULL,
  kind               TEXT NOT NULL,
  raw_sha256         TEXT,
  semantic_digest    TEXT,
  selected_evidence_json TEXT,
  validation_state   TEXT,
  source             TEXT
);
"""

PHASE3_INDEX_DDL = """
CREATE INDEX IF NOT EXISTS idx_tx_state ON transaction_journal(state, manual_review_required);
CREATE INDEX IF NOT EXISTS idx_tx_runtime ON transaction_journal(runtime_identity, created_at);
CREATE INDEX IF NOT EXISTS idx_recovery_obs ON recovery_observations(continuity_tx_id, observed_at);
CREATE INDEX IF NOT EXISTS idx_outbox_state ON history_outbox(state, created_at);
"""

# Canonical column order used for INSERT (must match _ts_cols in journal.py).
TS_COLS = (
    "continuity_tx_id", "protocol_version", "state", "created_at", "updated_at",
    "branch_id", "operation", "runtime_identity", "runtime_path_ref",
    "runtime_pre_sha256", "runtime_pre_semantic_digest",
    "runtime_expected_sha256", "runtime_expected_semantic_digest",
    "runtime_post_observed_sha256", "runtime_post_semantic_digest",
    "patch_digest", "canonicalisation_version", "adapter_fingerprint",
    "serializer_fingerprint", "attempt_count", "runtime_attempt_started_at",
    "runtime_attempt_finished_at", "runtime_outcome_class",
    "durability_status", "continuity_sync_state", "last_error_class",
    "last_error_detail", "manual_review_required", "manual_review_json",
    "recovery_attempt_count", "request_provenance_json", "source_provenance_json",
    "expected_candidate_digest", "precondition_status", "staged_sync_digest",
    "committed_at",
)

PHASE3_DDL_STATEMENTS = (
    SAGA_TRANSACTIONS_DDL,
    TRANSACTION_STATE_EVENTS_DDL,
    CONTINUITY_SYNC_EXECUTIONS_DDL,
    CONTINUITY_EFFECT_MARKERS_DDL,
    HISTORY_OUTBOX_DDL,
    RECOVERY_OBSERVATIONS_DDL,
)

PHASE3_SCHEMA_META_KEY = "phase3_tx_schema_version"


def phase3_ddl_statements() -> list[str]:
    return [s for s in PHASE3_DDL_STATEMENTS if s and s.strip()]
