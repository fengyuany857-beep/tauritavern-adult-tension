"""Phase 3A durable transaction journal DAO.

SQLite-backed, transactional journal for one continuity saga.  It is the
continuity operational/recovery authority for *orchestration metadata*, never
world truth, and cannot autonomously generate Canon/historical facts.

Guarantee (protocol §8/§13/§14/§15/§18):
- SQLite journal atomicity only; never claims runtime+SQLite atomicity.
- continuity_tx_id UNIQUE (PK).  It is a sidecar orchestration ID, NOT a
  runtime transaction id.
- attempt_count may be 0 or 1 (one runtime mutation attempt maximum).
  The attempt-slot flip is atomic (DB write-lock + re-read = check-and-set).
- explicit lifecycle transitions; invalid transition rejected (fail closed).
- OUTCOME_UNKNOWN / CONCURRENT_DIVERGENCE never auto-retry into
  RUNTIME_ATTEMPTING (a later runtime action needs a new tx_id).
- bounded error detail; structured fields stored as canonical JSON.
- manual-review packet stores evidence summary + safe-action codes, never CoT.

Phase 3A performs NO runtime mutation.  The DAO surfaces to model/move a row
through lifecycle states exist as a *rule engine / unit-test harness*; Phase 3A
product flows only ever create PREPARED rows and (on a second-read mismatch)
terminate them as PRECONDITION_FAILED, or abort them.  Runtime-outcome states
are entered only by Phase 3B's evidence classifier, which is out of scope here.
"""
from __future__ import annotations
import json
import sqlite3
from datetime import datetime, timezone
from typing import Any

from .contracts import (
    PHASE3A_NO_RUNTIME_STATES,
    MAX_ERROR_DETAIL,
    MAX_EVIDENCE_FIELD,
    TransactionState,
    can_transition,
    is_terminal,
)
from .errors import (
    TxError, TxErrorCode,
    DuplicateAttempt, InvalidTransition, UnknownTx,
)
from .schema import TS_COLS

JOURNAL_TABLES = (
    "transaction_journal", "transaction_state_events",
    "continuity_sync_executions", "continuity_effect_markers", "history_outbox",
    "recovery_observations",
)
# Authority tables that must remain immutable during Phase 3A operation. They
# are never written by this module; listed for the immutability harness.
AUTHORITY_TABLES = (
    "entities", "facts", "knowledge", "relationships", "commitments",
    "threads", "episodes", "admission_candidates", "admission_decisions",
    "entity_aliases", "fact_supersessions", "relationship_dimensions",
    "thread_requires", "thread_links", "thread_anti_merge",
    "episode_entity_links", "retrieval_traces", "continuity_transactions",
    "checkpoints",
)


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _bounded(value: str | None, limit: int) -> str | None:
    if value is None:
        return None
    value = str(value)
    return value[:limit - 1] + "…" if len(value) > limit else value


def _json_bounded(obj: Any, limit: int = MAX_EVIDENCE_FIELD) -> str | None:
    if obj is None:
        return None
    text = json.dumps(obj, sort_keys=True, ensure_ascii=False)
    return _bounded(text, limit)


class JournalDao:
    """Read/write access to the saga journal (operation tables only)."""

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    # ------------------------------------------------------------------ #
    def _row(self, tx_id: str) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM transaction_journal WHERE continuity_tx_id=?", (tx_id,)).fetchone()

    def _require(self, tx_id: str) -> sqlite3.Row:
        row = self._row(tx_id)
        if row is None:
            raise UnknownTx(tx_id)
        return row

    def _append_event(self, tx_id: str, from_state: str, to_state: str,
                      at_time: str, digest: str | None = None) -> None:
        nxt = self.conn.execute(
            "SELECT COALESCE(MAX(ordinal), -1) + 1 AS n FROM transaction_state_events "
            "WHERE continuity_tx_id=?", (tx_id,)).fetchone()["n"]
        self.conn.execute(
            "INSERT INTO transaction_state_events "
            "(continuity_tx_id, ordinal, from_state, to_state, at_time, evidence_digest) "
            "VALUES (?,?,?,?,?,?)",
            (tx_id, int(nxt), from_state, to_state, at_time, digest))

    # ------------------------------------------------------------------ #
    def create_prepared(
        self, *,
        tx_id: str, operation: str, branch_id: str, protocol_version: str,
        runtime_identity: str, runtime_path_ref: str,
        runtime_pre_sha256: str, runtime_pre_semantic_digest: str,
        patch_digest: str, canonicalisation_version: str,
        expected_candidate_digest: str,
        runtime_expected_semantic_digest: str | None = None,
        runtime_expected_sha256: str | None = None,
        request_provenance: dict[str, Any] | None = None,
        source_provenance: dict[str, Any] | None = None,
        adapter_fingerprint: str | None = None,
        serializer_fingerprint: str | None = None,
        staged_sync_digest: str | None = None,
    ) -> dict[str, Any]:
        """Atomically persist a PREPARED saga row (attempt_count=0) and its
        expected-candidate evidence in ONE committed SQLite transaction.

        If commit/durability fails nothing is persisted and no runtime call can
        follow (protocol P7: a missing durable PREPARED means no write).
        """
        if self._row(tx_id) is not None:
            raise TxError(f"duplicate continuity_tx_id: {tx_id}", code=TxErrorCode.DUPLICATE_TX)
        now = _now()
        record: dict[str, Any] = {k: None for k in TS_COLS}
        record.update({
            "continuity_tx_id": tx_id,
            "protocol_version": protocol_version,
            "state": TransactionState.PREPARED.value,
            "created_at": now, "updated_at": now,
            "branch_id": branch_id, "operation": operation,
            "runtime_identity": runtime_identity,
            "runtime_path_ref": runtime_path_ref,
            "runtime_pre_sha256": runtime_pre_sha256,
            "runtime_pre_semantic_digest": runtime_pre_semantic_digest,
            "runtime_expected_sha256": runtime_expected_sha256,
            "runtime_expected_semantic_digest": runtime_expected_semantic_digest,
            "patch_digest": patch_digest,
            "canonicalisation_version": canonicalisation_version,
            "adapter_fingerprint": adapter_fingerprint,
            "serializer_fingerprint": serializer_fingerprint,
            "attempt_count": 0,
            "expected_candidate_digest": expected_candidate_digest,
            "precondition_status": "NOT_YET_CHECKED",
            "request_provenance_json": _json_bounded(request_provenance, MAX_EVIDENCE_FIELD),
            "source_provenance_json": _json_bounded(source_provenance, MAX_EVIDENCE_FIELD),
            "staged_sync_digest": staged_sync_digest,
            "manual_review_required": 0, "recovery_attempt_count": 0,
        })
        cols = list(record.keys())
        values = [record[c] for c in cols]
        with self.conn:
            self.conn.execute(
                "INSERT INTO transaction_journal ("
                + ",".join(cols) + ") VALUES (" + ",".join("?" * len(cols)) + ")", values)
            self._append_event(tx_id, "NONE", TransactionState.PREPARED.value, now)
        return dict(self._row(tx_id))

    # ------------------------------------------------------------------ #
    def get(self, tx_id: str) -> dict[str, Any] | None:
        row = self._row(tx_id)
        return dict(row) if row is not None else None

    def state_of(self, tx_id: str) -> str:
        return self._require(tx_id)["state"]

    def attempt_count(self, tx_id: str) -> int:
        return int(self._require(tx_id)["attempt_count"] or 0)

    def terminal(self, tx_id: str) -> bool:
        return self.is_terminal_state(self._require(tx_id)["state"])

    def nonterminal(self, tx_id: str) -> bool:
        return not self.terminal(tx_id)

    @staticmethod
    def is_terminal_state(state_or_enum: Any) -> bool:
        key = state_or_enum.value if isinstance(state_or_enum, TransactionState) else str(state_or_enum)
        return is_terminal(TransactionState(key))

    def nonterminal_rows(self) -> list[dict[str, Any]]:
        rows = self.conn.execute("SELECT * FROM transaction_journal").fetchall()
        return [dict(r) for r in rows if not self.is_terminal_state(r["state"])]

    def state_events(self, tx_id: str) -> list[dict[str, Any]]:
        self._require(tx_id)
        rows = self.conn.execute(
            "SELECT ordinal, from_state, to_state, at_time, evidence_digest "
            "FROM transaction_state_events WHERE continuity_tx_id=? ORDER BY ordinal",
            (tx_id,)).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ #
    def _transition(self, tx_id: str, to_state: str,
                    fields: dict[str, Any] | None = None,
                    require_from: str | None = None,
                    allow_same: bool = False) -> dict[str, Any]:
        """Atomic lifecycle transition with the protocol transition table."""
        row = self._require(tx_id)
        cur = row["state"]
        if require_from is not None and cur != require_from:
            raise InvalidTransition(
                f"expected {require_from!r} but tx is {cur!r}")
        if cur == to_state and not allow_same:
            raise InvalidTransition(f"already in state {to_state!r}")
        if cur != to_state and not can_transition(TransactionState(cur), to_state):
            raise InvalidTransition(f"illegal transition {cur!r} -> {to_state!r}")
        at = _now()
        updates = {"state": to_state, "updated_at": at}
        if fields:
            updates.update(fields)
        sets = ", ".join(f"{k}=?" for k in updates)
        with self.conn:
            self.conn.execute(
                f"UPDATE transaction_journal SET {sets} WHERE continuity_tx_id=?",
                tuple(updates.values()) + (tx_id,))
            self._append_event(tx_id, cur, to_state, at)
        return dict(self._row(tx_id))

    # --- terminal convenience ------------------------------------------------- #
    def abort_prepared(self, tx_id: str, reason: str | None = None) -> dict[str, Any]:
        """PREPARED -> ABORTED_NOT_ATTEMPTED (terminal; abandoned, no attempt)."""
        return self._transition(
            tx_id, TransactionState.ABORTED_NOT_ATTEMPTED.value,
            fields={"last_error_class": "ABORTED_BEFORE_ATTEMPT",
                    "last_error_detail": _bounded(reason, MAX_ERROR_DETAIL) or "aborted before attempt"},
            require_from=TransactionState.PREPARED.value)

    def record_precondition_failure(self, tx_id: str, detail: str | None = None) -> dict[str, Any]:
        """PREPARED -> PRECONDITION_FAILED (terminal runtime outcome; no sync)."""
        return self._transition(
            tx_id, TransactionState.PRECONDITION_FAILED.value,
            fields={"runtime_outcome_class": "PRECONDITION_FAILED",
                    "precondition_status": "PRECONDITION_FAILED",
                    "continuity_sync_state": "NOT_ELIGIBLE",
                    "last_error_class": "PRECONDITION_HASH_MISMATCH",
                    "last_error_detail": _bounded(detail, MAX_ERROR_DETAIL) or "second H0 read differs"},
            require_from=TransactionState.PREPARED.value)

    def record_durability_capability_failure(self, tx_id: str, detail: str | None = None) -> dict[str, Any]:
        """PREPARED -> PRECONDITION_FAILED when required directory-fsync
        capability is unavailable.  No runtime attempt is consumed."""
        return self._transition(
            tx_id, TransactionState.PRECONDITION_FAILED.value,
            fields={"runtime_outcome_class": "PRECONDITION_FAILED",
                    "precondition_status": "PRECONDITION_FAILED",
                    "continuity_sync_state": "NOT_ELIGIBLE",
                    "durability_status": "DIR_FSYNC_UNSUPPORTED",
                    "manual_review_required": 1,
                    "last_error_class": "DIR_FSYNC_UNSUPPORTED",
                    "last_error_detail": _bounded(detail, MAX_ERROR_DETAIL)
                    or "required directory fsync capability unavailable"},
            require_from=TransactionState.PREPARED.value)

    def set_precondition_ok(self, tx_id: str) -> None:
        """Record a passing second H0 read on a PREPARED row (no state change)."""
        from .contracts import PreconditionStatus
        with self.conn:
            row = self._require(tx_id)
            if row["state"] != TransactionState.PREPARED.value:
                raise InvalidTransition("precondition OK only valid in PREPARED")
            self.conn.execute(
                "UPDATE transaction_journal SET precondition_status=?, updated_at=? "
                "WHERE continuity_tx_id=?",
                (PreconditionStatus.PRECONDITION_OK.value, _now(), tx_id))

    def fail_precondition(self, tx_id: str) -> dict[str, Any]:
        """Record PRECONDITION_FAILED (terminal) — returns the final row."""
        return self.record_precondition_failure(
            tx_id, detail="observed hash mismatch on second H0 read")

    # --- one-attempt invariant ------------------------------------------------ #
    def open_runtime_attempt(self, tx_id: str) -> dict[str, Any]:
        """Atomically flip attempt_count 0->1 and set RUNTIME_ATTEMPTING.

        Models protocol P9 (the guard).  A second attempt is always rejected.
        Phase 3A uses this only as the bookkeeping/invariant rule harness; it
        never invokes the vendor runtime.  Attempted outcome states below are
        reached by Phase 3B's classifier, not by Phase 3A product code.
        """
        row = self._require(tx_id)
        if int(row["attempt_count"] or 0) == 1:
            raise DuplicateAttempt(f"single runtime attempt already consumed: {tx_id}")
        entry = self._transition(
            tx_id, TransactionState.RUNTIME_ATTEMPTING.value,
            fields={"attempt_count": 1},
            require_from=TransactionState.PREPARED.value)
        # DB-level re-read confirms the invariant held atomically.
        if int(self._require(tx_id)["attempt_count"]) != 1:
            raise DuplicateAttempt("attempt_count !=1 after atomic flip")
        return entry

    def record_error(self, tx_id: str, error_class: str, detail: str | None) -> dict[str, Any]:
        """Record bounded last-error on the row (no lifecycle change)."""
        with self.conn:
            self._require(tx_id)
            self.conn.execute(
                "UPDATE transaction_journal SET last_error_class=?, last_error_detail=?, "
                "updated_at=? WHERE continuity_tx_id=?",
                (error_class, _bounded(detail, MAX_ERROR_DETAIL), _now(), tx_id))
        return dict(self._row(tx_id))

    # ------------------------------------------------------------------ #
    def mark_manual_review(self, tx_id: str, *, evidence_summary: dict[str, Any],
                           safe_actions: list[str]) -> dict[str, Any]:
        """Move the row to the frozen MANUAL_REVIEW sink with a no-CoT packet.

        Source must be a legal pre-manual state (e.g. OUTCOME_UNKNOWN or
        CONCURRENT_DIVERGENCE).  The packet records evidence summary and safe
        action codes only.
        """
        packet = {
            "evidence_summary": evidence_summary,
            "safe_action_codes": [str(x) for x in safe_actions],
            "unsafe_actions": [
                "invoke_runtime_same_tx", "infer_from_later_trust_or_turn",
                "write_H0_back", "force_sidecar_history",
                "claim_named_slot_pair_atomic", "suppress_ambiguity",
            ],
        }
        return self._transition(
            tx_id, TransactionState.MANUAL_REVIEW.value,
            fields={"manual_review_required": 1,
                    "manual_review_json": _json_bounded(packet),
                    "last_error_class": "MANUAL_REVIEW"})

    def record_outcome_unknown(self, tx_id: str, reason: str | None = None) -> dict[str, Any]:
        """RUNTIME_ATTEMPTING -> OUTCOME_UNKNOWN (evidence cannot conclude).

        Only Phase 3B's real classifier path reaches RUNTIME_ATTEMPTING in
        production; provided here so the transition rules are testable and so
        OUTCOME_UNKNOWN can be moved to MANUAL_REVIEW (both reads happen only
        when the child is stopped and evidence was fetched).  NEVER auto-retry.
        """
        return self._transition(
            tx_id, TransactionState.OUTCOME_UNKNOWN.value,
            fields={"runtime_outcome_class": "OUTCOME_UNKNOWN",
                    "last_error_detail": _bounded(reason, MAX_ERROR_DETAIL)},
            require_from=TransactionState.RUNTIME_ATTEMPTING.value)

    # --- Phase 3B outcome records (pure journal; never touch the runtime) ------- #
    def require_runtime_attempting(self, tx_id: str) -> dict[str, Any]:
        """Assert the tx is in RUNTIME_ATTEMPTING with attempt_count == 1.

        Enforced immediately before the vendor invocation so the one-attempt
        invariant is re-verified from the journal (the durable authority), and
        again immediately after."""
        row = self._require(tx_id)
        if row["state"] != TransactionState.RUNTIME_ATTEMPTING.value:
            raise InvalidTransition(
                f"expected RUNTIME_ATTEMPTING but tx is {row['state']!r}")
        if int(row["attempt_count"] or 0) != 1:
            raise DuplicateAttempt("attempt_count != 1 while in RUNTIME_ATTEMPTING")
        return dict(row)

    def mark_attempt_started_at(self, tx_id: str, at_time: str | None = None) -> dict[str, Any]:
        """Set runtime_attempt_started_at on an ATTEMPTING row (no state change)."""
        at = at_time or _now()
        with self.conn:
            self.require_runtime_attempting(tx_id)
            self.conn.execute(
                "UPDATE transaction_journal SET runtime_attempt_started_at=?, updated_at=? "
                "WHERE continuity_tx_id=?",
                (at, _now(), tx_id))
        return dict(self._row(tx_id))

    def record_runtime_outcome(self, tx_id: str, *, to_state: str,
                               outcome_class: str,
                               post_raw_sha256: str | None = None,
                               post_semantic_digest: str | None = None,
                               durability_status: str | None = None,
                               continuity_sync_state: str | None = None,
                               manual_review_required: bool | None = None,
                               last_error_class: str | None = None,
                               last_error_detail: str | None = None,
                               finished_at: str | None = None,
                               evidence_summary: dict[str, Any] | None = None,
                               ) -> dict[str, Any]:
        """Move an ATTEMPTING row to a runtime outcome state.

        `to_state` must be a legal transition (protocol §7).  The operation is
        atomic: the transition check + column update + state event commit in ONE
        SQLite transaction.  We store bounded post digests + a bounded no-CoT
        summary; we never store raw runtime bytes or the full current state.

        Called ONLY by Phase 3B's real classifier orchestration."""
        fields: dict[str, Any] = {
            "runtime_outcome_class": outcome_class,
        }
        if post_raw_sha256 is not None:
            fields["runtime_post_observed_sha256"] = post_raw_sha256
        if post_semantic_digest is not None:
            fields["runtime_post_semantic_digest"] = post_semantic_digest
        if durability_status is not None:
            fields["durability_status"] = durability_status
        if continuity_sync_state is not None:
            fields["continuity_sync_state"] = continuity_sync_state
        if manual_review_required is not None:
            fields["manual_review_required"] = 1 if manual_review_required else 0
        if last_error_class:
            fields["last_error_class"] = last_error_class
        if last_error_detail:
            fields["last_error_detail"] = _bounded(last_error_detail, MAX_ERROR_DETAIL)
        if evidence_summary is not None:
            fields["manual_review_json"] = _json_bounded(
                {"no_cot_evidence_summary": evidence_summary,
                 "unsafe_actions": [
                     "invoke_runtime_same_tx", "infer_from_later_trust_or_turn",
                     "write_H0_back", "force_sidecar_history",
                     "claim_named_slot_pair_atomic", "suppress_ambiguity",
                 ]})
        with self.conn:
            if finished_at is not None:
                fields["runtime_attempt_finished_at"] = finished_at
            return self._transition(
                tx_id, to_state, fields=fields,
                require_from=TransactionState.RUNTIME_ATTEMPTING.value,
                allow_same=(to_state == TransactionState.DURABILITY_PENDING.value
                            or to_state == TransactionState.CONTINUITY_SYNC_PENDING.value))

    def record_outcome_finished_only(self, tx_id: str, *, finished_at: str | None = None,
                                    writer_finished: bool = True) -> dict[str, Any]:
        """Record runtime_attempt_finished_at on an ATTEMPTING / any post state
        without changing lifecycle.  Used for honest post-invocation timestamps
        in windows where we want a durable timestamp even before classification."""
        at = finished_at or _now()
        with self.conn:
            self._require(tx_id)
            self.conn.execute(
                "UPDATE transaction_journal SET runtime_attempt_finished_at=?, updated_at=? "
                "WHERE continuity_tx_id=?",
                (at, _now(), tx_id))
        return dict(self._row(tx_id))

    def move_applied_to_durability_pending(self, tx_id: str, *,
                                           durability_status: str,
                                           durability_json: dict[str, Any] | None = None,
                                           continuity_sync_state: str = "PENDING",
                                           manual_review_required: bool = False) -> dict[str, Any]:
        """CONFIRMED_APPLIED -> DURABILITY_PENDING after the parent-directory
        fsync wrapper returns.  Keeps durability_status and a bounded no-CoT
        durability record.  Phase 3B stops here (it does NOT move to
        CONTINUITY_SYNC_PENDING / SYNCING / SYNCED)."""
        compact = durability_json or {}
        with self.conn:
            self.conn.execute(
                "UPDATE transaction_journal SET "
                "durability_status=?, continuity_sync_state=?, "
                "manual_review_required=?, updated_at=? "
                "WHERE continuity_tx_id=?",
                (durability_status, continuity_sync_state,
                 1 if manual_review_required else 0, _now(), tx_id))
            if compact:
                existing = json.loads(self._require(tx_id)["manual_review_json"] or "{}")
                existing["durability_metadata"] = compact
                self.conn.execute(
                    "UPDATE transaction_journal SET manual_review_json=? WHERE continuity_tx_id=?",
                    (_json_bounded(existing), tx_id))
            return self._transition(
                tx_id, TransactionState.DURABILITY_PENDING.value,
                fields={}, require_from=TransactionState.CONFIRMED_APPLIED.value)

    def record_durability_update(self, tx_id: str, *, durability_status: str,
                                 durability_json: dict[str, Any] | None = None) -> dict[str, Any]:
        """Record durability metadata (no lifecycle change).

        `durability_json` is the structured {attempted, supported, succeeded,
        status, error_class} result; size-bounded, never CoT."""
        compact = durability_json or {}
        with self.conn:
            self._require(tx_id)
            self.conn.execute(
                "UPDATE transaction_journal SET durability_status=?, updated_at=? "
                "WHERE continuity_tx_id=?",
                (durability_status, _now(), tx_id))
            if compact:
                existing = {}
                try:
                    import json as _json
                    existing = _json.loads(self._require(tx_id)["manual_review_json"] or "{}")
                except Exception:
                    existing = {}
                existing["durability_metadata"] = compact
                self.conn.execute(
                    "UPDATE transaction_journal SET manual_review_json=? WHERE continuity_tx_id=?",
                    (_json_bounded(existing), tx_id))
        return dict(self._row(tx_id))

    def recovery_required(self, tx_id: str, kind: str = "auto") -> dict[str, Any]:
        """Move a pre/post-confirmed row to RECOVERY_REQUIRED (observational)."""
        legal_src = {
            TransactionState.DURABILITY_PENDING.value,
            TransactionState.CONTINUITY_SYNC_PENDING.value,
            TransactionState.CONTINUITY_SYNCING.value,
        }
        cur = self.state_of(tx_id)
        if cur not in legal_src:
            raise InvalidTransition(
                f"recovevery_required not allowed from {cur!r}")
        return self._transition(tx_id, TransactionState.RECOVERY_REQUIRED.value,
                                fields={"last_error_class": "RECOVERY_REQUIRED"})

    def finalize(self, tx_id: str) -> dict[str, Any]:
        """CONTINUITY_SYNCED -> COMPLETED (writes the final saga marker)."""
        return self._transition(
            tx_id, TransactionState.COMPLETED.value,
            fields={"continuity_sync_state": "SYNCED", "committed_at": _now()},
            require_from=TransactionState.CONTINUITY_SYNCED.value)
