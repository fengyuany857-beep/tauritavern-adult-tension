"""Runtime identity and observation for Phase 3A.

Honest, stable, read-only understanding of the vendor runtime *before* any
command is prepared.  V1 supports ONE allowlisted canonical current-state file
(single-writer protocol).  Named-slot state/manifest mutation and alternate
--out identity are rejected.

Rules carried out in this file:
- reject symlink / non-regular file / path substitution / ambiguous identity;
- read exact bytes once -> raw SHA-256 (H0/H1 evidence only, never "revision"),
- parse the full mapping, run the vendor full validator,
- compute canonical semantic digest (S0) and capture bounded structural
  evidence (turn / clock / scene / changed IDs) WITHOUT copying the complete
  runtime state or the full adult-permission payload,
- re-read byte-identical verify (same method as Phase 1 read-only adapter:
  a change mid-read is refused).

We deliberately REUSE the Phase 1 / existing read-only vendor loader rather
than constructing a second `parse` implementation, and we perform NO writes,
NO temp runtime file, NO commit_turn call, NO os.replace.
"""
from __future__ import annotations
import dataclasses
import enum
import importlib.util
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..errors import RuntimeReadOnlyError  # reused Phase-1 read-only error semantics
from .digests import canonical_semantic_digest, raw_sha256_bytes
from .errors import (
    TxError,
    RuntimeNoRegularFile, RuntimeNotFound, RuntimeParseError,
    RuntimeSymlinkRejected, RuntimeUnreadable, UnsupportedRuntimeIdentity,
)

# V1 single-current-file mode marker used in runtime identities.
CURRENT_FILE_MODE = "current_state_single_file"
# Canonical current-state file name expected under the vendor saves directory
# (the canonical allowlisted single runtime file in V1).
ALLOWLIST_REL = ("saves", "current_state.yaml")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class ObservationStatus(str, enum.Enum):
    OK = "OK"
    RUNTIME_NOT_FOUND = "RUNTIME_NOT_FOUND"
    RUNTIME_UNREADABLE = "RUNTIME_UNREADABLE"
    RUNTIME_PARSE_ERROR = "RUNTIME_PARSE_ERROR"
    RUNTIME_VALIDATION_ERROR = "RUNTIME_VALIDATION_ERROR"
    CHANGED_DURING_READ = "CHANGED_DURING_READ"


@dataclass(frozen=True)
class RuntimeIdentity:
    """Stable-but-honest identity of the single canonical current runtime file.

    inode is diagnostic only: os.replace changes it, so it is never used as an
    authority or equality key.
    """
    campaign_id: str
    path: str
    mode: str = CURRENT_FILE_MODE

    # Diagnostic-only fields (never authoritative).
    inode: int | None = dataclasses.field(default=None, metadata={"diagnostic": True})
    dot_exists: bool | None = None  # diagnostic

    def to_dict(self) -> dict[str, Any]:
        return {
            "campaign_id": self.campaign_id,
            "path": self.path,
            "mode": self.mode,
            "inode": self.inode,
        }


@dataclass(frozen=True)
class RuntimeObservation:
    """One full honest read of the runtime current file.

    raw_sha256 is defined as: "SHA-256 fingerprint of exact runtime bytes
    observed at a specific path and time".  It is observational evidence only —
    never a runtime revision / CAS / writer identity.
    """
    observed_at: str
    identity: RuntimeIdentity
    raw_sha256: str
    semantic_digest: str
    parse_status: ObservationStatus
    validation_status: ObservationStatus
    validation_errors: tuple[str, ...] = ()
    # Bounded selected structural evidence, non-sensitive (no adult payload).
    turn: int | None = None
    clock: str | None = None
    scene_id: str | None = None
    file_size: int | None = None           # optional
    mtime: float | None = None             # optional, diagnostic only

    def to_evidence_dict(self) -> dict[str, Any]:
        """Bounded journal-able evidence: hashes, digests and structural refs."""
        return {
            "observed_at": self.observed_at,
            "runtime_identity": self.identity.to_dict(),
            "raw_sha256": self.raw_sha256,
            "semantic_digest": self.semantic_digest,
            "parse": self.parse_status.value,
            "validation": self.validation_status.value,
            "turn": self.turn,
            "clock": self.clock,
            "scene_id": self.scene_id,
            "file_size": self.file_size,
            "mtime": self.mtime,
        }


def _resolve_canonical_path(vendor_dir: Path, runtime_path: Path) -> Path:
    """Return the canonical allowlisted current-state path.

    V1 supports a single regular-file current runtime state located under the
    pinned vendor `saves/current_state.yaml`.  A caller may pass that path (resolved
    within the vendor) or an equivalent identical canonical path.  Any other
    different path, or a named-slot trajectory, is rejected as unsupported.
    """
    if runtime_path is None:
        raise UnsupportedRuntimeIdentity("no runtime path supplied")
    try:
        vendor_dir = vendor_dir.resolve()
        runtime_path = Path(runtime_path).expanduser().resolve()
    except OSError as exc:
        raise RuntimeUnreadable(f"cannot resolve path: {exc}") from exc
    canonical = vendor_dir.joinpath(*ALLOWLIST_REL)
    if runtime_path != canonical:
        raise UnsupportedRuntimeIdentity(
            f"runtime path is not the canonical V1 current state ({runtime_path} != {canonical})")
    return canonical


def probe_runtime_path(vendor_dir: Path | str, runtime_path: Path | str) -> tuple[Path, RuntimeIdentity, Any | None]:
    """Path/identity capability preamble (pure check, no writes).

    Returns (canonical_path, identity, None).  Raises TxError fail-closed for
    symlink, non-regular file, irreusable path, or a different path.
    """
    vendor_dir = Path(vendor_dir)
    canonical = _resolve_canonical_path(vendor_dir, Path(runtime_path))
    st = None
    try:
        st = canonical.stat()
    except FileNotFoundError as exc:
        raise RuntimeNotFound(f"runtime state not found: {canonical}") from exc
    except OSError as exc:
        raise RuntimeUnreadable(f"cannot stat runtime state: {exc}") from exc
    if canonical.is_symlink():
        raise RuntimeSymlinkRejected(str(canonical))
    if not canonical.is_file():
        raise RuntimeNoRegularFile(str(canonical))
    inode = st.st_ino
    identity = RuntimeIdentity(
        campaign_id="v1-current", path=str(canonical),
        mode=CURRENT_FILE_MODE, inode=inode,
    )
    return canonical, identity, None


def load_canonical_yaml(text: str) -> dict[str, Any]:
    """Parse canonical YAML text with the pinned PyYAML safe loader (read-only)."""
    try:
        import yaml
    except ImportError as exc:  # pragma: no cover
        raise RuntimeUnreadable("PyYAML unavailable") from exc
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise RuntimeParseError(f"cannot parse runtime state: {exc}") from exc
    if not isinstance(data, dict):
        raise RuntimeParseError("runtime state is not a mapping")
    return data


def read_observation(vendor_dir: Path | str, runtime_path: Path | str,
                     validate_full: bool = True) -> tuple[RuntimeObservation, dict[str, Any]]:
    """Honest full read (Phase 3A).

    - resolves canonical path & checks identity (no regular/symlink),
    - reads exact bytes once,
    - parses full mapping,
    - validates full mapping,
    - computes raw + semantic digests,
    - re-reads to confirm bytes unchanged during read (mirror of Phase 1).

    Returns (observation, parsed_state).  Does NOT write / temp / commit.
    """
    canonical, identity, _ = probe_runtime_path(vendor_dir, runtime_path)
    read_before = _now_iso()
    try:
        raw = canonical.read_bytes()
    except OSError as exc:
        raise RuntimeUnreadable(f"cannot read runtime state: {exc}") from exc
    text = raw.decode("utf-8", errors="strict")
    raw_sha = raw_sha256_bytes(raw)
    obs_time = _now_iso()

    # Parse (bounded, no side effects)
    try:
        parsed = load_canonical_yaml(text)
    except TxError:
        raise

    # Full validator (vendor's validate_state.validate_data(profile='save'))
    val_errors: tuple[str, ...] = ()
    val_status = ObservationStatus.OK
    if validate_full:
        validator = _load_vendor_validator(Path(vendor_dir))
        try:
            result = validator.validate_data(parsed, "save")
        except Exception as exc:  # validator may raise on non-state shapes
            val_status = ObservationStatus.RUNTIME_VALIDATION_ERROR
            val_errors = (f"exception during validate: {exc:.120}",)
            result = []
        if result:
            val_errors = tuple(str(e) for e in result[:5])
            val_status = ObservationStatus.RUNTIME_VALIDATION_ERROR

    # bounded structural evidence (no adult payload)
    meta = parsed.get("meta") or {}
    world = parsed.get("world") or {}
    node = parsed.get("current_node") or {}
    turn = meta.get("turn")
    clock = world.get("clock")
    scene = node.get("scene_id") or (node.get("location") if isinstance(node.get("location"), str) else None)
    turn_v = turn if isinstance(turn, int) else None
    clock_v = clock if isinstance(clock, str) else None
    scene_v = scene if isinstance(scene, str) else None

    semantic = canonical_semantic_digest(parsed)

    # Second read to ensure we did not observe a torn file (Phase 1 behaviour).
    try:
        reread = canonical.read_bytes()
    except OSError as exc:
        raise RuntimeUnreadable(f"runtime state disappeared during read: {exc}") from exc
    if reread != raw:
        raise RuntimeUnreadable("runtime state changed during read; refusing observation")

    try:
        st = canonical.stat()
        fsize = st.st_size
        fmtime = st.st_mtime
    except OSError:  # diagnostic only
        fsize = None
        fmtime = None

    parse_status = ObservationStatus.OK if text else ObservationStatus.RUNTIME_PARSE_ERROR
    identity = RuntimeIdentity(campaign_id="v1-current", path=str(canonical),
                               mode=CURRENT_FILE_MODE, inode=identity.inode)
    obs = RuntimeObservation(
        observed_at=obs_time, identity=identity, raw_sha256=raw_sha,
        semantic_digest=semantic, parse_status=parse_status,
        validation_status=val_status, validation_errors=val_errors,
        turn=turn_v, clock=clock_v, scene_id=scene_v,
        file_size=fsize, mtime=fmtime,
    )
    return obs, parsed


def _load_vendor_module(vendor_dir: Path, name: str) -> Any:
    """Load a pinned vendor script module by path (read-only)."""
    path = vendor_dir / "scripts" / f"{name}.py"
    try:
        spec = importlib.util.spec_from_file_location(f"phase3_vendor_{name}", path)
        if spec is None or spec.loader is None:
            raise RuntimeReadOnlyError(f"cannot load {name}")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except OSError as exc:
        raise RuntimeUnreadable(f"cannot load vendor module {name}: {exc}") from exc


def _load_vendor_validator(vendor_dir: Path) -> Any:
    commit = _load_vendor_module(vendor_dir, "validate_state")
    return commit


def _load_vendor_commit(vendor_dir: Path) -> Any:
    return _load_vendor_module(vendor_dir, "commit_turn")
