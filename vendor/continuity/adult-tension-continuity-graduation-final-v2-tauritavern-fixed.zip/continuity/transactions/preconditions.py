"""Phase 3A read-only precondition & prepare engine.

Implements the protocol's *prepare* (P1-P7) and the *pre-write precondition
recheck* (P8) without EVER performing a runtime mutation / commit_turn /
temp runtime write / os.replace.

The integration:
- accepts only an upstream-authorised concrete runtime *patch mapping*.  It
  never generates an NPC-belief/outcome from prose or a desired state.
- never copies the full adult-permission payload anywhere: the journal keeps
  only hashes / digests / refs and bounded non-sensitive structural evidence.
- persists a durable PREPARED saga row (attempt_count=0) + expected evidence in
  a single committed SQLite transaction (P7).  If it cannot commit, no runtime
  call is possible.
- verify_prewrite_precondition re-reads the same runtime identity; a mismatch is
  recorded as PRECONDITION_FAILED (P8) — never auto-rebase, never write,
  never call commit_turn, never re-plan under the old tx (observed hash
  mismatch, NOT a "revision conflict").
"""
from __future__ import annotations
import hashlib
import importlib.util
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .contracts import (
    CANONICALISATION_VERSION, PreconditionStatus,
)
from .errors import (
    AdultAuthorityViolation, CandidateValidationError, InvalidArgument,
    PatchRequired, PlayerSovereigntyViolation, SpecConflict,
    UnsupportedNamedSlot,
)
from .digests import canonical_semantic_digest
from .journal import JournalDao
from . import runtime_observation as ro


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_tx_id() -> str:
    return "tx-" + uuid.uuid4().hex[:32]


# --------------------------------------------------------------------------- #
# Input contract guards (pure, read-only).
# --------------------------------------------------------------------------- #
def require_concrete_patch(patch: Any) -> dict[str, Any]:
    """A patch must be a concrete runtime delta mapping (protocol §3, task §21).

    Desired-outcome prose ("make the NPC believe me") is NOT a patch and is
    never converted into an NPC-belief patch by this layer.
    """
    if not isinstance(patch, dict):
        raise InvalidArgument("patch must be a JSON mapping (concrete runtime delta)")
    if not patch:
        raise PatchRequired(
            "concrete patch mapping required (e.g. {'npc_updates': {...}}); "
            "natural-language desired outcome is not a patch")
    return patch


def guard_player_sovereignty(patch: dict[str, Any]) -> None:
    """Reject keys that try to force an NPC belief/result from a player attempt."""
    banned = {
        "desired_outcome", "then_believes", "make_npc_believe", "force_npc_result",
        "infer_belief", "result_prose", "consequence_from_player_wish",
    }
    got = sorted(k for k in patch if k in banned)
    if got:
        raise PlayerSovereigntyViolation(
            "player-desired-outcome keys cannot be a concrete upstream patch: " + ",".join(got))


CURRENT_ADULT_PERMISSION_KEYS = frozenset({
    "continuity_consent", "continuity_grant", "continuity_boundary",
    "inferred_current_consent", "set_current_consent",
})


def guard_adult_authority_inference(patch: dict[str, Any]) -> None:
    """Continuity must never turn trust/attraction/history into current adult
    permission.  We only submit an already-decided upstream patch verbatim to
    the vendor validator; we never add/infer such fields here."""
    inferred = sorted(k for k in patch if k in CURRENT_ADULT_PERMISSION_KEYS)
    if inferred:
        raise AdultAuthorityViolation(
            "continuity cannot write/infer current adult permission: " + ",".join(inferred))


# --------------------------------------------------------------------------- #
# Candidate / digest helpers (in-memory only, no runtime writes).
# --------------------------------------------------------------------------- #
def _fingerprint(vendor_dir: Path, script: str) -> str:
    try:
        data = (vendor_dir / "scripts" / script).read_bytes()
    except OSError:
        return "unavailable"
    return hashlib.sha256(data).hexdigest()


def _serializer_bytes(vendor_dir: Path, candidate: dict[str, Any]) -> bytes:
    """Deterministic in-memory serialization of a candidate using the pinned
    vendor writer serializer.  NEVER writes to disk (used only to compute the
    capability-gated expected-bytes hash HE)."""
    common_path = vendor_dir / "scripts" / "_common.py"
    spec = importlib.util.spec_from_file_location("phase3a_vendor_common", common_path)
    if spec is None or spec.loader is None:
        raise SpecConflict("cannot load vendor _common serializer")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.yaml_text(candidate).encode("utf-8")


def generate_expected_candidate(vendor_dir: Path, parsed_state: dict[str, Any],
                                patch: dict[str, Any]) -> tuple[dict[str, Any], str | None]:
    """Pure in-memory vendor candidate generation (protocol P5/P6).

    Reuses the vendor `commit_turn.commit(state, patch)` — a pure deep-copy +
    fixed-order transform + full validator — with NO file side effects.

    Returns (expected_candidate_mapping, expected_sha256_OR_None).  The byte
    hash HE is only produced behind the deterministic-serializer capability
    probe; semantic full-state equality is primary.
    """
    commit = _get_vendor_commit(Path(vendor_dir))
    try:
        candidate = commit(parsed_state, patch)
    except Exception as exc:
        name = getattr(exc, "__class__", Exception).__name__
        raise CandidateValidationError(
            f"vendor pure commit rejected the patch: {name}: {exc}") from exc
    if not isinstance(candidate, dict):
        raise CandidateValidationError("vendor commit returned no mapping")
    expected_sha = None
    try:
        expected_sha = hashlib.sha256(
            _serializer_bytes(Path(vendor_dir), candidate)).hexdigest()
    except Exception:
        expected_sha = None  # capability unavailable -> no HE claim
    return candidate, expected_sha


_COMMIT_CACHE: dict[str, Any] = {}


def _get_vendor_commit(vendor_dir: Path):
    key = str(Path(vendor_dir).resolve())
    if key in _COMMIT_CACHE:
        return _COMMIT_CACHE[key]
    path = Path(vendor_dir) / "scripts" / "commit_turn.py"
    spec = importlib.util.spec_from_file_location("phase3a_vendor_commit", path)
    if spec is None or spec.loader is None:
        raise SpecConflict("cannot load vendor commit_turn module")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    _COMMIT_CACHE[key] = mod.commit
    return mod.commit


# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class PreparedEvidence:
    continuity_tx_id: str
    protocol_version: str
    state: str
    runtime_identity: str
    runtime_path_ref: str
    runtime_pre_sha256: str
    runtime_pre_semantic_digest: str
    expected_candidate_digest: str
    expected_semantic_digest: str
    expected_sha256_available: bool
    expected_sha256: str | None
    patch_digest: str
    canonicalisation_version: str
    adapter_fingerprint: str
    serializer_fingerprint: str
    branch_id: str
    operation: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "continuity_tx_id": self.continuity_tx_id,
            "protocol_version": self.protocol_version,
            "state": self.state,
            "runtime_identity": self.runtime_identity,
            "runtime_path_ref": self.runtime_path_ref,
            "runtime_pre_sha256": self.runtime_pre_sha256,
            "runtime_pre_semantic_digest": self.runtime_pre_semantic_digest,
            "expected_candidate_digest": self.expected_candidate_digest,
            "expected_semantic_digest": self.expected_semantic_digest,
            "expected_sha256_available": self.expected_sha256_available,
            "expected_sha256": self.expected_sha256,
            "patch_digest": self.patch_digest,
            "canonicalisation_version": self.canonicalisation_version,
            "adapter_fingerprint": self.adapter_fingerprint,
            "serializer_fingerprint": self.serializer_fingerprint,
            "branch_id": self.branch_id,
            "operation": self.operation,
            "runtime_attempted": False,
            "runtime_outcome": "RUNTIME_NOT_ATTEMPTED",
            "manual_review_required": False,
            "retry_allowed": True,
            "retry_requires_new_tx": True,
        }


# --------------------------------------------------------------------------- #
def _dao(db_path: Path) -> JournalDao:
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    from ..migrations import migrate
    migrate(conn)
    return JournalDao(conn)


def prepare_transaction(
    *,
    vendor_dir: Path | str,
    db_path: Path | str,
    runtime_path: Path | str,
    patch: dict[str, Any],
    operation: str = "prepare_turn",
    branch_id: str = "default",
    protocol_version: str = "phase3-safe-saga-v1",
    request_provenance: dict[str, Any] | None = None,
    staged_sync_digest: str | None = None,
    reject_named_slot: bool = False,
    tx_id: str | None = None,
) -> PreparedEvidence:
    """Read-only preparation of a safe continuity transaction (P1-P7).

    NEVER mutates the runtime.  On any parse/validate/candidate/DB failure no
    durable PREPARED row is left behind.
    """
    if reject_named_slot:
        raise UnsupportedNamedSlot(
            "named-slot mutation is BLOCKED in V1 (the state/manifest pair is not "
            "atomically replaceable)")

    patch = require_concrete_patch(patch)
    guard_player_sovereignty(patch)
    guard_adult_authority_inference(patch)

    vendor_dir = Path(vendor_dir)
    db_path = Path(db_path)

    # P3 read (raw H0/pre, parse, full validate, semantic S0) — read-only
    obs, parsed = ro.read_observation(vendor_dir, runtime_path)
    if obs.validation_status.value != "OK":
        from .errors import RuntimeValidationError
        raise RuntimeValidationError(
            "runtime validation failed: " + "; ".join(obs.validation_errors))

    # P4 continuity branch sanity (deep sync-filter gate is Phase 3C).
    if not isinstance(branch_id, str) or not branch_id:
        raise InvalidArgument("branch_id must be a non-empty string")

    # P5/P6 candidate + digests (in memory only)
    candidate, expected_sha = generate_expected_candidate(vendor_dir, parsed, patch)
    from .digests import patch_digest as _patch_digest
    pd = _patch_digest(patch)
    se = canonical_semantic_digest(candidate)

    upstream_prov = request_provenance if isinstance(request_provenance, dict) else {}
    source_prov = {
        "runtime_identity": obs.identity.to_dict(),
        "runtime_path_ref": str(obs.identity.path),
        "branch": branch_id,
        "raw_pre_sha256": obs.raw_sha256,
        "pre_semantic_digest": obs.semantic_digest,
        "mode": obs.identity.mode,
    }

    tx = tx_id or new_tx_id()
    dao = _dao(db_path)
    try:
        row = dao.create_prepared(
            tx_id=tx, operation=operation, branch_id=branch_id,
            protocol_version=protocol_version,
            runtime_identity=obs.identity.to_dict()["campaign_id"],
            runtime_path_ref=str(obs.identity.path),
            runtime_pre_sha256=obs.raw_sha256,
            runtime_pre_semantic_digest=obs.semantic_digest,
            expected_candidate_digest=se,
            runtime_expected_semantic_digest=se,
            runtime_expected_sha256=expected_sha,
            patch_digest=pd,
            canonicalisation_version=CANONICALISATION_VERSION,
            adapter_fingerprint=_fingerprint(vendor_dir, "commit_turn.py"),
            serializer_fingerprint=_fingerprint(vendor_dir, "_common.py"),
            request_provenance=_bounded_mapping(upstream_prov),
            source_provenance=source_prov,
            staged_sync_digest=staged_sync_digest,
        )
    finally:
        dao.conn.close()

    return PreparedEvidence(
        continuity_tx_id=tx, protocol_version=protocol_version,
        state=row["state"], runtime_identity=source_prov["runtime_identity"]["campaign_id"]
        if isinstance(source_prov["runtime_identity"], dict) else str(source_prov["runtime_identity"]),
        runtime_path_ref=str(obs.identity.path),
        runtime_pre_sha256=obs.raw_sha256,
        runtime_pre_semantic_digest=obs.semantic_digest,
        expected_candidate_digest=se, expected_semantic_digest=se,
        expected_sha256_available=expected_sha is not None, expected_sha256=expected_sha,
        patch_digest=pd, canonicalisation_version=CANONICALISATION_VERSION,
        adapter_fingerprint=_fingerprint(vendor_dir, "commit_turn.py"),
        serializer_fingerprint=_fingerprint(vendor_dir, "_common.py"),
        branch_id=branch_id, operation=operation,
    )


def _bounded_mapping(obj: dict[str, Any]) -> dict[str, Any]:
    return dict(obj)


def verify_prewrite_precondition(db_path: Path | str, vendor_dir: Path | str,
                                 runtime_path: Path | str,
                                 tx_id: str) -> dict[str, Any]:
    """P8 second H0 observation before any invocation would be allowed.

    current raw H == prepared pre H0    -> set PRECONDITION_OK (stay PREPARED)
    current raw H != prepared pre H0    -> PRECONDITION_FAILED (terminal)

    Never auto-rebases the patch, never makes a new candidate, never writes the
    runtime, never calls commit_turn.  This is an *observed hash mismatch*, not
    a revision conflict and not a retry under the same tx.
    """
    db_path = Path(db_path)
    vendor_dir = Path(vendor_dir)
    dao = _dao(db_path)
    try:
        row = dao.get(tx_id)
        if row is None:
            raise ValueError(f"unknown tx {tx_id}")
        if row["state"] != "PREPARED":
            return {"tx_id": tx_id, "state": row["state"],
                    "precondition_status": "SKIPPED",
                    "reason": "tx is not in PREPARED"}
        obs, _parsed = ro.read_observation(vendor_dir, runtime_path)
        cur = obs.raw_sha256
        stored = row["runtime_pre_sha256"]
        if cur == stored:
            dao.set_precondition_ok(tx_id)
            return {"tx_id": tx_id, "state": row["state"],
                    "precondition_status": "PRECONDITION_OK",
                    "observed_raw_sha256": cur,
                    "prepared_raw_sha256": stored}
        return dao.fail_precondition(tx_id)
    finally:
        dao.conn.close()
