"""Phase 3A transaction contracts.

Sidecar continuity orchestration contracts (Phase 3A scope).  These model a
continuity-owned, forward-only safe saga around the vendor current runtime
state file.  Nothing here writes the runtime, nothing calls commit_turn, and
nothing claims a runtime revision / atomic cross-store commit.

The `continuity_tx_id` is a *sidecar orchestration id*.  The vendor runtime has
NO transaction id, idempotency key, outcome query, nominal current-state lock,
revision, restart semantics or CAS.  `runtime_pre_sha256` is a SHA-256 of exact
observed bytes at a named path/time — observational evidence only, never a
runtime revision / sequence / CAS token / writer identity.
"""
from __future__ import annotations
import enum


# --------------------------------------------------------------------------- #
# Stable opaque sidecar orchestration identifier type.
#   A continuity_tx_id identifies exactly one sidecar orchestration attempt
#   and is UNIQUE in SQLite.  It is NOT a runtime transaction id.
TransactTxId = str


# --------------------------------------------------------------------------- #
class TransactionState(str, enum.Enum):
    """Lifecycle state of one continuity saga (matches Phase 3 V1 protocol §7).

    The runtime-outcome dimension and the continuity-sync dimension are kept
    as distinct phases of an explicit sequence; there is no generic SUCCESS.
    Phase 3A models all states but never performs an actual runtime mutation.
    """
    PREPARED = "PREPARED"                        # durable intent recorded, attempt_count 0
    RUNTIME_ATTEMPTING = "RUNTIME_ATTEMPTING"    # the single allowed runtime invocation slot (attempt_count already 1)
    CONFIRMED_APPLIED = "CONFIRMED_APPLIED"      # strong evidence: expected candidate applied
    CONFIRMED_NOT_APPLIED = "CONFIRMED_NOT_APPLIED"  # strong evidence runtime did not apply
    OUTCOME_UNKNOWN = "OUTCOME_UNKNOWN"          # cannot prove applied/not-applied => fail closed
    CONCURRENT_DIVERGENCE = "CONCURRENT_DIVERGENCE"  # valid state is neither pre nor expected
    DURABILITY_PENDING = "DURABILITY_PENDING"    # applied but parent-directory fsync not yet evidenced
    CONTINUITY_SYNC_PENDING = "CONTINUITY_SYNC_PENDING"  # applied, waiting to sync continuity
    CONTINUITY_SYNCING = "CONTINUITY_SYNCING"     # SQLite authority+markers+outbox in progress
    CONTINUITY_SYNCED = "CONTINUITY_SYNCED"       # authority synced; awaits final saga marker
    RECOVERY_REQUIRED = "RECOVERY_REQUIRED"       # needs observational/forward recovery attention
    MANUAL_REVIEW = "MANUAL_REVIEW"               # automation cannot conclude
    ABORTED_NOT_ATTEMPTED = "ABORTED_NOT_ATTEMPTED"  # abandoned before any runtime invocation
    PRECONDITION_FAILED = "PRECONDITION_FAILED"   # second H0 mismatch before invocation
    COMPLETED = "COMPLETED"                       # terminal: final marker written


# Transitions allowed by the protocol (§7).  Mapping state -> set of next states.
_TRANSITIONS: dict[str, frozenset[str]] = {
    TransactionState.PREPARED: frozenset({
        TransactionState.RUNTIME_ATTEMPTING,
        TransactionState.ABORTED_NOT_ATTEMPTED,
        TransactionState.PRECONDITION_FAILED,
    }),
    TransactionState.RUNTIME_ATTEMPTING: frozenset({
        TransactionState.CONFIRMED_APPLIED,
        TransactionState.CONFIRMED_NOT_APPLIED,
        TransactionState.OUTCOME_UNKNOWN,
        TransactionState.CONCURRENT_DIVERGENCE,
        TransactionState.RECOVERY_REQUIRED,
        TransactionState.MANUAL_REVIEW,
    }),
    TransactionState.CONFIRMED_APPLIED: frozenset({
        TransactionState.DURABILITY_PENDING,
        TransactionState.CONTINUITY_SYNC_PENDING,
    }),
    TransactionState.DURABILITY_PENDING: frozenset({
        TransactionState.CONTINUITY_SYNC_PENDING,
        TransactionState.RECOVERY_REQUIRED,
        TransactionState.MANUAL_REVIEW,
    }),
    TransactionState.CONTINUITY_SYNC_PENDING: frozenset({
        TransactionState.CONTINUITY_SYNCING,
        TransactionState.RECOVERY_REQUIRED,
    }),
    TransactionState.CONTINUITY_SYNCING: frozenset({
        TransactionState.CONTINUITY_SYNCED,
        TransactionState.CONTINUITY_SYNC_PENDING,   # sqlite rollback => safe replay
        TransactionState.RECOVERY_REQUIRED,
    }),
    TransactionState.CONTINUITY_SYNCED: frozenset({
        TransactionState.COMPLETED,
    }),
    # Unknown / divergence may only go to MANUAL_REVIEW or to a *newly strong
    # evidence* confirmed result.  They never re-enter RUNTIME_ATTEMPTING.
    TransactionState.OUTCOME_UNKNOWN: frozenset({
        TransactionState.MANUAL_REVIEW,
        TransactionState.CONFIRMED_APPLIED,
        TransactionState.CONFIRMED_NOT_APPLIED,
        TransactionState.RECOVERY_REQUIRED,
    }),
    TransactionState.CONCURRENT_DIVERGENCE: frozenset({
        TransactionState.MANUAL_REVIEW,
        TransactionState.CONFIRMED_APPLIED,
        TransactionState.CONFIRMED_NOT_APPLIED,
    }),
    TransactionState.RECOVERY_REQUIRED: frozenset({
        TransactionState.CONTINUITY_SYNC_PENDING,
        TransactionState.CONTINUITY_SYNCED,
        TransactionState.COMPLETED,
        TransactionState.MANUAL_REVIEW,
        TransactionState.CONFIRMED_APPLIED,
        TransactionState.CONFIRMED_NOT_APPLIED,
        TransactionState.ABORTED_NOT_ATTEMPTED,
    }),
    TransactionState.MANUAL_REVIEW: frozenset({
        # terminal for automation; only an external strong-evidence adjudication
        # may move it, represented via a fresh-plan (new tx) contract.
    }),
    # Terminal states for this tx:
    TransactionState.PRECONDITION_FAILED: frozenset(),
    TransactionState.CONFIRMED_NOT_APPLIED: frozenset(),
    TransactionState.ABORTED_NOT_ATTEMPTED: frozenset(),
    TransactionState.COMPLETED: frozenset(),
}

# States that are terminal for the current continuity_tx_id.
_TERMINAL: frozenset[str] = frozenset({
    TransactionState.PRECONDITION_FAILED,
    TransactionState.CONFIRMED_NOT_APPLIED,
    TransactionState.ABORTED_NOT_ATTEMPTED,
    TransactionState.COMPLETED,
    TransactionState.MANUAL_REVIEW,
})

# Runtime-mutation states are never entered in Phase 3A (modelling only).
PHASE3A_NO_RUNTIME_STATES: frozenset[str] = frozenset({
    TransactionState.RUNTIME_ATTEMPTING,
    TransactionState.CONFIRMED_APPLIED,
    TransactionState.CONFIRMED_NOT_APPLIED,
    TransactionState.OUTCOME_UNKNOWN,
    TransactionState.CONCURRENT_DIVERGENCE,
    TransactionState.DURABILITY_PENDING,
    TransactionState.CONTINUITY_SYNC_PENDING,
    TransactionState.CONTINUITY_SYNCING,
    TransactionState.CONTINUITY_SYNCED,
    TransactionState.RECOVERY_REQUIRED,
    TransactionState.COMPLETED,
})


def allowed_next(state: "TransactionState") -> frozenset[str]:
    return _TRANSITIONS.get(state.value if isinstance(state, TransactionState) else state, frozenset())


def can_transition(current: "TransactionState", target: str) -> bool:
    key = current.value if isinstance(current, TransactionState) else str(current)
    return target in allowed_next(key)


def is_terminal(state: "TransactionState") -> bool:
    key = state.value if isinstance(state, TransactionState) else str(state)
    return key in _TERMINAL


def is_nonterminal(state: "TransactionState") -> bool:
    return not is_terminal(state)


# --------------------------------------------------------------------------- #
class RuntimeOutcomeClass(str, enum.Enum):
    """The runtime outcome dimension (never a generic SUCCESS)."""
    PRECONDITION_FAILED = "PRECONDITION_FAILED"
    CONFIRMED_APPLIED = "CONFIRMED_APPLIED"
    CONFIRMED_NOT_APPLIED = "CONFIRMED_NOT_APPLIED"
    OUTCOME_UNKNOWN = "OUTCOME_UNKNOWN"
    CONCURRENT_DIVERGENCE = "CONCURRENT_DIVERGENCE"
    RUNTIME_NOT_ATTEMPTED = "RUNTIME_NOT_ATTEMPTED"  # Phase 3A baseline: no attempt made


class ContinuitySyncState(str, enum.Enum):
    """The continuity sync dimension (never a generic SUCCESS)."""
    SYNC_PENDING = "SYNC_PENDING"
    SYNCING = "SYNCING"
    SYNCED = "SYNCED"
    NOT_ELIGIBLE = "NOT_ELIGIBLE"   # no applied run without durable evidence to sync
    NOT_REQUIRED = "NOT_REQUIRED"


class PreconditionStatus(str, enum.Enum):
    """Result of the second pre-write observation (the H0 recheck)."""
    NOT_YET_CHECKED = "NOT_YET_CHECKED"
    PRECONDITION_OK = "PRECONDITION_OK"
    PRECONDITION_FAILED = "PRECONDITION_FAILED"


class RecoveryDisposition(str, enum.Enum):
    """What an observational/forward recovery scanner may do with a row."""
    NO_RUNTIME_INVOCATION = "NO_RUNTIME_INVOCATION"
    FORWARD_SYNC_REPLAY = "FORWARD_SYNC_REPLAY"
    FINALISE = "FINALISE"
    MANUAL_REVIEW = "MANUAL_REVIEW"
    PERMANENT_UNKNOWN = "PERMANENT_UNKNOWN"
    ABANDON_NO_ATTEMPT = "ABANDON_NO_ATTEMPT"


class ManualReviewFlag(str, enum.Enum):
    NONE = "NONE"
    MANUAL_REVIEW_REQUIRED = "MANUAL_REVIEW_REQUIRED"


class TransactionConclusion(str, enum.Enum):
    """Terminal outcome of a saga (high-level envelope only; the fine state
    machine is authoritative for transitions)."""
    NOT_ATTEMPTED = "NOT_ATTEMPTED"
    PRECONDITION_FAILED = "PRECONDITION_FAILED"
    APPLIED_FORWARDED = "APPLIED_FORWARDED"
    APPLIED_NOT_SYNCED = "APPLIED_NOT_SYNCED"
    CONFIRMED_NOT_APPLIED = "CONFIRMED_NOT_APPLIED"
    UNKNOWN_MANUAL = "UNKNOWN_MANUAL"
    DIVERGENCE_MANUAL = "DIVERGENCE_MANUAL"


# --------------------------------------------------------------------------- #
class TransactionOutcome(str, enum.Enum):
    """Output-contract outcome (protocol §4)."""
    PREPARED = "PREPARED"
    PRECONDITION_FAILED = "PRECONDITION_FAILED"
    RUNTIME_ATTEMPTED = "RUNTIME_ATTEMPTED"
    DONE = "DONE"


# Bounded server/time fields are stored as bounded strings to satisfy the
# "bounded error detail / no unbounded blob in journal" requirement.
MAX_EVIDENCE_FIELD = 4000
MAX_PROVENANCE_FIELD = 2000
MAX_ERROR_DETAIL = 400
DIGEST_ALGO = "sha256"
CANONICALISATION_VERSION = "phase3-canonic-json-v1"
SAGA_SCHEMA_VERSION = 1
