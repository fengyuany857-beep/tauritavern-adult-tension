"""Deterministic digests for Phase 3A (protocol §5, §11).

- raw_sha256 : exact bytes at a named path/time (observational evidence only;
  NEVER a runtime revision / CAS / writer identity).
- canonical semantic digest : SHA-256 over canonical UTF-8 JSON of the complete
  parsed mapping (sorted keys, unambiguous separators).  Independent of YAML
  formatting / key ordering.  Same semantic state => same digest.
- patch_digest : over canonical patch JSON (key-order independent).
- candidate/expected digest : canonical semantic digest over the pure
  vendor-generated expected candidate mapping.

This module performs NO file writes and NO runtime mutation.
"""
from __future__ import annotations
import enum
import hashlib
import json
from typing import Any

from ..hashing import sha256_bytes as _sha256_bytes
from .errors import TxErrorCode, TxError


class ScalarMode(str, enum.Enum):
    CONTENT = "content"
    TYPE_TAGGED = "type_tagged"


def canonical(obj: Any) -> Any:
    """Recursively normalise a parsed object for stable semantic identity.

    Dictionaries are sorted by str(key); scalars are passed through as-is.
    This gives a structure whose JSON serialisation is canonical regardless of
    YAML formatting/spacing/order = the *same semantic state* produces the
    same canonical form.
    """
    if isinstance(obj, dict):
        return {str(k): canonical(v) for k, v in sorted(obj.items(), key=lambda item: str(item[0]))}
    if isinstance(obj, (list, tuple)):
        return [canonical(x) for x in obj]
    if obj is None or isinstance(obj, bool):
        return obj
    if isinstance(obj, int):
        return obj
    if isinstance(obj, float):
        return obj
    if isinstance(obj, str):
        return obj
    # Guard: nothing else should reach canonical serialisation for state we own.
    raise TxError(f"unsupported run-time type for canonical digest: {type(obj).__name__}",
                  code=TxErrorCode.UNSUPPORTED_DIGEST)


def _canonical_json_bytes(obj: Any) -> bytes:
    try:
        return json.dumps(canonical(obj), ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise TxError(f"cannot canonical-serialise mapping: {exc}", code=TxErrorCode.UNSUPPORTED_DIGEST) from exc


def canonical_semantic_digest(parsed_state: dict[str, Any]) -> str:
    """Deterministic digest over a complete parsed mapping (sorted keys)."""
    return _sha256_bytes(_canonical_json_bytes(parsed_state))


def canonical_semantic_digest_of_bytes(obj: Any) -> str:
    return canonical_semantic_digest(obj)


def raw_sha256_bytes(data: bytes) -> str:
    """Raw SHA-256 over exact provided bytes (observational evidence only)."""
    return _sha256_bytes(data)


def raw_sha256_file(path: Any) -> str:
    """Raw SHA-256 of exact bytes at `path`.  Evidence only — not a revision."""
    from pathlib import Path
    try:
        return _sha256_bytes(Path(path).read_bytes())
    except OSError as exc:
        raise TxError(f"cannot read path for raw sha256: {path}", code=TxErrorCode.RUNTIME_UNREADABLE) from exc


def patch_digest(patch: dict[str, Any]) -> str:
    """Digest over the canonical patch JSON (key-order independent)."""
    if not isinstance(patch, dict):
        raise TxError("patch must be a mapping", code=TxErrorCode.INVALID_ARGUMENT)
    return _sha256_bytes(_canonical_json_bytes(patch))
