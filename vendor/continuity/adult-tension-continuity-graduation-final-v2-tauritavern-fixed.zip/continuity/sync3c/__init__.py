"""Phase 3C — Idempotent Continuity Sync + Outbox + Recovery.

Public: ContinuitySyncEngine for the single-atomic authority sync; a durable
outbox EvidenceProjector; and a read-only RecoveryScanner with no-CoT manual
packets.  Phase 3C writes continuity historical consequences ONLY after a
durably Confirmed Applied runtime outcome; it never mutates runtime.
"""
from .contracts import (
    EffectKind, ContinuitySyncRequest, SyncPlan, PlanEffect, SyncStage,
    ReviewReason, HISTORICAL_EFFECT_KINDS, canonical_effect_id,
)
from .planner import build_plan, request_claimed_digest, payload_digest, PlanError
from .sqlwriter import effect_sql, EffectApplyError
from .engine import ContinuitySyncEngine, SyncEngineError
from .projector import EvidenceProjector, scan_volume, ProjectionError, QuarantineError
from .recovery import RecoveryScanner, RecoveryAction, recover_forward
from .manual_packet import build_manual_packet

__all__ = [
    "EffectKind", "ContinuitySyncRequest", "SyncPlan", "PlanEffect", "SyncStage",
    "ReviewReason", "HISTORICAL_EFFECT_KINDS", "canonical_effect_id",
    "build_plan", "request_claimed_digest", "payload_digest", "PlanError",
    "effect_sql", "EffectApplyError",
    "ContinuitySyncEngine", "SyncEngineError",
    "EvidenceProjector", "scan_volume", "ProjectionError", "QuarantineError",
    "RecoveryScanner", "RecoveryAction", "recover_forward",
    "build_manual_packet",
]
