"""Phase 3C — authoritative continuity sync engine.

Implements the protocol's single SQLite authority sync (Sol §7/§10/§18):

  CONTINUITY_SYNC_PENDING -> (single atomic txn) SYNCING
                            + apply every ownership-filtered historical effect
                            + insert every UNIQUE effect marker
                            + upsert the UNIQUE sync_execution row (guarded)
                            + insert the UNIQUE history_outbox row(s)
  SYNCING -> SYNCED   (quick bookkeeping commit; replay-safe)
  outbox  -> DELIVERED (projector)
  SYNCED  -> COMPLETED (final saga marker)

A crash anywhere is exactly the F7-F10 / W1-W4 window; because effects are
UNIQUE-by-(tx,kind,key) and outboxes are UNIQUE-by-envelope-id, replay is a
safe no-op for an identical payload, an *integrity conflict* (manual review)
for a differing payload under an existing key, and never a duplication.
"""
from __future__ import annotations
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .contracts import (
    EffectKind, SyncPlan, canonical_json, canonical_effect_id, _sha256_text,
)
from .planner import build_plan, request_claimed_digest, payload_digest
from .sqlwriter import effect_sql, EffectApplyError
from .projector import EvidenceProjector, scan_volume

# Inline journal helpers replicate the exact format JournalDao uses for event
# rows (same tabs, same ordinal scheme) but run inside the *one caller-owned
# SQLite transaction* so the state transition + all authority writes commit
# or roll back together.

def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _transition_inline(conn: sqlite3.Connection, tx_id: str,
                       from_state: str, to_state: str, *,
                       sync_col: str | None) -> None:
    """Move transaction_journal.state from->to and append one state event,
    all inside the caller's open transaction (no nested commit)."""
    conn.execute(
        "UPDATE transaction_journal SET state=?, updated_at=?, "
        " continuity_sync_state=COALESCE(?, continuity_sync_state) "
        " WHERE continuity_tx_id=?",
        (to_state, _now(), sync_col, tx_id))
    n = conn.execute(
        "SELECT COALESCE(MAX(ordinal), -1)+1 AS n FROM transaction_state_events "
        "WHERE continuity_tx_id=?", (tx_id,)).fetchone()["n"]
    conn.execute(
        "INSERT INTO transaction_state_events "
        "(continuity_tx_id, ordinal, from_state, to_state, at_time, evidence_digest) "
        "VALUES (?,?,?,?,?,?)",
        (tx_id, int(n), from_state, to_state, _now(), None))


def _install_outbox_row(conn: sqlite3.Connection, *, tx_id: str,
                        envelope_kind: str, envelope_id: str,
                        payload: dict[str, Any]) -> None:
    checksum = _sha256_text(canonical_json(payload))
    outbox_id = _sha256_text(f"{tx_id}\n{envelope_kind}")
    conn.execute(
        "INSERT OR IGNORE INTO history_outbox "
        "(outbox_id, continuity_tx_id, envelope_kind, envelope_id, payload_json, "
        " checksum, state, created_at, delivered_at) "
        "VALUES (?,?,?,?,?,?,?,?,?)",
        (outbox_id, tx_id, envelope_kind, envelope_id,
         canonical_json(payload), checksum, "PENDING", _now(), None))


class SyncEngineError(Exception):
    def __init__(self, reason: str, review_reason: str = "INTEGRITY"):
        super().__init__(reason)
        self.reason = reason
        self.review_reason = review_reason


# --------------------------------------------------------------------------- #
class ContinuitySyncEngine:
    """Owns one SQLite connection used for the durability-critical sync.

    The connection is *never* touched by code outside this engine within a
    transaction while applying, so it can hold effects + markers + outbox in
    one atomic commit.
    """

    def __init__(self, conn: sqlite3.Connection, *, evidence_path: Path | None = None,
                 auto_project: bool = True, app_name: str = "phase3c-engine"):
        self.conn = conn
        self.evidence_path = evidence_path
        self.auto_project = auto_project
        self.app_name = app_name

    # ------------------------------------------------------------------ #
    # Precondition gate (Sol §7 "only CONFIRMED_APPLIED syncs"; §15)
    # ------------------------------------------------------------------ #
    def sync_preconditions(self, tx_id: str) -> str:
        """Return a human-checkable reason string when sync is disallowed.

        Checks that the journal row is present, in a syncable state, carries a
        confirmed-applied runtime outcome with durable post evidence and isn't
        already fully completed."""
        row = self.conn.execute(
            "SELECT state, runtime_outcome_class, continuity_sync_state, "
            " runtime_post_observed_sha256, runtime_post_semantic_digest, "
            " expected_candidate_digest, runtime_pre_sha256, attempt_count, "
            " manual_review_required, durability_status, staged_sync_digest "
            " FROM transaction_journal "
            " WHERE continuity_tx_id=?", (tx_id,)).fetchone()
        if row is None:
            return f"unknown continuity_tx_id {tx_id}"
        row = dict(row)
        state = row["state"]
        allowed = {"CONFIRMED_APPLIED", "DURABILITY_PENDING",
                   "CONTINUITY_SYNC_PENDING", "CONTINUITY_SYNCING"}
        if state not in allowed:
            return (
                f"journal state {state!r} is not CONTINUITY_SYNC_PENDING or an "
                f"equivalent forward-confirmed state; cannot sync")
        if row["runtime_outcome_class"] != "CONFIRMED_APPLIED":
            return ("runtime_outcome_class is not CONFIRMED_APPLIED; "
                    "no historical sync is allowed (invariant 1/4/5)")
        if bool(row["manual_review_required"]):
            return "manual_review_required is set; automatic continuity sync is forbidden"
        if row["durability_status"] in ("DIR_FSYNC_FAILED", "DIR_FSYNC_UNSUPPORTED"):
            return "runtime directory fsync is failed/unsupported; automatic continuity sync is forbidden"
        if not row["staged_sync_digest"]:
            return "staged_sync_digest is absent; recovery must not guess a consequence plan"
        if not row["runtime_post_observed_sha256"] or not row["runtime_post_semantic_digest"]:
            return ("durable immediate post observation evidence is missing; "
                    "cannot sync (needs confirmed post refs)")
        if row["continuity_sync_state"] == "SYNCED":
            return "sync already marked SYNCED on the journal row"
        return ""

    # ------------------------------------------------------------------ #
    # The single atomic continuous sync
    # ------------------------------------------------------------------ #
    def sync_applied_transaction(self, request) -> dict[str, Any]:
        """Sync one CONFIRMED_APPLIED transaction idempotently and durably.

        Returns a result envelope.  Raises SyncEngineError on a precondition
        violation or an integrity (digest) conflict that must go to review."""
        tx_id = request.continuity_tx_id

        # Compile the deterministic plan (ownership filtering happens here).
        plan = build_plan(request)
        claimed = request_claimed_digest(request)
        row = self.conn.execute(
            "SELECT staged_sync_digest, continuity_sync_state, state, "
            " runtime_outcome_class "
            " FROM transaction_journal WHERE continuity_tx_id=?", (tx_id,)).fetchone()
        if row is None:
            raise SyncEngineError(f"unknown continuity_tx_id: {tx_id}", "PRECONDITION")
        row = dict(row)
        actual = row["state"]
        # plan digest must be deterministic and match what the tx staged.
        if not row["staged_sync_digest"]:
            raise SyncEngineError(
                "staged_sync_digest is absent; consequence identity was not durably "
                "bound at PREPARED and cannot be guessed during recovery",
                "PLAN_DIGEST_MISSING")
        if row["staged_sync_digest"] != claimed:
            raise SyncEngineError(
                f"sync plan digest differs from staged_sync_digest stored at prepare "
                f"({row['staged_sync_digest'][:16]}… != {claimed[:16]}…)",
                "PLAN_DIGEST_MISMATCH")

        # Already applied? sync_execution row is UNIQUE(tx_id).
        existing_syncex = self.conn.execute(
            "SELECT payload_digest FROM continuity_sync_executions "
            "WHERE continuity_tx_id=?", (tx_id,)).fetchone()
        if existing_syncex is not None:
            stored = dict(existing_syncex)["payload_digest"]
            if stored != plan.canonical_digest():
                raise SyncEngineError(
                    f"existing sync_execution carries a different payload_digest "
                    f"({stored[:16]}…) than this plan ({plan.canonical_digest()[:16]}…); "
                    f"manual review required (no overwrite)",
                    "EFFECT_DIGEST_CONFLICT")
            # identical replay already synced -> strict no-op forward (never
            # re-apply, never create duplicates, never re-transition)
            result = {
                "continuity_tx_id": tx_id,
                "plan_digest": plan.canonical_digest(),
                "n_effects": len(plan.effects),
                "effect_ids": [e.effect_id for e in plan.effects],
                "status": "ALREADY_SYNCED",
            }
            result["replay"] = True
            return result

        # genuine first sync -> run the precondition gate (only CONFIRMED_APPLIED
        # + durable post evidence + syncable state may enter)
        gate = self.sync_preconditions(tx_id)
        if gate:
            raise SyncEngineError(gate, "PRECONDITION")

        # --- single atomic authority txn: effects + markers + sync_exec +
        # outbox + PENDING->SYNCING; all commit or roll back together.
        syncing_col = "SYNCING"
        try:
            conn = self.conn
            with conn:
                from_state = actual if actual in (
                    "CONTINUITY_SYNC_PENDING", "CONTINUITY_SYNCING",
                    "DURABILITY_PENDING", "CONFIRMED_APPLIED") else actual
                _transition_inline(
                    conn, tx_id, self._journal_src(actual),
                    "CONTINUITY_SYNCING", sync_col=None)
                conn.execute(
                    "UPDATE transaction_journal SET continuity_sync_state=? "
                    "WHERE continuity_tx_id=?",
                    (syncing_col, tx_id))
                # apply every effect + marker inside this one txn
                applied = []
                for effect in plan.effects:
                    mark = conn.execute(
                        "SELECT payload_digest FROM continuity_effect_markers "
                        "WHERE continuity_tx_id=? AND effect_kind=? AND effect_key=?",
                        (tx_id,
                         effect.effect_kind.value if isinstance(effect.effect_kind, EffectKind)
                         else str(effect.effect_kind), effect.effect_key)).fetchone()
                    if mark is not None and dict(mark)["payload_digest"] != effect.payload_digest:
                        raise SyncEngineError(
                            f"effect {effect.effect_id[:12]}… marker payload digest differs "
                            f"from the plan; manual review required (no overwrite of an "
                            f"existing effect)",
                            "EFFECT_DIGEST_CONFLICT")
                    if mark is None:
                        conn.execute(
                            "INSERT INTO continuity_effect_markers "
                            "(continuity_tx_id, effect_kind, effect_key, payload_digest) "
                            "VALUES (?,?,?,?)",
                            (tx_id,
                             effect.effect_kind.value if isinstance(effect.effect_kind, EffectKind)
                             else str(effect.effect_kind),
                             effect.effect_key, effect.payload_digest))
                        trace = effect_sql(
                            conn, effect.effect_kind,
                            effect.payload, {
                                "continuity_tx_id": tx_id,
                                "branch_id": request.branch_id,
                                "plan_digest": plan.canonical_digest(),
                                "effect_id": effect.effect_id,
                                "turn": getattr(request, "turn", None),
                            })
                        applied.append(trace)
                # sync_execution UNIQUE row
                conn.execute(
                    "INSERT INTO continuity_sync_executions "
                    "(continuity_tx_id, payload_digest, started_at, synced_at) "
                    "VALUES (?,?,?,?)",
                    (tx_id, plan.canonical_digest(), _now(), None))
                # durable evidence-outbox rows (uniquely keyed)
                effect_ids = [e.effect_id for e in plan.effects]
                _install_outbox_row(
                    conn, tx_id=tx_id, envelope_kind="evidence_append",
                    envelope_id=f"evt-{_sha256_text(tx_id)[:24]}",
                    payload={"continuity_tx_id": tx_id,
                             "plan_digest": plan.canonical_digest(),
                             "branch": request.branch_id,
                             "n_effects": len(plan.effects),
                             "effect_ids": effect_ids},
                )
        except (SyncEngineError, EffectApplyError) as err:
            # EffectApplyError from an authority effect operation is translated
            # to the public SyncEngineError while preserving the rollback the
            # `with conn` context performed (no half-authority writes survive).
            if isinstance(err, EffectApplyError):
                raise SyncEngineError(
                    f"authority effect could not be applied safely: {err}",
                    review_reason="OWNERSHIP") from err
            raise
        # If an effect_sql raised before commit, `with conn` rolls back entirely
        # (python `with conn` context: exception -> rollback).  We re-raise the
        # original by checking here: the block above doesn't swallow, so if we are
        # here the commit succeeded and effects+markers are durable & atomic.

        # --- mark SYNCING -> SYNCED (bookkeeping, replay-safe) -------------
        result = self._post_synced_state(tx_id, plan)
        result["replay"] = False

        # --- outbox projection (drain) ------------------------------------
        if self.auto_project:
            self.drain_outbox(limit=250)
        else:
            result["projection"] = "SKIPPED_AUTO_PROJECT"

        # --- finalise marker once deliverable ------------------------------
        result = self.finalize_if_ready(tx_id, result)
        return result

    # ------------------------------------------------------------------ #
    def drain_outbox(self, limit: int = 250) -> dict[str, Any]:
        if self.evidence_path is None:
            return {"drained": 0, "errors": ["no evidence volume configured"]}
        proj = EvidenceProjector(self.conn, self.evidence_path)
        return proj.drain(limit=limit)

    # ------------------------------------------------------------------ #
    def finalize_if_ready(self, tx_id: str, result: dict[str, Any]) -> dict[str, Any]:
        """CONTINUITY_SYNCED -> COMPLETED once final marker conditions hold.

        Conditions: effect markers for every planned kind are present AND every
        history_outbox row for this tx is state != 'PENDING'.
        """
        row = self.conn.execute(
            "SELECT state, continuity_sync_state FROM transaction_journal "
            "WHERE continuity_tx_id=?", (tx_id,)).fetchone()
        if row is None:
            return result
        row = dict(row)
        if row["state"] != "CONTINUITY_SYNCED":
            return result
        pending = self.conn.execute(
            "SELECT COUNT(*) AS c FROM history_outbox "
            "WHERE continuity_tx_id=? AND state='PENDING'", (tx_id,)).fetchone()
        if pending and dict(pending)["c"]:
            result["status"] = "SYNCED_OUTBOX_PENDING"
            return result
        with self.conn:
            _transition_inline(self.conn, tx_id, "CONTINUITY_SYNCED", "COMPLETED",
                               sync_col="SYNCED")
        result["status"] = "COMPLETED"
        return result

    def _post_synced_state(self, tx_id: str, plan: SyncPlan) -> dict[str, Any]:
        cur = "NOT_PRESENT"
        row = self.conn.execute("SELECT state FROM transaction_journal "
                                "WHERE continuity_tx_id=?", (tx_id,)).fetchone()
        if row is not None:
            cur = row["state"]
        if row is not None and cur == "CONTINUITY_SYNCING":
            with self.conn:
                _transition_inline(self.conn, tx_id, "CONTINUITY_SYNCING",
                                   "CONTINUITY_SYNCED", sync_col="SYNCED")
        return {
            "continuity_tx_id": tx_id,
            "plan_digest": plan.canonical_digest(),
            "n_effects": len(plan.effects),
            "effect_ids": [e.effect_id for e in plan.effects],
            "status": "SYNCED",
        }

    @staticmethod
    def _journal_src(state: str) -> str:
        # For state-event bookkeeping we present the src as the canonical
        # pre-SYNCING journal state; DB integrity allowed for the states we
        # accept above.
        if state in ("CONTINUITY_SYNC_PENDING", "CONTINUITY_SYNCING",
                     "DURABILITY_PENDING", "CONFIRMED_APPLIED"):
            return "CONTINUITY_SYNC_PENDING"
        return state
