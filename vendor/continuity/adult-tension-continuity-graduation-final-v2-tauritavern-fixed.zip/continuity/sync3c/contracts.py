"""Phase 3C — continuity sync contracts.

Bounded, strongly-typed integration-surface model for turning a *durably
confirmed* runtime application into a once-only continuity historical sync.
It does NOT generate story meaning: it only carries the upstream / integration
contract's already-approved continuity consequence payload and validates it
against Phase 3C ownership rules.

Honesty rules carried from Sol protocol §7/§10/§15/§18/§20/§21:
- Only CONFIRMED_APPLIED (with acceptable durability evidence) may sync.
- UNKNOWN / DIVERGENCE / NOT_APPLIED / PRECONDITION_FAILED must NOT sync.
- A continuity_tx_id is a sidecar orchestration id, never a runtime tx id /
  revision / CAS.
- runtime_confirmed != COMPLETED; there is no generic SUCCESS.
- Continuity may record permitted *historical* consequence / reference, never
  a second current-permission or current-relationship authority.
"""
from __future__ import annotations
import enum
import hashlib
import json
from dataclasses import dataclass, field
from typing import Any

DIGEST_ALGO = "sha256"
# Bounded fields (same policy as Phase 3A/B).
MAX_SYNC_PLAN_JSON = 6000
MAX_PAYLOAD_FIELD = 4000


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def canonical_json(obj: Any) -> str:
    """Deterministic serialization used for all digests / stable effect keys."""
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


# --------------------------------------------------------------------------- #
# Ownership / effect-kind taxonomy (Sol protocol §4 output scope + §18).
# --------------------------------------------------------------------------- #
class EffectKind(str, enum.Enum):
    EPISODE_APPEND = "EPISODE_APPEND"           # add an episode record (tx-provenanced)
    FACT_INSERT = "FACT_INSERT"                 # insert an objective historical fact
    FACT_SUPERSESSION = "FACT_SUPERSESSION"     # mark one continuity fact superseded
    KNOWLEDGE_UPDATE = "KNOWLEDGE_UPDATE"       # explicit observer-scoped know effect
    RELATIONSHIP_SEMANTIC_UPDATE = "RELATIONSHIP_SEMANTIC_UPDATE"  # historical semantic only
    COMMITMENT_HISTORICAL_EFFECT = "COMMITMENT_HISTORICAL_EFFECT"  # explicit effect only
    THREAD_HISTORICAL_EFFECT = "THREAD_HISTORICAL_EFFECT"          # relevant event only
    EPISODE_LINK = "EPISODE_LINK"               # link an episode to entities/facts
    EVIDENCE_APPEND = "EVIDENCE_APPEND"         # outbox JSONL evidence (projector)

    # Never produced by the planner; reserved names that are strictly forbidden
    # as continuity "current authority" writes:
    CURRENT_RELATIONSHIP_WRITE = "CURRENT_RELATIONSHIP_WRITE"
    CURRENT_SEMANTIC_WRITE = "CURRENT_SEMANTIC_WRITE"
    CURRENT_CONSENT_WRITE = "CURRENT_CONSENT_WRITE"
    CURRENT_PERMISSION_WRITE = "CURRENT_PERMISSION_WRITE"


# Effect kinds that are continuity *historical* writes permitted after a
# CONFIRMED_APPLIED runtime outcome with acceptable durability.
HISTORICAL_EFFECT_KINDS = frozenset({
    EffectKind.EPISODE_APPEND,
    EffectKind.FACT_INSERT,
    EffectKind.FACT_SUPERSESSION,
    EffectKind.KNOWLEDGE_UPDATE,
    EffectKind.RELATIONSHIP_SEMANTIC_UPDATE,
    EffectKind.COMMITMENT_HISTORICAL_EFFECT,
    EffectKind.THREAD_HISTORICAL_EFFECT,
    EffectKind.EPISODE_LINK,
})

# Continuity-owned tables the sync planner may write inside authority tx.
AUTHORITY_WRITE_TABLES = frozenset({
    "episodes", "episode_entity_links", "episode_fact_links", "facts",
    "fact_supersessions", "knowledge", "relationships",
    "relationship_dimensions", "commitments", "threads", "thread_links",
    "thread_requires", "thread_anti_merge", "continuity_transactions",
})


# --------------------------------------------------------------------------- #
# Sync dimensions (this is the fine dimension; never a generic SUCCESS).
# --------------------------------------------------------------------------- #
class SyncStage(str, enum.Enum):
    NOT_ELIGIBLE = "NOT_ELIGIBLE"           # no applied run with durable evidence
    PENDING = "PENDING"                     # applied, waiting for the single sync txn
    PLANNED = "PLANNED"                     # deterministic plan computed, not committed
    SYNCING = "SYNCING"                     # authority+markers+outbox commit in progress
    SYNCED = "SYNCED"                       # authority+markers+outbox atomically committed
    OUTBOX_PENDING = "OUTBOX_PENDING"       # authority done; JSONL projection outstanding
    DELIVERED = "DELIVERED"                 # outbox envelopes projected to JSONL
    COMPLETED = "COMPLETED"                 # final saga marker written; required state done
    RECOVERY_REQUIRED = "RECOVERY_REQUIRED" # integrity conflict / needs forward attention
    MANUAL = "MANUAL"                       # automation must stop; external review


# The per-row journal column `continuity_sync_state` written by the engine maps
# loosely onto a subset (the protocol §7 uses SYNC_PENDING/SYNCING/SYNCED plus
# RECOVERY_REQUIRED).  We keep our richer SyncStage here and persist the
# protocol's coarse values into the EXISTING journal column so the whole state
# machine (transactions/contracts.ContinuitySyncState + JournalDao.finalize)
# stays consistent with prior phases.
SYNC_COLUMN_MAP = {
    SyncStage.NOT_ELIGIBLE: "NOT_ELIGIBLE",
    SyncStage.PENDING: "SYNC_PENDING",
    SyncStage.PLANNED: "SYNC_PENDING",
    SyncStage.SYNCING: "SYNCING",
    SyncStage.SYNCED: "SYNCED",
    SyncStage.OUTBOX_PENDING: "SYNCED",   # authority synced; outbox still pending
    SyncStage.DELIVERED: "SYNCED",
    SyncStage.COMPLETED: "SYNCED",
    SyncStage.RECOVERY_REQUIRED: "RECOVERY_REQUIRED",
    SyncStage.MANUAL: "NOT_ELIGIBLE",
}


# --------------------------------------------------------------------------- #
# Plan effect (one atomic unit of work within the single SQLite sync txn).
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class PlanEffect:
    """One historical consequence unit.

    `effect_key` must be UNIQUE for this (tx, effect_kind) pair and
    deterministic.  The continuation package stores UNIQUE(tx, effect_kind,
    effect_key) effect markers so a replay is a no-op for an identical digest
    and an integrity conflict for a differing digest.
    """
    effect_kind: EffectKind | str
    effect_key: str                  # deterministic within (tx, kind)
    payload_digest: str              # sha256 of the concrete payload
    payload: dict[str, Any] = field(default_factory=dict)  # bounded concrete payload
    extra: dict[str, Any] = field(default_factory=dict)   # bounded, no-CoT only

    # stable fully-qualified id string used inside continuity tables
    @property
    def effect_id(self) -> str:
        return canonical_effect_id(self.effect_kind, self.effect_key)


def canonical_effect_id(kind: str | EffectKind, effect_key: str) -> str:
    k = kind.value if isinstance(kind, EffectKind) else str(kind)
    return _sha256_text(f"{k}\n{effect_key}")


# --------------------------------------------------------------------------- #
# Input request — binds the sync to a durable, discipline-checked runtime tx.
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class ContinuitySyncRequest:
    """The full, self-checking synchronous input envelope.

    Never constructed from arbitrary runtime drift.  The caller (an integration
    harness that observed the APPLIED outcome) supplies the confirmed post
    observation refs, expected candidate digest, and the upstream-approved
    consequence payload.  Phase 3C only re-validates and applies.
    """
    continuity_tx_id: str
    runtime_outcome_class: str            # must equal CONFIRMED_APPLIED
    observed_post_sha256: str             # durable immediate post observation ref
    observed_post_semantic_digest: str
    expected_candidate_digest: str
    patch_digest: str
    branch_id: str
    source_provenance: dict[str, Any]     # who authored the runtime request
    request_provenance: dict[str, Any]    # who authorised this sync
    sync_plan_bytes_digest: str           # digest of the deterministic consequence plan
    consequences: list[dict[str, Any]]    # upstream-approved historical effect payloads
    plan_version: str = "phase3c-sync-v1"


# --------------------------------------------------------------------------- #
# A fully resolved, deterministic parse of the consequence payload into effects.
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class SyncPlan:
    continuity_tx_id: str
    branch_id: str
    effects: list[PlanEffect] = field(default_factory=list)

    def canonical_digest(self) -> str:
        items = [
            {
                "effect_kind": (e.effect_kind.value if isinstance(e.effect_kind, EffectKind)
                                else str(e.effect_kind)),
                "effect_key": e.effect_key,
                "payload_digest": e.payload_digest,
            }
            for e in self.effects
        ]
        return _sha256_text(canonical_json({"tx": self.continuity_tx_id,
                                            "branch": self.branch_id,
                                            "effects": items}))

    def to_dict(self, limit: int = MAX_SYNC_PLAN_JSON) -> dict[str, Any]:
        d = {
            "continuity_tx_id": self.continuity_tx_id,
            "branch_id": self.branch_id,
            "effects": [
                {
                    "effect_kind": (e.effect_kind.value if isinstance(e.effect_kind, EffectKind)
                                    else str(e.effect_kind)),
                    "effect_key": e.effect_key,
                    "payload_digest": e.payload_digest,
                    "effect_id": e.effect_id,
                }
                for e in self.effects
            ],
            "canonical_digest": self.canonical_digest(),
        }
        return d


# Tag description for manual-review packet reasons (no hidden CoT).
class ReviewReason(str, enum.Enum):
    NOT_CONFIRMED_APPLIED = "NOT_CONFIRMED_APPLIED"
    SYNC_ALREADY_DONE = "SYNC_ALREADY_DONE"
    PLAN_DIGEST_MISMATCH = "PLAN_DIGEST_MISMATCH"
    EFFECT_DIGEST_CONFLICT = "EFFECT_DIGEST_CONFLICT"
    AUTHORITY_INCONSISTENT = "AUTHORITY_INCONSISTENT"
    OUTCOME_UNKNOWN = "OUTCOME_UNKNOWN"
    CONCURRENT_DIVERGENCE = "CONCURRENT_DIVERGENCE"
    LATE_WITHOUT_DURABLE_PROOF = "LATE_WITHOUT_DURABLE_PROOF"
    PARTIAL_JSONL = "PARTIAL_JSONL"
    MALFORMED_JSONL = "MALFORMED_JSONL"
    INTEGRITY = "INTEGRITY"
    PLAYER_SOVEREIGNTY = "PLAYER_SOVEREIGNTY"
    ADULT_AUTHORITY = "ADULT_AUTHORITY"
    OWNERSHIP = "OWNERSHIP"
    UNKNOWN = "UNKNOWN"
