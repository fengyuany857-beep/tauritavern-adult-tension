"""Phase 3C — read-only runtime recovery scanner + classifier.

Scans nonterminal journal rows WITHOUT ever touching the vendor runtime or
invoking a writer.  For each row it decides one of the Sol §17 / task §17
dispositions (A-H), records an observation, and only ever takes a *sidecar*
forward action (idempotent replay sync / outbox drain / finalise marker) with a
re-offered identical plan, or emits a manual-review packet.  It never rolls
back runtime, never retries a runtime mutation, never guesses from later state.

Recovery keeps its outcome evidence in SQLite (never JSONL) and never depends on
the permissive retrieval JSONL iterator — guaranteeing the malformed-line P1
cannot make recovery misjudge an event as absent or present.
"""
from __future__ import annotations
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from .manual_packet import build_manual_packet

try:
    from .engine import ContinuitySyncEngine as _CES, SyncEngineError as _SEE
except Exception:  # pragma: no cover - import safety in unusual paths
    _CES = None  # type: ignore
    _SEE = Exception  # type: ignore

_APPLIED = "CONFIRMED_APPLIED"


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class RecoveryAction:
    NO_SYNC_MANUAL = "MANUAL_REVIEW"
    FORWARD_SYNC = "SYNC_REPLAY"
    DRAIN_OUTBOX = "DRAIN_OUTBOX"
    FINALISE = "FINALISE"
    NO_ACTION = "NO_ACTION"


class RecoveryScanner:
    """Observes nonterminal saga rows and drives sidecar forward-only steps.

    `request_provider` is a callable(tx_id) -> ContinuitySyncRequest | None that
    re-offers a *durably authorised, digest-stable* sync request.  None means we
    cannot safely reconstruct the intended plan; the scanner then only drains
    outbox / finalises / marks review, never invents a plan.
    """

    def __init__(self, conn: sqlite3.Connection, *,
                 evidence_path: Path | None = None,
                 request_provider: Callable[[str], Any] | None = None,
                 engine: "ContinuitySyncEngine | None" = None):
        self.conn = conn
        self.evidence_path = evidence_path
        self.request_provider = request_provider
        self._engine = engine

    # ------------------------------------------------------------------ #
    def scan(self, limit: int = 100) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT continuity_tx_id, state, runtime_outcome_class, "
            " continuity_sync_state, runtime_post_observed_sha256, "
            " expected_candidate_digest, branch_id, manual_review_required, "
            " staged_sync_digest, durability_status "
            " FROM transaction_journal "
            " WHERE state NOT IN ('PRECONDITION_FAILED','CONFIRMED_NOT_APPLIED',"
            "  'ABORTED_NOT_ATTEMPTED','COMPLETED','MANUAL_REVIEW') "
            " ORDER BY created_at LIMIT ?", (limit,)).fetchall()

        observations = []
        for r in rows:
            r = dict(r)
            action, packet, note = self._classify(r)
            self._record_observation(r["continuity_tx_id"], action, note)
            observations.append({
                "continuity_tx_id": r["continuity_tx_id"],
                "disposition": action,
                "manual_review_json": packet,
                "note": note,
            })
        return observations

    # ------------------------------------------------------------------ #
    def _classify(self, row: dict[str, Any]) -> tuple[str, str | None, str]:
        tx = row["continuity_tx_id"]
        state = row["state"]
        outcome = row["runtime_outcome_class"]
        sync_state = row["continuity_sync_state"]

        if (bool(row.get("manual_review_required"))
                or row.get("durability_status") in ("DIR_FSYNC_FAILED", "DIR_FSYNC_UNSUPPORTED")):
            packet = build_manual_packet(
                continuity_tx_id=tx, runtime_outcome_class=outcome or state,
                state=state, reason="Durable runtime result requires manual review; "
                "automatic continuity sync is forbidden.",
                review_tag="RUNTIME_DURABILITY_REVIEW", sync_state=sync_state)
            return RecoveryAction.NO_SYNC_MANUAL, packet, \
                "manual review/directory durability gate blocks automatic sync"

        # E/F/G/H: never sync historical truth.
        if outcome in ("OUTCOME_UNKNOWN", "CONCURRENT_DIVERGENCE"):
            packet = build_manual_packet(
                continuity_tx_id=tx, runtime_outcome_class=outcome, state=state,
                reason="Unconfirmed/non-applied or divergent runtime outcome must "
                       "not sync historical truth; manual review only.",
                review_tag=outcome, sync_state=sync_state,
                last_error_class=row.get("staged_sync_digest") and "staged_protected" or None)
            return RecoveryAction.NO_SYNC_MANUAL, packet, outcome
        if outcome == "CONFIRMED_NOT_APPLIED":
            packet = build_manual_packet(
                continuity_tx_id=tx, runtime_outcome_class=outcome, state=state,
                reason="Runtime confirmed not applied -> no historical sync.",
                review_tag="CONFIRMED_NOT_APPLIED", sync_state=sync_state)
            return RecoveryAction.NO_ACTION, None, "confirmed not applied; no sync"
        if outcome == "PRECONDITION_FAILED" or state == "PRECONDITION_FAILED":
            return RecoveryAction.NO_ACTION, None, "precondition failed; no sync"
        if state == "RUNTIME_ATTEMPTING":
            packet = build_manual_packet(
                continuity_tx_id=tx, runtime_outcome_class=outcome or "RUNTIME_ATTEMPTING",
                state=state, reason="An attempted tx was found mid-attempt with no "
                                    "recorded outcome; never auto-retry runtime.",
                review_tag="RUNTIME_ATTEMPTING", sync_state=sync_state,
                failure_window="F3-F6")
            return RecoveryAction.NO_SYNC_MANUAL, packet, "attempted, no outcome; manual, no retry"

        # A/B/C/D: confirmed applied forward path.
        durable_proof = bool(row.get("runtime_post_observed_sha256"))
        synced_row = self.conn.execute(
            "SELECT payload_digest FROM continuity_sync_executions "
            "WHERE continuity_tx_id=?", (tx,)).fetchone()
        pending_outbox = self.conn.execute(
            "SELECT COUNT(*) AS c FROM history_outbox "
            "WHERE continuity_tx_id=? AND state='PENDING'", (tx,)).fetchone()
        pending_outbox = pending_outbox and pending_outbox["c"]

        if state == "CONTINUITY_SYNCED" or (synced_row is not None):
            # C/D: authority done; drain outbox then finalize.
            if pending_outbox and self.evidence_path:
                return RecoveryAction.DRAIN_OUTBOX, None, "authority done, outbox pending -> drain"
            if state in ("CONTINUITY_SYNCED",):
                return RecoveryAction.FINALISE, None, "verify markers -> finalise"
            return RecoveryAction.NO_ACTION, None, "already synced; no action"

        # A/B: applied + not yet synced -> forward sync if a stable request plane.
        if outcome == _APPLIED:
            if not row.get("staged_sync_digest"):
                packet = build_manual_packet(
                    continuity_tx_id=tx, runtime_outcome_class=outcome, state=state,
                    reason="No consequence digest was durably bound at PREPARED; "
                    "recovery must not guess or accept a late plan.",
                    review_tag="PLAN_DIGEST_MISSING", sync_state=sync_state)
                return RecoveryAction.NO_SYNC_MANUAL, packet, \
                    "missing staged consequence digest -> manual"
            if not durable_proof:
                packet = build_manual_packet(
                    continuity_tx_id=tx, runtime_outcome_class=outcome, state=state,
                    reason="Applied but durable immediate post observation is missing; "
                           "cannot reconstruct intended consequences late.",
                    review_tag="LATE_WITHOUT_DURABLE_PROOF", sync_state=sync_state,
                    failure_window="F5-F7")
                return RecoveryAction.NO_SYNC_MANUAL, packet, \
                    "applied but durable post evidence absent -> manual"
            request = self.request_provider(tx) if self.request_provider else None
            if request is None:
                packet = build_manual_packet(
                    continuity_tx_id=tx, runtime_outcome_class=outcome, state=state,
                    sync_state=sync_state,
                    reason="Confirmed applied but no re-offered identical sync "
                           "request is available; cannot invent a consequence plan. "
                           "Re-issue the same digest-stable request to recover.",
                    review_tag="PYLON_REQUIRES_REQUEST")
                return RecoveryAction.NO_SYNC_MANUAL, packet, \
                    "confirmed applied + durable proof, needs re-issued request -> replay offered"
            # Idempotent replay sync (request re-offer) is forward-safe.
            return RecoveryAction.FORWARD_SYNC, None, "confirmed applied -> idempotent sync"

        return RecoveryAction.NO_ACTION, None, "no automatic disposition"

    # ------------------------------------------------------------------ #
    def _record_observation(self, tx: str, action: str, note: str) -> None:
        observed_at = _now()
        observation_id = f"recovery-{tx}-{uuid.uuid4().hex}"
        with self.conn:
            self.conn.execute(
                "INSERT INTO recovery_observations "
                "(observation_id, continuity_tx_id, observed_at, kind, source, "
                " validation_state) VALUES (?,?,?,?,?,?)",
                (observation_id, tx, observed_at, action, "recovery_scanner",
                 "observational"))


def recover_forward(scanner: RecoveryScanner, tx_id: str):
    """Highest-level helper: run the scanner's forward action for one tx.

    Uses the same single-connection engine for idempotent replay or the
    projector for outbox draining.  Never touches runtime."""
    if scanner.request_provider is None:
        return {"tx": tx_id, "status": "no_request_provider"}
    row = scanner.conn.execute(
        "SELECT state, runtime_outcome_class FROM transaction_journal "
        "WHERE continuity_tx_id=?", (tx_id,)).fetchone()
    if row is None:
        return {"tx": tx_id, "status": "no_row"}
    if scanner._engine is None:
        return {"tx": tx_id, "status": "no_engine"}
    request = scanner.request_provider(tx_id)
    if request is None:
        return {"tx": tx_id, "status": "needs_manual_review"}
    try:
        return scanner._engine.sync_applied_transaction(request)
    except _SEE as e:
        return {"tx": tx_id, "status": "manual_review", "reason": str(e)}
