"""Phase 3C — manual-review packet builder (no chain-of-thought).

A manual-review packet records only the observable, displayable evidence that
lets an operator decide whether automation may continue, plus the safe /
forbidden action codes.  It never stores hidden reasoning, an internal scratch
pad, a raw candidate, or anything an agent silently reasoned about.
"""
from __future__ import annotations
import json

BOUNDED = 2000


def _bounded(value, limit: int):
    if value is None:
        return None
    s = str(value)
    return s[: limit - 1] + "…" if len(s) > limit else s


def build_manual_packet(*, continuity_tx_id: str,
                        runtime_outcome_class: str,
                        state: str,
                        reason: str,
                        review_tag: str,
                        sync_state: str | None = None,
                        last_error_class: str | None = None,
                        last_error_detail: str | None = None,
                        applied_effect_ids: list[str] | None = None,
                        pending_effect_ids: list[str] | None = None,
                        outbox_state: str | None = None,
                        evidence_event_ids: list[str] | None = None,
                        failure_window: str | None = None,
                        extra_evidence: dict | None = None) -> str:
    """Return a bounded JSON string packet; no CoT ever included."""
    safe_actions: list[str] = []
    forbidden_actions: list[str] = [
        "invoke_runtime_same_tx", "rewind", "fork", "rollback_runtime",
        "write_H0_back", "retry_runtime_mutation", "auto_promote_canon",
        "auto_merge", "synthesize_adult_permission",
        "infer_from_later_turn_or_trust", "overwrite_existing_effect_digest",
        "silently_ignore_malformed_jsonl", "sync_outside_confirm",
    ]
    safe_actions = _safe_for_outcome(runtime_outcome_class, state)

    packet = {
        "continuity_tx_id": continuity_tx_id,
        "runtime_outcome_class": runtime_outcome_class,
        "journal_state": state,
        "sync_state": sync_state,
        "review_reason_tag": review_tag,
        "reason": reason[:400],
        "last_error_class": last_error_class,
        "last_error_detail": _bounded(last_error_detail, BOUNDED),
        "applied_effect_ids": applied_effect_ids or [],
        "pending_effect_ids": pending_effect_ids or [],
        "outbox_state": outbox_state,
        "evidence_event_ids": evidence_event_ids or [],
        "failure_window": failure_window,
        "safe_actions": safe_actions,
        "forbidden_actions": forbidden_actions,
        "why_automation_cannot_safely_continue": reason[:800],
    }
    if extra_evidence:
        packet["extra_evidence"] = _squash(extra_evidence, BOUNDED)
    return json.dumps(packet, sort_keys=True, ensure_ascii=False)


def _squash(d: dict, limit: int) -> dict:
    out = {}
    for k, v in d.items():
        if isinstance(v, str) and len(v) > limit:
            out[k] = v[: limit - 1] + "…"
        elif isinstance(v, list):
            out[k] = v[:50]
        else:
            out[k] = v
    return out


def _safe_for_outcome(outcome: str, state: str) -> list[str]:
    if outcome == "CONFIRMED_APPLIED" and state in (
            "CONTINUITY_SYNC_PENDING", "DURABILITY_PENDING", "CONTINUITY_SYNCING"):
        return ["idempotent_forward_sync", "drain_outbox", "finalise_marker"]
    if outcome == "OUTCOME_UNKNOWN" or outcome == "CONCURRENT_DIVERGENCE":
        return ["create_new_tx_for_a_new_runtime_attempt",
                "record_evidence_review", "read_only_queries"]
    if outcome in ("CONFIRMED_NOT_APPLIED", "PRECONDITION_FAILED"):
        return ["abandon_tx", "new_plan_for_a_new_tx"]
    if state == "RECOVERY_REQUIRED":
        return ["mark_recovery", "read_only_queries"]
    return []
