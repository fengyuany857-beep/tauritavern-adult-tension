"""Phase 3C — durable evidence outbox projector (strict, crash-window safe).

SQLite authority commit and the append-only JSONL evidence volume are NOT
atomic.  This module implements the *projector* that later, after the single
SQLite sync transaction has committed SYNCED, drains the durable
`history_outbox` rows into the JSONL evidence file with:

  - a stable event id / envelope id / checksum (no DB UNIQUE exists on the file),
  - a single-drainer cross-process lock so two workers cannot double append,
  - strict checksum + envelope-id scanning (NEVER the permissive silent-skip
    iterator used in retrieval), and
  - explicit handling of the crash windows W1-W4 and torn / malformed tail.

Windows (Sol §10 / §11, mirrored in the task):
  W1 SQLite authority+outbox committed, JSONL not yet appended.
      -> row.state='PENDING', envelope absent in file. recovery drains safely.
  W2 JSONL append started but not fully written (partial / torn tail).
      -> strict scanner sees an incomplete last record and either truncates the
         torn tail (a record without a trailing newline is not authoritative)
         or quarantines a checksum-invalid full record.  Re-append only after
         the tail is repaired; never blind-append onto an indeterminate tail.
  W3 JSONL fully appended + fsync succeeded but the DB delivered marker not yet
      written (delivered=false while the file already holds the exact envelope).
      -> the strict scanner sees the exact envelope_id + checksum already present
         and marks it delivered WITHOUT appending a duplicate.
  W4 DB delivered marker written.
      -> terminal; resume never re-projects.
"""
from __future__ import annotations
import fcntl
import hashlib
import json
import os
import sqlite3
from pathlib import Path
from typing import Any, Iterable

from .contracts import _sha256_text, canonical_json


class ProjectionError(Exception):
    pass


class QuarantineError(Exception):
    """A strict integrity failure the projector cannot repair automatically."""
    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


def _file_lock(fd: int, exclusive: bool = True) -> None:
    fcntl.flock(fd, fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)


def scan_volume(path: Path) -> tuple[list[dict[str, Any]], list[str], bytes]:
    """Strict read of the evidence volume.

    Returns (valid_records, quarantine_reasons, trailing_bytes).  A record is a
    whole JSON line whose decoding succeeds and whose sha256 of the canonical
    dict-minus-checksum equals the embedded checksum.  Any malformed full line
    (bad JSON, bad checksum) is quarantined (reason appended).  Trailing bytes
    after the last newline that are non-empty are reported separately so the
    caller can decide repair policy -- they cannot be blindly trusted.
    """
    if not path.exists():
        return [], [], b""
    raw = path.read_bytes()
    trailing: bytes = b""
    if raw and not raw.endswith(b"\n"):
        idx = raw.rfind(b"\n")
        if idx >= 0:
            valid_part = raw[: idx + 1]
            trailing = raw[idx + 1:]
        else:
            # no newline at all: whole file could be a partial write
            return [], ["no_newline_entire_file"], raw
    else:
        valid_part = raw

    records: list[dict[str, Any]] = []
    quarantines: list[str] = []
    for line in valid_part.splitlines():
        line = line.rstrip(b"\r\n")
        text = line.decode("utf-8", "replace")
        if not text.strip():
            continue
        rec = _strict_parse(text)
        if rec is None:
            quarantines.append("unparsable_or_bad_checksum_line")
            continue
        records.append(rec)
    return records, quarantines, trailing


def _strict_parse(text: str) -> dict[str, Any] | None:
    """Return the canonical envelope iff the line is complete + checksum valid."""
    try:
        row = json.loads(text)
        if not isinstance(row, dict):
            return None
    except (json.JSONDecodeError, TypeError):
        return None
    checksum = row.pop("checksum", None)
    if not isinstance(checksum, str):
        return None
    try:
        return row if checksum == _sha256_text(canonical_json(row)) else None
    except (TypeError, ValueError):
        return None


def _envelope_id_of(rec: dict[str, Any]) -> str | None:
    return rec.get("envelope_id") or rec.get("event_id") or rec.get("outbox_id")


class EvidenceProjector:
    """Projector operating on one sqlite connection + one evidence volume path.

    Concurrency: a cross-process exclusive `flock` on the volume lock file is
    taken before read-modify-append.  Two workers therefore cannot append the
    same event twice even transiently.  On top of that, the strict scan provides
    event-id + checksum dedupe so an "append succeeded, delivered marker lost"
    (W3) is never re-appended.
    """

    def __init__(self, conn: sqlite3.Connection, history_path: Path,
                 lock_path: Path | None = None):
        self.conn = conn
        self.history_path = history_path
        self.lock_path = lock_path or (history_path.with_suffix(history_path.suffix + ".lock"))

    # ------------------------------------------------------------------ #
    def drain(self, limit: int = 50, *, append_impl=None,
              delivered_marker_impl=None) -> dict[str, Any]:
        """Drain up to `limit` PENDING outbox rows to the evidence volume.

        `append_impl` / `delivered_marker_impl` are injectable seams for fault
        injection tests (partial write, append raises, marker raises).  Each
        returns after one pass so the caller can drive it in a loop to model a
        stream; every iteration holds the whole-file lock.
        """
        result = {"drained": 0, "already_delivered": 0, "quarantines": [],
                  "errors": []}
        # Take the single-drainer cross-process lock for safety.
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.lock_path, "a+b") as lockf:
            _file_lock(lockf, exclusive=True)
            try:
                rows = self.conn.execute(
                    "SELECT outbox_id, continuity_tx_id, envelope_kind, envelope_id, "
                    "       payload_json, checksum, state "
                    "FROM history_outbox WHERE state='PENDING' "
                    "ORDER BY created_at LIMIT ?", (limit,)).fetchall()
                records, quarantines, trailing = scan_volume(self.history_path)
                result["quarantines"] = quarantines
                present = {_envelope_id_of(r): r for r in records
                           if _envelope_id_of(r)}
                # Repair a torn tail: a trailing byte sequence not ending in
                # newline is not an authoritative record.  We only truncate it if
                # it does not complete to a valid record (partial write / kill).
                if trailing:
                    tail_text = trailing.decode("utf-8", "replace")
                    if _strict_parse(tail_text) is None:
                        # partial/incomplete last record -> remove it, safe to
                        # re-append after explicit agreement the event id is the
                        # same; otherwise quarantine.
                        self._truncate_trailing(trailing)
                    else:
                        quarantines.append("valid_record_without_newline")
                for row in rows:
                    row = dict(row)
                    ev_id = row["envelope_id"]
                    if ev_id in present:
                        # W3: already fully appended; just mark delivered.
                        try:
                            # A previous append may have reached the file but
                            # reported fsync failure.  Re-confirm durability
                            # before trusting presence as W3.
                            self._fsync_existing_volume()
                            self._mark_delivered(row, delivered_marker_impl)
                            result["already_delivered"] += 1
                        except ProjectionError as e:
                            result["errors"].append(str(e))
                        continue
                    try:
                        self._append_one(row, append_impl)
                        self._mark_delivered(row, delivered_marker_impl)
                        result["drained"] += 1
                    except ProjectionError as e:
                        result["errors"].append(str(e))
            except QuarantineError as q:
                result["quarantines"].append(q.reason)
            finally:
                pass
        return result

    # ------------------------------------------------------------------ #
    def _append_one(self, row: dict[str, Any], append_impl=None) -> None:
        payload_raw = row["payload_json"]
        try:
            payload = json.loads(payload_raw) if payload_raw else {}
        except (json.JSONDecodeError, TypeError):
            payload = {}
        envelope = {
            "event_id": row["envelope_id"],
            "envelope_id": row["envelope_id"],
            "outbox_id": row["outbox_id"],
            "continuity_tx_id": row["continuity_tx_id"],
            "envelope_kind": row["envelope_kind"],
            "payload": payload,
        }
        line = json.dumps(envelope, ensure_ascii=False, sort_keys=True,
                          separators=(",", ":"))
        envelope_no_checksum = dict(envelope)
        checksum = _sha256_text(canonical_json(envelope_no_checksum))
        line_with_checksum = json.dumps({**envelope, "checksum": checksum},
                                        ensure_ascii=False, sort_keys=True,
                                        separators=(",", ":"))
        # If the custom append impl raises, emulate the W2/W3 crash behaviour.
        if append_impl is not None:
            append_impl(self.history_path, line_with_checksum + "\n")
        else:
            self.history_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.history_path, "a", encoding="utf-8", newline="\n") as h:
                h.write(line_with_checksum + "\n")
                h.flush()
                try:
                    os.fsync(h.fileno())
                except OSError as exc:
                    raise ProjectionError(
                        f"evidence fsync failed; outbox remains PENDING: "
                        f"{exc.__class__.__name__}") from exc

    def _fsync_existing_volume(self) -> None:
        """Confirm an already-present exact envelope is durable before W3."""
        try:
            with open(self.history_path, "rb") as f:
                os.fsync(f.fileno())
        except OSError as exc:
            raise ProjectionError(
                f"existing evidence fsync failed; outbox remains PENDING: "
                f"{exc.__class__.__name__}") from exc

    def _mark_delivered(self, row: dict[str, Any], delivered_marker_impl=None) -> None:
        from datetime import datetime, timezone
        at = datetime.now(timezone.utc).isoformat(timespec="seconds")
        if delivered_marker_impl is not None:
            # The seam may simulate "marker write lost / raises after a good file"
            delivered_marker_impl()
        with self.conn:
            self.conn.execute(
                "UPDATE history_outbox SET state='DELIVERED', delivered_at=? "
                "WHERE outbox_id=? AND state='PENDING'",
                (at, row["outbox_id"]))

    def _truncate_trailing(self, trailing: bytes) -> None:
        """Remove incomplete trailing bytes after the last newline.

        Invariant: `trailing` was reported by scan_volume as the bytes after the
        last `\\n`.  Removing that suffix truncates to the last complete record
        boundary and never deletes a committed full record."""
        if not self.history_path.exists():
            return
        raw = self.history_path.read_bytes()
        if not raw.endswith(trailing):
            raise QuarantineError("volume changed between scan and truncate")
        prefix = raw[: len(raw) - len(trailing)]
        with open(self.history_path, "wb") as f:
            f.write(prefix)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError as exc:
                raise QuarantineError(
                    f"torn-tail truncation fsync failed: {exc.__class__.__name__}") from exc
