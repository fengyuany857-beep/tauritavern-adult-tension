"""Phase 3C — deterministic continuity sync planner.

Turns an upstream-approved ContinuitySyncRequest into an ordered list of
PlanEffect objects with stable keys and a canonical plan digest.  This module is
*pure*: it makes no DB writes and no runtime calls.  Every downstream object id
is derived deterministically from the (tx, existing consequence payload), so a
replay of the same tx produces the same effects and the same authority rows.

Ownership filtering (Sol §13/§15/§18/§19/§20/§21):
- Refuses to turn a runtime drift into unseen story consequences; the payload
  author must already name the explicit historical consequence.
- Adult payloads may only be *historical event references / episode memory*;
  anything that would act as current-consent/grant/permission/safety/sexuality
  or intimacy-current authority is rejected.
- Trust/attraction can never synthesise a "now intimate" relationship use;
  knowledge writes are a single observer on CHARACTER plane.
"""
from __future__ import annotations
from typing import Any

from .contracts import (
    ContinuitySyncRequest, PlanEffect, SyncPlan, EffectKind,
    HISTORICAL_EFFECT_KINDS, canonical_json, canonical_effect_id,
    _sha256_text,
)
from ..validation import validate_continuity_fact_claim
from ..errors import AuthorityError

# Reserved current-authority keys that a payload may never carry (adult/safety/
# current-permission/shadow-store markers live here).
_FORBIDDEN_PAYLOAD_KEYS = {
    "review", "grant", "boundary", "safety", "sexuality_profile",
    "intimacy_current", "consent_current", "permission_current",
}

# Consequence payload kinds payloads may claim.  A caller that hands us a raw
# patch is an error: only named explicit historical kinds are accepted.
_ALLOWED_CLAIMED_KINDS = frozenset({
    EffectKind.EPISODE_APPEND, EffectKind.FACT_INSERT,
    EffectKind.FACT_SUPERSESSION, EffectKind.KNOWLEDGE_UPDATE,
    EffectKind.RELATIONSHIP_SEMANTIC_UPDATE,
    EffectKind.COMMITMENT_HISTORICAL_EFFECT,
    EffectKind.THREAD_HISTORICAL_EFFECT, EffectKind.EPISODE_LINK,
})


def payload_digest(payload: dict[str, Any]) -> str:
    return _sha256_text(canonical_json(payload))


def _stable_effect_key(kind: EffectKind, payload: dict[str, Any]) -> str:
    # Stable within (tx, kind) across replays: derived from the canonicalised
    # payload, not from a random id.  Two identical payload nodes collapse; two
    # distinct payload nodes always differ.
    return _sha256_text(f"{kind.value}\n{canonical_json(payload)}")


class PlanError(Exception):
    pass


def _check_ownership_attack(kind: EffectKind, payload: dict[str, Any]) -> None:
    """Reject payloads that would sneak in current-authority / story meaning."""
    lower = canonical_json(payload).lower()
    forbidden_substrings = (
        "consent", "grant_consent", "current_permission", "safe_limits",
        "sexuality_current", "intimacy_current", "current_boundary",
        "sexually_active", "write_current=true", "write_current\":true",
        "player_intend", "player_intends", "player_feel", "player_intention",
        "player_private", "player_mental", "private_intent", "secret_intent",
        "synthesize_dialogue",
    )
    for s in forbidden_substrings:
        if s.lower() in lower:
            raise PlanError(
                f"payload for {kind.value} touches current-authority/sovereignty "
                f"key {s!r}; not permitted to sync raw meaning")

    if kind == EffectKind.FACT_INSERT:
        try:
            validate_continuity_fact_claim(
                predicate=payload.get("predicate", ""),
                subject_ref=payload.get("subject_ref", ""),
                plane=payload.get("plane", "OBJECTIVE"),
                classification=payload.get("classification", "AUTHORITY"),
            )
        except AuthorityError as exc:
            raise PlanError(str(exc)) from exc

    # relationship / trust must stay historical-semantic
    if kind == EffectKind.RELATIONSHIP_SEMANTIC_UPDATE:
        if payload.get("classification", "").upper() in ("CURRENT", "AUTHORITY"):
            raise PlanError("relationship semantic effect may not be current authority")
        if payload.get("write_current") is True:
            raise PlanError("relationship semantic effect may not write current authority")
    if kind == EffectKind.KNOWLEDGE_UPDATE:
        if payload.get("plane", "CHARACTER") != "CHARACTER":
            raise PlanError("knowledge effect may not extend out of CHARACTER plane")
        if payload.get("grant_to_additional"):
            raise PlanError("knowledge effect may not widen to additional observers")
    # explicit-effect discipline: commitment/thread effects must name a concrete
    # allowed consequence; they can never fire a wild-card auto-advance.
    if kind == EffectKind.COMMITMENT_HISTORICAL_EFFECT:
        t = payload.get("effect_type")
        if t not in ("fulfilled", "broken", "callback", "disclosure",
                     "cancelled", "deferred"):
            raise PlanError(
                "commitment historical effect requires an explicit allowed "
                "consequence type (never a silent auto-resolve)")
    if kind == EffectKind.THREAD_HISTORICAL_EFFECT:
        t = payload.get("effect_type") or payload.get("consequence_kind")
        if t not in ("relevant_event", "reveal_condition_event",
                     "anti_merge_satisfied", "resolved_event", "progress"):
            raise PlanError(
                "thread historical effect requires an explicit relevant/reveal/"
                "resolved event type (never a guessed status advance)")


def build_plan(request: ContinuitySyncRequest) -> SyncPlan:
    """Deterministically compile an approved request into a SyncPlan.

    The planner refuses non-applied requests and refuses payloads whose claimed
    kind is outside the explicit set.
    """
    if request.runtime_outcome_class != "CONFIRMED_APPLIED":
        raise PlanError(
            f"cannot plan continuity sync for outcome {request.runtime_outcome_class!r}; "
            f"only CONFIRMED_APPLIED may enter sync (invariant 1)")

    # Validate every consequence against correctness/ownership before use.
    effects: list[PlanEffect] = []
    for node in request.consequences:
        kind_val = node.get("kind") or node.get("effect_kind")
        if kind_val is None:
            raise PlanError("consequence payload lacks an explicit kind")
        try:
            kind = EffectKind(kind_val)
        except ValueError:
            raise PlanError(f"consequence kind not recognised: {kind_val!r}")
        if kind not in _ALLOWED_CLAIMED_KINDS:
            raise PlanError(f"consequence kind {kind.value} is not a sync effect")
        payload = node.get("payload", {})
        if not isinstance(payload, dict):
            raise PlanError("consequence payload must be an object")
        _check_ownership_attack(kind, payload)
        effects.append(PlanEffect(
            effect_kind=kind,
            effect_key=_stable_effect_key(kind, payload),
            payload_digest=payload_digest(payload),
            payload=dict(payload),
            extra={"claimed_digests": _sha256_text(canonical_json({
                "kind": kind.value, "payload": payload}))},
        ))

    # Deterministic: collapse identical effect nodes so a duplicate payload
    # appended twice never yields two markers under the same UNIQUE key.
    seen: set = set()
    ordered: list[PlanEffect] = []
    for e in effects:
        key = (e.effect_kind.value if isinstance(e.effect_kind, EffectKind) else str(e.effect_kind),
               e.effect_key)
        if key in seen:
            continue
        seen.add(key)
        ordered.append(e)
    effects = ordered

    # A plan with no effects is allowed only when the tx marked nothing to
    # apply (e.g. episode memory only).  We still return a deterministic plan.
    return SyncPlan(
        continuity_tx_id=request.continuity_tx_id,
        branch_id=request.branch_id,
        effects=effects,
    )


def request_claimed_digest(request: ContinuitySyncRequest) -> str:
    """Digest that the request self-claims for its consequence list.

    This is what was staged at Phase 3A prepare as `staged_sync_digest` and
    re-verified before sync: it lets recovery detect a changed plan."""
    return _sha256_text(canonical_json({
        "tx": request.continuity_tx_id,
        "branch": request.branch_id,
        "plan_version": request.plan_version,
        "consequences": [
            {
                "kind": c.get("kind") or c.get("effect_kind"),
                "payload": c.get("payload", {}),
            }
            for c in request.consequences
        ],
    }))
