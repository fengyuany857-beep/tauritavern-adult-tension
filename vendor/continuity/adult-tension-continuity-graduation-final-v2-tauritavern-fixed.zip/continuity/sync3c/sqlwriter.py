"""Phase 3C — authoritative continuity SQL writer.

Applies one *historical consequence* PlanEffect inside the caller's open
SQLite transaction, reusing the same authority table column conventions as the
rest of the repo (Phase 2 retrieval seeds / context builder fixtures).  Nothing
here touches the vendor runtime, commit_turn, os.replace, named slots,
LLM/vector/adult evaluators, or any derived cache.  All object ids are derived
deterministically from the effect (tx + kind + key) so that a replay resolves
to the same authority rows: combined with the caller's effect markers, a sync
replay can never duplicate a logical effect.

Ownership rules enforced here (Sol §15/§18/§19/§20):
- RELATIONSHIP_SEMANTIC_UPDATE writes only *historical semantic* rows labelled
  classification=HISTORICAL (never a second `relationships.actual_relation`
  current authority).
- COMMITMENT_HISTORICAL_EFFECT / THREAD_HISTORICAL_EFFECT write only the exact
  consequence carried in the payload (explicit) and never auto-complete/infer.
- KNOWLEDGE_UPDATE grants one observer learned a proposition; it never widens
  the seeing set or flips Objective secrets / PLAYER_VISIBLE to an NPC.
- Adult payloads are only ever *historical event references / episode memory*,
  never current consent/grant/permission/safety/intimacy writes.
"""
from __future__ import annotations
import json
import sqlite3
from datetime import datetime, timezone
from typing import Any

from .contracts import (
    EffectKind,
    canonical_json,
    canonical_effect_id,
    _sha256_text,
    MAX_PAYLOAD_FIELD,
)
from ..validation import validate_continuity_fact_claim
from ..errors import AuthorityError


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _bounded_json(obj: Any) -> str:
    text = json.dumps(obj, sort_keys=True, ensure_ascii=False)
    if len(text) > MAX_PAYLOAD_FIELD:
        raise EffectApplyError(
            f"JSON payload exceeds safe bound ({len(text)} > {MAX_PAYLOAD_FIELD})")
    return text


class EffectApplyError(Exception):
    pass


def effect_sql(conn: sqlite3.Connection,
               kind: EffectKind | str,
               payload: dict[str, Any],
               scope: dict[str, Any]) -> dict[str, Any]:
    """Dispatch one PlanEffect payload onto the authority tables.

    `scope` carries deterministic context (continuity_tx_id, branch_id,
    effect_id, plan digest).  Returns a small bounded row of what it wrote."""
    k = kind.value if isinstance(kind, EffectKind) else str(kind)
    dispatcher = {
        EffectKind.EPISODE_APPEND.value: _episode_append,
        EffectKind.FACT_INSERT.value: _fact_insert,
        EffectKind.FACT_SUPERSESSION.value: _fact_supersede,
        EffectKind.KNOWLEDGE_UPDATE.value: _knowledge_update,
        EffectKind.RELATIONSHIP_SEMANTIC_UPDATE.value: _relationship_semantic,
        EffectKind.COMMITMENT_HISTORICAL_EFFECT.value: _commitment_effect,
        EffectKind.THREAD_HISTORICAL_EFFECT.value: _thread_effect,
        EffectKind.EPISODE_LINK.value: _episode_link,
    }
    fn = dispatcher.get(k)
    if fn is None:
        raise EffectApplyError(f"unsupported / forbidden effect kind for a plan node: {k}")
    trace = fn(conn, payload, scope)
    # Hard no-CoT guard: traces must not carry config/scratchpad content.
    return {key: val for key, val in trace.items() if not isinstance(val, str)
            or len(val) <= 400}


# --------------------------------------------------------------------------- #
# EPISODE_APPEND
# --------------------------------------------------------------------------- #
def _episode_append(conn: sqlite3.Connection, payload: dict[str, Any],
                    scope: dict[str, Any]) -> dict[str, Any]:
    eid = _entity_ref(scope["effect_id"], "ep")
    tx = scope["continuity_tx_id"]
    checksum = _sha256_text(canonical_json({
        "episode": payload.get("summary", ""), "tx": tx,
        "scene": payload.get("scene_ref", ""),
    }))
    _ensure_continuity_tx(conn, tx, scope["branch_id"])   # FK target first
    conn.execute(
        "INSERT OR IGNORE INTO episodes "
        "(episode_id, continuity_tx_id, branch_id, runtime_pre_hash, "
        " runtime_post_hash, history_pointer, checksum) VALUES (?,?,?,?,?,?,?)",
        (eid, tx, scope["branch_id"],
         payload.get("runtime_pre_hash"), payload.get("runtime_post_hash"),
         payload.get("history_pointer") or None, checksum))
    return {"episode_id": eid, "checksum": checksum}


def _ensure_continuity_tx(conn: sqlite3.Connection, tx: str, branch: str) -> None:
    # continuity_transactions is the pre-existing commit ledger (distinct from
    # the transaction_journal saga table).  Ensure an FK target exists so an
    # episode created under this tx can reference it; second write is a no-op.
    if conn.execute("SELECT 1 FROM continuity_transactions WHERE continuity_tx_id=?",
                    (tx,)).fetchone():
        return
    conn.execute(
        "INSERT OR IGNORE INTO continuity_transactions "
        "(continuity_tx_id, operation, observed_runtime_pre_hash, "
        " observed_runtime_post_hash, sidecar_state, created_at, committed_at, "
        " failure_reason) VALUES (?,?,?,?,?,?,?,?)",
        (tx, "phase3c_historical_sync", None, None, "HISTORICAL_SYNCED",
         _now(), None, None))


# --------------------------------------------------------------------------- #
# FACT_INSERT
# --------------------------------------------------------------------------- #
def _fact_insert(conn: sqlite3.Connection, payload: dict[str, Any],
                 scope: dict[str, Any]) -> dict[str, Any]:
    subject = payload.get("subject_ref", "")
    branch = scope["branch_id"]
    entity = conn.execute(
        "SELECT kind FROM entities WHERE entity_id=? AND branch_id=?",
        (subject, branch)).fetchone()
    is_player = bool(entity is not None and str(entity["kind"]).lower() == "player")
    try:
        validate_continuity_fact_claim(
            predicate=payload.get("predicate", ""), subject_ref=subject,
            plane=payload.get("plane", "OBJECTIVE"),
            classification=payload.get("classification", "AUTHORITY"),
            is_player_subject=is_player)
    except AuthorityError as exc:
        raise EffectApplyError(str(exc)) from exc
    fid = _entity_ref(scope["effect_id"], "fact")
    vf = int(payload.get("valid_from_turn") or scope.get("turn") or 1)
    conn.execute(
        "INSERT OR IGNORE INTO facts "
        "(fact_id, branch_id, subject_ref, predicate, object_json, plane, "
        " admission_state, truth_status, valid_from_turn, invalid_at_turn, "
        " recorded_at_turn, recorded_at, provenance_json, classification) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (fid, branch,
         subject, payload["predicate"],
         _bounded_json(payload.get("object", {})),
         payload.get("plane", "OBJECTIVE"),
         "COMMITTED", payload.get("truth_status", "ACTIVE"),
         vf, payload.get("invalid_at_turn"), vf,
         _now(),
         _bounded_json({"source": "phase3c", "tx": scope["continuity_tx_id"],
                        "plan_digest": scope.get("plan_digest")}),
         payload.get("classification", "AUTHORITY")))
    return {"fact_id": fid}


# --------------------------------------------------------------------------- #
# FACT_SUPERSESSION
# --------------------------------------------------------------------------- #
def _fact_supersede(conn: sqlite3.Connection, payload: dict[str, Any],
                    scope: dict[str, Any]) -> dict[str, Any]:
    old = payload.get("old_fact_id") or payload.get("old_fact_key")
    new = payload.get("new_fact_id") or payload.get("new_fact_key")
    if payload.get("old_fact_key") and not payload.get("old_fact_id"):
        old = _entity_ref(canonical_effect_id(EffectKind.FACT_INSERT,
                                              payload["old_fact_key"]), "fact")
    if payload.get("new_fact_key") and not payload.get("new_fact_id"):
        new = _entity_ref(canonical_effect_id(EffectKind.FACT_INSERT,
                                              payload["new_fact_key"]), "fact")
    if not old or not new:
        raise EffectApplyError("fact supersession requires old_fact_id/old_fact_key "
                               "and new_fact_id/new_fact_key")
    existed_old = conn.execute("SELECT 1 FROM facts WHERE fact_id=?", (old,)).fetchone()
    existed_new = conn.execute("SELECT 1 FROM facts WHERE fact_id=?", (new,)).fetchone()
    if not existed_old or not existed_new:
        raise EffectApplyError(f"fact supersession requires both facts present: {old},{new}")
    conn.execute(
        "UPDATE facts SET truth_status='SUPERSEDED', "
        "            invalid_at_turn=COALESCE(invalid_at_turn, ?) "
        " WHERE fact_id=?",
        (payload.get("invalid_at_turn"), old))
    conn.execute(
        "INSERT OR IGNORE INTO fact_supersessions "
        "(old_fact_id, new_fact_id, continuity_tx_id) VALUES (?,?,?)",
        (old, new, scope["continuity_tx_id"]))
    return {"old_fact_id": old, "new_fact_id": new}


# --------------------------------------------------------------------------- #
# KNOWLEDGE_UPDATE (single explicit observer, CHARACTER plane)
# --------------------------------------------------------------------------- #
def _knowledge_update(conn: sqlite3.Connection, payload: dict[str, Any],
                      scope: dict[str, Any]) -> dict[str, Any]:
    subj = payload["subject_ref"]
    prop = payload["proposition_ref"]
    if payload.get("plane", "CHARACTER") != "CHARACTER":
        raise EffectApplyError("knowledge update plane must be CHARACTER (observer-scoped); "
                               "never widen senses or flip a secret plane to an NPC")
    if payload.get("grant_to_additional", []):
        raise EffectApplyError("knowledge update may not widen to additional observers")
    kid = _entity_ref(scope["effect_id"], "know")
    conn.execute(
        "INSERT OR IGNORE INTO knowledge "
        "(knowledge_id, branch_id, subject_ref, proposition_ref, state, plane, "
        " source, promotion_basis, turn, provenance_json) "
        "VALUES (?,?,?,?,?,?,?,?,?,?)",
        (kid, scope["branch_id"], subj, prop,
         payload.get("state", "knows"), "CHARACTER",
         payload.get("source", "witnessed"),
         payload.get("basis", "confirmed_historical"),
         int(payload.get("turn", scope.get("turn") or 1)),
         _bounded_json({"source": "phase3c", "tx": scope["continuity_tx_id"],
                        "plan_digest": scope.get("plan_digest")})))
    return {"knowledge_id": kid, "subject_ref": subj, "proposition_ref": prop}


# --------------------------------------------------------------------------- #
# RELATIONSHIP_SEMANTIC_UPDATE (HISTORICAL semantic only)
# --------------------------------------------------------------------------- #
def _relationship_semantic(conn: sqlite3.Connection, payload: dict[str, Any],
                           scope: dict[str, Any]) -> dict[str, Any]:
    src = payload["source_ref"]
    tgt = payload["target_ref"]
    semantic_name = payload.get("semantic_name") or payload.get("consequence_kind")
    if not semantic_name:
        raise EffectApplyError("relationship semantic requires a named semantic consequence")
    if payload.get("write_current", False):
        raise EffectApplyError("relationship semantic effect may not write current authority")
    rel_id = payload.get("relationship_id") or (f"rel-{src}-{tgt}")
    if conn.execute("SELECT 1 FROM relationships WHERE relationship_id=?",
                    (rel_id,)).fetchone() is None:
        conn.execute(
            "INSERT OR IGNORE INTO relationships "
            "(relationship_id, branch_id, source_ref, target_ref, runtime_refs_json, "
            " public_surface, actual_relation, phase, provenance_json) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (rel_id, scope["branch_id"], src, tgt,
             "[]", payload.get("public_surface", ""),
             payload.get("relation_label", ""), payload.get("phase", "historical"),
             _bounded_json({"source": "phase3c", "tx": scope["continuity_tx_id"]})))
    dim = ("dim-3c-" + scope["effect_id"][:20])
    conn.execute(
        "INSERT OR IGNORE INTO relationship_dimensions "
        "(dimension_id, relationship_id, name, value_json, classification) "
        "VALUES (?,?,?,?,?)",
        (dim, rel_id, semantic_name,
         _bounded_json({"event_ref": payload.get("history_pointer"),
                        "occurred_at_turn": payload.get("turn")}),
         "HISTORICAL"))
    return {"relationship_id": rel_id, "semantic_name": semantic_name}


# --------------------------------------------------------------------------- #
# COMMITMENT_HISTORICAL_EFFECT (explicit consequence only)
# --------------------------------------------------------------------------- #
def _commitment_effect(conn: sqlite3.Connection, payload: dict[str, Any],
                       scope: dict[str, Any]) -> dict[str, Any]:
    cid = payload.get("commitment_id")
    if not cid:
        raise EffectApplyError("commitment effect requires an explicit commitment_id")
    effect_type = payload.get("effect_type")
    if effect_type not in ("fulfilled", "broken", "callback", "disclosure",
                           "cancelled", "deferred"):
        raise EffectApplyError(
            "commitment historical effect requires an explicit allowed consequence type")
    row = conn.execute("SELECT 1 FROM commitments WHERE commitment_id=?", (cid,)).fetchone()
    if row is None:
        raise EffectApplyError(f"commitment row must already exist: {cid}")
    new_status = payload.get("status_transition")
    allowed_statuses = {"open", "due", "kept", "resolved", "closed",
                        "deferred", "broken"}
    if new_status is not None:
        if new_status not in allowed_statuses:
            raise EffectApplyError(f"illegal commitment status '{new_status}'")
        conn.execute(
            "UPDATE commitments SET status=?, provenance_json=? WHERE commitment_id=?",
            (new_status,
             _bounded_json({"phase3c_tx": scope["continuity_tx_id"],
                            "effect": effect_type}), cid))
    return {"commitment_id": cid, "effect_type": effect_type,
            "status_changed": new_status if new_status is not None else None}


# --------------------------------------------------------------------------- #
# THREAD_HISTORICAL_EFFECT (relevant / reveal-event / explicit events only)
# --------------------------------------------------------------------------- #
def _thread_effect(conn: sqlite3.Connection, payload: dict[str, Any],
                   scope: dict[str, Any]) -> dict[str, Any]:
    tid = payload.get("thread_id")
    effect_type = payload.get("effect_type") or payload.get("consequence_kind")
    if not tid:
        raise EffectApplyError("thread effect requires an explicit thread_id")
    if conn.execute("SELECT 1 FROM threads WHERE thread_id=?",
                    (tid,)).fetchone() is None:
        raise EffectApplyError(f"thread row must already exist: {tid}")
    if effect_type not in ("relevant_event", "reveal_condition_event",
                           "anti_merge_satisfied", "resolved_event", "progress"):
        raise EffectApplyError(
            "thread historical effect only permits explicit relevant/reveal/resolved/"
            "progress event types, never a guessed status advance")
    new_state = payload.get("state_transition")
    allowed = {"active", "resolved", "closed", "dormant", "scripted_neutral",
               "secondary_thread"}
    if new_state is not None and new_state not in allowed:
        raise EffectApplyError(f"illegal thread status '{new_state}'")
    if new_state is not None:
        conn.execute(
            "UPDATE threads SET status=?, provenance_json=? WHERE thread_id=?",
            (new_state,
             _bounded_json({"phase3c_tx": scope["continuity_tx_id"],
                            "effect": effect_type}), tid))
    return {"thread_id": tid, "effect_type": effect_type,
            "status_changed": new_state if new_state is not None else None}


# --------------------------------------------------------------------------- #
# EPISODE_LINK
# --------------------------------------------------------------------------- #
def _episode_link(conn: sqlite3.Connection, payload: dict[str, Any],
                  scope: dict[str, Any]) -> dict[str, Any]:
    episode_id = payload.get("episode_id") or _entity_ref(scope["effect_id"], "ep")
    _ensure_continuity_tx(conn, scope["continuity_tx_id"], scope["branch_id"])
    conn.execute(
        "INSERT OR IGNORE INTO episodes "
        "(episode_id, continuity_tx_id, branch_id, runtime_pre_hash, "
        " runtime_post_hash, history_pointer, checksum) VALUES (?,?,?,?,?,?,?)",
        (episode_id, scope["continuity_tx_id"], scope["branch_id"], None, None,
         payload.get("history_pointer"), "x"))
    linked = 0
    for ent in payload.get("entity_ids", []):
        if conn.execute("SELECT 1 FROM entities WHERE entity_id=?", (ent,)).fetchone():
            conn.execute("INSERT OR IGNORE INTO episode_entity_links "
                         "(episode_id, entity_id) VALUES (?,?)", (episode_id, ent))
            linked += 1
    for f in payload.get("fact_ids", []):
        if conn.execute("SELECT 1 FROM facts WHERE fact_id=?", (f,)).fetchone():
            conn.execute("INSERT OR IGNORE INTO episode_fact_links "
                         "(episode_id, fact_id) VALUES (?,?)", (episode_id, f))
            linked += 1
    return {"episode_id": episode_id, "links": linked}


def _entity_ref(seed: str, prefix: str) -> str:
    return f"{prefix}-{_sha256_text(seed)[:24]}"
