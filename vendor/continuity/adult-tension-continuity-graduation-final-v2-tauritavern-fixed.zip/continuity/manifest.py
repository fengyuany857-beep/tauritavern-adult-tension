from __future__ import annotations
import json
from pathlib import Path
from .constants import AUDITED_VENDOR_HEAD, BUILDER_VERSION, MIGRATION_VERSION, SCHEMA_VERSION
from .errors import ManifestError
from .hashing import sha256_file

def build(db:Path, history:Path, key_hashes:dict[str,str]) -> dict:
    if not db.exists(): raise ManifestError('authority DB missing')
    return {'schema_version':SCHEMA_VERSION,'migration_version':MIGRATION_VERSION,'sidecar_db_sha256':sha256_file(db),'active_history_volume':history.name,'history_volume_checksum':sha256_file(history) if history.exists() else None,'builder_version':BUILDER_VERSION,'audited_adult_tension_head':AUDITED_VENDOR_HEAD,'audited_key_file_hashes':dict(sorted(key_hashes.items()))}
def write(path:Path,data:dict) -> None:
    path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(data,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def load(path:Path) -> dict:
    try: data=json.loads(path.read_text(encoding='utf-8'))
    except (OSError,json.JSONDecodeError) as e: raise ManifestError(str(e)) from e
    if data.get('audited_adult_tension_head') != AUDITED_VENDOR_HEAD: raise ManifestError('audited vendor HEAD mismatch')
    return data
