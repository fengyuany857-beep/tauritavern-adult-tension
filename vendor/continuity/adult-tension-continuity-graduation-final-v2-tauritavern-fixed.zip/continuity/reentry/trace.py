"""Activation trace ledger + deterministic digest for Re-entry (SPEC §22).

Every record pulled for a returning NPC must be explainable: why was that old
scene / commitment / thread loaded now that this character is back?  Traces live
only inside the ReentryPlan (EPHEMERAL / NON_AUTHORITY); none are written to the
sidecar ledger, and the digest is required to be deterministic across runs.
"""
from __future__ import annotations
import hashlib
import json

from .contracts import ActivationEntry, HardSoft

# ---------------------------------------------------------------------------
# Determinism helpers
# ---------------------------------------------------------------------------
def stable_digest(*parts) -> str:
    blob = json.dumps(list(parts), ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def activation_digest(entries) -> str:
    """Deterministic digest over the activation ledger (sorted, deduped)."""
    seen = []
    for e in entries:
        if not isinstance(e, ActivationEntry) and isinstance(e, dict):
            e = ActivationEntry(**e)
        seen.append({
            "id": e.activation_id,
            "src": e.source_ref,
            "type": e.source_type,
            "atype": e.activation_type.value if hasattr(e.activation_type, "value") else e.activation_type,
            "reason": e.reason,
            "hard": e.hard_or_soft.value if hasattr(e.hard_or_soft, "value") else str(e.hard_or_soft),
            "scene": e.relation_to_scene,
        })
    # sort_by stable key (id) for determinism
    seen.sort(key=lambda d: str(d["id"]))
    return stable_digest(seen)
