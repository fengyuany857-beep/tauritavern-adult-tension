"""Phase 2B-2 — Important NPC Re-entry + Commitment / Thread Activation.

Re-entry is *read-only orchestration*: it decides which already-committed
continuity records are worth surfacing now that an important NPC is back on
stage (or a long-open commitment/thread is being re-touched).  "Activation"
here strictly means *selected for a temporary Context Pack*, never a ledger
status mutation.

Every type in this module is pure data / a read-only plan object.  A
ReentryPlan is EPHEMERAL / NON_AUTHORITY: it carries references, reasons and
an activation trace, and — through ``plan.to_candidates()`` — feeds the SAME
ContextPackBuilder that did Phase 2B-1, so residency / budget / FAST scope /
reveal / anti_merge / adult-authority guards still apply unchanged.
"""
from __future__ import annotations
from dataclasses import dataclass, field, fields
from enum import Enum
from typing import Any


# --------------------------------------------------------------------------- #
# Enumerations
# --------------------------------------------------------------------------- #
class NpcClass(str, Enum):
    """Role weight read from the runtime NPC card (vendor role_level) or, when
    the card is unavailable, inferred conservatively from continuity `kind`.
    MINOR never triggers the heavy targeted DEEP recall path by default."""
    MAIN = "main"
    IMPORTANT_SUPPORTING = "important_supporting"
    MINOR = "minor"
    UNKNOWN = "unknown"


class ResolutionStatus(str, Enum):
    RESOLVED = "RESOLVED"
    AMBIGUOUS = "AMBIGUOUS"
    NOT_FOUND = "NOT_FOUND"
    RUNTIME_CARD_MISSING = "RUNTIME_CARD_MISSING"
    RUNTIME_HASH_CHANGED = "RUNTIME_HASH_CHANGED"
    BLOCKED = "BLOCKED"


class ReentryReason(str, Enum):
    """Why re-entry planning fired for this entity (see SPEC §6 triggers)."""
    PARTICIPANT_RETURN = "participant_return"
    QUERY_EXPLICIT_MENTION = "query_explicit_mention"
    ROUTER_DEEP_RESOLVED = "router_deep_resolved"
    SCENE_ABSENCE_THRESHOLD = "scene_absence_threshold"
    EXPLICIT_HISTORICAL_RECALL = "explicit_historical_recall"


class ActivationStatus(str, Enum):
    """Where an activated record sits relative to the *current* scene (never
    written back to the ledger)."""
    ACTIVE_NOW = "ACTIVE_NOW"
    RELEVANT = "RELEVANT"
    BACKGROUND = "BACKGROUND"
    NOT_ACTIVATED = "NOT_ACTIVATED"


class HardSoft(str, Enum):
    HARD = "HARD"
    SOFT = "SOFT"


class ReentryStatus(str, Enum):
    OK = "OK"
    PARTIAL = "PARTIAL"
    AMBIGUOUS = "AMBIGUOUS"
    ENTITY_NOT_FOUND = "ENTITY_NOT_FOUND"
    RUNTIME_CARD_MISSING = "RUNTIME_CARD_MISSING"
    RUNTIME_HASH_CHANGED = "RUNTIME_HASH_CHANGED"
    EVIDENCE_INSUFFICIENT = "EVIDENCE_INSUFFICIENT"
    BLOCKED = "BLOCKED"


class ReentryEpCategory(str, Enum):
    RECENT = "REENTRY_RECENT"
    RELATIONSHIP = "REENTRY_RELATIONSHIP"
    COMMITMENT = "REENTRY_COMMITMENT"
    THREAD = "REENTRY_THREAD"
    EVIDENCE = "REENTRY_EVIDENCE"


class ActivationKind(str, Enum):
    ANCHOR = "ANCHOR"
    KNOWLEDGE = "KNOWLEDGE"
    RELATIONSHIP = "RELATIONSHIP"
    COMMITMENT = "COMMITMENT"
    THREAD = "THREAD"
    EPISODE = "EPISODE"
    GUARD = "GUARD"
    RUNTIME_CARD = "RUNTIME_CARD"
    ABSENCE = "ABSENCE"
    REENTRY_VIEW = "REENTRY_VIEW"


# --------------------------------------------------------------------------- #
# Input request
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class ReentryRequest:
    """Read-only input describing an NPC that is back / being recalled.

    Callers supply either the stable runtime NPC id (preferred — used for a
    registry card lookup and an entity mapping by runtime_external_ref) or a
    free-text mention (resolved via confirmed aliases only, never guessed).
    """
    runtime_npc_id: str | None = None
    mention_text: str | None = None
    branch_id: str = "default"
    observer_entity_id: str | None = None
    # runtime participant ids currently on stage (already mapped to continuity)
    scene_runtime_ids: tuple[str, ...] = ()
    current_participant_entity_ids: tuple[str, ...] = ()
    query_text: str = ""
    explicit_historical: bool = False
    reentry_reason: ReentryReason | None = None
    # structured absence, if the caller tracks turn counters
    last_seen_turn: int | None = None
    event_turn: int | None = None
    absence_threshold: int = 30        # turns; >= triggers long-absence planning
    token_budget: int | None = None
    query_id: str = ""
    mode: str = "FAST"                 # routing decision.final_mode value


# --------------------------------------------------------------------------- #
# Resolver / card read results
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class EntityResolution:
    """Continuity-side resolution of the runtime NPC."

    Follows SPEC §8/§24/§25: never auto-merges, never resolves a merge_candidate,
    never picks among same-name entities with only lexical evidence."""
    resolution_status: ResolutionStatus
    entity_id: str | None = None
    runtime_npc_id: str | None = None
    runtime_card_ref: str | None = None      # stable path or runtime id referenced
    kind: str | None = None
    identity_status: str | None = None
    matched_by: str = ""                     # 'runtime_external_ref' | 'confirmed_alias'
    matched_candidates: tuple[str, ...] = ()
    reason: str = ""


@dataclass(frozen=True)
class RuntimeCardRead:
    """A read-only full-runtime-NPC-card snap with observed-hash stability
    (SPEC §9).  The observed hash is not a revision."""
    npc_id: str
    card_ref: str                    # stable id used to look up the full card
    observed_runtime_sha256: str
    npc_class: NpcClass
    card_fields: tuple[tuple[str, Any], ...] = ()   # deterministic ordered name->sanitized value
    absence_turns: int | None = None


# --------------------------------------------------------------------------- #
# Activation entries and trace
# --------------------------------------------------------------------------- #
@dataclass
class ActivationEntry:
    """Read-only decision that an already-committed record is active context for
    the returning entity (SPEC §22).  Never mutated back into the ledger."""
    activation_id: str
    target_entity_id: str
    source_ref: str
    source_type: str                 # ENTITY/FACT/KNOWLEDGE/RELATIONSHIP/COMMITMENT/THREAD/EPISODE/GUARD
    activation_type: ActivationKind
    relation_to_scene: str           # ACTIVE_NOW/RELEVANT/BACKGROUND/equivalent
    hard_or_soft: HardSoft
    reason: str
    relation_to_query: str = ""
    relationship_link: str | None = None
    commitment_link: str | None = None
    thread_link: str | None = None
    temporal_distance: str = ""      # "now" | "N_turns_ago" | "archival"
    included: bool = True
    exclusion_reason: str | None = None
    classification: str = "AUTHORITY_REFERENCE"
    plane: str = "OBJECTIVE"
    activation_status: ActivationStatus = ActivationStatus.RELEVANT
    activation_trace_refs: tuple[str, ...] = ()
    category: str = ""


# --------------------------------------------------------------------------- #
# Plan output
# --------------------------------------------------------------------------- #
@dataclass
class ReentryPlan:
    """EPHEMERAL / NON_AUTHORITY orchestration ledger for a single returning /
    recalled NPC (SPEC §5).  Its candidates are handed to the same
    ContextPackBuilder for residency/budget/filter/trace deciding the pack."""
    query_id: str = ""
    target_entity_id: str = ""
    runtime_npc_id: str = ""
    resolution_status: ResolutionStatus = ResolutionStatus.BLOCKED
    reentry_reason: str = ""
    absence_turns: int | None = None
    runtime_card_ref: str | None = None
    runtime_observed_sha256: str | None = None
    entity_anchor_refs: tuple[str, ...] = ()
    knowledge_refs: tuple[str, ...] = ()
    relationship_refs: tuple[str, ...] = ()
    commitment_refs: tuple[str, ...] = ()
    thread_refs: tuple[str, ...] = ()
    episode_refs: tuple[str, ...] = ()
    guard_refs: tuple[str, ...] = ()
    insufficiency: tuple[str, ...] = ()
    activation_traces: tuple[ActivationEntry, ...] = ()
    status: ReentryStatus = ReentryStatus.BLOCKED
    mode: str = "FAST"
    npc_class: str = NpcClass.UNKNOWN.value
    activation_statuses: tuple[str, ...] = ()
    semantic_digest: str = ""
    authoritativeness: str = "EPHEMERAL / NON_AUTHORITY"

    def as_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {}
        for f in fields(self):
            v = getattr(self, f.name)
            if f.name == "activation_traces":
                v = [t.__dict__ for t in v]
            elif isinstance(v, ResolutionStatus):
                v = v.value
            elif isinstance(v, ReentryStatus):
                v = v.value
            elif isinstance(v, tuple):
                v = list(v)
            elif isinstance(v, NpcClass):
                v = v.value
            d[f.name] = v
        return d
