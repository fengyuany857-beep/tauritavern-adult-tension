"""Re-entry Entity Resolution (read-only).

Given a returning / recalled runtime NPC, resolve it to its stable continuity
entity (SPEC §7/§8).  Rules enforced here, in priority order:

1. A stable continuity entity that already holds a ``runtime_external_ref``
   mapping to the runtime NPC id IS the identity (authoritative mapping) —
   never a lexical guess.
2. Otherwise resolve a free-text mention through **confirmed** aliases only.
3. A ``merge_candidate`` alias is never treated as confirmed (SPEC §24/§25).
4. Two-or-more continuity entities of the same canonical name with no stable
   context -> AMBIGUOUS (never auto-pick; never auto-merge).
5. Full runtime card is read by stable runtime id from the registry snapshot;
   the observed-file SHA-256 must be stable across the read (SPEC §9).  If the
   id is absent from the registry -> RUNTIME_CARD_MISSING (no card invented).
6. Naming/lookup never fabricates a runtime card from continuity.

Role weight (SPEC §6/§7 + §10 intro) is taken from the runtime card
``role_level`` when present; it is degraded to the continuity entity ``kind``
only when the card itself is unavailable AND we are still within a partial plan
(never pretending a missing card exists).
"""
from __future__ import annotations
import hashlib
import json
import sqlite3
from pathlib import Path
from typing import Any

from ..hashing import sha256_file
from .contracts import (
    EntityResolution, NpcClass, ResolutionStatus,
)


# Role-level vocabulary mirrored from the audited v3 runtime contract.
_MAIN_LABELS = {"main", "protagonist", "lead"}
_SUPPORT_LABELS = {"important_supporting", "supporting", "important_support",
                   "important", "secondary"}
_MINOR_LABELS = {"minor", "background", "extra", "bit", "walk_on"}


def classify_role(role: Any) -> NpcClass:
    """Map a runtime role_level (or a continuity kind fallback) to an NpcClass.

    Deterministic; unknown text -> NpcClass.UNKNOWN (never invents a weight).
    When both main and supporting are matched the main label wins."""
    if role is None:
        return NpcClass.UNKNOWN
    text = str(role).strip().lower()
    if not text:
        return NpcClass.UNKNOWN
    for tok in text.replace("-", " ").replace("_", " ").replace("/", " ").split():
        if tok in _MAIN_LABELS or text in _MAIN_LABELS:
            return NpcClass.MAIN
    for tok in text.replace("-", " ").replace("_", " ").replace("/", " ").split():
        if tok in _SUPPORT_LABELS or text in _SUPPORT_LABELS:
            return NpcClass.IMPORTANT_SUPPORTING
    for tok in text.replace("-", " ").replace("_", " ").replace("/", " ").split():
        if tok in _MINOR_LABELS or text in _MINOR_LABELS:
            return NpcClass.MINOR
    return NpcClass.UNKNOWN


class _ResolveDao:
    """Tiny read-only (query_only) SQLite accessor for the sidecar authority."""

    def __init__(self, base: Path):
        self.base = Path(base)
        self.conn = sqlite3.connect(str(self.base / "state" / "continuity.sqlite3"))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.execute("PRAGMA query_only=ON")

    def q(self, sql: str, params: tuple = ()) -> list:
        return list(self.conn.execute(sql, params))

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:  # pragma: no cover
            pass


class RuntimeCardReader:
    """Read-only, full-registry runtime NPC card fetch (SPEC §7/§9).

    Reads the *full* card from ``state["npcs"]`` by stable runtime id — NOT from
    the trimmed live_slice (which may drop off-stage supporting NPCs).  Computes
    an observed SHA-256 pre/post around the read; if the file changed while
    reading, resolution is RUNTIME_HASH_CHANGED (never a mixed snapshot).
    """

    def __init__(self, snapshot_path: Path):
        self.snapshot_path = Path(snapshot_path)

    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.snapshot_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError("runtime snapshot must be a JSON-subset mapping") from exc
        if not isinstance(data, dict):
            raise ValueError("runtime snapshot must be a JSON mapping")
        return data

    def read_card(self, runtime_npc_id: str, *, sha_required: bool = True) -> dict[str, Any]:
        """Return {stable, npc, hash, absent} or raise RuntimeHashChangedError /
        return absent marker.  sha_required=False supports a caller who already
        snapshotted a stable hash (degrades only when the file cannot change)."""
        pre = sha256_file(self.snapshot_path)
        data = self._load()
        post = sha256_file(self.snapshot_path)
        if sha_required and pre != post:
            raise RuntimeHashChangedError(runtime_npc_id, pre, post)
        for npc in data.get("npcs") or []:
            if isinstance(npc, dict) and npc.get("id") == runtime_npc_id:
                return {"stable": True, "npc": dict(npc), "hash": pre, "absent": False}
        return {"stable": False, "npc": None, "hash": pre, "absent": True}


class RuntimeHashChangedError(Exception):
    def __init__(self, runtime_npc_id: str, pre: str, post: str):
        super().__init__(f"runtime NPC card changed during read: {runtime_npc_id}")
        self.runtime_npc_id = runtime_npc_id
        self.pre = pre
        self.post = post


def _card_fields(npc: dict[str, Any]) -> tuple[tuple[str, Any], ...]:
    """Deterministic ordered subset of the NPC card *excluding* any runtime
    permission/authority fields (consent/grant/boundary/safety/intimacy) which
    remain entirely runtime authority.  Only identity/behavioural text is
    surfaced as reference material."""
    denylist_prefixes = ("consent", "grant", "boundary", "safety",
                         "sexuality", "intimacy", "permission")
    def _ok(k: str) -> bool:
        kk = k.lower()
        return not any(kk.startswith(t) for t in denylist_prefixes) and \
               "relationships.trust" not in kk
    safe = {k: v for k, v in (npc or {}).items() if _ok(k)}
    return tuple(sorted(safe.items(), key=lambda kv: str(kv[0])))


def resolve_runtime_entity(runtime_npc_id: str | None,
                           mention_text: str | None,
                           dao: _ResolveDao,
                           branch_id: str = "default") -> EntityResolution:
    """Stable runtime NPC id / mention -> continuity entity resolution.

    Priority: runtime_external_ref mapping (authoritative) > confirmed alias.
    Same-canonical-name multiple -> AMBIGUOUS.  merge_candidate -> not resolved.
    """

    def by_ref(rid: str):
        return dao.q(
            "SELECT * FROM entities WHERE runtime_external_ref=? AND branch_id=?",
            (rid, branch_id))

    def by_confirmed_alias(text: str):
        return dao.q(
            "SELECT e.* FROM entity_aliases a JOIN entities e "
            "ON e.entity_id=a.entity_id "
            "WHERE a.status='confirmed' AND e.branch_id=? AND a.alias=?",
            (branch_id, text))

    def by_name(text: str):
        # canonical_name lives in anchors_json; used for the same-name ambiguity
        rows = dao.q("SELECT * FROM entities WHERE branch_id=?", (branch_id,))
        out = []
        for r in rows:
            anchors = {}
            try:
                anchors = json.loads(r["anchors_json"] or "{}")
            except Exception:
                pass
            if str(anchors.get("canonical_name") or "") == text or r["entity_id"] == text:
                out.append(r)
        return out

    # ---- priority 1: authoritative runtime_external_ref mapping ------------
    matched_by = ""
    rows = []
    if runtime_npc_id:
        rows = by_ref(runtime_npc_id)
        matched_by = "runtime_external_ref"
        if not rows:
            # no continuity entity claims this runtime id; give an explicit
            # NOT_FOUND so the caller can short-circuit before guessing.
            return EntityResolution(ResolutionStatus.NOT_FOUND,
                                    runtime_npc_id=runtime_npc_id,
                                    reason="no continuity entity maps this stable runtime id")

    # ---- priority 2: confirmed alias resolution ---------------------------
    if not rows and mention_text:
        alias_rows = by_confirmed_alias(mention_text)
        distinct_alias = {str(r["entity_id"]) for r in alias_rows}
        if len(distinct_alias) == 1:
            return _mk_resolution(list(alias_rows)[0], runtime_npc_id, "confirmed_alias")
        if len(distinct_alias) > 1:
            return EntityResolution(ResolutionStatus.AMBIGUOUS,
                                    runtime_npc_id=runtime_npc_id,
                                    matched_candidates=tuple(sorted(distinct_alias)),
                                    reason="confirmed alias claimed by >1 continuity entity")
        # alias not confirmed: never use a merge_candidate as identity.
        merge = dao.q(
            "SELECT e.entity_id FROM entity_aliases a JOIN entities e "
            "ON e.entity_id=a.entity_id "
            "WHERE a.status='merge_candidate' AND e.branch_id=? AND a.alias=?",
            (branch_id, mention_text))
        if merge:
            return EntityResolution(ResolutionStatus.AMBIGUOUS,
                                    runtime_npc_id=runtime_npc_id,
                                    matched_candidates=(str(merge[0]["entity_id"]),),
                                    reason="merge_candidate alias claimed; not confirmed identity")

    # ---- name-only collision when no stable id provided --------------------
    if runtime_npc_id is None and mention_text and not rows:
        byname = by_name(mention_text)
        distinct = {str(r["entity_id"]) for r in byname}
        if len(distinct) > 1:
            return EntityResolution(ResolutionStatus.AMBIGUOUS,
                                    runtime_npc_id=None,
                                    matched_candidates=tuple(sorted(distinct)),
                                    reason="same display name maps to >1 continuity entity; no stable context")
        if len(distinct) == 1:
            (one,) = tuple(byname)
            return _mk_resolution(one, None, "canonical_name_singleton")
        # token-level name match is not used (no lexical auto-resolution).

    # ---- a single authoritative/existing mapping ---------------------------
    unr = {str(r["entity_id"]) for r in rows}
    if len(unr) == 1:
        return _mk_resolution(rows[0], runtime_npc_id, matched_by or "runtime_external_ref")

    return EntityResolution(ResolutionStatus.AMBIGUOUS,
                            runtime_npc_id=runtime_npc_id,
                            matched_candidates=tuple(sorted(unr)),
                            reason="multiplicity of entities matched")


def _mk_resolution(row: sqlite3.Row, runtime_npc_id: str | None,
                   matched_by: str) -> EntityResolution:
    eid = str(row["entity_id"])
    ref = row["runtime_external_ref"]
    if runtime_npc_id is None and ref:
        runtime_npc_id = str(ref)
    return EntityResolution(
        resolution_status=ResolutionStatus.RESOLVED,
        entity_id=eid, runtime_npc_id=runtime_npc_id,
        runtime_card_ref=eid, kind=row["kind"],
        identity_status=row["identity_status"],
        matched_by=matched_by,
        reason="stable continuity entity resolved",
    )
