"""Re-entry Guard assembly (SPEC §10/§16/§18/§19/§20).

These guards describe protections that apply to everything surfaced for a
returning NPC — they are *pack-level* and are ALSO enforced structurally by the
ContextPackBuilder negative guards (reveal gate record vs payload, anti-merge
individuality, adult-authority reference-only).  This module is the Plan-level
ledger of which guard protections are in force for a given entity.
"""
from __future__ import annotations
from .contracts import (
    ActivationEntry, ActivationKind, ActivationStatus, HardSoft,
)

# The emitted markers stay human/ledger level; the actual "do not reveal the
# payload / do not grant permission" enforcement lives in the builder filters.

# A re-entry plan must never *require* the returned NPC to advance the plot.
GUARD_NO_REQUIRED_PLOT_ACTION = "reentry_does_not_require_plot_action"
GUARD_ADULT_HISTORICAL_REF = "adult_historical_event_reference_only"
GUARD_ADULT_NO_CURRENT_PERMISSION = "adult_no_current_permission_synthesized"
GUARD_RUNTIME_TRUST_REFERENCE = "runtime_trust_reference_only_not_duplicated"
GUARD_PRESENTATION_RESTRICTED = "presentation_restricted"
GUARD_REVEAL_GATE_RECORD = "reveal_gate_record_only"
GUARD_ANTI_MERGE_NO_SYNTHESIS = "anti_merge_no_synthetic_merge"
GUARD_PLAYER_SOVEREIGNTY = "player_state_not_synthesized"
GUARD_RUNTIME_CARD_REF = "runtime_card_reference_only"


def plan_guards(*,
               adult_sensitive: bool,
               has_reveal_gate: bool,
               has_anti_merge: bool,
               player_in_scope: bool,
               runtime_trust_present: bool) -> tuple[ActivationEntry, ...]:
    """Compose the guard ActivationEntries that a plan should carry.

    ``adult_sensitive`` is a *metadata* hint only (target shares high-trust /
    attraction / historical intimacy with the player); the planner still never
    writes permission and the pack only surfaces observed-hash references.  The
    guards themselves are deterministic descriptions of the protections, and the
    pack-level builder filters enforce them."""
    out: list[ActivationEntry] = []

    def add(aid: str, hard: bool, reason: str, status: ActivationStatus):
        out.append(ActivationEntry(
            activation_id=aid, target_entity_id="", source_ref=aid,
            source_type="GUARD", activation_type=ActivationKind.GUARD,
            relation_to_scene="BACKGROUND", hard_or_soft=HardSoft.HARD if hard else HardSoft.SOFT,
            reason=reason, activation_status=status,
            classification="AUTHORITY_REFERENCE"))

    # A re-entry context never *forces* the NPC to deliver plot (SPEC §18).
    add("guard:no-required-plot-action", True,
        GUARD_NO_REQUIRED_PLOT_ACTION, ActivationStatus.BACKGROUND)
    # Adult: historical isn't current (SPEC §20).
    if adult_sensitive:
        add("guard:adult-historical-only", True,
            GUARD_ADULT_HISTORICAL_REF + " ; " + GUARD_ADULT_NO_CURRENT_PERMISSION,
            ActivationStatus.BACKGROUND)
    # Runtime trust must be echoed as a reference, never a second authority.
    if runtime_trust_present:
        add("guard:runtime-trust-reference", True,
            GUARD_RUNTIME_TRUST_REFERENCE, ActivationStatus.BACKGROUND)
    if has_reveal_gate:
        add("guard:reveal-gate-record", True,
            GUARD_REVEAL_GATE_RECORD, ActivationStatus.RELEVANT)
    if has_anti_merge:
        add("guard:anti-merge-no-synthesis", True,
            GUARD_ANTI_MERGE_NO_SYNTHESIS, ActivationStatus.RELEVANT)
    if player_in_scope:
        add("guard:player-sovereignty", True,
            GUARD_PLAYER_SOVEREIGNTY, ActivationStatus.BACKGROUND)
    add("guard:runtime-card-ref", True,
        GUARD_RUNTIME_CARD_REF, ActivationStatus.RELEVANT)
    return tuple(out)
