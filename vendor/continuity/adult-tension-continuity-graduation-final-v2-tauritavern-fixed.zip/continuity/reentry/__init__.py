"""Phase 2B-2 — Important NPC Re-entry + Commitment / Thread Activation
(read-only).

Public surface for building a :class:`ReentryPlan` for a returning NPC and
turning it into ContextCandidates that the Phase 2B-1 ContextPackBuilder keeps
governing (SPEC §21).  Everything here is read-only and EPHEMERAL /
NON_AUTHORITY.
"""
from .activator import ActivatorDao, ReentryActivator
from .contracts import (
    ActivationEntry, ActivationKind, ActivationStatus,
    EntityResolution, HardSoft, NpcClass, ReentryPlan, ReentryReason,
    ReentryRequest, ReentryStatus, ResolutionStatus,
)
from .guards import plan_guards
from .planner import (
    GLOBAL_EP_CAP, ReentryPlanner, ReentryPlannerError,
    plan_to_reentry_candidates, to_card_candidate,
)
from .resolver import RuntimeCardReader, RuntimeHashChangedError, resolve_runtime_entity
from .trace import activation_digest

__all__ = [
    "ReentryRequest", "ReentryPlan", "ReentryStatus", "ResolutionStatus",
    "EntityResolution", "NpcClass", "ActivationEntry", "ActivationKind",
    "ActivationStatus", "HardSoft", "ReentryReason",
    "ReentryPlanner", "ReentryPlannerError", "ReentryActivator", "ActivatorDao",
    "plan_guards", "resolve_runtime_entity", "RuntimeCardReader",
    "RuntimeHashChangedError", "plan_to_reentry_candidates",
    "to_card_candidate", "activation_digest", "GLOBAL_EP_CAP",
]
