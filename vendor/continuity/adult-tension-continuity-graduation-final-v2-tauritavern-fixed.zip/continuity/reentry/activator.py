"""Re-entry Activator — select already-committed continuity records for the
returning NPC (SPEC §11-§15).

Read-only selection *for the current temporary Context Pack*.  It never:
  * advances a ledger column (commitment.status / thread.status ...),
  * promotes knowledge state (does_not_know/partial/suspects/knows/false_belief
    are preserved verbatim),
  * copies runtime relation/trust as a second writable authority,
  * pulls another character's knowledge for the target, or a PLAYER_VISIBLE /
    AUTHOR note into an in-character target view.

Every selected record is emitted as an ActivationEntry so the ledger is fully
explainable.  Class bounds (knowledge/commitment/thread/episode counts) are
deterministic and configurable; nothing scans the whole timeline unbounded.
"""
from __future__ import annotations
import json
import sqlite3
from pathlib import Path

from .contracts import (
    ActivationEntry, ActivationKind, ActivationStatus, HardSoft,
)


class ActivatorDao:
    """Re-entry read-only DAO (query_only, no DDL/DML)."""

    def __init__(self, base: Path):
        self.base = Path(base)
        self.conn = sqlite3.connect(str(self.base / "state" / "continuity.sqlite3"))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.execute("PRAGMA query_only=ON")

    def q(self, sql: str, params: tuple = ()) -> list:
        return list(self.conn.execute(sql, params))

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:  # pragma: no cover
            pass


def _ser(v):
    return json.dumps(v, ensure_ascii=False, sort_keys=True)


class ReentryActivator:
    """Per-target activation orchestrator.  Deterministic; emits ActivationEntry
    lists grouped by kind (already surfaced in sorted order)."""

    def __init__(self, dao: ActivatorDao, *, branch_id: str = "default",
                 observer_entity_id: str | None = None,
                 mode: str = "FAST",
                 scene_participant_entity_ids: tuple[str, ...] = (),
                 query_entity_ids: tuple[str, ...] = (),
                 player_entity_id: str | None = None,
                 npc_class: str = "unknown",
                 absence_turns: int | None = None,
                 due_statuses: tuple[str, ...] = ("open", "due", "OPEN", "DUE",
                                                  "active", "ACTIVE"),
                 cap_recent_turns: int = 6,
                 cap_episode_each: int = 3,
                 max_episode_refs: int = 12,
                 cap_knowledge: int = 12):
        self.dao = dao
        self.branch = branch_id
        self.observer = observer_entity_id
        self.mode = mode.upper()
        self.scene = set(scene_participant_entity_ids or ())
        self.query_ents = set(query_entity_ids or ())
        self.player = player_entity_id
        self.npc_class = npc_class or "unknown"
        self.absence_turns = absence_turns
        self.due_statuses = due_statuses
        self.cap_recent_turns = cap_recent_turns
        self.cap_each = cap_episode_each
        self.max_episode_refs = max_episode_refs
        self.cap_knowledge = cap_knowledge

    # ------------------------------------------------------------------ #
    def anchors(self, target: str) -> list[ActivationEntry]:
        """Identity / non-capability / behaviour anchors (SPEC §10).

        HARD:
          - stable identity anchor (identity_status + kind)
          - every explicit non-capability / hard impossibility
        SOFT:
          - personality tendencies / voice / normal/stress notes surfaced from
            anchors_json (never mislabelled as objective hard truth).
        """
        rows = self.dao.q(
            "SELECT * FROM entities WHERE entity_id=? AND branch_id=?",
            (target, self.branch))
        out: list[ActivationEntry] = []
        for r in rows:
            kind = r["kind"]
            iid = r["identity_status"]
            eid = str(r["entity_id"])
            anchors = {}
            try:
                anchors = json.loads(r["anchors_json"] or "{}")
            except Exception:
                anchors = {}
            # HARD stable identity token
            out.append(ActivationEntry(
                activation_id=f"anc:{target}:identity",
                target_entity_id=target, source_ref=f"entity:{eid}",
                source_type="ENTITY", activation_type=ActivationKind.ANCHOR,
                relation_to_scene="ACTIVE_NOW", hard_or_soft=HardSoft.HARD,
                reason="stable identity anchor (kind=%s, identity_status=%s)" % (kind, iid),
                classification="AUTHORITY_REFERENCE", plane="OBJECTIVE",
                relation_to_query="target identity"))
            # HARD non-capabilities / impossibilities
            noncap = r["explicit_non_capabilities_json"] or "[]"
            try:
                noncap_list = json.loads(noncap) if isinstance(noncap, str) else list(noncap)
            except Exception:
                noncap_list = []
            if not isinstance(noncap_list, list):
                noncap_list = []
            for token in sorted({str(x) for x in noncap_list}):
                out.append(ActivationEntry(
                    activation_id=f"nc:{target}:{token}",
                    target_entity_id=target,
                    source_ref=f"entity-cap:{eid}:{token}",
                    source_type="ENTITY", activation_type=ActivationKind.ANCHOR,
                    relation_to_scene="RELEVANT", hard_or_soft=HardSoft.HARD,
                    reason="explicit non-capability / do-not-regress constraint",
                    classification="AUTHORITY_REFERENCE"))
            # SOFT behavioural tendencies from anchors (voice/personality etc.)
            soft_keys = (k for k in anchors if k not in ("canonical_name", "identity_status"))
            for key in sorted(soft_keys):
                val = anchors.get(key)
                if val in (None, ""):
                    continue
                label = str(val)
                if isinstance(val, dict):
                    label = _ser(val)
                elif not isinstance(val, str):
                    label = str(val)
                out.append(ActivationEntry(
                    activation_id=f"soft:{target}:{key}",
                    target_entity_id=target, source_ref=f"entity-soft:{eid}:{key}",
                    source_type="ENTITY", activation_type=ActivationKind.ANCHOR,
                    relation_to_scene="BACKGROUND", hard_or_soft=HardSoft.SOFT,
                    reason="behavioral tendency (soft, not hard truth)"))
        return out

    # ------------------------------------------------------------------ #
    def knowledge(self, target: str) -> list[ActivationEntry]:
        """Target-scoped character knowledge (SPEC §11).  Only rows whose
        subject_ref == target.  Knowledge *states* preserved verbatim."""
        out: list[ActivationEntry] = []
        rows = self.dao.q(
            "SELECT * FROM knowledge WHERE branch_id=? AND subject_ref=? "
            "AND plane='CHARACTER'",
            (self.branch, target))
        # deterministic; cap is a bound not a promotion
        for r in sorted(rows, key=lambda x: str(x["knowledge_id"]))[: self.cap_knowledge]:
            state = r["state"]
            prop = r["proposition_ref"]
            kid = str(r["knowledge_id"])
            hard = state in ("does_not_know",)   # explicit restriction is HARD guard
            reason = ("explicit does-not-know restriction" if state == "does_not_know"
                      else ("POV false belief (classification CHARACTER)"
                            if state == "false_belief"
                            else "target-scoped character knowledge"))
            plane = "CHARACTER"
            out.append(ActivationEntry(
                activation_id=f"kw:{kid}",
                target_entity_id=target, source_ref=kid,
                source_type="KNOWLEDGE", activation_type=ActivationKind.KNOWLEDGE,
                relation_to_scene="RELEVANT", hard_or_soft=HardSoft.HARD if hard else HardSoft.SOFT,
                reason=reason, plane=plane,
                activation_status=(ActivationStatus.ACTIVE_NOW
                                   if state in ("knows", "false_belief")
                                   else ActivationStatus.RELEVANT),
                relationship_link=f"prop:{prop}",
                classification="AUTHORITY_REFERENCE",
                activation_trace_refs=("observer_character",)))
        return out

    # ------------------------------------------------------------------ #
    def relationships(self, target: str) -> list[ActivationEntry]:
        """Relationship semantics for target vs player / current participants /
        query-relevant entities (SPEC §12).  Context only: fields from the
        continuity `relationships` row (public_surface/actual_relation/phase)
        plus refs — never runtime trust/permission as a second authority."""
        rows = self.dao.q(
            "SELECT * FROM relationships WHERE branch_id=? AND "
            "(source_ref=? OR target_ref=?)",
            (self.branch, target, target))
        out: list[ActivationEntry] = []
        for r in rows:
            s = str(r["source_ref"]); t = str(r["target_ref"])
            other = t if s == target else s
            # participant / query relevance
            relevant = (other == target or
                        (self.player is not None and other == self.player) or
                        other in self.scene or other in self.query_ents)
            rel_text = f"relationship {s}->{t} phase={r['phase']} public={r['public_surface']} actual={r['actual_relation']}"
            active_entities = self.scene | ({self.player} if self.player is not None else set())
            act_status = (ActivationStatus.ACTIVE_NOW if other in active_entities
                          else ActivationStatus.RELEVANT if relevant
                          else ActivationStatus.BACKGROUND)
            if not relevant:
                # unrelated offscreen relationship still *logically* excluded from
                # the pack but recorded so the trace explains why not surfaced.
                out.append(ActivationEntry(
                    activation_id=f"rel:{r['relationship_id']}",
                    target_entity_id=target, source_ref=str(r["relationship_id"]),
                    source_type="RELATIONSHIP",
                    activation_type=ActivationKind.RELATIONSHIP,
                    relation_to_scene="BACKGROUND", hard_or_soft=HardSoft.SOFT,
                    reason="unrelated/offscreen relationship (context only)",
                    activation_status=ActivationStatus.BACKGROUND,
                    included=False, exclusion_reason="offscreen_unrelated_relationship",
                    classification="AUTHORITY_REFERENCE",
                    relationship_link=f"{s}->{t}"))
                continue
            out.append(ActivationEntry(
                activation_id=f"rel:{r['relationship_id']}",
                target_entity_id=target, source_ref=str(r["relationship_id"]),
                source_type="RELATIONSHIP",
                activation_type=ActivationKind.RELATIONSHIP,
                relation_to_scene=act_status.value,
                relationship_link=f"{s}->{t}",
                hard_or_soft=HardSoft.SOFT,
                reason=f"relationship semantics {rel_text}",
                activation_status=act_status,
                classification="AUTHORITY_REFERENCE",
                plane="OBJECTIVE",
                activation_trace_refs=(r["relationship_id"],)))
        return out

    # ------------------------------------------------------------------ #
    def commitments(self, target: str) -> list[ActivationEntry]:
        """Open/due commitments involving target (SPEC §13).  Activation status
        is NOT_ACTIVATED/RELEVANT/ACTIVE_NOW but never written to status."""
        rows = self.dao.q("SELECT * FROM commitments WHERE branch_id=?", (self.branch,))
        out: list[ActivationEntry] = []
        for c in sorted(rows, key=lambda x: str(x["commitment_id"])):
            iss = str(c["issuer_ref"])
            try:
                ben = json.loads(c["beneficiary_refs_json"] or "[]")
            except Exception:
                ben = []
            if not isinstance(ben, list):
                ben = []
            ben_e = {str(x) for x in ben}
            inbound = (iss == target) or (target in ben_e)
            if not inbound:
                continue
            openq = c["status"] in self.due_statuses
            cid = str(c["commitment_id"])
            others = (ben_e | {iss}) - {target}          # counterparty side ids
            player_involved = bool(self.player and self.player in others)
            scene_involved = bool(others & (self.scene | {self.player}))
            if not openq:
                out.append(ActivationEntry(
                    activation_id=f"com:{cid}", target_entity_id=target,
                    source_ref=cid, source_type="COMMITMENT",
                    activation_type=ActivationKind.COMMITMENT,
                    relation_to_scene="BACKGROUND", hard_or_soft=HardSoft.SOFT,
                    reason="resolved/closed commitment (context only)", included=False,
                    exclusion_reason="not_open_or_due",
                    activation_status=ActivationStatus.NOT_ACTIVATED,
                    commitment_link=f"{iss}->{','.join(sorted(ben_e))}"))
                continue
            # SPEC §13: an unrelated off-screen commitment is not force-activated
            # for this return; it is recorded but excluded (never a leakage).
            if not (player_involved or scene_involved):
                out.append(ActivationEntry(
                    activation_id=f"com:{cid}", target_entity_id=target,
                    source_ref=cid, source_type="COMMITMENT",
                    activation_type=ActivationKind.COMMITMENT,
                    relation_to_scene="BACKGROUND", hard_or_soft=HardSoft.SOFT,
                    reason="open but offscreen-unrelated commitment (context only)",
                    included=False, exclusion_reason="offscreen_unrelated_commitment",
                    activation_status=ActivationStatus.BACKGROUND,
                    commitment_link=f"{iss}->{','.join(sorted(ben_e))}"))
                continue
            act = (ActivationStatus.ACTIVE_NOW if player_involved
                   else ActivationStatus.RELEVANT)
            out.append(ActivationEntry(
                activation_id=f"com:{cid}", target_entity_id=target,
                source_ref=cid, source_type="COMMITMENT",
                activation_type=ActivationKind.COMMITMENT,
                relation_to_scene=act.value,
                hard_or_soft=HardSoft.HARD if (act == ActivationStatus.ACTIVE_NOW) else HardSoft.SOFT,
                reason="open/due commitment engaging target",
                activation_status=act,
                commitment_link=f"{iss}->{','.join(sorted(ben_e))}",
                classification="AUTHORITY_REFERENCE"))
        return out

    # ------------------------------------------------------------------ #
    def threads(self, target: str) -> list[ActivationEntry]:
        """Target-linked thread + reveal/presentation/anti_merge (SPEC §14).
        Unmet-requires threads surface as a guard *only* (no reveal payload);
        anti-merge blocks are echoed individually (never merged).  Threads not
        linked to this target are left out entirely (unrelated offscreen)."""
        rows = self.dao.q("SELECT * FROM threads WHERE branch_id=?", (self.branch,))
        out: list[ActivationEntry] = []
        for th in rows:
            tid = str(th["thread_id"])
            gate = {}
            try:
                gate = json.loads(th["reveal_gate_json"] or "{}")
            except Exception:
                gate = {}
            requires = self.dao.q("SELECT ref FROM thread_requires WHERE thread_id=?",
                                  (tid,))
            block_refs = self.dao.q("SELECT blocked_ref FROM thread_anti_merge "
                                    "WHERE thread_id=?", (tid,))
            # Authoritative target linkage (SPEC §14): a thread is linked to this
            # target when its author / objective continuity state equals the
            # target.  No lexical guess of linkage.
            author_tied = (th["author_state"] is not None and str(th["author_state"]) == target)
            obj_tied = (th["objective_state"] is not None and str(th["objective_state"]) == target)
            target_linked = bool(author_tied or obj_tied)
            if not target_linked:
                continue
            # reveal gate: unmet requires -> a guard *record* (never payload).
            if gate:
                met = True
                for req in requires:
                    ref = req["ref"]
                    rows2 = self.dao.q(
                        "SELECT truth_status,admission_state FROM facts "
                        "WHERE fact_id=? AND branch_id=?",
                        (ref, self.branch))
                    if not rows2 or not (rows2[0]["admission_state"] == "COMMITTED"
                                         and rows2[0]["truth_status"]
                                         in ("ACTIVE", "ACTIVE_INTERPRETATION")):
                        met = False
                        break
                out.append(ActivationEntry(
                    activation_id=f"thread:guard:{tid}", target_entity_id=target,
                    source_ref=tid, source_type="THREAD",
                    activation_type=ActivationKind.THREAD,
                    relation_to_scene="RELEVANT", hard_or_soft=HardSoft.HARD,
                    reason="reveal gate: record only, payload withheld" if not met
                           else "thread reveal gate met",
                    thread_link=tid,
                    classification="AUTHORITY_REFERENCE",
                    included=True,
                    activation_status=ActivationStatus.RELEVANT))
            # anti-merge distinctness (target-linked only, never merged)
            for bk in block_refs:
                b = str(bk["blocked_ref"])
                out.append(ActivationEntry(
                    activation_id=f"am:{tid}-x-{b}", target_entity_id=target,
                    source_ref=b, source_type="THREAD",
                    activation_type=ActivationKind.THREAD,
                    relation_to_scene="RELEVANT", hard_or_soft=HardSoft.HARD,
                    thread_link=tid,
                    reason="anti-merge: thread %s must not be merged with %s" % (tid, b),
                    classification="AUTHORITY_REFERENCE",
                    activation_status=ActivationStatus.RELEVANT))
            # open/unresolved target-linked thread surfaces as context.
            if th["status"] in ("active", "open", "unresolved", "ACTIVE", "OPEN"):
                out.append(ActivationEntry(
                    activation_id=f"thread:{tid}", target_entity_id=target,
                    source_ref=tid, source_type="THREAD",
                    activation_type=ActivationKind.THREAD,
                    relation_to_scene="ACTIVE_NOW", hard_or_soft=HardSoft.SOFT,
                    thread_link=tid,
                    reason="open/unresolved thread context",
                    activation_status=(ActivationStatus.ACTIVE_NOW
                                       if th["status"] in ("active", "ACTIVE")
                                       else ActivationStatus.RELEVANT)))
        return out

    def episodes(self, target: str, categories) -> list[ActivationEntry]:
        """Episodic recall is capped & category-bucketed in the planner (it needs
        the retrieval Context + continuity-tx ordering).  See
        `planner._recall_episodes`.  Activator leaves this to the planner to
        avoid unbounded whole-timeline scans inside every single method."""
        return []

