"""Phase 2B-2 Re-entry Planner (SPEC §5-§28 & §32 PASS conditions).

``ReentryPlanner.plan(request, runtime_snapshot)`` resolves a returning /
recalled runtime NPC to its stable continuity entity, reads its *full* runtime
NPC card (registry lookup with observed-SHA-256 stability; SPEC §7/§9), and —
when the role warrants a targeted recall — loads its target-scoped continuity
anchors / knowledge / relationships / commitments / threads / episodes into an
EPHEMERAL :class:`ReentryPlan`.

The ReentryPlan is a *ledger*, never a second pack.  Followers convert it into
ContextCandidates with ``to_candidates(plan)`` and pass those into the existing
:class:`ContextPackBuilder` so the ONE residency / budget / FAST-scope / reveal /
anti_merge / adult-authority pipeline (SPEC §21) decides the actual pack.

Design constraints honoured here:
  * every SQLite handle opened is ``PRAGMA query_only`` (no authority mutation)
  * no runtime write / auto-promotion / auto-merge / LLM / vector / graph tool
  * no adult-permission synthesis (historical != current)
  * deterministic cap per recall category (GLOBAL_EP_CAP) — a huge absence-gap
    never dumps the full history
  * MINOR / UNKNOWN NPCs never default to a heavy DEEP recall (SPEC §6)
"""
from __future__ import annotations
import json
import sqlite3
from pathlib import Path
from typing import Any

from ..hashing import sha256_file
from ..routing.contracts import ContextCandidate, ResidencyTier
from .activator import ActivatorDao, ReentryActivator
from .contracts import (
    ActivationEntry, ActivationKind, ActivationStatus, HardSoft,
    NpcClass, ReentryRequest, ReentryPlan, ReentryStatus, ResolutionStatus,
)
from .guards import plan_guards
from .resolver import (_ResolveDao, classify_role, resolve_runtime_entity)
from .trace import activation_digest

HEAVY_CLASSES = frozenset({NpcClass.MAIN.value, NpcClass.IMPORTANT_SUPPORTING.value})

# Bounded per-category episode caps (SPEC §15/§35).
_EP_CAPS = {
    "REENTRY_RECENT": 3,
    "REENTRY_RELATIONSHIP": 3,
    "REENTRY_COMMITMENT": 3,
    "REENTRY_THREAD": 3,
    "REENTRY_EVIDENCE": 1,
}
GLOBAL_EP_CAP = 10
_RECENT_SCAN_WINDOW = 60          # bounded index window (never a full scan)


class _CandItem:
    """Synthetic read-only reference item compatible with the routing builder's
    candidate vocabulary.  It repeats the same *shape* as
    ``routing.builder._RefItem`` but lives here so re-entry planning has no
    private dependency.  Never claims an authority row / permission."""

    def __init__(self, item_id: str, source_type: str, source_ref: str,
                 content: str, classification: str, est: int, *,
                 plane: str = "OBJECTIVE", observer_scope=None,
                 temporal_scope: str = "", flags: tuple = ()):
        self.item_id = item_id
        self.source_type = source_type
        self.source_ref = source_ref
        self.content = content
        self.classification = classification
        self.authority_status = "AUTHORITY_REFERENCE"
        self.current_or_historical = "historical" if "reentry_episode" in str(flags) or "EPISODE" == source_type else "current"
        self.plane = plane
        self.observer_scope = observer_scope
        self.temporal_scope = temporal_scope
        self.provenance = "reference-only reentry"
        self.flags = flags
        self.estimated_token_cost = est
        self.rank_score = 0.0
        self.branch_id = "default"



class ReentryPlannerError(Exception):
    """Not an insufficiency: configuration misuse."""


def _deny_permission_fields(card: dict) -> tuple[tuple[str, Any], ...]:
    """Return deterministic ordered identity/behaviour card fields, dropping any
    runtime permission/authority field (consent/grant/boundary/safety/intimacy/
    trust) that stays runtime-owned.  Observed-hash is enough of a reference."""
    denied = ("consent", "grant", "boundary", "safety", "sexuality", "intimacy",
              "permission")
    clean: dict[str, Any] = {}
    for k, v in (card or {}).items():
        kk = str(k).lower().replace(" ", "").replace("_", "")
        if any(kk.startswith(t) for t in denied) or kk in ("relationships", "checkpoint"):
            continue
        clean[str(k)] = v
    return tuple(sorted(clean.items(), key=lambda kv: kv[0]))


class _CardRead:
    """Small immutable snapshot of a full-registry card read."""

    def __init__(self, status: str, card: dict | None = None, hashv: str | None = None):
        self.status = status            # 'ok' | 'absent' | 'hash_changed' | 'none'
        self.card = card if card else {}
        self.hash = hashv

    @property
    def role(self) -> str | None:
        return self.card.get("role_level") if self.card else None

    def classify(self, fallback: str | None) -> NpcClass:
        return classify_role(self.role or fallback or "unknown")


def _read_card(snapshot_path: Path, npc_id: str) -> _CardRead:
    """Registry read with observed file-SHA-256 pre/post stability (SPEC §9)."""
    path = Path(snapshot_path)
    if not path.is_file():
        return _CardRead("none")
    pre = sha256_file(path)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return _CardRead("none")
    post = sha256_file(path)
    if pre != post:
        return _CardRead("hash_changed", hashv=pre)
    for npc in data.get("npcs") or []:
        if isinstance(npc, dict) and str(npc.get("id")) == npc_id:
            return _CardRead("ok", card=dict(npc), hashv=pre)
    return _CardRead("absent", hashv=pre)


class ReentryPlanner:
    """Read-only per-NPC re-entry orchestrator."""

    def __init__(self, base: Path, *, important_absent_floor: int = 30,
                 due_statuses: tuple = ("open", "due", "OPEN", "DUE",
                                        "active", "ACTIVE")):
        self.base = Path(base)
        self.important_absent_floor = important_absent_floor
        self.due_statuses = due_statuses

    # ============================================================== #
    # public entry
    # ============================================================== #
    def plan(self, request: ReentryRequest,
             runtime_snapshot: Path | None,
             base: Path | None = None) -> ReentryPlan:
        base = base or self.base
        # --- 1. resolve stable continuity entity --------------------------
        res_row = self._resolve(base, request)
        status = res_row.resolution_status

        # --- 2. determine runtime npc id to read --------------------------
        npc_id = request.runtime_npc_id
        if not npc_id and res_row.runtime_npc_id:
            npc_id = str(res_row.runtime_npc_id)

        if status == ResolutionStatus.AMBIGUOUS:
            return self._plan_early(request, res=res_row, plan_status=ReentryStatus.AMBIGUOUS,
                                    npc_class=NpcClass.UNKNOWN.value,
                                    reason="entity resolution ambiguous: no auto-select / merge")
        if status == ResolutionStatus.NOT_FOUND:
            return self._plan_early(request, res=res_row, plan_status=ReentryStatus.ENTITY_NOT_FOUND,
                                    npc_class=NpcClass.UNKNOWN.value,
                                    reason="no stable continuity entity maps this runtime NPC/mention")

        # --- 3. read runtime card w/ hash stability ------------------------
        if runtime_snapshot is None:
            return self._plan_early(request, res=res_row,
                                    plan_status=ReentryStatus.RUNTIME_CARD_MISSING,
                                    npc_class=NpcClass.UNKNOWN.value,
                                    reason="no runtime snapshot: cannot verify full card; continuity noted only")
        card = _read_card(runtime_snapshot, npc_id)
        if card.status == "hash_changed":
            return self._plan_early(request, res=res_row,
                                    plan_status=ReentryStatus.RUNTIME_HASH_CHANGED,
                                    npc_class=NpcClass.UNKNOWN.value,
                                    reason="runtime snapshot hash changed during card read",
                                    card_hash=card.hash)
        if card.status == "absent":
            # continuity anchors may note who this identity was historically,
            # but never pretend a current runtime card exists (SPEC §8/§23).
            return self._plan_early(request, res=res_row,
                                    plan_status=ReentryStatus.RUNTIME_CARD_MISSING,
                                    npc_class=NpcClass.UNKNOWN.value,
                                    reason="runtime NPC card missing from registry")

        npc_class = card.classify(res_row.kind)
        absence = self._absence(request)

        # --- 4. heavy / thin gating -----------------------------------------
        depth = self._depth(request, npc_class, absence)
        # MINOR / UNKNOWN default to a thin (anchors-only) plan.
        thin = npc_class.value not in HEAVY_CLASSES

        # --- 5. activate -----------------------------------------------------
        return self._activate(base, request, res_row, npc_class, card,
                              absence, thin, depth, reason="re-entry planning completed")

    # ============================================================== #
    # helpers
    # ============================================================== #
    def _resolve(self, base, request):
        dao = _ResolveDao(base)
        try:
            return resolve_runtime_entity(request.runtime_npc_id,
                                          request.mention_text,
                                          dao, request.branch_id)
        finally:
            dao.close()

    @staticmethod
    def _absence(request: ReentryRequest) -> int | None:
        if request.last_seen_turn is None or request.event_turn is None:
            return None
        return max(0, request.event_turn - request.last_seen_turn)

    def _depth(self, req: ReentryRequest, npc_class: NpcClass,
               absence: int | None) -> int:
        """Recall breadth (SPEC §17+§35 use a bounded cap, not the gap)."""
        if npc_class == NpcClass.MAIN:
            return 2
        if npc_class == NpcClass.IMPORTANT_SUPPORTING:
            if absence is not None and absence >= self.important_absent_floor:
                return 2
            return 1
        # MINOR / UNKNOWN: thin by default; an explicit historical ask deepens to
        # anchor-level but never a heavy targeted recall.
        return 1 if req.reentry_reason == "explicit_historical_recall" else 0

    # ============================================================== #
    # activation assembly
    # ============================================================== #
    def _activate(self, base, req, res, npc_class, card, absence,
                  thin: bool, depth: int, reason: str) -> ReentryPlan:
        dao = ActivatorDao(base)
        try:
            target = res.entity_id or ""
            player_id = self._player_entity(dao)
            act = ReentryActivator(
                dao, branch_id=req.branch_id, observer_entity_id=req.observer_entity_id,
                mode=str(req.mode or "DEEP").upper(),
                scene_participant_entity_ids=tuple(req.current_participant_entity_ids),
                player_entity_id=player_id, npc_class=npc_class.value,
                absence_turns=absence)

            anchors = act.anchors(target)
            traces: list[ActivationEntry] = list(anchors)
            if not thin and target:
                traces += act.knowledge(target)
                traces += act.relationships(target)
                traces += act.commitments(target)
                traces += act.threads(target)
                traces += self._episodes(base, dao, req, target, player_id, depth)

            guards = self._guards(base, dao, req, target, traces)

            keep = [e for e in traces if e.included]
            full = list(keep) + [g for g in guards if g.included]
            anchor_refs = tuple(sorted({e.source_ref for e in anchors if e.included}))
            knowledge_refs = tuple(sorted({e.source_ref for e in keep if e.activation_type == ActivationKind.KNOWLEDGE}))
            relationship_refs = tuple(sorted({e.source_ref for e in keep if e.activation_type == ActivationKind.RELATIONSHIP}))
            commitment_refs = tuple(sorted({e.source_ref for e in keep if e.activation_type == ActivationKind.COMMITMENT}))
            thread_refs = tuple(sorted({e.source_ref for e in keep if e.activation_type == ActivationKind.THREAD}))
            episode_refs = tuple(sorted({e.source_ref for e in keep if e.activation_type == ActivationKind.EPISODE}))
            guard_refs = tuple(sorted({e.source_ref for e in guards}))
            digest = activation_digest(full)

            plan = ReentryPlan(
                query_id=req.query_id,
                target_entity_id=target,
                runtime_npc_id=res.runtime_npc_id or req.runtime_npc_id or "",
                resolution_status=res.resolution_status,
                reentry_reason=reason,
                absence_turns=absence,
                runtime_card_ref=res.runtime_npc_id,
                runtime_observed_sha256=card.hash,
                entity_anchor_refs=anchor_refs,
                knowledge_refs=knowledge_refs,
                relationship_refs=relationship_refs,
                commitment_refs=commitment_refs,
                thread_refs=thread_refs,
                episode_refs=episode_refs,
                guard_refs=guard_refs,
                activation_traces=tuple(full),
                status=ReentryStatus.OK,
                mode=str(req.mode or "DEEP").upper(),
                npc_class=npc_class.value,
                semantic_digest=digest,
            )
            return plan
        finally:
            dao.close()

    def _player_entity(self, dao: ActivatorDao) -> str | None:
        rows = dao.q("SELECT entity_id FROM entities WHERE kind='player' AND branch_id=?",
                     ("default",))
        return str(rows[0]["entity_id"]) if rows else None

    def _guards(self, base, dao, req, target, traces) -> list:
        reveal = any(e.activation_type == ActivationKind.THREAD and
                     "reveal" in (e.reason or "").lower() for e in traces)
        antimer = any(e.activation_id.startswith("am:") for e in traces)
        # adult_sensitive as a *metadata hint*: high trust/attraction dimension.
        adult_sensitive = False
        for e in traces:
            if e.activation_type == ActivationKind.RELATIONSHIP:
                adult_sensitive = True   # relationship semantics present => hint
                break
        return list(plan_guards(adult_sensitive=adult_sensitive,
                                has_reveal_gate=reveal, has_anti_merge=antimer,
                                player_in_scope=True, runtime_trust_present=True))

    # ----- episode recall (capped across categories; deterministic) --------
    def _episodes(self, base, dao, req, target, player_id, depth) -> list:
        if depth <= 0:
            return []
        rows = dao.q(
            "SELECT e.episode_id, e.continuity_tx_id, t.created_at "
            "FROM episodes e LEFT JOIN continuity_transactions t "
            "ON t.continuity_tx_id=e.continuity_tx_id "
            "WHERE e.branch_id=? ORDER BY COALESCE(t.created_at,'') DESC",
            (req.branch_id,))
        out: list = []
        counted = {"REENTRY_RECENT": 0}
        # bounded recency window (never a full-history scan)
        for r in rows[: _RECENT_SCAN_WINDOW]:
            if counted["REENTRY_RECENT"] >= _EP_CAPS["REENTRY_RECENT"]:
                break
            ep = str(r["episode_id"])
            if not self._episode_involves(dao, ep, target):
                continue
            out.append(self._episode_entry(req, target, ep, "REENTRY_RECENT",
                                           "recent shared scene"))
            counted["REENTRY_RECENT"] += 1
            if len(out) >= GLOBAL_EP_CAP:
                break
        return out

    def _episode_involves(self, dao, ep, target):
        hit = dao.q("SELECT 1 FROM episode_entity_links WHERE episode_id=? AND entity_id=? LIMIT 1",
                    (ep, target))
        return bool(hit)

    @staticmethod
    def _episode_entry(req, target, ep, category, why) -> ActivationEntry:
        return ActivationEntry(
            activation_id=f"ep:{category}:{ep}",
            target_entity_id=target, source_ref=ep, source_type="EPISODE",
            activation_type=ActivationKind.EPISODE,
            relation_to_scene="BACKGROUND", hard_or_soft=HardSoft.SOFT,
            reason=why,
            activation_status=ActivationStatus.BACKGROUND,
            activation_trace_refs=(category,),
            category=category, classification="AUTHORITY_REFERENCE")

    # ----- early-exit plan ---------------------------------------------------
    def _plan_early(self, request, res, plan_status: ReentryStatus,
                    npc_class: str, reason: str,
                    card_hash: str | None = None) -> ReentryPlan:
        return ReentryPlan(
            query_id=request.query_id,
            target_entity_id="",
            runtime_npc_id=request.runtime_npc_id or (res.runtime_npc_id or "") if res else request.runtime_npc_id or "",
            resolution_status=res.resolution_status,
            reentry_reason=reason,
            absence_turns=request.last_seen_turn if request.last_seen_turn else None,
            runtime_card_ref=None,
            runtime_observed_sha256=card_hash,
            status=plan_status, mode=str(request.mode or "FAST").upper(),
            npc_class=npc_class,
            semantic_digest="", activation_traces=(),)


def to_card_candidate(plan: ReentryPlan, *, est_token: int = 12) -> ContextCandidate | None:
    """Return a ContextCandidate carrying the plan's runtime-card reference, or
    None when there is nothing to pin (no card / hash mismatch / not resolved).

    Lane ``reentry_runtime_card`` (HOT hard) so the returning character's full
    runtime card presence is a *reference* the decision model sees once a
    re-entry is planned."""
    if plan.runtime_observed_sha256 is None or not plan.runtime_npc_id:
        return None
    content = ("runtime NPC card reference (read-only observed-hash): %s for "
               "stable runtime id %s" % (plan.runtime_observed_sha256[:16],
                                         plan.runtime_npc_id))
    ref = _CandItem(plan.runtime_npc_id + ":card", "ENTITY", plan.runtime_npc_id,
                    content, "AUTHORITY_REFERENCE", 12)
    return ContextCandidate(item=ref, meta={"ctx": "reentry_runtime_card",
                                            "hard": True},
                            hard_pin=True,
                            classification="AUTHORITY_REFERENCE",
                            activation_reason="returning NPC runtime card reference")


def _entry_lane(e: ActivationEntry) -> str:
    """Pick the single residency lane for an ActivationEntry so the routing
    builder classifies with the SAME authority maps (SPEC §21).  All returned
    lane names exist in ``routing.residency`` (the new reentry_* entries or the
    pre-existing warm ``nearby_commitment`` / ``relationship_semantics``)."""
    t = e.activation_type
    if t == ActivationKind.ANCHOR:
        if e.hard_or_soft == HardSoft.HARD:
            if e.activation_id.startswith("nc:") or "non-capability" in (e.reason or "").lower():
                return "reentry_noncapability"
            return "reentry_identity"
        return "reentry_soft_anchor"
    if t == ActivationKind.KNOWLEDGE:
        return "reentry_knowledge"
    if t == ActivationKind.RELATIONSHIP:
        return "reentry_relationship"
    if t == ActivationKind.COMMITMENT:
        if e.activation_status == ActivationStatus.ACTIVE_NOW:
            return "reentry_commitment_due"
        return "nearby_commitment"
    if t == ActivationKind.THREAD:
        if e.activation_id.startswith("am:"):
            return "reentry_anti_merge_guard"
        if "reveal gate" in (e.reason or "").lower():
            return "reentry_reveal_gate_record"
        return "reentry_thread"
    if t == ActivationKind.GUARD:
        return "reentry_guard"
    if t == ActivationKind.EPISODE:
        return "reentry_episode"
    return "reentry_soft_anchor"


def plan_to_reentry_candidates(plan: ReentryPlan,
                               est=None) -> tuple[ContextCandidate, ...]:
    """Convert a completed ReentryPlan into a deterministic tuple of
    ContextCandidates ready for :meth:`ContextPackBuilder.build` (SPEC §21).

    Every *included* activation becomes one candidate whose lane is derived by
    :func:`_entry_lane` so the builder's residency / budget / FAST-scope /
    anti-bypass negative guards run on the SAME dataset.  GUARD entries are all
    hard HOT (they are pack-level instructions, never plot/payload).
    """
    from ..retrieval import ApproximateTokenEstimator
    from ..routing.contracts import ContextCandidate as _CC
    est = est or ApproximateTokenEstimator()
    out: list[ContextCandidate] = []
    seen: set[str] = set()
    for e in plan.activation_traces:
        if not e.included:
            continue
        lane = _entry_lane(e)
        source_type = e.source_type
        content = ("%s:%s %s" % (e.source_type, e.source_ref, e.reason)).strip()
        hard = e.hard_or_soft == HardSoft.HARD and e.activation_type in (
            ActivationKind.ANCHOR, ActivationKind.THREAD, ActivationKind.GUARD,
            ActivationKind.COMMITMENT)
        is_ep = e.activation_type == ActivationKind.EPISODE
        epoch = "historical" if is_ep else "current"
        item_id = e.activation_id
        if item_id in seen:
            continue
        seen.add(item_id)
        plane = "CHARACTER" if e.activation_type == ActivationKind.KNOWLEDGE and e.plane == "CHARACTER" else (
            "OBJECTIVE")
        ref = _CandItem(item_id, source_type, e.source_ref, content,
                        "AUTHORITY_REFERENCE", est.estimate(content),
                        plane=plane, temporal_scope=epoch,
                        flags=("EPISODE",) if is_ep else ())
        out.append(_CC(item=ref, meta={"ctx": lane, "hard": bool(hard)},
                       hard_pin=bool(hard), classification="AUTHORITY_REFERENCE",
                       activation_reason=e.reason,
                       trace_refs=e.activation_trace_refs))
    return tuple(out)
