from __future__ import annotations
import math
from abc import ABC, abstractmethod


class TokenEstimator(ABC):
    @abstractmethod
    def estimate(self, text: str) -> int:
        raise NotImplementedError


class ApproximateTokenEstimator(TokenEstimator):
    """Deterministic approximation. ASCII ~4 chars/token; CJK ~1 char/token.
    Always marked estimated; never claims a model-tokenizer contract."""

    def estimate(self, text: str) -> int:
        ascii_chars = 0
        cjk_chars = 0
        for ch in text:
            if ch == "\n" or ch == "\t":
                continue
            code = ord(ch)
            if code <= 0x2E7F:
                ascii_chars += 1
            else:
                cjk_chars += 1
        return max(1, cjk_chars + math.ceil(ascii_chars / 4.0))
