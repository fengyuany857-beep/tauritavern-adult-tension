"""Read-only append-only history evidence retrieval with checksum verification."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any

from ..history import verify_line
from .base import RetrievalItem, RetrievalQuery, RetrievalStatus, SourceType
from .retriever import Context, RetrieverBase


def _envelopes(base: Path):
    for path in sorted(base.glob("history/*.jsonl")):
        if not path.exists():
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            row["_path"] = path
            yield path, line, row


class EvidenceRetriever(RetrieverBase):
    name = "EvidenceRetriever"
    score_kind = "evidence"

    def _candidates(self, query: RetrievalQuery, ctx: Context) -> list[tuple[RetrievalItem, dict[str, Any]]]:
        out: list[tuple[RetrievalItem, dict[str, Any]]] = []
        est = ctx.estimator
        for path, line, env in _envelopes(ctx.base):
            checksum_ok = verify_line(line)
            matches = True
            if query.episode_id and env.get("episode_id") != query.episode_id:
                matches = False
            if query.scene_id and env.get("scene_id") != query.scene_id:
                matches = False
            if query.participant_id and query.participant_id not in (env.get("participants") or []):
                matches = False
            if query.turn_range:
                start = env.get("turn_start")
                end = env.get("turn_end")
                lo, hi = query.turn_range
                matches = matches and start is not None and end is not None and start <= hi and end >= lo
            if not matches:
                continue
            eid = str(env.get("episode_id") or env.get("scene_id") or "ev")
            clean = {k: v for k, v in env.items() if k != "_path"}
            content = json.dumps(clean.get("payload", clean.get("summary", clean)), ensure_ascii=False, sort_keys=True)
            item = RetrievalItem(
                item_id=eid, source_type=SourceType.HISTORICAL_EVIDENCE, source_ref=eid,
                classification=str(env.get("payload_classification", "HISTORICAL_EVIDENCE")),
                authority_status="HISTORICAL", branch_id=str(env.get("branch_id", "default")),
                plane="OBJECTIVE", observer_scope=None,
                temporal_scope=f"{env.get('turn_start')}..{env.get('turn_end')}",
                current_or_historical="historical", content=content,
                provenance=f"{path.name}:{env.get('checksum', '')}",
                estimated_token_cost=est.estimate(content),
            )
            meta = {
                "classification": item.classification, "truth_status": "HISTORICAL_FACT",
                "valid_from_turn": env.get("turn_start"), "invalid_at_turn": None,
                "branch_id": item.branch_id, "corrupt": not checksum_ok,
                "source_type": item.source_type,
            }
            out.append((item, meta))
        return out

    def _status(self, query: RetrievalQuery, items, traces, insufficiency) -> RetrievalStatus:
        if any(not t.included and t.exclusion_reason and "corrupt" in t.exclusion_reason for t in traces):
            return RetrievalStatus.EVIDENCE_CORRUPT
        if query.exact_evidence_required and not items:
            return RetrievalStatus.EVIDENCE_INSUFFICIENT
        return super()._status(query, items, traces, insufficiency)
