"""Bitemporal retrieval: as_of_event vs as_known_at."""
from __future__ import annotations
from typing import Any

from .base import RetrievalItem, RetrievalQuery, SourceType
from .retriever import Context, RetrieverBase, SqlMixin
from .ledger import fact_content
from ..validation import (is_runtime_owned_predicate,
                          is_player_internal_predicate, looks_like_player_ref)


class TemporalRetriever(RetrieverBase, SqlMixin):
    name = "TemporalRetriever"
    score_kind = "temporal"

    def _candidates(self, query: RetrievalQuery, ctx: Context) -> list[tuple[RetrievalItem, dict[str, Any]]]:
        out: list[tuple[RetrievalItem, dict[str, Any]]] = []
        est = ctx.estimator
        turn = query.event_turn
        known_at = getattr(query, "as_known_at", None)
        rows = self._rows(ctx, "SELECT * FROM facts WHERE admission_state='COMMITTED' AND branch_id=?", (query.branch_id,))
        try:
            player_refs = {r["entity_id"] for r in self._rows(
                ctx, "SELECT entity_id FROM entities WHERE branch_id=? AND lower(kind)='player'",
                (query.branch_id,))}
        except Exception:
            player_refs = set()
        for row in rows:
            vf = row["valid_from_turn"]
            ia = row["invalid_at_turn"]
            truth = row["truth_status"]
            visible = turn is None
            if turn is not None:
                if vf is not None and turn < vf:
                    continue
                if ia is not None and turn >= ia:
                    continue
                visible = True
            if not visible:
                if truth == "HISTORICAL_FACT" and not query.include_historical:
                    continue
                if truth == "SUPERSEDED" and not query.include_superseded:
                    continue
                if truth not in ("HISTORICAL_FACT", "SUPERSEDED"):
                    continue
            content = fact_content(row)
            current = "current" if truth in ("ACTIVE", "ACTIVE_INTERPRETATION") else "historical"
            item = RetrievalItem(
                item_id=row["fact_id"], source_type=SourceType.FACT, source_ref=row["fact_id"],
                classification=row["classification"] or "AUTHORITY", authority_status=truth,
                branch_id=row["branch_id"], plane=row["plane"], observer_scope=None,
                temporal_scope=f"{vf or ''}..{ia or ''}", current_or_historical=current,
                content=content, provenance=row["provenance_json"],
                estimated_token_cost=est.estimate(content),
            )
            subject = row["subject_ref"]
            player_subject = subject in player_refs or looks_like_player_ref(subject)
            ownership_blocked = (is_runtime_owned_predicate(row["predicate"])
                                 or (player_subject and
                                     is_player_internal_predicate(row["predicate"])))
            meta = dict(row) | {
                "classification": row["classification"] or "AUTHORITY",
                "ownership_blocked": ownership_blocked,
            }
            out.append((item, meta))
        if known_at is not None:
            for row in self._rows(ctx, "SELECT * FROM knowledge WHERE branch_id=? AND turn <= ?", (query.branch_id, known_at)):
                if row["plane"] == "CHARACTER" and query.observer_entity_id is None:
                    continue
                if row["plane"] == "CHARACTER" and query.observer_entity_id and row["subject_ref"] != query.observer_entity_id:
                    continue
                content = f"{row['subject_ref']} {row['state']} {row['proposition_ref']}"
                item = RetrievalItem(
                    item_id=row["knowledge_id"], source_type=SourceType.KNOWLEDGE, source_ref=row["knowledge_id"],
                    classification="AUTHORITY", authority_status="COMMITTED", branch_id=row["branch_id"],
                    plane=row["plane"], observer_scope=row["subject_ref"] if row["plane"] == "CHARACTER" else None,
                    temporal_scope=row["turn"], current_or_historical="current",
                    content=content, provenance=row["provenance_json"],
                    estimated_token_cost=est.estimate(content),
                )
                out.append((item, dict(row) | {"classification": "AUTHORITY"}))
        return out
