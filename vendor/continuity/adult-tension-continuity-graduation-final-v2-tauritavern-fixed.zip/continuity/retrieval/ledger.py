"""Structured committed-authority retrieval over facts/knowledge/commitments/threads."""
from __future__ import annotations
import json
import sqlite3
from typing import Any

from .base import RetrievalItem, RetrievalQuery, SourceType
from .retriever import Context, RetrieverBase, SqlMixin


def fact_content(row: sqlite3.Row) -> str:
    return f"{row['subject_ref']} {row['predicate']}: {row['object_json']}"


class LedgerRetriever(RetrieverBase, SqlMixin):
    name = "LedgerRetriever"
    score_kind = "ledger"

    def _candidates(self, query: RetrievalQuery, ctx: Context) -> list[tuple[RetrievalItem, dict[str, Any]]]:
        out: list[tuple[RetrievalItem, dict[str, Any]]] = []
        est = ctx.estimator
        if query.fact_ids:
            qs = ",".join("?" * len(query.fact_ids))
            for row in self._rows(ctx, f"SELECT * FROM facts WHERE admission_state='COMMITTED' AND fact_id IN ({qs})", tuple(query.fact_ids)):
                content = fact_content(row)
                adult = any(row["predicate"].startswith(p + ".") or row["predicate"] == p for p in default_prefixes())
                current = "current" if row["truth_status"] in ("ACTIVE", "ACTIVE_INTERPRETATION") else "historical"
                item = RetrievalItem(
                    item_id=row["fact_id"], source_type=SourceType.FACT, source_ref=row["fact_id"],
                    classification=row["classification"] or "AUTHORITY", authority_status=row["truth_status"],
                    branch_id=row["branch_id"], plane=row["plane"], observer_scope=None,
                    temporal_scope=row["valid_from_turn"], current_or_historical=current,
                    content=content, provenance=row["provenance_json"],
                    estimated_token_cost=est.estimate(content), flags=("ADULT_OWNED",) if adult else (),
                )
                meta = dict(row) | {"classification": row["classification"] or "AUTHORITY", "adult_owned": adult}
                out.append((item, meta))

        if query.observer_entity_id:
            krows = self._rows(ctx, "SELECT * FROM knowledge WHERE plane='CHARACTER' AND subject_ref=?", (query.observer_entity_id,))
            for row in krows:
                content = f"{row['subject_ref']} {row['state']} {row['proposition_ref']}"
                item = RetrievalItem(
                    item_id=row["knowledge_id"], source_type=SourceType.KNOWLEDGE, source_ref=row["knowledge_id"],
                    classification="AUTHORITY", authority_status="COMMITTED", branch_id=row["branch_id"],
                    plane=row["plane"], observer_scope=row["subject_ref"],
                    temporal_scope=row["turn"], current_or_historical="current",
                    content=content, provenance=row["provenance_json"],
                    estimated_token_cost=est.estimate(content),
                    flags=("FALSE_BELIEF",) if row["state"] == "false_belief" else (),
                )
                out.append((item, dict(row) | {"classification": "AUTHORITY"}))
            ksel = "SELECT * FROM knowledge WHERE plane <> 'CHARACTER' AND branch_id=?"
            for row in self._rows(ctx, ksel, (query.branch_id,)):
                if row["plane"] not in query.requested_planes:
                    continue
                content = f"{row['subject_ref']} {row['state']} {row['proposition_ref']}"
                item = RetrievalItem(
                    item_id=row["knowledge_id"], source_type=SourceType.KNOWLEDGE, source_ref=row["knowledge_id"],
                    classification="AUTHORITY", authority_status="COMMITTED", branch_id=row["branch_id"],
                    plane=row["plane"], observer_scope=None, temporal_scope=row["turn"],
                    current_or_historical="current", content=content, provenance=row["provenance_json"],
                    estimated_token_cost=est.estimate(content),
                )
                out.append((item, dict(row) | {"classification": "AUTHORITY"}))

        if query.commitment_ids:
            qs = ",".join("?" * len(query.commitment_ids))
            for row in self._rows(ctx, f"SELECT * FROM commitments WHERE commitment_id IN ({qs})", tuple(query.commitment_ids)):
                content = f"{row['kind']}: {row['content']} issuer={row['issuer_ref']}"
                item = RetrievalItem(
                    item_id=row["commitment_id"], source_type=SourceType.COMMITMENT, source_ref=row["commitment_id"],
                    classification="AUTHORITY", authority_status="COMMITTED", branch_id=row["branch_id"],
                    plane="OBJECTIVE", observer_scope=None, temporal_scope=None, current_or_historical="current",
                    content=content, provenance=row["provenance_json"],
                    estimated_token_cost=est.estimate(content),
                )
                out.append((item, dict(row) | {"classification": "AUTHORITY"}))
        elif query.entity_ids:
            qs = ",".join("?" * len(query.entity_ids))
            for row in self._rows(
                ctx,
                f"SELECT * FROM commitments WHERE branch_id=? AND (issuer_ref IN ({qs}) OR " + " OR ".join("beneficiary_refs_json LIKE ?" for _ in query.entity_ids) + ")",
                (query.branch_id, *query.entity_ids, *[f'%"{e}"%' for e in query.entity_ids]),
            ):
                content = f"{row['kind']}: {row['content']} issuer={row['issuer_ref']}"
                item = RetrievalItem(
                    item_id=row["commitment_id"], source_type=SourceType.COMMITMENT, source_ref=row["commitment_id"],
                    classification="AUTHORITY", authority_status="COMMITTED", branch_id=row["branch_id"],
                    plane="OBJECTIVE", observer_scope=None, temporal_scope=None, current_or_historical="current",
                    content=content, provenance=row["provenance_json"],
                    estimated_token_cost=est.estimate(content),
                )
                out.append((item, dict(row) | {"classification": "AUTHORITY"}))

        thread_sel = "SELECT t.*, group_concat(r.ref, ',') AS requires_refs FROM threads t LEFT JOIN thread_requires r ON r.thread_id=t.thread_id"
        if query.thread_ids:
            qs = ",".join("?" * len(query.thread_ids))
            thread_sel += f" WHERE t.thread_id IN ({qs})"
        thread_sel += " GROUP BY t.thread_id"
        for row in self._rows(ctx, thread_sel, tuple(query.thread_ids)):
            gate = row["reveal_gate_json"] or "{}"
            flags = ["PRESENTATION_RESTRICTED"] if gate not in ("{}", "", "null") else []
            content = f"thread {row['thread_id']} status={row['status']} requires={row['requires_refs'] or ''}"
            item = RetrievalItem(
                item_id=row["thread_id"], source_type=SourceType.THREAD, source_ref=row["thread_id"],
                classification="AUTHORITY", authority_status="COMMITTED", branch_id=row["branch_id"],
                plane="OBJECTIVE", observer_scope=None, temporal_scope=None, current_or_historical="current",
                content=content, provenance=row["provenance_json"],
                estimated_token_cost=est.estimate(content), flags=tuple(flags),
            )
            meta = dict(row) | {"classification": "AUTHORITY"}
            if query.thread_ids:
                blocked = self._rows(ctx, "SELECT blocked_ref FROM thread_anti_merge WHERE thread_id IN (%s)" % ",".join("?" * len(query.thread_ids)), tuple(query.thread_ids))
                if any(b["blocked_ref"] == row["thread_id"] for b in blocked):
                    meta["anti_merge_blocked"] = row["thread_id"]
            out.append((item, meta))

        rel_sel = "SELECT r.*, d.name AS dim_name, d.value_json AS dim_value FROM relationships r LEFT JOIN relationship_dimensions d ON d.relationship_id=r.relationship_id"
        if query.entity_ids:
            qs = ",".join("?" * len(query.entity_ids))
            rel_sel += f" WHERE r.source_ref IN ({qs}) OR r.target_ref IN ({qs})"
            for row in self._rows(ctx, rel_sel, tuple(query.entity_ids) * 2):
                content = f"relationship {row['source_ref']}->{row['target_ref']} phase={row['phase']}"
                dim = row["dim_value"] if row["dim_name"] else None
                if dim:
                    content += f" {row['dim_name']}={dim}"
                item = RetrievalItem(
                    item_id=row["relationship_id"], source_type=SourceType.RELATIONSHIP, source_ref=row["relationship_id"],
                    classification="AUTHORITY", authority_status="COMMITTED", branch_id=row["branch_id"],
                    plane="OBJECTIVE", observer_scope=None, temporal_scope=None, current_or_historical="current",
                    content=content, provenance=row["provenance_json"],
                    estimated_token_cost=est.estimate(content),
                )
                out.append((item, dict(row) | {"classification": "AUTHORITY"}))
        return out


def default_prefixes() -> frozenset[str]:
    return frozenset({
        "consent", "grant", "grants", "boundary", "boundaries", "safety",
        "sexuality_profile", "intimacy", "relationships.trust",
    })
