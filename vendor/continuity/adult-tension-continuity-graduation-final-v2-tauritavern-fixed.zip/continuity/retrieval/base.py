"""Phase 2A read-only retrieval contracts."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class RetrievalStatus(str, Enum):
    OK = "OK"
    PARTIAL = "PARTIAL"
    AMBIGUOUS = "AMBIGUOUS"
    EVIDENCE_INSUFFICIENT = "EVIDENCE_INSUFFICIENT"
    EVIDENCE_CORRUPT = "EVIDENCE_CORRUPT"
    BLOCKED_BY_FILTERS = "BLOCKED_BY_FILTERS"


class SourceType(str, Enum):
    FACT = "FACT"
    ENTITY = "ENTITY"
    KNOWLEDGE = "KNOWLEDGE"
    RELATIONSHIP = "RELATIONSHIP"
    COMMITMENT = "COMMITMENT"
    THREAD = "THREAD"
    EPISODE = "EPISODE"
    HISTORICAL_EVIDENCE = "HISTORICAL_EVIDENCE"


DEFAULT_PLANES = frozenset({"OBJECTIVE", "CHARACTER"})


@dataclass(frozen=True)
class RetrievalQuery:
    raw_text: str = ""
    branch_id: str = "default"
    observer_entity_id: str | None = None
    entity_ids: tuple[str, ...] = ()
    fact_ids: tuple[str, ...] = ()
    thread_ids: tuple[str, ...] = ()
    commitment_ids: tuple[str, ...] = ()
    event_turn: int | None = None
    turn_range: tuple[int, int] | None = None
    as_known_at: int | None = None
    world_time: str | None = None
    requested_planes: frozenset[str] = DEFAULT_PLANES
    include_historical: bool = False
    include_superseded: bool = False
    exact_evidence_required: bool = False
    source_types: tuple[str, ...] = ()
    limit: int = 10
    token_budget: int | None = None
    episode_id: str | None = None
    scene_id: str | None = None
    participant_id: str | None = None
    query_id: str = ""


@dataclass(frozen=True)
class RetrievalItem:
    item_id: str
    source_type: SourceType
    source_ref: str
    classification: str
    authority_status: str
    branch_id: str
    plane: str
    observer_scope: str | None
    temporal_scope: str
    current_or_historical: str
    content: str
    provenance: str
    estimated_token_cost: int
    rank_score: float = 0.0
    hard_exclusion_reason: str | None = None
    flags: tuple[str, ...] = ()


@dataclass(frozen=True)
class RetrievalTrace:
    trace_id: str
    query_id: str
    retriever: str
    candidate_item_id: str
    source_refs: tuple[str, ...]
    lexical_score: float = 0.0
    entity_score: float = 0.0
    temporal_score: float = 0.0
    ledger_score: float = 0.0
    evidence_score: float = 0.0
    final_score: float = 0.0
    filters_applied: tuple[str, ...] = ()
    filter_results: tuple[str, ...] = ()
    included: bool = True
    exclusion_reason: str | None = None
    original_rank: int = 0
    final_rank: int = 0
    estimated_token_cost: int = 0
    builder_version: str = "phase2a-1.0.0"


@dataclass(frozen=True)
class RetrievalResult:
    status: RetrievalStatus
    query_id: str
    items: tuple[RetrievalItem, ...] = ()
    traces: tuple[RetrievalTrace, ...] = ()
    insufficiency: tuple[str, ...] = ()
