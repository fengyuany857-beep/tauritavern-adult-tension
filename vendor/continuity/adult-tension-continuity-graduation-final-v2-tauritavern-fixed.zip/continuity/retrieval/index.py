"""DERIVED_REBUILDABLE FTS5 index. Never an authority store."""
from __future__ import annotations
import json
import sqlite3
from pathlib import Path
from typing import Iterator


def _facts(conn: sqlite3.Connection):
    for row in conn.execute("SELECT * FROM facts WHERE admission_state='COMMITTED'"):
        yield "FACT", row["fact_id"], f"{row['subject_ref']} {row['predicate']} {row['object_json']}", row["branch_id"]


def _entities(conn: sqlite3.Connection):
    for row in conn.execute("SELECT * FROM entities"):
        yield "ENTITY", row["entity_id"], f"{row['entity_id']} {row['anchors_json']} {row['explicit_non_capabilities_json']}", row["branch_id"]


def _aliases(conn: sqlite3.Connection):
    for row in conn.execute("SELECT a.alias AS alias, a.entity_id AS entity_id, e.branch_id AS branch_id FROM entity_aliases a JOIN entities e ON e.entity_id=a.entity_id"):
        yield "ALIAS", row["entity_id"], str(row["alias"]), row["branch_id"]


def _commitments(conn: sqlite3.Connection):
    for row in conn.execute("SELECT * FROM commitments"):
        yield "COMMITMENT", row["commitment_id"], f"{row['kind']} {row['content']} issuer={row['issuer_ref']}", row["branch_id"]


def _threads(conn: sqlite3.Connection):
    for row in conn.execute("SELECT * FROM threads"):
        yield "THREAD", row["thread_id"], f"{row['status']} {row['objective_state'] or ''} {row['author_state'] or ''}", row["branch_id"]


def _episodes(base: Path):
    for path in sorted(base.glob("history/*.jsonl")):
        if not path.exists():
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue
            text = data.get("summary") or data.get("payload") or ""
            yield "EPISODE", str(data.get("episode_id") or data.get("scene_id") or "ev"), str(text), str(data.get("branch_id", "default"))


class FtsIndex:
    def __init__(self, path: Path):
        self.path = path

    def rebuild(self, conn: sqlite3.Connection, base: Path) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + ".rebuild")
        if tmp.exists():
            tmp.unlink()
        c = sqlite3.connect(str(tmp))
        c.execute("CREATE VIRTUAL TABLE docs USING fts5(source_type, source_ref, content, branch_id)")
        if conn.row_factory is not sqlite3.Row:
            conn.row_factory = sqlite3.Row
        for source_type, ref, content, branch in self._documents(conn, base):
            c.execute("INSERT INTO docs VALUES (?,?,?,?)", (source_type, ref, content, branch))
        c.commit()
        c.close()
        tmp.replace(self.path)

    def exists(self) -> bool:
        return self.path.exists()

    def search(self, source_types: tuple[str, ...] = ()) -> list[tuple[str, str, str]]:
        if not self.exists():
            return []
        c = sqlite3.connect(str(self.path))
        rows = [tuple(r) for r in c.execute("SELECT source_type, source_ref, branch_id FROM docs")]
        c.close()
        if source_types:
            rows = [r for r in rows if r[0] in source_types]
        return rows

    @staticmethod
    def _documents(conn: sqlite3.Connection, base: Path) -> Iterator[tuple[str, str, str, str]]:
        for gen in (_facts, _entities, _aliases, _commitments, _threads):
            yield from gen(conn)
        yield from _episodes(base)
