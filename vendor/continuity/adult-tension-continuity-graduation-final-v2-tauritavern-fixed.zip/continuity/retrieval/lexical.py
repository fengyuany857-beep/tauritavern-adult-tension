"""Deterministic term-overlap lexical retrieval over committed authority text.
Terminal source for content is authority rows; the FTS index is advisory only."""
from __future__ import annotations
import json
import re
import sqlite3
from typing import Any

from .base import RetrievalItem, RetrievalQuery, SourceType
from .index import FtsIndex
from .retriever import Context, RetrieverBase, SqlMixin

_TOKEN = re.compile(r"[A-Za-z0-9_]+|[\u3400-\u9fff]")


def tokenize(text: str) -> list[str]:
    return _TOKEN.findall(text.lower())


def matches(text: str, tokens: list[str]) -> tuple[bool, int]:
    low = text.lower()
    hits = 0
    for tok in tokens:
        if tok in low:
            hits += 1
        else:
            return False, hits
    return True, hits


class LexicalRetriever(RetrieverBase, SqlMixin):
    name = "LexicalRetriever"
    score_kind = "lexical"

    def __init__(self, index: FtsIndex | None = None):
        self.index = index

    def _candidates(self, query: RetrievalQuery, ctx: Context) -> list[tuple[RetrievalItem, dict[str, Any]]]:
        tokens = tokenize(query.raw_text or "")
        if not tokens:
            return []
        out: list[tuple[RetrievalItem, dict[str, Any]]] = []
        est = ctx.estimator

        def push(item: RetrievalItem, meta: dict[str, Any], text: str) -> None:
            ok, count = matches(text, tokens)
            if not ok:
                return
            scored = RetrievalItem(**{**item.__dict__, "rank_score": float(count)})
            out.append((scored, meta | {"score": float(count)}))

        for row in ctx.conn.execute("SELECT * FROM facts WHERE admission_state='COMMITTED' AND branch_id=?", (query.branch_id,)):
            text = f"{row['subject_ref']} {row['predicate']} {row['object_json']}"
            current = "current" if row["truth_status"] in ("ACTIVE", "ACTIVE_INTERPRETATION") else "historical"
            item = RetrievalItem(
                item_id=row["fact_id"], source_type=SourceType.FACT, source_ref=row["fact_id"],
                classification=row["classification"] or "AUTHORITY", authority_status=row["truth_status"],
                branch_id=row["branch_id"], plane=row["plane"], observer_scope=None,
                temporal_scope=row["valid_from_turn"], current_or_historical=current,
                content=text, provenance=row["provenance_json"],
                estimated_token_cost=est.estimate(text),
            )
            push(item, dict(row) | {"classification": item.classification}, text)

        for row in ctx.conn.execute("SELECT * FROM commitments WHERE branch_id=?", (query.branch_id,)):
            text = f"{row['kind']} {row['content']} issuer={row['issuer_ref']}"
            item = RetrievalItem(
                item_id=row["commitment_id"], source_type=SourceType.COMMITMENT, source_ref=row["commitment_id"],
                classification="AUTHORITY", authority_status="COMMITTED", branch_id=row["branch_id"],
                plane="OBJECTIVE", observer_scope=None, temporal_scope=None, current_or_historical="current",
                content=text, provenance=row["provenance_json"],
                estimated_token_cost=est.estimate(text),
            )
            push(item, dict(row) | {"classification": "AUTHORITY"}, text)

        for row in ctx.conn.execute("SELECT * FROM threads WHERE branch_id=?", (query.branch_id,)):
            text = f"{row['status']} {row['objective_state'] or ''} {row['author_state'] or ''}"
            flags = ("PRESENTATION_RESTRICTED",) if (row["reveal_gate_json"] or "") not in ("", "{}") else ()
            item = RetrievalItem(
                item_id=row["thread_id"], source_type=SourceType.THREAD, source_ref=row["thread_id"],
                classification="AUTHORITY", authority_status="COMMITTED", branch_id=row["branch_id"],
                plane="OBJECTIVE", observer_scope=None, temporal_scope=None, current_or_historical="current",
                content=text, provenance=row["provenance_json"],
                estimated_token_cost=est.estimate(text), flags=flags,
            )
            push(item, dict(row) | {"classification": "AUTHORITY"}, text)

        for path in sorted(ctx.base.glob("history/*.jsonl")):
            if not path.exists():
                continue
            from ..history import verify_line
            for line in path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    env = json.loads(line)
                except json.JSONDecodeError:
                    continue
                checksum_ok = verify_line(line)
                text = str(env.get("summary") or env.get("payload") or "")
                eid = str(env.get("episode_id") or env.get("scene_id") or "ev")
                item = RetrievalItem(
                    item_id=eid, source_type=SourceType.EPISODE, source_ref=eid,
                    classification=str(env.get("payload_classification", "HISTORICAL_EVIDENCE")),
                    authority_status="HISTORICAL", branch_id=str(env.get("branch_id", "default")),
                    plane="OBJECTIVE", observer_scope=None,
                    temporal_scope=f"{env.get('turn_start')}..{env.get('turn_end')}",
                    current_or_historical="historical", content=text,
                    provenance=f"{path.name}:{env.get('checksum', '')}",
                    estimated_token_cost=est.estimate(text),
                )
                if matches(text, tokens)[0]:
                    meta = {"classification": item.classification, "corrupt": not checksum_ok,
                            "truth_status": "HISTORICAL_FACT", "branch_id": item.branch_id,
                            "valid_from_turn": env.get("turn_start"), "invalid_at_turn": None}
                    push(item, meta, text)
        return out
