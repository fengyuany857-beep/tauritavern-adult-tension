"""Stable-ID, alias, and participant-aware entity retrieval (no auto-merge)."""
from __future__ import annotations
import json
import sqlite3
from pathlib import Path
from typing import Any

from .base import RetrievalItem, RetrievalQuery, SourceType
from .retriever import Context, RetrieverBase, SqlMixin


def _history_paths(base: Path) -> list[Path]:
    return sorted(base.glob("history/*.jsonl"))


def _episodes_with_participant(ctx: Context, participant: str) -> list[sqlite3.Row]:
    hits: list[sqlite3.Row] = []
    for row in ctx.conn.execute("SELECT * FROM episodes WHERE branch_id='default'"):
        for path in _history_paths(ctx.base):
            if not path.exists():
                continue
            for line in path.read_text(encoding="utf-8").splitlines():
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if data.get("episode_id") != row["episode_id"]:
                    continue
                parts = data.get("participants") or []
                if participant in parts:
                    hits.append(row)
                    break
    return hits


class EntityRetriever(RetrieverBase, SqlMixin):
    name = "EntityRetriever"
    score_kind = "entity"

    def _candidates(self, query: RetrievalQuery, ctx: Context) -> list[tuple[RetrievalItem, dict[str, Any]]]:
        out: list[tuple[RetrievalItem, dict[str, Any]]] = []
        est = ctx.estimator
        wanted = list(query.entity_ids or [])
        raw = (query.raw_text or "").strip()
        seen: set[str] = set()

        def add_entity_row(row: sqlite3.Row) -> None:
            eid = row["entity_id"]
            if eid in seen or row["branch_id"] != query.branch_id:
                return
            seen.add(eid)
            content = f"entity {eid} {row['kind']} ref={row['runtime_external_ref']} anchors={row['anchors_json']}"
            item = RetrievalItem(
                item_id=eid, source_type=SourceType.ENTITY, source_ref=eid,
                classification="AUTHORITY_REFERENCE", authority_status="confirmed",
                branch_id=row["branch_id"], plane="OBJECTIVE", observer_scope=None,
                temporal_scope=None, current_or_historical="current",
                content=content, provenance=json.dumps({"identity_status": row["identity_status"]}, sort_keys=True),
                estimated_token_cost=est.estimate(content),
            )
            out.append((item, dict(row) | {"classification": "AUTHORITY_REFERENCE"}))

        if wanted:
            qs = ",".join("?" * len(wanted))
            for row in self._rows(ctx, f"SELECT * FROM entities WHERE entity_id IN ({qs})", tuple(wanted)):
                add_entity_row(row)
        if raw:
            for row in self._rows(ctx, "SELECT * FROM entities WHERE branch_id=?", (query.branch_id,)):
                anchors = json.loads(row["anchors_json"] or "{}")
                name = anchors.get("canonical_name") or ""
                if name and name == raw:
                    add_entity_row(row)
            aliases = self._rows(
                ctx,
                "SELECT a.*, e.* FROM entity_aliases a JOIN entities e ON e.entity_id=a.entity_id WHERE a.status='confirmed' AND e.branch_id=? AND a.alias=?",
                (query.branch_id, raw),
            )
            for row in aliases:
                add_entity_row(row)
            merge = self._rows(
                ctx,
                "SELECT a.*, e.* FROM entity_aliases a JOIN entities e ON e.entity_id=a.entity_id WHERE a.status='merge_candidate' AND e.branch_id=? AND a.alias=?",
                (query.branch_id, raw),
            )
            for row in merge:
                if row["entity_id"] not in seen:
                    content = f"unconfirmed alias candidate for {row['entity_id']}"
                    item = RetrievalItem(
                        item_id=row["entity_id"] + ":merge", source_type=SourceType.ENTITY,
                        source_ref=row["entity_id"], classification="CANDIDATE",
                        authority_status="merge_candidate", branch_id=row["branch_id"],
                        plane="OBJECTIVE", observer_scope=None, temporal_scope=None,
                        current_or_historical="current", content=content,
                        provenance=json.dumps({"identity_status": "merge_candidate"}, sort_keys=True),
                        estimated_token_cost=est.estimate(content),
                    )
                    out.append((item, dict(row) | {"classification": "CANDIDATE", "identity_status": "merge_candidate"}))

        target = query.participant_id or (wanted[0] if len(wanted) == 1 else None)
        if target:
            for row in _episodes_with_participant(ctx, target):
                content = f"episode {row['episode_id']} contains participant {target}"
                item = RetrievalItem(
                    item_id=row["episode_id"], source_type=SourceType.EPISODE, source_ref=row["episode_id"],
                    classification="HISTORICAL_EVIDENCE", authority_status="HISTORICAL",
                    branch_id=row["branch_id"], plane="OBJECTIVE", observer_scope=None,
                    temporal_scope=None, current_or_historical="historical",
                    content=content, provenance=row["history_pointer"] or "",
                    estimated_token_cost=est.estimate(content),
                )
                out.append((item, dict(row) | {"classification": "HISTORICAL_EVIDENCE"}))
        return out

    def _insufficiency(self, query: RetrievalQuery, items: list[RetrievalItem], traces) -> list[str]:
        if query.raw_text and not query.entity_ids:
            entity_ids = [i.item_id for i in items if i.source_type == SourceType.ENTITY and i.branch_id == query.branch_id]
            if len(set(entity_ids)) >= 2:
                return ["ambiguous_identity"]
        return []
