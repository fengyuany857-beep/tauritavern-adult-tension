"""Deterministic Reciprocal Rank Fusion. No learned weights, no promotion."""
from __future__ import annotations
from dataclasses import replace
from typing import Any

from .base import RetrievalItem, RetrievalQuery, RetrievalResult, RetrievalStatus, RetrievalTrace
from .retriever import Context, RetrieverBase

RRF_K = 60.0
BIG_LIMIT = 500


def rrf_scores(ranked: list[list[str]]) -> dict[str, float]:
    scores: dict[str, float] = {}
    for ranking in ranked:
        for pos, key in enumerate(ranking):
            scores[key] = scores.get(key, 0.0) + 1.0 / (RRF_K + pos + 1.0)
    return scores


def item_key(item: RetrievalItem) -> str:
    return f"{item.source_type.value}:{item.branch_id}:{item.source_ref}"


class HybridRetriever(RetrieverBase):
    """Runs a fixed list of read-only retrievers and deterministically fuses hits.
    Hard-filtered candidates are never resurrected."""

    name = "HybridRetriever"
    score_kind = "hybrid"

    def __init__(self, components: list[RetrieverBase]):
        if not components:
            raise ValueError("HybridRetriever requires at least one component")
        self.components = components

    def _candidates(self, query: RetrievalQuery, ctx: Context) -> list:
        # retrieve() overrides the base pipeline; this satisfies the abstract contract.
        return []

    def retrieve(self, query: RetrievalQuery, ctx: Context) -> RetrievalResult:
        query_id = query.query_id or "hybrid"
        wide = replace(query, query_id=query_id, limit=BIG_LIMIT)
        per_component: list[list[str]] = []
        included_by_key: dict[str, tuple[RetrievalItem, list[RetrievalTrace]]] = {}
        all_traces: list[RetrievalTrace] = []
        insufficiency: list[str] = []
        for comp in self.components:
            result = comp.retrieve(wide, ctx)
            all_traces.extend(result.traces)
            insufficiency.extend(result.insufficiency)
            ranking: list[str] = []
            for item in result.items:
                key = item_key(item)
                ranking.append(key)
                if key not in included_by_key:
                    included_by_key[key] = (item, [t for t in result.traces if t.candidate_item_id == item.item_id and t.included])
            per_component.append(ranking)
        fused = rrf_scores(per_component)
        ordered_keys = sorted(fused.keys(), key=lambda k: (-fused[k], k))
        limit = max(1, query.limit or 10)
        kept_keys = ordered_keys[:limit]
        kept: list[tuple[RetrievalItem, float]] = [(included_by_key[k][0], fused[k]) for k in kept_keys]
        budget = query.token_budget
        if budget is not None:
            acc = 0
            trimmed: list[tuple[RetrievalItem, float]] = []
            for item, score in kept:
                if acc + item.estimated_token_cost > budget and trimmed:
                    break
                trimmed.append((item, score))
                acc += item.estimated_token_cost
            kept = trimmed or kept[:1]
        items: list[RetrievalItem] = []
        final_traces: list[RetrievalTrace] = []
        for rank, (item, score) in enumerate(kept, start=1):
            items.append(item)
            final_traces.append(RetrievalTrace(
                trace_id=f"hybrid-{item_key(item)[:8]}", query_id=query_id, retriever=self.name,
                candidate_item_id=item.item_id, source_refs=(item.source_ref,),
                final_score=round(score, 6), filters_applied=("rrf",), filter_results=("hard filters preserved",),
                included=True, original_rank=rank, final_rank=rank,
                estimated_token_cost=item.estimated_token_cost,
            ))
        status = self._status(query, items, final_traces, insufficiency)
        return RetrievalResult(status=status, query_id=query_id, items=tuple(items),
                               traces=tuple(all_traces) + tuple(final_traces), insufficiency=tuple(insufficiency))
