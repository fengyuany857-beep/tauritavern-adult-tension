"""Central read-only retrieval pipeline: candidates -> hard filters -> rank -> trace."""
from __future__ import annotations
import hashlib
import sqlite3
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..errors import RuntimeReadOnlyError
from ..validation import (is_runtime_owned_predicate, is_player_internal_predicate,
                          looks_like_player_ref)
from .base import (
    DEFAULT_PLANES, RetrievalItem, RetrievalQuery, RetrievalResult,
    RetrievalStatus, RetrievalTrace,
)
from .tokens import ApproximateTokenEstimator, TokenEstimator


@dataclass
class Context:
    """Read-only retrieval context. conn must be opened query_only."""
    conn: sqlite3.Connection
    base: Path
    index_path: Path
    estimator: TokenEstimator = field(default_factory=ApproximateTokenEstimator)

    @classmethod
    def open(cls, base: Path) -> "Context":
        conn = sqlite3.connect(str(base / "state" / "continuity.sqlite3"))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA query_only=ON")
        return cls(conn=conn, base=base, index_path=base / "indexes" / "retrieval_fts.sqlite3")


CANDIDATE = "CANDIDATE"
REJECTED = "REJECTED"


def apply_hard_filters(item: RetrievalItem, meta: dict[str, Any], query: RetrievalQuery,
                       ctx: Context | None = None) -> tuple[bool, str | None, tuple[str, ...], tuple[str, ...]]:
    """Returns (excluded, reason, filters_applied, filter_results)."""
    filters_applied: list[str] = []
    results: list[str] = []
    reason: str | None = None

    def fail(name: str, msg: str) -> None:
        nonlocal reason
        filters_applied.append(name)
        results.append(msg)
        if reason is None:
            reason = msg

    branch = meta.get("branch_id") or "default"
    filters_applied.append("branch")
    if branch != query.branch_id:
        return True, "wrong branch", tuple(filters_applied), tuple(results)
    results.append("branch ok")

    filters_applied.append("source_type")
    if query.source_types and item.source_type.value not in query.source_types:
        return True, "source type not requested", tuple(filters_applied), tuple(results)
    results.append("source_type ok")

    filters_applied.append("plane")
    if item.plane not in query.requested_planes:
        return True, f"plane not requested: {item.plane}", tuple(filters_applied), tuple(results)
    results.append("plane ok")

    filters_applied.append("admission")
    if meta.get("classification") == "CANDIDATE" or meta.get("admission_state") in (CANDIDATE, REJECTED):
        return True, "candidate/rejected never enters authority retrieval", tuple(filters_applied), tuple(results)
    results.append("admission ok")

    # Knowledge-of-record visibility: when a transaction/record time is supplied,
    # an objective fact is only knowable once it was recorded.  This is independent
    # of world/event validity (valid_from..invalid_at).  A fact recorded *after*
    # as_known_at must never surface, even if it was world-valid at as_of_event.
    filters_applied.append("recorded_visibility")
    known_at = query.as_known_at
    recorded = meta.get("recorded_at_turn")
    if item.source_type.value == "FACT" and known_at is not None and recorded is not None and recorded > known_at:
        return True, "recorded after as_known_at: not yet recorded by system", tuple(filters_applied), tuple(results)
    results.append("recorded_visibility ok")

    filters_applied.append("superseded")
    if not query.include_superseded and meta.get("truth_status") == "SUPERSEDED":
        return True, "superseded excluded from current retrieval", tuple(filters_applied), tuple(results)
    results.append("superseded ok")

    filters_applied.append("historical")
    exempt = item.source_type.value in ("EPISODE", "HISTORICAL_EVIDENCE")
    if not exempt and not query.include_historical and item.current_or_historical == "historical" and meta.get("truth_status") != "SUPERSEDED":
        return True, "historical excluded unless requested", tuple(filters_applied), tuple(results)
    results.append("historical ok")

    filters_applied.append("temporal_validity")
    vf = meta.get("valid_from_turn")
    ia = meta.get("invalid_at_turn")
    turn = query.event_turn
    if meta.get("truth_status") not in ("HISTORICAL_FACT", "SUPERSEDED") and turn is not None:
        if vf is not None and turn < vf:
            return True, "fact not yet valid at query turn", tuple(filters_applied), tuple(results)
        if ia is not None and turn >= ia:
            return True, "fact no longer valid at query turn", tuple(filters_applied), tuple(results)
    results.append("temporal_validity ok")

    filters_applied.append("observer_epistemic")
    if item.source_type.value == "KNOWLEDGE" and item.plane == "CHARACTER":
        if query.observer_entity_id is None or meta.get("subject_ref") != query.observer_entity_id:
            return True, "character knowledge is observer-scoped", tuple(filters_applied), tuple(results)
    results.append("observer_epistemic ok")

    filters_applied.append("anti_merge")
    blocked = meta.get("anti_merge_blocked")
    if blocked:
        return True, f"anti_merge blocks: {blocked}", tuple(filters_applied), tuple(results)
    results.append("anti_merge ok")

    filters_applied.append("evidence")
    if meta.get("corrupt"):
        return True, "corrupt evidence checksum", tuple(filters_applied), tuple(results)
    results.append("evidence ok")

    filters_applied.append("adult_authority")
    ownership_blocked = bool(meta.get("ownership_blocked"))
    # Defense-in-depth lives here, not in one retriever.  Every FACT candidate
    # is structurally classified from its own subject/predicate.  When Context
    # is available, opaque player IDs are resolved centrally from entities.
    if item.source_type.value == "FACT":
        predicate = str(meta.get("predicate") or "")
        subject = str(meta.get("subject_ref") or "")
        player_subject = looks_like_player_ref(subject)
        if ctx is not None and subject:
            try:
                erow = ctx.conn.execute(
                    "SELECT kind FROM entities WHERE branch_id=? AND entity_id=?",
                    (query.branch_id, subject)).fetchone()
                player_subject = player_subject or bool(
                    erow is not None and str(erow[0]).lower() == "player")
            except sqlite3.Error:
                # Keep the pure-name fallback; callers with a healthy authority
                # DB get the stronger opaque-ID check above.
                pass
        try:
            ownership_blocked = ownership_blocked or is_runtime_owned_predicate(predicate)
            ownership_blocked = ownership_blocked or (
                player_subject and is_player_internal_predicate(predicate))
        except Exception:
            # A malformed fact predicate is not safe to surface.
            ownership_blocked = True
    if ownership_blocked:
        return True, "runtime/player-owned shadow fact blocked", tuple(filters_applied), tuple(results)
    if meta.get("classification") == "AUTHORITY" and meta.get("adult_owned"):
        return True, "adult runtime authority cannot be reclassified", tuple(filters_applied), tuple(results)
    results.append("adult_authority ok")

    return False, None, tuple(filters_applied), tuple(results)


def _stable_trace(retriever: str, item: RetrievalItem, reason: str | None) -> str:
    return hashlib.md5(f"{retriever}:{item.item_id}:{reason or ''}".encode()).hexdigest()[:16]


def default_adult_prefixes() -> frozenset[str]:
    return frozenset({
        "consent", "grant", "grants", "boundary", "boundaries", "safety",
        "sexuality", "intimacy", "meta.safety_state", "relationships.trust",
    })


class RetrieverBase(ABC):
    name: str = "base"
    score_kind: str = "ledger"

    @abstractmethod
    def _candidates(self, query: RetrievalQuery, ctx: Context) -> list[tuple[RetrievalItem, dict[str, Any]]]:
        raise NotImplementedError

    def _score(self, item: RetrievalItem, meta: dict[str, Any], query: RetrievalQuery) -> float:
        return float(meta.get("score", 0.0))

    def _insufficiency(self, query: RetrievalQuery, items: list[RetrievalItem], traces: list[RetrievalTrace]) -> list[str]:
        return []

    def retrieve(self, query: RetrievalQuery, ctx: Context) -> RetrievalResult:
        query_id = query.query_id or f"q-{uuid.uuid4().hex[:12]}"
        all_traces: list[RetrievalTrace] = []
        included: list[tuple[RetrievalItem, dict[str, Any], RetrievalTrace]] = []
        for item, meta in self._candidates(query, ctx):
            excluded, reason, fa, fr = apply_hard_filters(item, meta, query, ctx)
            score = 0.0
            if not excluded:
                score = self._score(item, meta, query)
            tr = RetrievalTrace(
                trace_id=_stable_trace(self.name, item, reason), query_id=query_id, retriever=self.name,
                candidate_item_id=item.item_id, source_refs=(item.source_ref,),
                filters_applied=fa, filter_results=fr, included=not excluded,
                exclusion_reason=reason, final_score=score,
                estimated_token_cost=item.estimated_token_cost,
            )
            all_traces.append(tr)
            if not excluded:
                included.append((item, meta, tr))
        included.sort(key=lambda t: (-t[2].final_score, t[0].item_id))
        limit = max(1, query.limit or 10)
        kept = included[:limit]
        budget = query.token_budget
        if budget is not None:
            acc = 0
            trimmed: list[tuple[RetrievalItem, dict[str, Any], RetrievalTrace]] = []
            for row in kept:
                if acc + row[0].estimated_token_cost > budget and trimmed:
                    break
                trimmed.append(row)
                acc += row[0].estimated_token_cost
            kept = trimmed or kept[:1]
        from dataclasses import replace
        rank_by_trace: dict[str, int] = {}
        items: list[RetrievalItem] = []
        for rank, (item, _meta, tr) in enumerate(kept, start=1):
            rank_by_trace[tr.trace_id] = rank
            items.append(item)
        traces = [
            replace(t, original_rank=rank_by_trace.get(t.trace_id, 0), final_rank=rank_by_trace.get(t.trace_id, 0))
            for t in all_traces
        ]
        insufficiency = self._insufficiency(query, items, traces)
        status = self._status(query, items, traces, insufficiency)
        return RetrievalResult(status=status, query_id=query_id, items=tuple(items), traces=tuple(traces), insufficiency=tuple(insufficiency))

    def _status(self, query: RetrievalQuery, items: list[RetrievalItem], traces: list[RetrievalTrace], insufficiency: list[str]) -> RetrievalStatus:
        if not items:
            excluded = [t for t in traces if not t.included]
            if any(t.exclusion_reason and "corrupt" in t.exclusion_reason for t in excluded):
                return RetrievalStatus.EVIDENCE_CORRUPT
            if excluded:
                return RetrievalStatus.BLOCKED_BY_FILTERS
            return RetrievalStatus.EVIDENCE_INSUFFICIENT if query.exact_evidence_required else RetrievalStatus.PARTIAL
        if "ambiguous_identity" in insufficiency:
            return RetrievalStatus.AMBIGUOUS
        if len(items) < max(1, query.limit or 10) or insufficiency:
            return RetrievalStatus.PARTIAL
        return RetrievalStatus.OK


class SqlMixin:
    def _rows(self, ctx: Context, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        return list(ctx.conn.execute(sql, params))
