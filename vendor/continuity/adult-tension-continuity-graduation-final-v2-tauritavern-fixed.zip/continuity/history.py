from __future__ import annotations
import json
from datetime import datetime, timezone
from pathlib import Path
from .errors import HistoryIntegrityError
from .hashing import sha256_bytes

def canonical_json(data: dict) -> bytes: return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
def append_envelope(path: Path, envelope: dict) -> str:
    if path.exists():
        for line in path.read_text(encoding='utf-8').splitlines():
            if line and not verify_line(line): raise HistoryIntegrityError('existing history checksum invalid')
    row=dict(envelope)
    if 'timestamp' not in row: row['timestamp']=datetime.now(timezone.utc).isoformat(timespec='seconds')
    row['checksum']=sha256_bytes(canonical_json(row))
    required={'branch_id','episode_id','transaction_id','runtime_pre_hash','runtime_post_hash','timestamp','payload_classification','source_references','checksum'}
    if not required.issubset(row): raise HistoryIntegrityError('history envelope missing required fields')
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf-8',newline='\n') as h: h.write(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n')
    return row['checksum']
def verify_line(line: str) -> bool:
    try: row=json.loads(line); checksum=row.pop('checksum')
    except (json.JSONDecodeError,KeyError): return False
    return sha256_bytes(canonical_json(row)) == checksum
def validate_volume(path: Path) -> str:
    digest=__import__('hashlib').sha256()
    for line in path.read_bytes().splitlines(keepends=True):
        text=line.decode('utf-8').rstrip('\r\n')
        if not verify_line(text): raise HistoryIntegrityError('history checksum invalid')
        digest.update(line)
    return digest.hexdigest()
def envelope(**kwargs: object) -> dict:
    return {'timestamp':datetime.now(timezone.utc).isoformat(timespec='seconds'), **kwargs}
