from __future__ import annotations
import json, sqlite3, subprocess, sys
from pathlib import Path
from .constants import AUDITED_VENDOR_HEAD, MIGRATION_VERSION
from .db import connect, integrity
from .errors import ManifestError
from .manifest import load

def check(base:Path, vendor:Path) -> tuple[str,list[str]]:
    notes=[]; status='PASS'; db=base/'state'/'continuity.sqlite3'
    if not db.exists(): return 'BLOCKED',['authority DB missing']
    c=connect(db)
    if integrity(c)!='ok': return 'BLOCKED',['SQLite integrity_check failed']
    if c.execute('PRAGMA foreign_keys').fetchone()[0] != 1: return 'BLOCKED',['foreign keys disabled']
    if not any('ENABLE_FTS5' in r[0] for r in c.execute('PRAGMA compile_options')): notes.append('FTS5 unavailable (optional V1 capability)'); status='WARN'
    mp=base/'manifests'/'manifest.json'
    try: load(mp)
    except ManifestError as e: return 'BLOCKED',[f'manifest: {e}']
    if not vendor.is_dir(): return 'BLOCKED',['vendor repository unavailable']
    head_proc=subprocess.run(['git','-C',str(vendor),'rev-parse','HEAD'],capture_output=True,text=True)
    if head_proc.returncode != 0 or not head_proc.stdout.strip(): return 'BLOCKED',['vendor is not a Git repository or HEAD is unavailable']
    head=head_proc.stdout.strip()
    dirty=subprocess.run(['git','-C',str(vendor),'status','--porcelain'],capture_output=True,text=True).stdout.strip()
    if head!=AUDITED_VENDOR_HEAD: return 'BLOCKED',['vendor HEAD mismatch']
    if dirty: notes.append('vendor worktree dirty'); status='WARN'
    return status,notes or ['all safe checks passed']
