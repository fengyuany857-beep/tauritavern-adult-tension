from __future__ import annotations
import json, re, sqlite3
from datetime import datetime, timezone
from .constants import *
from .errors import AuthorityError, ValidationError
from .models import FactInput

def utc_now() -> str: return datetime.now(timezone.utc).isoformat(timespec='seconds')
def stable_id(prefix: str, n: int) -> str: return f'{prefix}-{n:06d}'

def assert_authority(classification: Classification) -> None:
    if classification == Classification.DERIVED_REBUILDABLE: raise AuthorityError('derived/rebuildable data cannot write authority tables')

_CURRENT_AUTHORITY_TOKENS = frozenset({
    "boundary", "boundaries", "consent", "grant", "grants", "safety",
    "sexuality", "sexuality_profile", "intimacy", "permission",
    "relationship", "relationships", "trust", "emotion", "goal",
    "autonomy", "turn", "clock", "scene", "location", "participant",
    "participants", "event", "events",
})
_PLAYER_INTERNAL_TOKENS = frozenset({
    "dialogue", "action", "actions", "attempt", "attempts", "desire",
    "desires", "feel", "feeling", "feelings", "intend", "intends",
    "intent", "intention", "intentions", "internal", "mental", "private",
})
_SAFE_FACT_PLANES = frozenset({Plane.OBJECTIVE.value})
_SAFE_FACT_CLASSIFICATIONS = frozenset({
    Classification.AUTHORITY.value, Classification.HISTORICAL_EVIDENCE.value,
})


def predicate_tokens(predicate: str) -> tuple[str, ...]:
    """Return structural, case-insensitive path/name components.

    Separators are syntax, not an authority escape hatch: ``boundary.current``
    and ``current_boundary`` therefore have the same significant components.
    Compact spellings are handled separately by :func:`predicate_compact_key`
    so a caller cannot evade ownership merely by deleting separators.
    """
    if not isinstance(predicate, str) or not predicate.strip():
        raise AuthorityError("fact predicate must be a non-empty string")
    expanded = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", predicate.strip())
    return tuple(x.lower() for x in re.split(r"[^A-Za-z0-9]+", expanded) if x)


def predicate_compact_key(predicate: str) -> str:
    """Canonical alphanumeric key used only for reserved-name classification.

    This deliberately does *not* rewrite stored predicates.  It closes spelling
    equivalence such as ``current.boundary`` / ``current_boundary`` /
    ``CurrentBoundary`` / ``currentboundary`` while keeping the storage schema
    and user-facing predicate text unchanged.
    """
    return "".join(predicate_tokens(predicate))


def _compact_set(values) -> frozenset[str]:
    return frozenset(re.sub(r"[^a-z0-9]+", "", str(v).lower()) for v in values)


_RUNTIME_PREFIX_COMPACT = _compact_set(RUNTIME_OWNED_PREFIXES)
_CURRENT_AUTHORITY_COMPACT = _compact_set(_CURRENT_AUTHORITY_TOKENS)
_PLAYER_INTERNAL_COMPACT = _compact_set(_PLAYER_INTERNAL_TOKENS)

# Compact identifiers are ambiguous because separator deletion erases path
# structure.  Treat only *structurally composable reserved semantics* as
# reserved: a runtime/player/NPC scope followed (or preceded) by a known
# current-authority field.  This closes e.g. ``playeremotion`` /
# ``npcpermission`` without falling back to arbitrary substring matching.
_RUNTIME_SCOPE_COMPACT = _compact_set(
    set(RUNTIME_OWNED_PREFIXES)
    | {"runtime", "current", "npc", "npcs", "player", "pc", "plr",
       "player_character"}
)
_PLAYER_SCOPE_COMPACT = _compact_set(
    {"player", "pc", "plr", "player_character", "private"}
)


def _compact_reserved_scope_field(
        compact: str, scopes: frozenset[str], fields: frozenset[str]) -> bool:
    """Return True when a compact key is a reserved scope/field composition.

    Up to three leading or trailing scope atoms are recognized so canonical
    separator-free equivalents such as ``playercurrentboundary`` and
    ``currentnpcgoal`` cannot evade the same ownership rule.  Matching is by
    complete reserved atoms, never arbitrary substring containment.
    """
    if compact in fields:
        return True

    frontier = {compact}
    seen = {compact}
    for _ in range(3):
        nxt: set[str] = set()
        for value in frontier:
            for scope in scopes:
                if value.startswith(scope) and len(value) > len(scope):
                    rest = value[len(scope):]
                    if rest in fields:
                        return True
                    if rest not in seen:
                        seen.add(rest); nxt.add(rest)
                if value.endswith(scope) and len(value) > len(scope):
                    rest = value[:-len(scope)]
                    if rest in fields:
                        return True
                    if rest not in seen:
                        seen.add(rest); nxt.add(rest)
        frontier = nxt
        if not frontier:
            break
    return False


_PLAYER_INTERNAL_COMBINATIONS = frozenset(
    {scope + token for scope in _PLAYER_SCOPE_COMPACT
                     for token in _PLAYER_INTERNAL_COMPACT}
    | {token + scope for scope in _PLAYER_SCOPE_COMPACT
                     for token in _PLAYER_INTERNAL_COMPACT}
    | {a + b for a in _PLAYER_INTERNAL_COMPACT for b in _PLAYER_INTERNAL_COMPACT
       if a != b}
)


def is_runtime_owned_predicate(predicate: str) -> bool:
    tokens = predicate_tokens(predicate)
    compact = predicate_compact_key(predicate)
    head = tokens[0]
    if head in RUNTIME_OWNED_PREFIXES or head in _CURRENT_AUTHORITY_TOKENS or head == "runtime":
        return True
    # Exact canonical equivalents of reserved namespaces remain reserved even
    # when the separator was removed (e.g. sexuality_profile -> sexualityprofile).
    if compact in _RUNTIME_PREFIX_COMPACT or compact in _CURRENT_AUTHORITY_COMPACT:
        return True
    # An explicit compact runtime namespace is always runtime-owned.
    if compact.startswith("runtime"):
        return True
    # Reverse/path-order and compact spellings cannot evade current authority.
    if "current" in tokens and bool(set(tokens) & _CURRENT_AUTHORITY_TOKENS):
        return True
    return _compact_reserved_scope_field(
        compact, _RUNTIME_SCOPE_COMPACT, _CURRENT_AUTHORITY_COMPACT)


def looks_like_player_ref(subject_ref: str) -> bool:
    """Conservative planner-side recognition; the writer also checks entities."""
    if not isinstance(subject_ref, str):
        return False
    ref = subject_ref.strip().lower()
    return (ref in {"player", "pc", "player_character"}
            or ref.startswith(("player-", "player_", "plr-", "plr_", "e-pl")))


def is_player_internal_predicate(predicate: str) -> bool:
    tokens = set(predicate_tokens(predicate))
    if tokens & _PLAYER_INTERNAL_TOKENS:
        return True
    compact = predicate_compact_key(predicate)
    return compact in _PLAYER_INTERNAL_COMBINATIONS


def validate_continuity_fact_claim(*, predicate: str, subject_ref: str,
                                   plane: str = "OBJECTIVE",
                                   classification: str = "AUTHORITY",
                                   is_player_subject: bool = False) -> None:
    """Shared Phase 1/3 structural ownership gate for continuity facts."""
    if is_runtime_owned_predicate(predicate):
        raise AuthorityError(f"runtime-owned field rejected: {predicate}")
    player = bool(is_player_subject or looks_like_player_ref(subject_ref))
    if player and is_player_internal_predicate(predicate):
        raise AuthorityError(
            f"player-owned internal state rejected: {subject_ref}:{predicate}")
    if str(plane).upper() not in _SAFE_FACT_PLANES:
        raise AuthorityError(f"continuity fact plane is not OBJECTIVE: {plane}")
    if str(classification).upper() not in _SAFE_FACT_CLASSIFICATIONS:
        raise AuthorityError(
            f"continuity fact classification is not authority-safe: {classification}")


def assert_non_runtime_predicate(predicate: str) -> None:
    if is_runtime_owned_predicate(predicate):
        raise AuthorityError(f'runtime-owned field rejected: {predicate}')

def validate_fact(f: FactInput) -> None:
    assert_authority(f.classification)
    assert_non_runtime_predicate(f.predicate)
    if looks_like_player_ref(f.subject_ref) and is_player_internal_predicate(f.predicate):
        raise AuthorityError(
            f"player-owned internal state rejected: {f.subject_ref}:{f.predicate}")
    if f.valid_from_turn is not None and f.valid_from_turn < 0: raise ValidationError('valid_from_turn must be non-negative')
    if f.invalid_at_turn is not None and f.valid_from_turn is not None and f.invalid_at_turn < f.valid_from_turn: raise ValidationError('invalid_at precedes valid_from')
    if f.truth_status == TruthStatus.AUTHOR_PLAN and f.plane != Plane.AUTHOR: raise ValidationError('AUTHOR_PLAN must be AUTHOR plane')
    if f.admission_state == AdmissionState.COMMITTED and f.truth_status in {TruthStatus.ACTIVE,TruthStatus.ACTIVE_INTERPRETATION} and not f.provenance_json.strip(): raise ValidationError('committed current fact requires provenance')

def insert_fact(conn: sqlite3.Connection, f: FactInput) -> None:
    validate_fact(f)
    # Phase 1 also resolves opaque player IDs from the authority entity table so
    # the sovereignty gate does not depend on a naming convention.
    row = conn.execute(
        "SELECT kind FROM entities WHERE branch_id='default' AND entity_id=?",
        (f.subject_ref,)).fetchone()
    is_player = bool(row is not None and str(row[0]).lower() == "player")
    if is_player and is_player_internal_predicate(f.predicate):
        raise AuthorityError(
            f"player-owned internal state rejected: {f.subject_ref}:{f.predicate}")
    with conn:
        conn.execute(
            'INSERT INTO facts (fact_id, branch_id, subject_ref, predicate, object_json, plane, admission_state, truth_status, valid_from_turn, invalid_at_turn, recorded_at_turn, recorded_at, provenance_json, classification) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
            (f.fact_id, 'default', f.subject_ref, f.predicate, f.object_json, f.plane.value, f.admission_state.value, f.truth_status.value, f.valid_from_turn, f.invalid_at_turn, f.recorded_at_turn, utc_now(), f.provenance_json, f.classification.value),
        )

def current_facts(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return list(conn.execute("SELECT * FROM facts WHERE admission_state='COMMITTED' AND truth_status IN ('ACTIVE','ACTIVE_INTERPRETATION') AND plane='OBJECTIVE'"))

def supersede(conn: sqlite3.Connection, old: str, new: str, tx: str) -> None:
    with conn:
        cur=conn.execute("UPDATE facts SET truth_status='SUPERSEDED' WHERE fact_id=? AND admission_state='COMMITTED'",(old,))
        if cur.rowcount != 1: raise ValidationError('cannot supersede missing/noncommitted fact')
        conn.execute('INSERT INTO fact_supersessions VALUES(?,?,?)',(old,new,tx))

def add_knowledge(conn: sqlite3.Connection, *, knowledge_id:str, subject_ref:str, proposition_ref:str, state:KnowledgeState, source:str, promotion_basis:str, turn:int, provenance:dict, plane:Plane=Plane.CHARACTER, previous:KnowledgeState|None=None) -> None:
    if not source or not promotion_basis or not provenance: raise ValidationError('knowledge promotion requires source, basis, provenance')
    if previous == KnowledgeState.SUSPECTS and state == KnowledgeState.KNOWS and promotion_basis.strip().lower() in {'', 'automatic', 'inference'}: raise ValidationError('suspects cannot promote to knows without basis')
    with conn:
        conn.execute(
            'INSERT INTO knowledge (knowledge_id, branch_id, subject_ref, proposition_ref, state, plane, source, promotion_basis, turn, provenance_json) VALUES (?,?,?,?,?,?,?,?,?,?)',
            (knowledge_id, 'default', subject_ref, proposition_ref, state.value, plane.value, source, promotion_basis, turn, json.dumps(provenance, sort_keys=True)),
        )

def assert_reveal_allowed(conn: sqlite3.Connection, thread_id:str, satisfied_refs:set[str]) -> None:
    reqs=conn.execute('SELECT ref FROM thread_requires WHERE thread_id=?',(thread_id,)).fetchall()
    missing=[r['ref'] for r in reqs if r['ref'] not in satisfied_refs]
    if missing: raise ValidationError('REVEAL_BLOCKED: '+','.join(missing))

def unsupported_merge(*_: object) -> None:
    from .errors import UnsupportedOperationError
    raise UnsupportedOperationError('entity merge is unsupported and fail-closed in Phase 1')
def unsupported_fork(*_: object) -> None:
    from .errors import UnsupportedOperationError
    raise UnsupportedOperationError('runtime fork is unsupported and fail-closed in Phase 1')
def unsupported_restore(*_: object) -> None:
    from .errors import UnsupportedOperationError
    raise UnsupportedOperationError('runtime restore is unsupported and fail-closed in Phase 1')
