from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from .constants import AdmissionState, Classification, Plane, TruthStatus

@dataclass(frozen=True)
class FactInput:
    fact_id: str; subject_ref: str; predicate: str; object_json: str
    plane: Plane; admission_state: AdmissionState; truth_status: TruthStatus
    valid_from_turn: int | None; invalid_at_turn: int | None; recorded_at_turn: int
    provenance_json: str; classification: Classification = Classification.AUTHORITY

@dataclass(frozen=True)
class RuntimeObservation:
    path: str; observed_runtime_sha256: str; turn: int | None
    clock: str | None; scene_id: str | None; live_slice: dict[str, Any]
