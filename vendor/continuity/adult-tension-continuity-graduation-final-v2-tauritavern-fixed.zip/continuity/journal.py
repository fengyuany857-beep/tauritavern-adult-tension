from __future__ import annotations
from datetime import datetime, timezone
from .constants import JOURNAL_TRANSITIONS, JournalState
from .errors import JournalTransitionError

def transition(current: JournalState, target: JournalState) -> JournalState:
    if target not in JOURNAL_TRANSITIONS[current]: raise JournalTransitionError(f'illegal journal transition: {current.value}->{target.value}')
    return target
def new_entry(tx_id:str, operation:str, pre_hash:str) -> dict[str,str|None]:
    return {'continuity_tx_id':tx_id,'operation':operation,'observed_runtime_pre_hash':pre_hash,'observed_runtime_post_hash':None,'sidecar_state':JournalState.PREPARED.value,'created_at':datetime.now(timezone.utc).isoformat(timespec='seconds'),'committed_at':None,'failure_reason':None}
