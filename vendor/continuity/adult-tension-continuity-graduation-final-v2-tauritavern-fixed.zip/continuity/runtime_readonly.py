from __future__ import annotations
import importlib.util
from pathlib import Path
from typing import Any
from .errors import RuntimeReadOnlyError
from .hashing import sha256_file
from .models import RuntimeObservation

def _load_module(vendor: Path, name:str) -> Any:
    path=vendor/'scripts'/f'{name}.py'; spec=importlib.util.spec_from_file_location(f'continuity_readonly_{name}',path)
    if spec is None or spec.loader is None: raise RuntimeReadOnlyError(f'cannot load runtime read-only module: {name}')
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def _read_state(live: Any, path: Path) -> dict[str, Any]:
    if getattr(live, 'yaml', None) is not None:
        return live._load(path)
    # JSON is a strict YAML subset; this supports offline test fixtures only without
    # pretending arbitrary YAML can be parsed when the runtime dependency is absent.
    import json
    try: data=json.loads(path.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError) as exc: raise RuntimeReadOnlyError('PyYAML unavailable; only JSON-subset YAML fixture is readable') from exc
    if not isinstance(data,dict): raise RuntimeReadOnlyError('runtime state is not a mapping')
    return data

def observe(vendor: Path, runtime_state: Path) -> RuntimeObservation:
    if not runtime_state.is_file(): raise RuntimeReadOnlyError('runtime state is not a readable file')
    before=sha256_file(runtime_state)
    live=_load_module(vendor,'live_slice')
    state=_read_state(live,runtime_state)
    payload=live.extract_live_slice(state)
    after=sha256_file(runtime_state)
    if before != after: raise RuntimeReadOnlyError('runtime state changed during read; refusing observation')
    node=state.get('current_node') or {}; meta=state.get('meta') or {}; world=state.get('world') or {}
    return RuntimeObservation(str(runtime_state),before,meta.get('turn'),world.get('clock'),node.get('scene_id'),payload)

def npc_card(vendor: Path, runtime_state: Path, npc_id:str) -> dict[str,Any]:
    live=_load_module(vendor,'live_slice'); before=sha256_file(runtime_state); state=_read_state(live,runtime_state); after=sha256_file(runtime_state)
    if before != after: raise RuntimeReadOnlyError('runtime state changed during read; refusing card')
    for npc in state.get('npcs') or []:
        if isinstance(npc,dict) and npc.get('id') == npc_id: return dict(npc)
    raise RuntimeReadOnlyError(f'unknown runtime NPC ID: {npc_id}')

def validate_runtime(vendor: Path, runtime_state: Path) -> list[str]:
    live=_load_module(vendor,'live_slice'); validator=_load_module(vendor,'validate_state'); before=sha256_file(runtime_state); data=_read_state(live,runtime_state); result=validator.validate_data(data,'save'); after=sha256_file(runtime_state)
    if before != after: raise RuntimeReadOnlyError('runtime state changed during validation')
    return list(result)
