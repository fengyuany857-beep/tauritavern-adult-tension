from __future__ import annotations
import sqlite3
from pathlib import Path
from .migrations import migrate

def connect(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    c=sqlite3.connect(path); c.row_factory=sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON'); c.execute('PRAGMA journal_mode=WAL'); migrate(c)
    return c

def integrity(conn: sqlite3.Connection) -> str:
    return str(conn.execute('PRAGMA integrity_check').fetchone()[0])
