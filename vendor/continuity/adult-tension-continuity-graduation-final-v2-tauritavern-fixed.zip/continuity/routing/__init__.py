"""Phase 2B-1 Context Router + Residency + Context Pack (read-only)."""
from .builder import BUILDER_VERSION, ContextPackBuilder, BuilderError
from .budget import allocate, BudgetResult
from .contracts import (
    ContextCandidate, ContextMode, ContextPack, ContextPackItem, DroppedRecord,
    Insufficiency, PackStatus, ResidencyTier, RoutingDecision, RoutingRequest,
)
from .features import QueryFeatures
from .residency import classify, best_activation, PRESENTATION_RESTRICTED
from .router import ContextRouter

__all__ = [
    "ContextMode", "ResidencyTier", "PackStatus", "RoutingRequest",
    "RoutingDecision", "ContextCandidate", "ContextPackItem", "ContextPack",
    "Insufficiency", "DroppedRecord",
    "ContextRouter", "QueryFeatures", "ContextPackBuilder", "allocate",
    "BudgetResult", "classify", "best_activation", "PRESENTATION_RESTRICTED",
    "BUILDER_VERSION", "BuilderError",
]
