"""Residency classification & pack-level negative guards (read-only policy).

Residency tiers are retrieval-distance only (SPEC §"Context residency", §18):

  HOT  = current references / constraints that a decision model MUST see.
         Hard-pinned (budget-protected).  Never truth/permission.
  WARM = relevant context activated by scene/entity/recent signals.
  COLD = archival/old/resolved/superseded.  Only surface under DEEP/EVIDENCE or
         an explicit historical request; otherwise excluded at pack level.

A "lane" is the stable retrieval-domain label a ContextCandidate carries in
``meta["ctx"]``.  Decision of lane→tier lives HERE and nowhere else so the
builder is deterministic and introspectable.
"""
from __future__ import annotations
from .contracts import ContextCandidate, ContextMode, ResidencyTier

PRESENTATION_RESTRICTED = "PRESENTATION_RESTRICTED"

# (tier, hard) for canonical lanes -------------------------------------------
HOT_HARD_LANES = {
    "scene_participant",
    "runtime_authority_reference",
    "explicit_non_capability",
    "due_commitment",
    "observer_restriction",
    "reveal_gate_record",
    "anti_merge_guard",
    # Phase 2B-2 re-entry lanes (SPEC §10 hard anchors / §13 priority commitments
    # / §22 guard assembly).  Hard HOT means *must be presented to the decision
    # model*, never truth/permission.  Additive lanes; existing FAST scope filter
    # ignores them because they only materialise under a DEEP/return decision.
    "reentry_identity",
    "reentry_noncapability",
    "reentry_commitment_due",
    "reentry_reveal_gate_record",
    "reentry_anti_merge_guard",
    "reentry_runtime_card",
    "reentry_guard",
    "reentry_plot_non_requirement",
    "reentry_observer_restriction",
}
WARM_LANES = {
    "observer_knowledge",
    "relationship_semantics",
    "recent_scene",
    "thread_linkage",
    "nearby_commitment",
    "canonical_current",
    "character_false_belief",      # stays CHARACTER, not objective
    # Phase 2B-2 relaxed (soft) recall lanes are still WARM so they can enter a
    # DEEP/EVIDENCE pack after the branch-wide FAST scope filter, but never on a
    # bare FAST turn.
    "reentry_knowledge",
    "reentry_relationship",
    "reentry_soft_anchor",
    "reentry_thread",
}
ARCHIVAL_LANES = {
    "historical_quote_evidence",
    "superseded_history",
    "old_resolved_thread",
    "old_branch",
    "archival_episode",
    "historical_pointer",
    # Phase 2B-2 re-entry episodic recall is archival: only DEEP/EVIDENCE (or an
    # explicit historical request) surfaces old "last met" / changed-episode.
    "reentry_episode",
    "reentry_evidence",
}

_LANE_TIER: dict[str, tuple[str, bool]] = {
    lane: ("HOT", True) for lane in HOT_HARD_LANES
}
_LANE_TIER.update({lane: ("WARM", False) for lane in WARM_LANES})
_LANE_TIER.update({lane: ("COLD", False) for lane in ARCHIVAL_LANES})


def classify(candidate: ContextCandidate, mode: ContextMode) -> tuple[ResidencyTier, bool]:
    """Return (residency tier, hard_pin).

    Deterministic: uses the candidate's stable lane.  Fallbacks cover items that
    entered without an explicit lane (e.g. mapped retrieval items) — current
    items become WARM, non-current/resolved become COLD.
    """
    lane = candidate.meta.get("ctx")
    if isinstance(lane, str) and lane in _LANE_TIER:
        tier_s, hard = _LANE_TIER[lane]
        return ResidencyTier(tier_s), hard
    # presentation restricted never enters ordinary IC narration
    if candidate.presentation_state == PRESENTATION_RESTRICTED or \
            PRESENTATION_RESTRICTED in (candidate.item.flags or ()) if candidate.item is not None else False:
        return ResidencyTier.COLD, candidate.meta.get("hard", False)
    ai = str(candidate.item.authority_status) if candidate.item is not None else ""
    cur = str(candidate.item.current_or_historical) if candidate.item is not None else "current"
    if cur == "current" and ai != "SUPERSEDED":
        return ResidencyTier.WARM, candidate.meta.get("hard", False)
    if candidate.meta.get("hard") is True:
        return ResidencyTier.HOT, True
    return ResidencyTier.COLD, False


def best_activation(candidate: ContextCandidate, tier: ResidencyTier) -> str:
    lane = candidate.meta.get("ctx")
    return candidate.activation_reason or (lane if isinstance(lane, str) else "contextual")
