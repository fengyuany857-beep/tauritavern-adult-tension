"""Deterministic Context Pack token-budget allocation.

Ordering / drop discipline (SPEC §24 / §25 "Token budget overflow"):
  1. reserve hard HOT items  (never dropped for budget)
  2. include remaining HOT
  3. relevant WARM
  4. COLD only if mode permits
  5. if a hard item set alone exceeds the budget -> PACK_BUDGET_BLOCKED
     (never quietly truncate a hard constraint)

Every soft item dropped because of the budget emits a BUDGET_DROPPED record so
callers can explain exactly what was trimmed (no silent drops).
"""
from __future__ import annotations
from dataclasses import dataclass
from .contracts import (ContextCandidate, DroppedRecord, ResidencyTier)

_TIER_ORDER = (ResidencyTier.HOT, ResidencyTier.WARM, ResidencyTier.COLD)


@dataclass
class BudgetResult:
    kept: list[ContextCandidate]
    dropped: list[DroppedRecord]
    budget_blocked: bool = False
    hard_cost: int = 0
    used: int = 0


def _tier_rank(tier: ResidencyTier) -> int:
    return {ResidencyTier.HOT: 0, ResidencyTier.WARM: 1, ResidencyTier.COLD: 2}[tier]


def _candidate_key(c: ContextCandidate) -> tuple[int, int, str]:
    # (tier asc, priority desc, item_id asc) -> deterministic
    return (_tier_rank(c.residency), -c.priority, c.item.item_id)


def allocate(candidates: list[ContextCandidate], budget: int | None,
             mode_allows_cold: bool) -> BudgetResult:
    hard_cost = sum(c.item.estimated_token_cost for c in candidates
                    if c.hard_pin and c.residency == ResidencyTier.HOT)

    if budget is not None and hard_cost > budget:
        # Never silently truncate hard constraints.
        dropped = [
            DroppedRecord(item_id=c.item.item_id, source_ref=c.item.source_ref,
                          source_type=c.item.source_type.value if hasattr(c.item.source_type, "value") else str(c.item.source_type),
                          residency=c.residency.value, hard_included=c.hard_pin,
                          activation_reason=c.activation_reason,
                          estimated_token_cost=c.item.estimated_token_cost,
                          reason="PACK_BUDGET_BLOCKED: hard HOT alone exceeds budget")
            for c in candidates if c.hard_pin and c.residency == ResidencyTier.HOT
        ]
        return BudgetResult(kept=[], dropped=dropped, budget_blocked=True, hard_cost=hard_cost)

    ordered = sorted(candidates, key=_candidate_key)

    # Separate pass: add candidates in tier order; hard items are locked in.
    kept: list[ContextCandidate] = []
    acc = 0
    dropped: list[DroppedRecord] = []

    def can_add(c: ContextCandidate) -> bool:
        nonlocal acc
        new_cost = c.item.estimated_token_cost
        if budget is None:
            return True
        return acc + new_cost <= budget

    # Hard HOT always enters regardless of mode/budget cap beyond hard_cost check.
    for c in ordered:
        if c.hard_pin and c.residency == ResidencyTier.HOT:
            kept.append(c)
            acc += c.item.estimated_token_cost

    if budget is not None and acc > budget:
        # only reachable if non-boolean model over-budget; treat as blocked
        dropped = [DroppedRecord(item_id=c.item.item_id, source_ref=c.item.source_ref,
                                 source_type=get_stype(c), residency=c.residency.value,
                                 hard_included=True, activation_reason=c.activation_reason,
                                 estimated_token_cost=c.item.estimated_token_cost,
                                 reason="PACK_BUDGET_BLOCKED: hard HOT exceeds budget")
                   for c in kept]
        return BudgetResult(kept=[], dropped=dropped, budget_blocked=True,
                            hard_cost=acc, used=0)

    # Then remaining items by tier order, respecting budget, with drops traced.
    mode_ok_tier = {ResidencyTier.HOT, ResidencyTier.WARM}
    if mode_allows_cold:
        mode_ok_tier.add(ResidencyTier.COLD)

    for tier in _TIER_ORDER:
        bucket = [c for c in ordered
                  if not (c.hard_pin and c.residency == ResidencyTier.HOT)
                  and c.residency == tier]
        for c in bucket:
            if tier not in mode_ok_tier:
                dropped.append(DroppedRecord(
                    item_id=c.item.item_id, source_ref=c.item.source_ref,
                    source_type=get_stype(c), residency=tier.value, hard_included=c.hard_pin,
                    activation_reason=c.activation_reason, estimated_token_cost=c.item.estimated_token_cost,
                    reason="COLD_EXCLUDED_IN_MODE"))
                continue
            if not can_add(c):
                dropped.append(DroppedRecord(
                    item_id=c.item.item_id, source_ref=c.item.source_ref,
                    source_type=get_stype(c), residency=tier.value, hard_included=False,
                    activation_reason=c.activation_reason, estimated_token_cost=c.item.estimated_token_cost,
                    reason="BUDGET_DROPPED"))
                continue
            kept.append(c)
            acc += c.item.estimated_token_cost

    return BudgetResult(kept=kept, dropped=dropped, budget_blocked=False,
                        hard_cost=hard_cost, used=acc)


def get_stype(c: ContextCandidate) -> str:
    st = c.item.source_type
    return st.value if hasattr(st, "value") else str(st)
