"""Phase 2B-1 read-only Context Router / Context Pack contracts.

All types here are pure data: building a Context Pack never writes authority
or runtime state.  These dataclasses mirror the SPEC_LOCK §17/§18/§19/§20 and
§"Context residency" contracts.

Residency (HOT/WARM/COLD) is a retrieval/distance policy, never truth/permission.
Hard pin means "must be presented to the decision model", never "is objective".
"""
from __future__ import annotations
from dataclasses import dataclass, field, fields
from enum import Enum
from typing import Any


class ContextMode(str, Enum):
    FAST = "FAST"
    DEEP = "DEEP"
    EVIDENCE = "EVIDENCE"


class ResidencyTier(str, Enum):
    HOT = "HOT"
    WARM = "WARM"
    COLD = "COLD"


class PackStatus(str, Enum):
    OK = "OK"
    PARTIAL = "PARTIAL"
    AMBIGUOUS = "AMBIGUOUS"
    EVIDENCE_INSUFFICIENT = "EVIDENCE_INSUFFICIENT"
    EVIDENCE_CORRUPT = "EVIDENCE_CORRUPT"
    PACK_BUDGET_BLOCKED = "PACK_BUDGET_BLOCKED"
    ROUTING_BLOCKED = "ROUTING_BLOCKED"


# Information planes permitted inside an ordinary in-character Context Pack.
# PLAYER_VISIBLE and AUTHOR are intentionally excluded unless an explicit
# Director/evidence request opts them in via the EscapePlane override.
IC_OBJECTIVE_AND_CHARACTER = frozenset({"OBJECTIVE", "CHARACTER"})


@dataclass(frozen=True)
class RoutingRequest:
    """Input to the deterministic Router.

    raw_text never drives mode by a single keyword; it is decomposed into
    semantic query features and combined with scene/entity signals.
    mode_override is DEBUG/test only; production orchestration passes None.
    """
    query_id: str = ""
    raw_text: str = ""
    branch_id: str = "default"
    observer_entity_id: str | None = None
    # Continuity entity ids currently present in the scene (read-only context).
    scene_entity_ids: tuple[str, ...] = ()
    event_turn: int | None = None
    as_known_at: int | None = None
    world_time: str | None = None
    mode_override: ContextMode | None = None
    token_budget: int | None = None
    # Director context allows AUTHOR plane; evidence re-inspection allows the
    # PLAYER_VISIBLE / presentation gates to be opened explicitly.
    explicit_historical_request: bool = False
    explicit_author_context: bool = False
    # E.g. the exact last time this observer turned 3 world days ago.
    last_seen_turn: int | None = None


@dataclass(frozen=True)
class RoutingDecision:
    initial_mode: ContextMode
    final_mode: ContextMode
    reasons: tuple[str, ...] = ()
    hard_triggers: tuple[str, ...] = ()
    soft_triggers: tuple[str, ...] = ()
    escalation_reasons: tuple[str, ...] = ()
    evidence_required: bool = False
    confidence: str = "high"
    escalation_allowed: bool = True
    query_features: tuple[tuple[str, Any], ...] = ()


@dataclass
class ContextCandidate:
    """Internal pre-pack assembly unit.  NOT serialised as authority."""
    item: Any                 # RetrievalItem or synthetic runtime reference
    residency: ResidencyTier = ResidencyTier.COLD
    hard_pin: bool = False
    activation_reason: str = ""
    priority: int = 100       # higher = sooner
    classification: str = "AUTHORITY_REFERENCE"
    plane: str = "OBJECTIVE"
    observer_scope: str | None = None
    temporal_scope: str = ""
    presentation_state: str = "PRESENTABLE"
    meta: dict[str, Any] = field(default_factory=dict)
    trace_refs: tuple[str, ...] = ()
    retrieval_score: float = 0.0


@dataclass
class ContextPackItem:
    item_id: str
    source_ref: str
    source_type: str
    classification: str
    authority_status: str
    plane: str
    observer_scope: str | None
    residency: str
    hard_or_soft: str
    activation_reason: str
    priority: int
    retrieval_score: float
    estimated_token_cost: int
    temporal_scope: str
    presentation_state: str
    content: str
    provenance: str
    trace_refs: tuple[str, ...] = ()
    budget_action: str = "KEPT"


@dataclass
class DroppedRecord:
    item_id: str
    source_ref: str
    source_type: str
    residency: str
    hard_included: bool
    activation_reason: str
    estimated_token_cost: int
    reason: str = "BUDGET_DROPPED"


@dataclass
class Insufficiency:
    claim: str
    mode_attempted: str
    reason: str


@dataclass
class ContextPack:
    pack_id: str
    query_id: str
    branch_id: str
    observer_entity_id: str | None
    runtime_observed_sha256: str | None
    initial_mode: str
    final_mode: str
    routing_reasons: tuple[str, ...]
    token_budget: int | None
    estimated_token_used: int
    status: PackStatus
    mode: str
    items: tuple[ContextPackItem, ...] = ()
    dropped: tuple[DroppedRecord, ...] = ()
    scope_drops: tuple[DroppedRecord, ...] = ()
    insufficiency: tuple[Insufficiency, ...] = ()
    retrieval_trace_refs: tuple[str, ...] = ()
    builder_version: str = ""
    semantic_digest: str = ""
    hard_cost: int = 0
    authoritativeness: str = "EPHEMERAL / NON_AUTHORITY"

    def as_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {}
        for f in fields(self):
            v = getattr(self, f.name)
            if f.name == "items":
                v = [i.__dict__ for i in self.items]
            elif f.name in ("dropped", "scope_drops"):
                v = [i.__dict__ for i in v]
            elif f.name == "insufficiency":
                v = [i.__dict__ for i in self.insufficiency]
            elif isinstance(v, tuple):
                v = list(v)
            elif isinstance(v, PackStatus):
                v = v.value
            d[f.name] = v
        return d
