"""ContextPackBuilder — read-only orchestration (Phase 2B-1).

Composes the Phase 2A Retrieval Engine into an EPHEMERAL / NON_AUTHORITY
Context Pack for a single decision.

Read-only & authority rules enforced:
  * SQLite handle is opened read-only (PRAGMA query_only) and executes only
    SELECT; no DDL/DML, no scripts, and no runtime write is ever performed.
  * Runtime adult authority appears only as a fingerprint *reference*; its value
    and interpretation stay in the runtime contract.  The pack never caches a
    permission result across turns and never treats history/trust/attraction as
    current permission.
  * Hard HOT constraints are budget protected; if they alone overflow the budget
    the pack is PACK_BUDGET_BLOCKED (never a silent truncation).
  * NO promotion, NO relationship mutation, NO auto-merge, NO Canon writing.
"""
from __future__ import annotations
import json
import sqlite3
import uuid
from dataclasses import replace
from pathlib import Path
from typing import Any

from ..errors import ContinuityError
from ..hashing import sha256_file
from .budget import allocate
from .contracts import (
    ContextCandidate, ContextMode, ContextPack, ContextPackItem, DroppedRecord,
    Insufficiency, PackStatus, ResidencyTier, RoutingDecision, RoutingRequest,
)
from .features import QueryFeatures
from .residency import classify, best_activation, PRESENTATION_RESTRICTED
from .router import ContextRouter, ESCALABLE_BY_STATUS

BUILDER_VERSION = "phase2b1-1.0.0"


class BuilderError(ContinuityError):
    """Raised only when the pack cannot be formed from a non-insufficiency cause
    (e.g. hard-constraint overflow)."""


# --------------------------------------------------------------------------- #
class _RefItem:
    """Synthetic read-only reference sharing the RetrievalItem vocabulary;
    never pretends to be an authority row and never carries a permission of its
    own."""

    def __init__(self, item_id: str, source_type: str, source_ref: str,
                 content: str, classification: str, est: int, *, plane: str = "OBJECTIVE",
                 flags: tuple = ()):
        self.item_id = item_id
        self.source_type = source_type
        self.source_ref = source_ref
        self.content = content
        self.classification = classification
        self.plane = plane
        self.authority_status = "AUTHORITY_REFERENCE"
        self.current_or_historical = "current"
        self.observer_scope = None
        self.temporal_scope = ""
        self.provenance = "reference-only"
        self.flags = flags
        self.estimated_token_cost = est
        self.rank_score = 0.0
        self.branch_id = ""


class _Runtime:
    """Read-only JSON-subset snapshot; surfaces scene participant ids and a
    fingerprint only.  Adult permission fields are never inspected."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.fingerprint = sha256_file(self.path)
        try:
            self._data = json.loads(self.path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:  # pragma: no cover - unsupported path
            raise BuilderError("offline runtime snapshot must be JSON-subset YAML") from exc

    def participant_list(self):
        """Real on-stage participant source.  Order of authority:
             1) current_node.participants (the scene roster)
             2) player id (present by definition)
           npcs[] is NEVER a scene-participant source (P0-2): it is only a
           loaded-NPC registry, not evidence that an NPC is on stage now.
        Returns (deduped_ids, source_known: bool).  source_known=False means
        no authoritative current-node participant list existed (degraded); we
        fail closed rather than treat the npcs registry as on stage.
        """
        node = self._data.get("current_node")
        node_list = None
        if isinstance(node, dict):
            node_list = node.get("participants")
        out: list[str] = []
        source = []
        known = True
        if isinstance(node_list, (list, tuple)) and node_list:
            source.extend(str(p) for p in node_list)
        else:
            known = False            # no authoritative roster present
            source = []
        pl = self._data.get("player")
        if isinstance(pl, dict) and pl.get("id"):
            source.append(str(pl["id"]))
        for sid in source:
            if sid not in out:
                out.append(sid)
        return out, known

    def npc_ids(self) -> tuple[str, ...]:
        """Registry lookup of all loaded NPC ids.  Purely informational: used as
        a lookup index, never equivalent to 'current participants'."""
        out: list[str] = []
        for npc in (self._data.get("npcs") or []):
            if isinstance(npc, dict) and npc.get("id") and str(npc["id"]) not in out:
                out.append(str(npc["id"]))
        return tuple(out)


# --------------------------------------------------------------------------- #
def _jcomma(v):
    if isinstance(v, list):
        return ", ".join(str(x) for x in v)
    if isinstance(v, dict):
        # never include runtime keys that could be permission (consent etc.)
        safe = {k: val for k, val in v.items()
                if not any(tok in str(k).lower() for tok in ("consent", "grant", "boundary", "safety", "intimacy"))}
        return ", ".join(f"{k}={val}" for k, val in safe.items())
    return str(v)


class _Dao:
    def __init__(self, base: Path):
        self.base = Path(base)
        self.conn = sqlite3.connect(str(self.base / "state" / "continuity.sqlite3"))
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.execute("PRAGMA query_only=ON")

    def q(self, sql: str, params: tuple = ()) -> list:
        return list(self.conn.execute(sql, params))

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:  # pragma: no cover
            pass


# --------------------------------------------------------------------------- #
def _fast_relevant_ctx() -> frozenset[str]:
    """Context (lane) ids that are per se on-scene / guard ties and always
    eligible in a FAST pack.  Everything else only enters FAST when its subject
    intersects the current scene / detected query entity (P0-3)."""
    return frozenset({
        "scene_participant", "runtime_authority_reference", "explicit_non_capability",
        "due_commitment", "observer_restriction", "reveal_gate_record",
        "anti_merge_guard", "recent_scene",               # recent-context pointers
        "observer_knowledge", "character_false_belief",    # observer/POV knowledge
        "reentry_identity", "reentry_noncapability",
        "reentry_commitment_due", "reentry_reveal_gate_record",
        "reentry_anti_merge_guard", "reentry_runtime_card", "reentry_guard",
        "reentry_plot_non_requirement", "reentry_observer_restriction",
    })


def _subject_token(text: str) -> str:
    """Best-effort first whitespace token of a 'subject predicate: obj' content
    field (ids in this schema are single whitespace-free tokens)."""
    if not text:
        return ""
    return text.split(" ", 1)[0].strip()


def apply_fast_relevance_scope(dao: "_Dao", candidates: list, scene_ids: tuple,
                               detected: tuple, observer: str | None) -> tuple[list, list]:
    """FAST-only relevance filter (P0-3).  Branch-wide canonical pulls may leak
    offscreen entities into a FAST pack.  A candidate whose lane is not always
    on-scene / a guard tie is kept only when its subject intersects the current
    scene or a detected query entity; otherwise it is removed with an explicit
    trace (never silent).  DEEP/EVIDENCE path is untouched and retains broader
    recall."""
    always_eligible = _fast_relevant_ctx()
    kept: list = []
    scope_drops: list = []
    active_set = set(scene_ids) | set(detected)
    if observer:
        active_set.add(str(observer))
    for c in candidates:
        ctx = c.meta.get("ctx") or c.activation_reason or ""
        lane = ctx if isinstance(ctx, str) else "contextual"
        stype = getattr(c.item, "source_type", "")
        source_ref = getattr(c.item, "source_ref", "")
        if lane in always_eligible:
            kept.append(c)
            continue
        content = getattr(c.item, "content", "") or ""
        subjects: set[str] = set()
        if lane == "canonical_current" and stype == "FACT":
            row = dao.q("SELECT subject_ref FROM facts WHERE fact_id=? AND branch_id=?",
                        (source_ref, c.meta.get("branch_id") or "default"))
            if row:
                subjects.add(str(row[0]["subject_ref"]))
            if not subjects:
                subjects.add(_subject_token(content))
        elif lane == "relationship_semantics":
            subjects.add(_subject_token(content))
            if "->" in content:
                subjects.add(content.split("->", 1)[1].split(" ", 1)[0].strip())
        else:
            # Unknown-lane warm items without a guard tie are not forced on-scene.
            subjects.add(_subject_token(content))

        if subjects and (subjects & active_set):
            kept.append(c)
            continue
        tier_label = (c.residency.value if c.residency is not None else "") or "WARM"
        reason = ("FAST_SCOPE_OFFSCREEN" if lane == "canonical_current"
                  else "FAST_SCOPE_UNRELATED_ENTITY")
        scope_drops.append(DroppedRecord(
            item_id=c.item.item_id, source_ref=source_ref,
            source_type=str(stype),
            residency=tier_label, hard_included=False,
            activation_reason=c.activation_reason,
            estimated_token_cost=getattr(c.item, "estimated_token_cost", 0),
            reason=reason,
        ))
    return kept, scope_drops


# --------------------------------------------------------------------------- #
class Lanes:
    """Produces candidate ContextCandidates from a routing request + scene
    context + retrieval engine reads.  Deterministic; never writes."""

    def __init__(self, dao: _Dao, est, req: RoutingRequest, decision: RoutingDecision,
                 scene_ids: tuple[str, ...], observed: str | None,
                 detected_entities: tuple[str, ...], recent_window_turns: int = 20,
                 due_statuses: tuple = ("open", "due", "OPEN", "DUE", "active"),
                 off_card_max: int = 0):
        self.dao = dao
        self.est = est
        self.req = req
        self.decision = decision
        self.mode = decision.final_mode
        self.scene_ids = tuple(scene_ids)
        self.observed = observed
        self.detected_entities = tuple(detected_entities)
        self.recent_window_turns = recent_window_turns
        self.due_statuses = due_statuses
        self.off_card_max = off_card_max  # offscreen npc card reference cap (0 = none in FAST)

    # -------------------------------- public -------------------------------
    def assemble(self) -> tuple[list[ContextCandidate], list[Insufficiency], bool]:
        """returns (candidates, insufficiency, evidence_corrupt)"""
        out: list[ContextCandidate] = []
        insuff: list[Insufficiency] = []
        self.observed  # fingerprint handled in builder main pipeline

        # ---- HOT hard reference lanes ---------------------------------
        if self.observed:
            self._ref(out, "runtime-ref", "AUTHORITY_REFERENCE", "runtime",
                      f"observed runtime SHA-256 reference: {self.observed}",
                      ctx="runtime_authority_reference", reason="runtime observed hash (not a revision)")
        for e in self.scene_ids:
            self._ref(out, e, "ENTITY", e,
                      f"current participant anchor ({e})",
                      ctx="scene_participant", reason="scene participant identity anchor")

            row = self.dao.q("SELECT * FROM entities WHERE entity_id=?", (e,))
            if not row:
                continue
            self._ref(out, f"anchor:{e}", "ENTITY", e,
                      f"entity {e} hard anchor present",
                      ctx="scene_participant", reason="participant hard anchor (identity only)")
            noncap = self._entity_noncap(row[0])
            if noncap:
                self._ref(out, f"nc:{e}", "ENTITY", e,
                          f"{e} explicit non-capabilities: {noncap}",
                          ctx="explicit_non_capability",
                          reason="continuity non-capability constraint (ref only)")

        # ---- observer-scoped knowledge lanes ----------------------------
        self._knowledge(out)

        # ---- commitments / threads -------------------------------------
        self._commitments(out)
        corrupt_thread = self._threads(out)

        # ---- relationship semantics (context only, never permission) ----
        self._relationships(out)

        # ---- canonical + historical objective context via engines ------
        ev_corrupt = self._activity(out, insuff)

        if self.mode in (ContextMode.FAST, ContextMode.DEEP):
            self._recent_scene(out)   # small scene window (warm)

        if len(self.detected_entities) > 1:
            insuff.append(Insufficiency(claim="entity ambiguity",
                                        mode_attempted=self.mode.value,
                                        reason=">1 candidate identity; ambiguous"))

        return out, insuff, (corrupt_thread or ev_corrupt)

    # -------------------------------- lanes --------------------------------
    def _ref(self, out, item_id, stype, sref, content, *, ctx, reason="",
             hard=False, classification="AUTHORITY_REFERENCE", plane="OBJECTIVE"):
        flags = (PRESENTATION_RESTRICTED,) if stype == "THREAD" else ()
        try:
            stype_v = stype
        except Exception:
            stype_v = stype
        obj = _RefItem(item_id, stype_v, sref, content, classification,
                       self.est.estimate(content), plane=plane, flags=flags)
        cand = ContextCandidate(item=obj, meta={"ctx": ctx, "hard": hard,
                                                "_for_mode": self.mode.value},
                                hard_pin=hard, classification=classification,
                                plane=plane, activation_reason=reason or ctx)
        out.append(cand)
        return cand

    def _knowledge(self, out) -> None:
        obs = self.req.observer_entity_id
        if not obs:
            return
        rows = self.dao.q(
            "SELECT * FROM knowledge WHERE plane='CHARACTER' AND subject_ref=? AND branch_id=?",
            (obs, self.req.branch_id))
        for r in rows:
            state = r["state"]
            content = f"{r['subject_ref']} {state} {r['proposition_ref']}"
            if state == "does_not_know":
                self._ref(out, r["knowledge_id"], "KNOWLEDGE", r["knowledge_id"], content,
                          ctx="observer_restriction", reason="explicit does-not-know restriction")
            elif state == "false_belief":
                self._ref(out, r["knowledge_id"], "KNOWLEDGE", r["knowledge_id"], content,
                          ctx="character_false_belief", reason="POV false belief (classification CHARACTER)",
                          plane="CHARACTER", classification="CHARACTER")
            else:
                self._ref(out, r["knowledge_id"], "KNOWLEDGE", r["knowledge_id"], content,
                          ctx="observer_knowledge", reason="observer-scoped knowledge")

    def _commitments(self, out) -> None:
        if not (self.scene_ids or self.req.scene_entity_ids):
            return
        rows = self.dao.q("SELECT * FROM commitments WHERE branch_id=?", (self.req.branch_id,))
        for c in rows:
            iss = c["issuer_ref"]
            try:
                ben = json.loads(c["beneficiary_refs_json"] or "[]")
            except Exception:
                ben = []
            if not isinstance(ben, list):
                ben = []
            relevant = iss in self.scene_ids or any(b in self.scene_ids for b in ben)
            if not relevant:
                continue
            if c["status"] not in self.due_statuses:
                continue
            self._ref(out, c["commitment_id"], "COMMITMENT", c["commitment_id"],
                      f"{c['kind']}: {c['content']} issuer={iss} status={c['status']}",
                      ctx="due_commitment", reason="due/open commitment")

    def _threads(self, out) -> bool:
        corrupt = False
        requires: dict[str, list] = {}
        for r in self.dao.q("SELECT * FROM thread_requires", ()):
            requires.setdefault(r["thread_id"], []).append(r["ref"])
        am: dict[str, list] = {}
        for r in self.dao.q("SELECT * FROM thread_anti_merge", ()):
            am.setdefault(r["thread_id"], []).append(r["blocked_ref"])

        rows = self.dao.q("SELECT * FROM threads WHERE branch_id=?", (self.req.branch_id,))
        for row in rows:
            tid = row["thread_id"]
            try:
                gate = json.loads(row["reveal_gate_json"] or "{}")
            except Exception:
                gate = {}
            gate_open = bool(gate)
            reqlist = requires.get(tid, [])
            met = all(self._requirement_met(r) for r in reqlist) if gate_open else True

            if gate_open and not met:
                self._ref(out, f"gate:{tid}", "THREAD", tid,
                          f"reveal gate on thread {tid} unmet (prereqs={reqlist})",
                          ctx="reveal_gate_record", reason="gate-only record; reveal payload withheld")

            for blk in am.get(tid, []):
                self._ref(out, f"am:{tid}-x-{blk}", "THREAD", tid,
                          f"anti-merge guard: thread {tid} must not be merged with {blk}",
                          ctx="anti_merge_guard", reason="hard anti-merge guard")

            gated_closed = gate_open and not met
            if not gated_closed:
                self._ref(out, tid, "THREAD", tid,
                          f"thread {tid} linkage", ctx="thread_linkage",
                          reason="relevant thread linkage")
        return corrupt

    def _requirement_met(self, ref: str) -> bool:
        rows = self.dao.q(
            "SELECT truth_status, admission_state FROM facts WHERE fact_id=? AND branch_id=?",
            (ref, self.req.branch_id))
        if not rows:
            return False
        r = rows[0]
        return r["admission_state"] == "COMMITTED" and r["truth_status"] in ("ACTIVE", "ACTIVE_INTERPRETATION")

    def _relationships(self, out) -> None:
        if not self.scene_ids:
            return
        rows = self.dao.q("SELECT * FROM relationships WHERE branch_id=?", (self.req.branch_id,))
        for rel in rows:
            if rel["source_ref"] not in self.scene_ids and rel["target_ref"] not in self.scene_ids:
                continue
            content = f"relationship {rel['source_ref']}->{rel['target_ref']} phase={rel['phase']}"
            self._ref(out, rel["relationship_id"], "RELATIONSHIP", rel["relationship_id"],
                      content, ctx="relationship_semantics", reason="relationship semantics context")

    def _activity(self, out, insuff) -> bool:
        """Objective authoritative context via Temporal engine plus (only when
        the mode/historical warrants it) a read-only Evidence pass."""
        from ..retrieval import (Context, EvidenceRetriever, RetrievalQuery,
                                 TemporalRetriever)
        ctx = Context(conn=self.dao.conn, base=self.dao.base,
                      index_path=self.dao.base / "indexes" / "retrieval_fts.sqlite3")
        temporal = TemporalRetriever()
        query = RetrievalQuery(
            branch_id=self.req.branch_id,
            observer_entity_id=self.req.observer_entity_id,
            entity_ids=self.scene_ids,
            event_turn=self.req.event_turn,
            as_known_at=self.req.as_known_at,
            include_superseded=self.mode in (ContextMode.DEEP, ContextMode.EVIDENCE),
            include_historical=self.mode in (ContextMode.DEEP, ContextMode.EVIDENCE),
            exact_evidence_required=(self.mode == ContextMode.EVIDENCE),
            query_id=self.req.query_id or "builder",
        )
        res = temporal.retrieve(query, ctx)
        trace_by_id = {}
        for t in res.traces:
            trace_by_id.setdefault(t.candidate_item_id, []).append(t.trace_id)
        for item in res.items:
            cand = self._map_item(item, out, mode=self.mode)
            if cand is not None:
                cand.trace_refs = tuple(sorted(trace_by_id.get(item.item_id, ())))

        ev_corrupt = False
        if self.mode in (ContextMode.DEEP, ContextMode.EVIDENCE) or self.req.explicit_historical_request:
            ev = EvidenceRetriever()
            eq = RetrievalQuery(branch_id=self.req.branch_id,
                                observer_entity_id=self.req.observer_entity_id,
                                exact_evidence_required=(self.mode == ContextMode.EVIDENCE),
                                query_id=self.req.query_id or "evidence")
            er = ev.retrieve(eq, ctx)
            ev_corrupt = any(
                (not tr.included) and tr.exclusion_reason and "corrupt" in tr.exclusion_reason
                for tr in er.traces)
            trace_by_id2 = {}
            for t in er.traces:
                trace_by_id2.setdefault(t.candidate_item_id, []).append(t.trace_id)
            added_corrupt_ptr = False
            for item in er.items:
                corrupt = ev_corrupt and any(
                    (not tr.included) and tr.exclusion_reason and "corrupt" in tr.exclusion_reason
                    for tr in er.traces if tr.candidate_item_id == item.item_id)
                if corrupt:
                    cand = self._ref(out, item.item_id, "HISTORICAL_EVIDENCE", getattr(item, "source_ref", item.item_id),
                                     "evidence pointer corrupt (checksum)", ctx="historical_pointer",
                                     reason="evidence hash invalid; pointer preserved")
                    added_corrupt_ptr = True
                else:
                    cand = self._ref(out, item.item_id, "HISTORICAL_EVIDENCE", getattr(item, "source_ref", item.item_id),
                                     item.content, ctx="historical_quote_evidence", reason="evidence pointer")
                if cand is not None:
                    cand.trace_refs = tuple(sorted(trace_by_id2.get(item.item_id, ())))
            if ev_corrupt and not added_corrupt_ptr:
                self._ref(out, "evidence:corrupt-range", "HISTORICAL_EVIDENCE", "history",
                          "evidence span checksum corrupt; range quarantined",
                          ctx="historical_pointer", reason="quarantined corrupted evidence range")
            if self.mode == ContextMode.EVIDENCE:
                if ev_corrupt:
                    insuff.append(Insufficiency(claim="exact evidence span", mode_attempted="EVIDENCE",
                                                reason="evidence checksum corrupt; quarantined"))
                elif not er.items:
                    insuff.append(Insufficiency(claim="exact evidence span", mode_attempted="EVIDENCE",
                                                reason="no verifiable history span matched"))
        return ev_corrupt

    def _map_item(self, item, out, mode: ContextMode):
        atype = str(getattr(item, "authority_status", ""))
        plane = str(getattr(item, "plane", "OBJECTIVE"))
        item_id = getattr(item, "item_id", getattr(item, "source_ref", ""))
        sref = getattr(item, "source_ref", item_id)
        content = getattr(item, "content", "")
        src = getattr(item, "source_type", "")
        src_name = src.value if hasattr(src, "value") else str(src)
        if atype == "SUPERSEDED":
            return self._ref(out, item_id, "FACT", sref, content, ctx="superseded_history",
                             reason="superseded record (only shown under historical/evidence)")
        if plane == "CHARACTER":
            return self._ref(out, item_id, src_name or "FACT", sref, content,
                             ctx="character_false_belief", plane="CHARACTER", classification="CHARACTER",
                             reason="scene character context")
        return self._ref(out, item_id, src_name or "FACT", sref, content,
                         ctx="canonical_current", reason="canonical current objective context")

    def _entity_noncap(self, row) -> str:
        try:
            v = json.loads(row["explicit_non_capabilities_json"] or "[]")
        except Exception:
            v = []
        if not v:
            return ""
        return _jcomma(v)

    def _recent_scene(self, out) -> None:
        """Fast/DEEP small scene context: the most recent few episodes for this
        branch (deterministic, read from sidecar history pointers only)."""
        # Episodes we have pointers to; order by when the most recent transaction
        # was committed (created_at availability) — prefer continuity_tx order.
        rows = self.dao.q(
            "SELECT e.episode_id FROM episodes e "
            "LEFT JOIN continuity_transactions t ON t.continuity_tx_id=e.continuity_tx_id "
            "WHERE e.branch_id=? AND e.continuity_tx_id IS NOT NULL "
            "ORDER BY COALESCE(t.created_at,'') DESC",
            (self.req.branch_id,))
        for i, r in enumerate(rows[:self.recent_window_turns]):
            if i >= 2:  # a small scene window (FAST doesn't want a whole history)
                break
            self._ref(out, f"recent:{r['episode_id']}", "EPISODE", r["episode_id"],
                      f"recent scene pointer {r['episode_id']}",
                      ctx="recent_scene", reason="recent scene context")


# --------------------------------------------------------------------------- #
class ContextPackBuilder:
    """Public read-only pack builder entry point."""

    def __init__(self, base: Path):
        self.base = Path(base)
        from ..retrieval import ApproximateTokenEstimator
        self.est = ApproximateTokenEstimator()
        self.router = ContextRouter()

    def build(self, request: RoutingRequest, *,
              runtime_state: Path | None = None,
              detected_entities: tuple[str, ...] = (),
              reentry_candidates: tuple = ()) -> ContextPack:
        """Build a read-only Context Pack.

        ``reentry_candidates`` is an optional additive batch of
        :class:`ContextCandidate` produced by the Phase 2B-2 Re-entry Planner.
        Passing it keeps re-entry recall inside this single pack authority
        (residency / FAST scope / budget / drop traces / digest all still run
        here).  Empty by default — so Phase 2B-1 behaviour is unchanged.
        """
        dao = _Dao(self.base)
        try:
            return self._inner(dao, request, runtime_state, detected_entities,
                               reentry_candidates)
        finally:
            dao.close()

    # ==================================================================== #
    def _inner(self, dao: _Dao, request: RoutingRequest,
               runtime_state: Path | None,
               detected_entities: tuple[str, ...],
               reentry_candidates: tuple = ()) -> ContextPack:
        features = QueryFeatures(request.raw_text or "",
                                 explicit_historical=request.explicit_historical_request,
                                 scene_entity_ids=request.scene_entity_ids,
                                 entity_ids=detected_entities)
        decision = self.router.decide_initial(request, features)

        observed = None
        rt_participants: tuple[str, ...] = ()
        participant_source_known = False
        if runtime_state is not None:
            rt = _Runtime(runtime_state)
            observed = rt.fingerprint
            rt_participants, participant_source_known = rt.participant_list()
            rt_participants = tuple(rt_participants)

        # scene ids = EXPLICIT scene participants on the request take highest
        # authority (P0-2).  Falling back to the runtime roster is done ONLY from
        # the authoritative current_node participants list -- never from the
        # loaded npcs registry.  When no authoritative participant source is
        # present (degraded state) we fail closed and treat the scene as unknown
        # rather than promote unrelated npcs to 'scene participants'.
        scene_ids = tuple(request.scene_entity_ids)
        if not scene_ids and observed and participant_source_known:
            scene_ids = rt_participants
        # NOTE: when scene knowledge is genuinely absent we leave scene_ids empty
        # (no silent promotion of the npcs registry into HOT scene participants).
        if not scene_ids and detected_entities:
            scene_ids = tuple(e for e in detected_entities
                              if e in detected_entities)

        lanes = Lanes(dao, self.est, request, decision, scene_ids=scene_ids,
                      observed=observed, detected_entities=detected_entities)
        candidates, insuff, corrupt = lanes.assemble()

        # Phase 2B-2: additive re-entry candidates (if any) enter the SAME pack
        # authority pipeline below — they are not a second pack.  Re-entry items
        # only materialise from the Re-entry Planner on a DEEP/entity-return or
        # explicit historical decision, so an empty tuple keeps Phase 2B-1
        # behaviour identical.
        if reentry_candidates:
            merged = list(reentry_candidates) + list(candidates)
            candidates = merged

        # P0-3: FAST relevance scope — an on-present offscreen/old NPC must not
        # leak into a FAST pack through branch-wide canonical pulls.  Guard
        # / reveal / anti-merge records always stay; unrelated warm items are
        # removed with an explicit FAST_SCOPE_* trace.
        fast_scope_drops: list = []
        if decision.final_mode == ContextMode.FAST:
            candidates, fast_scope_drops = apply_fast_relevance_scope(
                dao, candidates, scene_ids=scene_ids,
                detected=detected_entities, observer=request.observer_entity_id)

        # pre-classify every candidate deterministically so the budget allocator
        # reasons over the correct residency / hard-pin before deciding what fits.
        for c in candidates:
            t, h = classify(c, decision.final_mode)
            c.residency = t
            c.hard_pin = h or bool(c.meta.get("hard"))

        cold_ok = (decision.final_mode in (ContextMode.DEEP, ContextMode.EVIDENCE)
                   or request.explicit_historical_request)
        br = allocate(candidates, request.token_budget, mode_allows_cold=cold_ok)

        if br.budget_blocked:
            return self._final(request, decision, observed, [], br.dropped, br.hard_cost,
                               PackStatus.PACK_BUDGET_BLOCKED, insuff, cold_ok, br,
                               scope_drops=fast_scope_drops)

        status = self._final_status(request, decision, insuff, corrupt, br)
        return self._final(request, decision, observed, br.kept, br.dropped, br.used,
                           status, insuff, cold_ok, br, scope_drops=fast_scope_drops)

    # ------------------------------------------------------------------ #
    def _final_status(self, request: RoutingRequest, decision: RoutingDecision,
                      insuff: list[Insufficiency], corrupt: bool, br) -> PackStatus:
        # evidence-domain: corruption and missing spans outrank ordinary OK even
        # when non-evidence (scene anchors etc.) are still present in the pack.
        if corrupt:
            return PackStatus.EVIDENCE_CORRUPT
        if decision.final_mode == ContextMode.EVIDENCE:
            ev_ins = [i for i in insuff if i.mode_attempted == "EVIDENCE"]
            if any("corrupt" in i.reason for i in ev_ins):
                return PackStatus.EVIDENCE_CORRUPT
            if any(i.reason.startswith("no verifiable") for i in ev_ins) or not br.kept:
                return PackStatus.EVIDENCE_INSUFFICIENT
        # other insufficiency that survived at the attempted mode
        for i in insuff:
            if i.mode_attempted == decision.final_mode.value:
                return PackStatus.AMBIGUOUS if "ambiguous" in i.reason else PackStatus.PARTIAL
        return PackStatus.OK

    # ------------------------------------------------------------------ #
    def _final(self, request: RoutingRequest, decision: RoutingDecision,
               observed: str | None, kept: list[ContextCandidate],
               dropped: list[DroppedRecord], used: int, status: PackStatus,
               insuff: list[Insufficiency], cold_ok: bool, br,
               scope_drops: list | None = None) -> ContextPack:
        items = self._to_items(kept, decision.final_mode)
        total = sum(i.estimated_token_cost for i in items)
        digest = self._digest(items, decision.final_mode, request.branch_id)
        trace_refs = tuple(sorted({t for c in kept for t in c.trace_refs}))
        hard_cost = br.hard_cost if br else sum(c.item.estimated_token_cost for c in kept if c.hard_pin)
        return ContextPack(
            pack_id=f"CP-{uuid.uuid4().hex[:10]}",
            query_id=request.query_id or "",
            branch_id=request.branch_id,
            observer_entity_id=request.observer_entity_id,
            runtime_observed_sha256=observed,
            initial_mode=decision.initial_mode.value,
            final_mode=decision.final_mode.value,
            routing_reasons=decision.reasons,
            token_budget=request.token_budget,
            estimated_token_used=total if status != PackStatus.PACK_BUDGET_BLOCKED else br.hard_cost,
            status=status,
            mode=decision.final_mode.value,
            items=tuple(items),
            dropped=tuple(dropped),
            scope_drops=tuple(scope_drops or ()),
            insufficiency=tuple(insuff),
            retrieval_trace_refs=trace_refs,
            builder_version=BUILDER_VERSION,
            semantic_digest=digest,
            hard_cost=hard_cost,
        )

    def _to_items(self, kept, mode: ContextMode) -> list[ContextPackItem]:
        staged: list[tuple[ContextPackItem, ResidencyTier, str]] = []
        for c in kept:
            tier, hard = classify(c, mode)
            c.residency = tier
            if hard:
                c.hard_pin = True
            item = self._pack_item(c, tier, hard)
            staged.append((item, tier, getattr(item, "source_ref", "")))
        order = {ResidencyTier.HOT: 0, ResidencyTier.WARM: 1, ResidencyTier.COLD: 2}
        staged.sort(key=lambda t: (order[t[1]], -t[0].priority, t[2], t[0].content))
        return [t[0] for t in staged]

    def _pack_item(self, cand: ContextCandidate, tier: ResidencyTier, hard: bool) -> ContextPackItem:
        st = cand.item
        stype = getattr(st, "source_type", "REFERENCE")
        if not isinstance(stype, str):
            stype = stype.value if hasattr(stype, "value") else str(stype)
        content = getattr(st, "content", "") or ""
        est = int(getattr(st, "estimated_token_cost", 0) or self.est.estimate(content))
        flags = getattr(st, "flags", ()) or ()
        pres = PRESENTATION_RESTRICTED if PRESENTATION_RESTRICTED in flags else "PRESENTABLE"
        obs_scope = getattr(st, "observer_scope", None)
        return ContextPackItem(
            item_id=getattr(st, "item_id", cand.item.item_id),
            source_ref=getattr(st, "source_ref", ""),
            source_type=stype,
            classification=getattr(cand, "classification", None) or "AUTHORITY_REFERENCE",
            authority_status=getattr(st, "authority_status", "COMMITTED"),
            plane=getattr(st, "plane", "OBJECTIVE"),
            observer_scope=obs_scope,
            residency=tier.value,
            hard_or_soft="hard" if hard else "soft",
            activation_reason=cand.activation_reason or best_activation(cand, tier),
            priority=cand.priority,
            retrieval_score=float(getattr(st, "rank_score", 0.0) or 0.0),
            estimated_token_cost=est,
            temporal_scope=str(getattr(st, "temporal_scope", "")),
            presentation_state=pres,
            content=content,
            provenance=str(getattr(st, "provenance", "")),
            trace_refs=tuple(getattr(cand, "trace_refs", ())),
        )

    def _digest(self, items: list[ContextPackItem], mode: ContextMode, branch: str) -> str:
        payload = {
            "mode": mode.value,
            "branch": branch,
            "items": [{
                "source_type": i.source_type, "source_ref": i.source_ref,
                "classification": i.classification, "residency": i.residency,
                "hard": i.hard_or_soft, "activation_reason": i.activation_reason,
                "content": i.content,
            } for i in items],
        }
        blob = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        import hashlib
        return hashlib.sha256(blob.encode()).hexdigest()

