"""Deterministic query-feature extraction for the Context Router.

The Router never decides on a single keyword.  It decomposes raw_text into a
bounded feature set and combines intents with scene/entity + temporal signals.

Anticipated adversarial targets (must be classified robustly, not by one word):

* EVIDENCE intent (exact / verbatim / provenance / who-knew-when / retcon):
    - direct quotation intent         "她上次原话到底是什么"
    - exactness object/time/turn      "具体是哪一回合"
    - provenance / source request     "这句话的出处" "当时那句话在哪说的"
    - who-knew-what-when              "当时谁知道这件事"
    - contested / deprecated historical claim  "这话她真说过吗"
    - explicit historical date/time query      "她具体是哪天说的"
* DEEP recall intent (continuity recall, entity return, mystery/thread):
    - ordinary continuity recall      "她以前是不是说过喜欢咖啡"  -> DEEP (soft recall)
    - entity return / old presence    "那个很久没见的医生走进来了" -> DEEP
    - secret / unresolved thread ask  "上次那个还悬着的约定"
* FAST: none of the above; an ordinary turn ("我喝了口水").

The one word that could wrongly force EVIDENCE, "以前", is deliberately only a
*recall* signal; exactness requires *verbatim quotation / provenance / exact
turn-of-record* phrasing, which "她以前是不是说过喜欢咖啡" lacks.
"""
from __future__ import annotations
import re

# ---- EVIDENCE intent tables ----------------------------------------------
_EVIDENCE_QUOTE_RE = re.compile(
    r"原话说|原话到底|原句|当时的原话|上一句原(话|文)|说过的那句|went verbatim|"
    r"exact (words|quote|line|sentence)|quote (her|him) exactly|原话是",
    re.IGNORECASE,
)
_EVIDENCE_TURN_TIME_RE = re.compile(
    r"具体(是哪|几|那个)?(一)?回|第\s*[0-9一二三四五六七八九十]", re.IGNORECASE
)
_EVIDENCE_PROVENANCE_RE = re.compile(
    r"出处|来源|在哪(次|一章|一场)说|which (line|scene|source|turn)|where did", re.IGNORECASE
)
_EVIDENCE_KNEW_RE = re.compile(
    r"谁(当时)?知道|谁知道|谁已经知道|who knew|she knew|he knew(什么|吗)|当时(他|她|他们)?知道",
    re.IGNORECASE,
)
_EVIDENCE_CONTEST_RE = re.compile(
    r"真说过|真说过吗|到底说没说过|到底有没有(说|做|给)过|contradict|retcon|改了吗",
    re.IGNORECASE,
)
_EVIDENCE_EXACTDATE_RE = re.compile(
    r"具体(时间|哪天|日期)|exact(ly)? (date|when|time)|是哪天(说|做)的|哪一天说的",
    re.IGNORECASE,
)

# ---- DEEP intent tables ---------------------------------------------------
_DEEP_RECALL_RE = re.compile(r"以前|之前|还记得|回想|那次|当初|曾近|earlier|back (then|in)|remember")
_DEEP_RETURN_RE = re.compile(
    r"很久没|好久没|多年(不见|以后|之后)|多年后|回到了|回来了|finally (come|back)|return after|再次(出现|见到)|久违",
    re.IGNORECASE,
)
_DEEP_MYSTERY_RE = re.compile(
    r"秘密|悬案|未解|还欠|那个约定|说到一半|relationship (changed|shift|end)|谁(到底)?是(他|她)",
    re.IGNORECASE,
)

# ---- Long-absence expressed in turn counts (old-entity return) ------------
# "八十回合没出现的医生走进来了" is an *entity-return* cue phrased in explicit
# turn terms.  These are bounded, deterministic patterns (NOT general NLP).  We
# only extract an explicit count that directly prefixes an absence marker such
# as "<count>回合没出现 / didn't appear for <count> rounds".  Small recent
# counts ("三回合没出现") must not fire hard; the Router applies a floor.
_ABSENT_CN_RE = re.compile(
    r"(?P<num>[一二两三四五六七八九十百千]+|[0-9]+)\s*回合\s*"
    r"(?:还|還|仍)?\s*(?:(?:没|未|莫)(?:有)?)?\s*"
    r"(?:出现过?|出现|露面|露过面|来过|来|见过|见|进过|进|到场)",
)
_ABSENT_EN_RE = re.compile(
    r"(?:absent|gone|away)\s+(?:for\s+)?(?P<num>[0-9]+)\s+(?:rounds?|turns?)|"
    r"(?P<num2>[0-9]+)\s+turns?\s+(?:absent|gone|away)",
    re.IGNORECASE,
)
_CJK_DIGITS = {"一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5,
               "六": 6, "七": 7, "八": 8, "九": 9}
_CJK_SCALE = {"十": 10, "百": 100, "千": 1000}


def _decode_cjk_num(seg: str):
    """Decode a *bounded* set of CJK whole numbers seen in turn counts:
    八, 八十, 十二, 五百, 三百五十, 两, 一千.  Returns int, or None when the
    form is not confidently parseable (caller treats as 'no numeric cue')."""
    if not seg or len(seg) > 12:
        return None
    if not all(ch in _CJK_DIGITS or ch in _CJK_SCALE for ch in seg):
        return None
    # positional accumulation left→right
    total = 0
    run_digit = 0            # current digit pending a scale
    for ch in seg:
        if ch in _CJK_DIGITS:
            run_digit = _CJK_DIGITS[ch]
        else:  # ch is a scale marker
            scale = _CJK_SCALE[ch]
            if run_digit == 0:
                run_digit = 1        # bare "十" / "百" means one scale unit
            total += run_digit * scale
            run_digit = 0
    return total + run_digit


def _extract_absent_rounds(text: str):
    """Return tuple of explicit turn-counts from absence phrases, e.g.
    "八十回合没出现" -> (80,); "absent for 40 rounds" -> (40,).  Empty tuple
    when no reliable explicit count is present."""
    out: list[int] = []
    for m in _ABSENT_CN_RE.finditer(text):
        num = m.group("num")
        if num is None:
            continue
        v = int(str(num)) if num.isdigit() else _decode_cjk_num(num)
        if v is not None and v > 0:
            out.append(v)
    for m in _ABSENT_EN_RE.finditer(text):
        num = m.group("num") or m.group("num2")
        if num and num.isdigit():
            v = int(num)
            if v > 0:
                out.append(v)
    # deterministic and de-duplicated
    seen: set[int] = set()
    uniq: list[int] = []
    for v in sorted(out):
        if v not in seen:
            seen.add(v)
            uniq.append(v)
    return tuple(uniq)


class QueryFeatures:
    """Small frozen bucket of extracted booleans.  Serialisable / deterministic."""

    def __init__(self, text: str, *, explicit_historical: bool = False,
                 scene_entity_ids: tuple = (), entity_ids: tuple = ()):
        self.raw = text
        self.explicit_historical = bool(explicit_historical)
        self.exact_quote = _EVIDENCE_QUOTE_RE.search(text) is not None
        self.exact_time_turn = _EVIDENCE_TURN_TIME_RE.search(text) is not None
        self.provenance = _EVIDENCE_PROVENANCE_RE.search(text) is not None
        self.who_knew = _EVIDENCE_KNEW_RE.search(text) is not None
        self.contested = _EVIDENCE_CONTEST_RE.search(text) is not None
        self.exact_date_time = _EVIDENCE_EXACTDATE_RE.search(text) is not None
        self.routine_recall = _DEEP_RECALL_RE.search(text) is not None
        self.entity_returning = _DEEP_RETURN_RE.search(text) is not None
        self.mystery_secret = _DEEP_MYSTERY_RE.search(text) is not None
        self.round_absence: tuple[int, ...] = _extract_absent_rounds(text)
        self.entity_ids_in_text = list(entity_ids)
        self.scene_entity_ids = list(scene_entity_ids)

    # Combined EVIDENCE exactness intent (verbatim provenance / record-level).
    @property
    def exactness_intent(self) -> bool:
        return bool(self.exact_quote or self.exact_time_turn or self.who_knew or self.exact_date_time
                    or self.provenance or self.contested)

    # Combined DEEP recall intent.
    @property
    def recall_intent(self) -> bool:
        return bool(self.routine_recall or self.entity_returning or self.mystery_secret)

    def as_dict(self) -> dict:
        return {
            "exact_quote": self.exact_quote,
            "exact_time_turn": self.exact_time_turn,
            "provenance": self.provenance,
            "who_knew": self.who_knew,
            "contested": self.contested,
            "exact_date_time": self.exact_date_time,
            "routine_recall": self.routine_recall,
            "entity_returning": self.entity_returning,
            "mystery_secret": self.mystery_secret,
            "entity_absent_rounds": list(self.round_absence),
            "exactness_intent": self.exactness_intent,
            "recall_intent": self.recall_intent,
            "explicit_historical": self.explicit_historical,
            "mentioned_in_text": self.entity_ids_in_text,
            "scene_entities": self.scene_entity_ids,
        }
