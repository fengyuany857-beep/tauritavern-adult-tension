"""Deterministic Context Router (no LLM, no classifier server).

Classifies a RoutingRequest into FAST / DEEP / EVIDENCE using explicit,
deterministic feature rules and scene/entity/temporal signals, then applies the
one-way escalation chain FAST -> DEEP -> EVIDENCE base on retrieval insufficiency.
"""
from __future__ import annotations
from dataclasses import replace
from .contracts import ContextMode, RoutingDecision, RoutingRequest
from .features import QueryFeatures

_ESCALATION_ORDER = [ContextMode.FAST, ContextMode.DEEP, ContextMode.EVIDENCE]
_GROUP = {m: i for i, m in enumerate(_ESCALATION_ORDER)}
MAX_ESCALATIONS = 2  # FAST -> DEEP then DEEP -> EVIDENCE (one-way, no back).

# Retrieval statuses that may justify an upward escalation.
ESCALABLE_BY_STATUS = {
    "PARTIAL", "AMBIGUOUS", "EVIDENCE_INSUFFICIENT", "BLOCKED_BY_FILTERS",
}


class ContextRouter:
    """Rule-based, purely deterministic router.

    ``decode`` returns a RoutingDecision with initial_mode/final_mode.  When
    used with a builder, the builder inspects each component retrieval status
    and calls ``escalate`` (a pure function) if mode permits; no LLM involved.
    """

    def __init__(self, *, entity_turn_gap: int = 120,
                 text_absence_min_rounds: int = 30,
                 current_entity_set: frozenset[str] | None = None):
        # turn gap beyond which an entity counts as "long-absent" -> DEEP.
        self.entity_turn_gap = entity_turn_gap
        # an explicit textual absence interval (e.g. "八十回合没出现") at or
        # above this many turns is treated as an old-entity return cue.
        self.text_absence_min_rounds = text_absence_min_rounds

    # ---- structured entity absence (authoritative when last_seen supplied) --
    def _absence_gap(self, req: RoutingRequest):
        """(gap, last_seen, current) when structured last_seen + a current turn
        reference are both known; else (None, None, None)."""
        if req.last_seen_turn is None:
            return None, None, None
        # the "current" turn for the decision model is the scene / event turn.
        current = getattr(req, "event_turn", None)
        if current is None:
            return None, None, None
        gap = int(current) - int(req.last_seen_turn)
        return gap, int(req.last_seen_turn), int(current)

    # ---- initial classification -------------------------------------------
    def decide_initial(self, req: RoutingRequest, features: QueryFeatures | None = None) -> RoutingDecision:
        feats = features or QueryFeatures(
            text=req.raw_text or "", explicit_historical=req.explicit_historical_request,
            scene_entity_ids=req.scene_entity_ids, entity_ids=(),
        )
        reasons: list[str] = []
        if req.mode_override is not None:
            return RoutingDecision(
                initial_mode=req.mode_override, final_mode=req.mode_override,
                reasons=("mode_override (debug/test only)",), query_features=tuple(feats.as_dict().items()),
            )

        # EVIDENCE triggers first (exactness / provenance / who-knew / contested).
        evidence_triggers: set[str] = set()
        if feats.exactness_intent:
            for label, cond in (("verbatim_quote", feats.exact_quote), ("exact_time_turn", feats.exact_time_turn),
                                ("provenance_source", feats.provenance), ("who_knew_when", feats.who_knew),
                                ("exact_date_time", feats.exact_date_time), ("contested_retcon", feats.contested)):
                if cond:
                    evidence_triggers.add(label)
        for t in evidence_triggers:
            reasons.append(f"EVIDENCE trigger: {t}")

        if evidence_triggers or feats.explicit_historical:
            initial = ContextMode.EVIDENCE
            return RoutingDecision(
                initial_mode=ContextMode.FAST, final_mode=ContextMode.EVIDENCE,
                reasons=tuple(reasons or ["EVIDENCE intent"]),
                hard_triggers=("exactness",), escalation_reasons=("classify-EVIDENCE",),
                evidence_required=True, confidence="high",
                query_features=tuple(feats.as_dict().items()),
            )

        # DEEP triggers (recall / entity return / mystery / identity) when no EVIDENCE.
        deep_triggers: set[str] = set()

        # P0-1-1: structured entity absence.  If we know when an entity was last
        # seen and the current scene turn, and the gap exceeds entity_turn_gap,
        # this is a *hard* DEEP trigger (long-absent entity -> widen recall).
        gap, last_d, cur_d = self._absence_gap(req)
        if gap is not None and gap > self.entity_turn_gap:
            deep_triggers.add("structured_entity_absence")
            reasons.append(
                f"DEEP trigger: structured_entity_absence "
                f"(last_seen={last_d}, current={cur_d}, gap={gap} > entity_turn_gap={self.entity_turn_gap})")

        # P0-1-2: explicit *textual* long-absence interval ("八十回合没出现").
        # This is read as an old-entity/historical-entity return cue only when the
        # count is clearly beyond an ordinary recent window.
        if (not deep_triggers and feats.round_absence
                and max(feats.round_absence) >= self.text_absence_min_rounds):
            deep_triggers.add("textual_round_absence")
            reasons.append(f"DEEP trigger: textual_round_absence "
                           f"rounds={feats.round_absence} >= text_absence_min_rounds={self.text_absence_min_rounds}")

        if feats.recall_intent:
            for label, cond in (("routine_recall_continuity", feats.routine_recall),
                                ("entity_return", feats.entity_returning),
                                ("secret_or_mystery", feats.mystery_secret)):
                if cond:
                    deep_triggers.add(label)
        for t in deep_triggers:
            reasons.append(f"DEEP trigger: {t}")

        if deep_triggers:
            return RoutingDecision(
                initial_mode=ContextMode.FAST, final_mode=ContextMode.DEEP,
                reasons=tuple(reasons or ["DEEP continuity recall"]),
                soft_triggers=tuple(sorted(deep_triggers)), evidence_required=False,
                confidence="high", query_features=tuple(feats.as_dict().items()),
            )

        # Default ordinary turn -> FAST.
        reasons.append("no EVIDENCE/DEEP intent -> FAST ordinary turn")
        return RoutingDecision(
            initial_mode=ContextMode.FAST, final_mode=ContextMode.FAST,
            reasons=tuple(reasons), evidence_required=False, confidence="high",
            query_features=tuple(feats.as_dict().items()),
        )

    # ---- pure one-way escalation ------------------------------------------
    @staticmethod
    def escalate(decision: RoutingDecision, escalation_needed: bool,
                 extra_reason: str = "") -> RoutingDecision:
        """Return an escalated RoutingDecision or the same one if blocked.

        Allowed: FAST -> DEEP -> EVIDENCE, no reverse and no EVIDENCE "guess
        back".  Escalation never lowers the final mode once raised.
        """
        if not escalation_needed:
            return decision
        cur = decision.final_mode
        idx = _GROUP[cur]
        if idx >= len(_ESCALATION_ORDER) - 1:
            # EVIDENCE is the ceiling; never guess a result -> stay.
            extra = extra_reason or "EVIDENCE: escalation ceiling, no result guess"
            return RoutingDecision(
                initial_mode=decision.initial_mode, final_mode=cur,
                reasons=decision.reasons + (extra,),
                hard_triggers=decision.hard_triggers + (extra,) if extra_reason else decision.hard_triggers,
                soft_triggers=decision.soft_triggers,
                escalation_reasons=decision.escalation_reasons,
                evidence_required=True, confidence=decision.confidence,
                escalation_allowed=False, query_features=decision.query_features,
            )
        nxt = _ESCALATION_ORDER[idx + 1]
        escalation_reasons = list(decision.escalation_reasons)
        why = extra_reason or ("insufficient in " + cur.value)
        escalation_reasons.append(f"{cur.value} -> {nxt.value}: {why}")
        return RoutingDecision(
            initial_mode=decision.initial_mode, final_mode=nxt,
            reasons=decision.reasons + (f"escalated to {nxt.value} because {why}",),
            hard_triggers=decision.hard_triggers, soft_triggers=decision.soft_triggers,
            escalation_reasons=tuple(escalation_reasons),
            evidence_required=(nxt == ContextMode.EVIDENCE),
            confidence=decision.confidence,
            escalation_allowed=(_GROUP[nxt] < len(_ESCALATION_ORDER) - 1),
            query_features=decision.query_features,
        )
