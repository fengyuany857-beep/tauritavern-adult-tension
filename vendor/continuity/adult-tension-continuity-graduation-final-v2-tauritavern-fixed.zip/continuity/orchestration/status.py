"""Phase 3D — orchestration status / query (read-only).

Answers "where does this continuity_tx_id sit right now?" from the durable journal
alone.  It NEVER invokes a runtime writer and never exposes full adult
current-permission payloads or chain-of-thought.

Status surfaces: tx id, current transaction state, runtime outcome, attempt_count,
writer_invoked, pre/post hash fingerprints, durability status, fine
continuity-sync state, outbox pending count, manual-review flag, and
retry_requires_new_tx.
"""
from __future__ import annotations
import sqlite3
from pathlib import Path
from typing import Any

from .errors import UnknownOrchestration

# Phase 3 hard invariant, surfaced everywhere: any *new* runtime attempt requires
# a new tx.  A re-entry never re-runs the runtime writer on the same tx.
RETRY_REQUIRES_NEW_TX = True

_SELECT = (
    "SELECT continuity_tx_id, state, branch_id, operation, runtime_identity, "
    " runtime_path_ref, runtime_pre_sha256, runtime_post_observed_sha256, "
    " runtime_pre_semantic_digest, runtime_post_semantic_digest, patch_digest, "
    " attempt_count, runtime_outcome_class, durability_status, "
    " continuity_sync_state, precondition_status, manual_review_required, "
    " created_at, updated_at, committed_at, last_error_class, last_error_detail "
    " FROM transaction_journal WHERE continuity_tx_id=?")


def _connect(db_path: Path) -> sqlite3.Connection:
    con = sqlite3.connect(str(Path(db_path)))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        from ..migrations import migrate
        migrate(con)
    except Exception:
        pass
    return con


def orchestration_status(*, db_path: Path | str, tx_id: str) -> dict[str, Any]:
    """Return the durable audit status of one orchestration tx."""
    db_path = Path(db_path)
    con = _connect(db_path)
    row = None
    try:
        row = con.execute(_SELECT, (tx_id,)).fetchone()
        outbox_pending = _outbox_pending(con, tx_id)
    finally:
        con.close()
    if row is None:
        raise UnknownOrchestration(f"no durable transaction for tx {tx_id}")
    r = dict(row)
    writer_invoked = (r.get("attempt_count") or 0) > 0
    return {
        "continuity_tx_id": r["continuity_tx_id"],
        "state": r["state"],
        "runtime_outcome_class": r.get("runtime_outcome_class"),
        "attempt_count": r.get("attempt_count") or 0,
        "writer_invoked": writer_invoked,
        "pre_sha256": (r.get("runtime_pre_sha256") or "")[:64],
        "post_sha256": (r.get("runtime_post_observed_sha256") or "")[:64],
        "pre_semantic_digest": (r.get("runtime_pre_semantic_digest") or "")[:64],
        "post_semantic_digest": (r.get("runtime_post_semantic_digest") or "")[:64],
        "patch_digest": (r.get("patch_digest") or "")[:64],
        "durability_status": r.get("durability_status"),
        "sync_state": r.get("continuity_sync_state"),
        "outbox_pending": outbox_pending,
        "precondition_status": r.get("precondition_status"),
        "manual_review_required": bool(r.get("manual_review_required")),
        "retry_requires_new_tx": RETRY_REQUIRES_NEW_TX,
        "branch_id": r.get("branch_id"),
        "operation": r.get("operation"),
        "created_at": r.get("created_at"),
        "updated_at": r.get("updated_at"),
        "committed_at": r.get("committed_at"),
        "last_error_class": r.get("last_error_class"),
        "last_error_detail": (r.get("last_error_detail") or "")[:400],
    }


def scan_recoverable(db_path: Path | str, *, limit: int = 100) -> list[dict[str, Any]]:
    """List recoverable (nonterminal, not-completed/manual) orchestration rows."""
    db_path = Path(db_path)
    con = _connect(db_path)
    try:
        rows = con.execute(
            "SELECT continuity_tx_id, state, runtime_outcome_class, "
            " continuity_sync_state, attempt_count, manual_review_required "
            " FROM transaction_journal "
            " WHERE state NOT IN "
            " ('COMPLETED','PRECONDITION_FAILED','CONFIRMED_NOT_APPLIED',"
            "  'ABORTED_NOT_ATTEMPTED','MANUAL_REVIEW')"
            " ORDER BY created_at LIMIT ?", (limit,)).fetchall()
    finally:
        con.close()
    return [dict(r) for r in rows]


def _outbox_pending(con: sqlite3.Connection, tx: str) -> int:
    row = con.execute(
        "SELECT COUNT(*) AS c FROM history_outbox WHERE continuity_tx_id=? "
        "AND state='PENDING'", (tx,)).fetchone()
    return int(row["c"]) if row else 0
