"""Phase 3D — orchestration request / result contracts.

These model a *top-level* continuity saga that composes the already-gated
Phase 3A/3B/3C muscles.  They carry the same honesty rules as the underlying
phases: no generic SUCCESS that hides sub-phases, no outcome overrides, no
rollback illusion.  A natural-language "desired outcome" is never accepted as a
concrete runtime patch.
"""
from __future__ import annotations
import enum
from dataclasses import dataclass, field
from typing import Any

# Bounded fields (same policy as Phase 3A/B/C).
MAX_ORCH_PROVENANCE = 2000
MAX_ERROR_DETAIL = 400


class OrchestrationStage(str, enum.Enum):
    """Distinguishes the three sub-phases + manual state (never a single SUCCESS)."""
    VALIDATED = "VALIDATED"                       # request safety/contract validated
    PREPARED = "PREPARED"                         # Phase 3A durable PREPARED row exists
    RUNTIME_ATTEMPTED = "RUNTIME_ATTEMPTED"       # Phase 3B single-file commit executed
    RUNTIME_OUTCOME = "RUNTIME_OUTCOME"           # runtime outcome classified + journaled
    SYNC_PHASE = "SYNC_PHASE"                     # Phase 3C continuity sync in progress/done
    OUTBOX_PHASE = "OUTBOX_PHASE"                 # outbox projection
    FINALISED = "FINALISED"                       # final COMPLETED marker written
    MANUAL_REVIEW_REQUIRED = "MANUAL_REVIEW_REQUIRED"  # automation stops; needs review
    REFUSED = "REFUSED"                           # request refused before any change


class OrchestrationStatus(str, enum.Enum):
    """Coarse, honest top-level outcome (fine state machine stays authoritative)."""
    PENDING = "PENDING"                 # durable PREPARED; not yet attempted
    PRECONDITION_FAILED = "PRECONDITION_FAILED"
    ABORTED_NOT_ATTEMPTED = "ABORTED_NOT_ATTEMPTED"
    COMPLETED = "COMPLETED"
    MANUAL_REVIEW_REQUIRED = "MANUAL_REVIEW_REQUIRED"
    REFUSED = "REFUSED"


# --------------------------------------------------------------------------- #
# Consequence plan: the upstream-authorised historical continuity consequences
# that MAY be synced AFTER a CONFIRMED_APPLIED runtime outcome.  It carries only
# permitted CONTINUITY effect payloads (episode / fact / knowledge / historical
# relationship-semantic / commitment / thread effects).  It is never built from
# natural-language drift; it never writes current adult-permission / current
# relationship authority (Phase 3C ownership filter re-checks every payload).
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class ConsequencePlan:
    branch_id: str = "default"
    consequences: list[dict[str, Any]] = field(default_factory=list)  # sync-effect payloads
    plan_version: str = "phase3c-sync-v1"

    def is_empty(self) -> bool:
        return not self.consequences


@dataclass(frozen=True)
class OrchestrationRequest:
    """The complete, explicit, upstream-authorised input envelope.

    `patch` MUST be a concrete upstream runtime delta (dict of declarative
    change / command fields the pinned vendor CLI understands).  A bare
    natural-language "desired outcome" is rejected by Phase 3A guard.
    `consequence_plan` declares which *historical continuity* consequences the
    upstream explicitly approves to sync after a confirmed runtime application.
    """
    operation: str = "orchestrate_turn"
    branch_id: str = "default"
    patch: dict[str, Any] = field(default_factory=dict)          # concrete runtime delta
    vendor_dir: str = ""                                          # disposable fixture root
    runtime_path: str = ""                                        # canonical current_state.yaml
    consequence_plan: ConsequencePlan | None = None
    source_provenance: dict[str, Any] = field(default_factory=dict)  # who authored
    request_provenance: dict[str, Any] = field(default_factory=dict)  # who authorised
    protocol_version: str = "phase3-safe-saga-v1"
    tx_id: str | None = None           # optional caller-supplied stable id (new-tx per order)
    disposable_proof_hint: bool = False   # explicit "test/disposable context" switch
    # explicit safety context: production real-save is DISABLED during dev tests.
    allow_production_write: bool = False  # must stay False in this phase


# --------------------------------------------------------------------------- #
# The fine result / status surface a caller uses to tell runtime vs sync vs
# outbox vs manual phases apart.
# --------------------------------------------------------------------------- #
@dataclass
class OrchestrationResult:
    continuity_tx_id: str = ""
    status: str = OrchestrationStatus.PENDING.value
    stage_reached: str = OrchestrationStage.VALIDATED.value   # furthest safe stage reached
    runtime_attempted: bool = False
    runtime_outcome: str | None = None          # RuntimeOutcomeClass value (if attempted)
    writer_invoked: bool = False
    attempt_count: int = 0
    sync_state: str | None = None               # ContinuitySyncState / SyncStage value
    outbox_pending: int = 0
    manual_review_required: bool = False
    retry_requires_new_tx: bool = True
    durability_status: str | None = None
    runtime_pre_sha256: str | None = None
    runtime_post_sha256: str | None = None
    effect_counts: dict[str, int] = field(default_factory=dict)
    evidence_event_ids: list[str] = field(default_factory=list)
    detail_bounded: str = ""
    error_class: str | None = None
    refused_reason: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "continuity_tx_id": self.continuity_tx_id,
            "status": self.status,
            "stage_reached": self.stage_reached,
            "runtime_attempted": self.runtime_attempted,
            "runtime_outcome": self.runtime_outcome,
            "writer_invoked": self.writer_invoked,
            "attempt_count": self.attempt_count,
            "sync_state": self.sync_state,
            "outbox_pending": self.outbox_pending,
            "manual_review_required": self.manual_review_required,
            "retry_requires_new_tx": self.retry_requires_new_tx,
            "durability_status": self.durability_status,
            "runtime_pre_sha256": (self.runtime_pre_sha256 or "")[:64],
            "runtime_post_sha256": (self.runtime_post_sha256 or "")[:64],
            "effect_counts": self.effect_counts,
            "evidence_event_ids": self.evidence_event_ids,
            "detail": self.detail_bounded[:400],
            "error_class": self.error_class,
            "refused_reason": self.refused_reason,
        }
