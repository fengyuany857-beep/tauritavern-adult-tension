"""Phase 3D — full orchestration + crash integration + end-to-end recovery.

Composition layer that drives ONE safe continuity saga across the already-gated,
already merged Phase 3A/3B/3C muscles:

  Phase 3A  continuity.transactions.preconditions.prepare_transaction  (prepare)
  Phase 3B  continuity.runtime3b.execute.commit_single_file            (single-file
            runtime commit: second-prewrite + attempt reservation + vendor writer
            + immediate post observation + outcome classification + durability)
  Phase 3C  continuity.sync3c.engine.ContinuitySyncEngine               (idempotent
            continuity sync + transactional outbox + finalisation)

This package does NOT re-implement a runtime writer, a sync writer, a classifier,
an outcome override, rollback, automatic runtime retry, named-slot mutation or
any adult current-permission writer.  It *composes* the existing product entry
points in the order locked down by the Sol protocol, keeps every sub-phase
explicitly distinguishable in its result envelope, guarantees re-entry
idempotency from durable state only, and provides read-only status / recovery
orchestration across process restarts.

Honesty invariants carried through the whole Phase 3D layer (protocol §7/§15/§16/
§8/§19):
  - one runtime mutation attempt maximum per continuity_tx_id;
  - runtime outcome must be CONFIRMED_APPLIED (durable immediate post evidence)
    before any continuity sync;
  - UNKNOWN / DIVERGENCE / NOT_APPLIED / PRECONDITION_FAILED never sync and never
    auto-retry the runtime;
  - a new runtime attempt always requires a fresh read + fresh plan + NEW tx;
  - no rollback / rewind / fork illusion and no "atomic across runtime + SQLite +
    JSONL" claim (a saga is staged/recoverable, never a distributed transaction);
  - no native exactly-once runtime commit claim: we expose at-most-one attempt,
    idempotent sidecar sync, replay-safe outbox projection;
  - production real-save mutation stays disabled in this development phase; real
    runtime mutation happens only on a provably disposable fixture.
"""
from __future__ import annotations

from .contracts import (
    OrchestrationRequest, OrchestrationResult, OrchestrationStage, ConsequencePlan,
)
from .errors import (
    OrchestrationError, RuntimePhaseError, RequestRejected, ProductionPathRefused,
    NoConsequencePlan, UnknownOrchestration, NotReentrant,
)
from .orchestrator import Orchestrator, orchestrate  # noqa: E402  (public API)

from .recovery import (  # noqa: E402,F401
    recover_orchestration, scan_recoverable_orchestrations,
)
from .status import (  # noqa: E402,F401
    orchestration_status, scan_recoverable,
)

__all__ = [
    "OrchestrationRequest",
    "OrchestrationResult",
    "OrchestrationStage",
    "ConsequencePlan",
    "Orchestrator",
    "orchestrate",
    "OrchestrationError",
    "RuntimePhaseError",
    "RequestRejected",
    "ProductionPathRefused",
    "NoConsequencePlan",
    "UnknownOrchestration",
    "NotReentrant",
    "recover_orchestration",
    "scan_recoverable_orchestrations",
    "orchestration_status",
    "scan_recoverable",
]
