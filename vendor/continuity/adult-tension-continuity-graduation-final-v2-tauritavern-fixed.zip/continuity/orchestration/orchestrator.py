"""Phase 3D — top-level Orchestrator.

Compiles one full continuity saga in the order locked by the Sol protocol
(§10/§11), re-using Phase 3A/3B/3C modules as the actual muscles and adding only
sequencing / idempotency / phase-distinction:

  1. validate the concrete request + prove a disposable runtime (this package);
  2. prepare  -> Phase 3A transactions/preconditions.prepare_transaction;
  3. commit   -> Phase 3B runtime3b/execute.commit_single_file (second prewrite
     re-check + atomic attempt reservation + pinned vendor single-file writer +
     immediate post observation + outcome classification + durability journal).
     These steps are all internal to 3B and happen in that order.
  4. If the durable outcome is CONFIRMED_APPLIED (durability-pending): build the
     digest-stable ContinuitySyncRequest from the pre-approved consequence plan
     and the journal's durable post refs, then drive Phase 3C
     ContinuitySyncEngine.sync_applied_transaction (single atomic sync + outbox
     drain + finalisation).

Re-entry / crash semantics:
  - `orchestrate` is idempotent from the durable journal only: it first reads the
    row for the tx and, depending on its state, only advances the *missing* later
    sub-phases.  It never re-invokes the runtime writer once an attempt has been
    consumed, and never double-applies a completed sync.
  - A fresh or PREPARED row runs exactly one runtime attempt through 3B's atomic
    reservation.
  - The consequence plan (approved historical sync effects) is an explicit input;
    recovery is re-entrant because the same approved plan is re-offered (matching
    Phase 3C's "re-offer a digest-stable identical request" model).  Nothing here
    invents consequences from drift.

No runtime writer / sync writer / classifier logic is re-implemented here.
"""
from __future__ import annotations
import sqlite3
from pathlib import Path
from typing import Any, Callable

from ..transactions.contracts import TransactionState
from ..sync3c.engine import ContinuitySyncEngine, SyncEngineError
from .contracts import (
    OrchestrationRequest, ConsequencePlan, OrchestrationResult,
    OrchestrationStage, OrchestrationStatus,
)
from .errors import RequestRejected, ProductionPathRefused, NoConsequencePlan
from .safety import validate_and_prove, require_consequence_plan

# Test-only injected crash seams (production default is disabled).
FAULT_SEAMS = (
    "F0", "F1", "F2", "F3", "F4", "F5", "F6", "F7",
    "F8", "F9", "F10", "F11", "F12", "F13", "F14",
)

_TERMINAL = frozenset({
    TransactionState.COMPLETED.value,
    TransactionState.CONFIRMED_NOT_APPLIED.value,
    TransactionState.PRECONDITION_FAILED.value,
    TransactionState.ABORTED_NOT_ATTEMPTED.value,
    TransactionState.MANUAL_REVIEW.value,
})

_SYNCABLE = frozenset({
    TransactionState.CONFIRMED_APPLIED.value,
    TransactionState.DURABILITY_PENDING.value,
    TransactionState.CONTINUITY_SYNC_PENDING.value,
    TransactionState.CONTINUITY_SYNCING.value,
    TransactionState.CONTINUITY_SYNCED.value,
})

_NONAPPLIED = frozenset({
    TransactionState.OUTCOME_UNKNOWN.value,
    TransactionState.CONCURRENT_DIVERGENCE.value,
    TransactionState.CONFIRMED_NOT_APPLIED.value,
    TransactionState.PRECONDITION_FAILED.value,
    TransactionState.RECOVERY_REQUIRED.value,
})


def _connect(db_path: Path) -> sqlite3.Connection:
    con = sqlite3.connect(str(Path(db_path)))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    from ..migrations import migrate
    migrate(con)
    return con


def _default_evidence_path(db_path: Path) -> Path:
    return Path(db_path).resolve().parent / "history" / "VOL-001.jsonl"


class Orchestrator:
    def __init__(self, *, db_path: Path | str,
                 evidence_path: Path | str | None = None,
                 fault_on: str | None = None,
                 fault_impl: Callable[[str], Any] | None = None):
        self.db_path = Path(db_path).resolve()
        self.evidence_path = Path(evidence_path) if evidence_path \
            else _default_evidence_path(self.db_path)
        if fault_on is not None and fault_on not in FAULT_SEAMS:
            raise RequestRejected(f"unknown injected fault seam {fault_on!r}")
        self.fault_on = fault_on
        self.fault_impl = fault_impl
        self._conn = _connect(self.db_path)

    # ------------------------------------------------------------------ #
    def _inject(self, seam: str) -> None:
        if self.fault_on is None:
            return
        if seam == self.fault_on:
            if self.fault_impl is not None:
                self.fault_impl(seam)
            else:
                raise RuntimeError(f"injected orchestration fault at {seam}")

    def close(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None

    def _con(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = _connect(self.db_path)
        return self._conn

    def get_row(self, tx_id: str) -> dict | None:
        row = self._con().execute(
            "SELECT * FROM transaction_journal WHERE continuity_tx_id=?", (tx_id,)).fetchone()
        return dict(row) if row is not None else None

    # ------------------------------------------------------------------ #
    def orchestrate(self, request: OrchestrationRequest,
                    consequence_plan: ConsequencePlan | None = None,
                    tx_id_hint: str | None = None
                    ) -> OrchestrationResult:
        """Drive one saga; idempotent from durable state only.

        Guarantees the connection is closed even when a test-injected crash seam
        raises (a simulated process/thread death mid-saga)."""
        try:
            return self._run(request, consequence_plan, tx_id_hint)
        finally:
            self.close()

    def _run(self, request: OrchestrationRequest,
             consequence_plan: ConsequencePlan | None,
             tx_id_hint: str | None) -> OrchestrationResult:
        # A separately-supplied consequence plan is merged onto the (frozen)
        # request via dataclasses.replace so downstream code always reads only
        # request.consequence_plan.
        if consequence_plan is not None and consequence_plan is not request.consequence_plan:
            import dataclasses
            request = dataclasses.replace(request, consequence_plan=consequence_plan)
        plan = request.consequence_plan or _default_plan(request)
        out = OrchestrationResult(continuity_tx_id=request.tx_id or tx_id_hint or _fresh_id())

        # ---- 0) validate + prove disposable path + require consequences --------
        try:
            vendor_dir, runtime_path = _prove(request)
            plan = require_consequence_plan(request) if (
                plan is None and request.consequence_plan is None) else (
                plan or request.consequence_plan)
            staged_plan_digest = _validate_and_digest_plan(
                out.continuity_tx_id, request.branch_id, plan)
        except (RequestRejected, ProductionPathRefused, NoConsequencePlan) as exc:
            return _refuse(out, exc)
        except Exception as exc:
            if exc.__class__.__name__ in ("UnsupportedNamedSlot",
                                          "PlayerSovereigntyViolation",
                                          "InvalidArgument"):
                return _refuse(out, exc)
            raise

        self._inject("F0")                 # before durable intent
        tx_id = out.continuity_tx_id
        existing = self.get_row(tx_id)

        if existing is None:
            # ---- Phase 3A prepare (durable PREPARED) ------------------------
            from ..transactions.preconditions import prepare_transaction
            try:
                prepare_transaction(
                    vendor_dir=vendor_dir, db_path=self.db_path,
                    runtime_path=runtime_path, patch=request.patch,
                    operation=request.operation, branch_id=request.branch_id,
                    protocol_version=request.protocol_version,
                    request_provenance=request.request_provenance,
                    staged_sync_digest=staged_plan_digest,
                    tx_id=tx_id)
                out.stage_reached = OrchestrationStage.PREPARED.value
            except Exception as exc:
                return _refuse(out, exc) if exc.__class__.__name__ in (
                    "DuplicateTx", "UnsupportedNamedSlot", "PlayerSovereigntyViolation",
                    "InvalidArgument", "RuntimeValidationError", "RuntimeParseError",
                    "RuntimeNotFound", "TxDBError", "TxError",
                ) else _raise(exc)
            existing = self.get_row(tx_id)

        # A durable tx is forever bound to the plan staged before its runtime
        # attempt.  Missing/changed identity is review-only and cannot reach 3B/3C.
        if not existing.get("staged_sync_digest"):
            return _state_result(
                out, existing, OrchestrationStage.MANUAL_REVIEW_REQUIRED.value,
                OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value,
                "staged consequence digest is missing; no runtime write or sync is allowed",
                True)
        if existing.get("staged_sync_digest") != staged_plan_digest:
            return _state_result(
                out, existing, OrchestrationStage.MANUAL_REVIEW_REQUIRED.value,
                OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value,
                "re-offered consequence plan differs from PREPARED durable intent",
                True)

        self._inject("F1")                 # after PREPARED durable, before 3B
        state = existing["state"]

        # terminal -> done or manual no-op
        if state in _TERMINAL:
            self.close()
            return _compose_terminal(existing, out)
        # applied/durability-pending -> resume sync only (never re-write runtime)
        if state in _SYNCABLE:
            if _durable_manual_gate(existing):
                return _manual_gate_result(out, existing)
            result = self._sync_applied(out, existing, plan)
            self.close()
            return result
        # non-applied / unknown / divergence / not-applied -> no sync, manual
        if state in _NONAPPLIED:
            self.close()
            return _compose_nonapplied(existing, out)
        # mid-attempt no durable outcome => manual/new-tx (no same-tx retry)
        if state == TransactionState.RUNTIME_ATTEMPTING.value:
            out = _state_result(out, existing,
                                OrchestrationStage.MANUAL_REVIEW_REQUIRED.value,
                                OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value,
                                "tx mid-attempt with no durable runtime outcome; "
                                "new-tx required (never auto-retry runtime).", True)
            self.close()
            return out
        if state != TransactionState.PREPARED.value:
            out = _state_result(out, existing, OrchestrationStage.RUNTIME_OUTCOME.value,
                                OrchestrationStatus.PENDING.value,
                                f"unexpected durable state {state}", False)
            self.close()
            return out

        # ---- state == PREPARED: single runtime attempt through Phase 3B --------
        # Ownership gate: two Orchestrators may race on the SAME tx from PREPARED.
        # Exactly one may drive 3B's reservation->writer->observe->classify window;
        # the loser must be NON-DESTRUCTIVE (never journal OUTCOME_UNKNOWN / never
        # overwrite the winner's durable result / never crash).
        self._inject("F3")                  # before writer invocation
        from ..runtime3b.execute import commit_single_file
        gate = _orchestration_gate(self.db_path, runtime_path)
        env = None
        owner_lost = False
        gate_held = gate.try_lock(timeout=_GATE_WAIT)   # bounded blocking acquire
        if not gate_held.acquired:
            # Another Orchestrator holds this (db,runtime) attempt window.
            owner_lost = True
        try:
            # Whoever owns the gate re-reads durable state: the tx may have moved
            # off PREPARED while this worker waited; only a PREPARED row may still
            # receive the single runtime attempt from this worker.
            owned_row = self.get_row(tx_id) or dict(existing)
            if owner_lost or owned_row.get("state") != TransactionState.PREPARED.value:
                # Non-destructive: reflect the owner's (or settled) durable state.
                # We never reserve/write/classify as a substitute owner here.
                result = self._compose_durable(out, owned_row, request.consequence_plan)
                self.close()
                return result
            env = commit_single_file(db_path=self.db_path, vendor_dir=vendor_dir,
                                     runtime_path=runtime_path, tx_id=tx_id,
                                     patch=request.patch)
        except Exception as exc:            # 3B refused or transient error
            name = exc.__class__.__name__
            if name in ("DuplicateAttempt", "InvalidTransition"):
                # Another worker already reserved/consumed the single attempt for
                # this tx -> we are a LOSER.  Do NOT classify an outcome we don't
                # own.  Reflect the durable state (bounded wait for the winner),
                # never UNKNOWN, never crash.
                result = self._await_owned_or_unequivocal(out, tx_id, existing)
                self.close()
                return result
            if name in ("InvalidArgument", "UnknownTx", "UnsupportedNamedSlot",
                        "PlayerSovereigntyViolation", "RuntimeNotFound",
                        "RuntimeParseError", "RuntimeValidationError"):
                # Genuine refusal by the sole owner (this worker held the gate):
                # re-read the durable row so the disposition reflects reality.
                cur_owned = self.get_row(tx_id) or dict(existing)
                manual = cur_owned.get("state") in (
                    TransactionState.RUNTIME_ATTEMPTING.value,
                    TransactionState.OUTCOME_UNKNOWN.value,
                    TransactionState.CONCURRENT_DIVERGENCE.value,
                    TransactionState.MANUAL_REVIEW.value)
                out = _state_result(out, cur_owned, OrchestrationStage.RUNTIME_OUTCOME.value,
                                    OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value
                                    if (manual or name == "DuplicateAttempt")
                                    else OrchestrationStatus.PRECONDITION_FAILED.value
                                    if name == "InvalidArgument"
                                    else OrchestrationStatus.PENDING.value,
                                    f"phase3b refused single-file commit: {str(exc)[:220]}",
                                    manual=manual)
                self.close()
                return out
            raise
        finally:
            gate.release()

        cur = self.get_row(tx_id) or dict(existing)
        state2 = cur["state"]
        out.runtime_attempted = bool(env.runtime_attempted)
        out.writer_invoked = bool(env.writer_invoked)
        out.attempt_count = 1 if env.runtime_attempted else 0
        out.runtime_outcome = env.runtime_outcome
        out.runtime_pre_sha256 = (env.runtime_pre_observation or {}).get("raw_sha256")
        out.runtime_post_sha256 = (env.runtime_post_observation or {}).get("raw_sha256")
        out.durability_status = env.durability_status
        out.detail_bounded = env.detail_bounded
        out.retry_requires_new_tx = bool(env.retry_requires_new_tx)

        if state2 in (TransactionState.CONFIRMED_APPLIED.value,
                      TransactionState.DURABILITY_PENDING.value,
                      TransactionState.CONTINUITY_SYNC_PENDING.value,
                      TransactionState.CONTINUITY_SYNCING.value,
                      TransactionState.CONTINUITY_SYNCED.value):
            out.runtime_outcome = "CONFIRMED_APPLIED"
            if _durable_manual_gate(cur):
                return _manual_gate_result(out, cur)
            result = self._sync_applied(out, cur, request.consequence_plan)
            self.close()
            return result

        # non-applied / fail-closed after the single attempt -> no sync
        if state2 in _NONAPPLIED:
            result = _compose_nonapplied(cur, out)
            self.close()
            return result

        result = _state_result(out, cur, OrchestrationStage.RUNTIME_OUTCOME.value,
                               OrchestrationStatus.PENDING.value,
                               f"tx ended in state {state2}", False)
        self.close()
        return result

    # ------------------------------------------------------------------ #
    def _sync_applied(self, out: OrchestrationResult, row: dict,
                      plan: ConsequencePlan | None) -> OrchestrationResult:
        """Drive Phase 3C idempotent sync + outbox + finalise for an APPLIED tx.

        Uses only durable journal post-refs + the pre-approved consequence plan.
        Never touches runtime (Phase 3C product path is runtime-free)."""
        tx = out.continuity_tx_id
        if _durable_manual_gate(row):
            return _manual_gate_result(out, row)
        self._inject("F8")                 # confirmed applied; before continuity sync
        try:
            req = build_sync_request(row, plan)
        except Exception as exc:
            return _state_result(out, {**row, "state": "MANUAL_REVIEW"},
                                 OrchestrationStage.MANUAL_REVIEW_REQUIRED.value,
                                 OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value,
                                 f"cannot (re)build the digest-stable sync request: {str(exc)[:220]}",
                                 True)

        engine = ContinuitySyncEngine(self._con(), evidence_path=self.evidence_path,
                                      auto_project=True, app_name="phase3d")
        try:
            res = engine.sync_applied_transaction(req)
        except SyncEngineError as exc:
            return _state_result(out, {**row},
                                 OrchestrationStage.MANUAL_REVIEW_REQUIRED.value,
                                 OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value,
                                 f"sync blocked for review ({exc.review_reason}): {str(exc.reason)[:200]}",
                                 True)
        except Exception as exc:
            return _state_result(out, {**row},
                                 OrchestrationStage.MANUAL_REVIEW_REQUIRED.value,
                                 OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value,
                                 f"sync raised unexpected error: {str(exc)[:200]}", True)

        # ---- COMPLETED must be gated on EVIDENCE/OUTBOX DELIVERY -------------
        # SyncEngine returns ALREADY_SYNCED (replay) WITHOUT draining the outbox
        # that the earlier atomic sync commit left PENDING.  Authority effects +
        # sync_execution are durable, but the tx is NOT terminal until its
        # evidence-outbox rows are delivered.  ALREADY_SYNCED only means "effects
        # logically applied", never "outbox/evidence delivered".  We therefore:
        #   (1) drain any PENDING outbox via the idempotent strict projector;
        #   (2) only then finalise CONTINUITY_SYNCED -> COMPLETED;
        #   (3) truthfully report outbox_pending / non-terminal SYNCED otherwise.
        out.runtime_outcome = "CONFIRMED_APPLIED"
        out.effect_counts = {"effects": int(res.get("n_effects", 0))}
        n_pending = outbox_pending(self._con(), tx)
        out.outbox_pending = n_pending

        if n_pending:
            # drain (safe/idempotent; projector never duplicates an envelope).
            try:
                engine.drain_outbox(limit=250)
            except Exception:
                # outbox append / delivered-marker fault -> NOT terminal: leave
                # PENDING so a later recover retries idempotently.  Never COMPLETED.
                out.status = OrchestrationStatus.PENDING.value
                out.stage_reached = OrchestrationStage.OUTBOX_PHASE.value
                out.sync_state = "SYNCED"
                out.outbox_pending = outbox_pending(self._con(), tx)
                out.runtime_outcome = "CONFIRMED_APPLIED"
                out.detail_bounded = ("continuity synced but outbox drain failed "
                                      "(outbox still pending; fraud-safe retry via recovery)")
                return out
            n_pending = outbox_pending(self._con(), tx)
            out.outbox_pending = n_pending

        # (2) advance to COMPLETED only once the evidence-outbox is delivered.
        if n_pending == 0:
            try:
                res = engine.finalize_if_ready(tx, res)
            except Exception:
                pass  # continue to honest reporting below (never fake COMPLETED)

        # (3) honest terminal state from durable row + real outbox count.
        row_after = self.get_row(tx) or {}
        n_left = outbox_pending(self._con(), tx)
        out.outbox_pending = n_left
        if n_left == 0 and row_after.get("state") == TransactionState.COMPLETED.value:
            out.status = OrchestrationStatus.COMPLETED.value
            out.stage_reached = OrchestrationStage.FINALISED.value
            out.sync_state = "SYNCED"
            return out
        cur = row_after.get("state")
        if cur in _SYNCABLE:
            out.status = OrchestrationStatus.PENDING.value
            out.stage_reached = (OrchestrationStage.OUTBOX_PHASE.value if n_left
                                 else OrchestrationStage.SYNC_PHASE.value)
            out.sync_state = row_after.get("continuity_sync_state") or "SYNCED"
            out.detail_bounded = ("continuity synced; outbox still pending drain"
                                  if n_left else
                                  "continuity synced but not yet terminally marked")
            return out
        # unexpected residual -> manual review (no force/COMPLETED illusion)
        out.outbox_pending = n_left
        out.status = OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value
        out.stage_reached = OrchestrationStage.MANUAL_REVIEW_REQUIRED.value
        out.manual_review_required = True
        out.sync_state = row_after.get("continuity_sync_state")
        out.detail_bounded = ((f"continuity sync/outbox in unexpected durable state "
                               f"{cur!r}; manual review required")[:400])
        return out

    # ------------------------------------------------------------------ #
    def _await_owned_or_unequivocal(self, out: OrchestrationResult, tx_id: str,
                                    fallback: dict[str, Any]
                                    ) -> OrchestrationResult:
        """Bounded rendezvous used by a LOSING worker on the same tx.

        A worker that did NOT acquire the attempt-owner gate (or had 3B refuse the
        attempt with DuplicateAttempt/InvalidTransition while another worker ran)
        is NOT allowed to reserve, write, classify, journal an outcome, or re-run
        the runtime.  It only *reads* durable state to report the owner's (or the
        owner-crash) progress, waiting a bounded window so it can observe a leader
        that just finished.  It never writes OUTCOME_UNKNOWN and never crashes.
        """
        import time
        deadline = time.monotonic() + _AWAIT_WAIT
        last = None
        while time.monotonic() < deadline:
            row = self.get_row(tx_id) or last or fallback
            last = row
            st = row.get("state")
            # leader reached a terminal / settled outcome -> reflect it truthfully.
            if st == TransactionState.COMPLETED.value:
                return _compose_terminal(row, out)
            if st in _TERMINAL:
                return _compose_terminal(row, out)
            if st in _NONAPPLIED or st == TransactionState.MANUAL_REVIEW.value:
                # Leader's genuine fail-closed state (e.g. real owner-crash
                # uncertainty) -> manual, never auto-retry.  We did NOT create it.
                return _compose_nonapplied(row, out)
            if st in (TransactionState.RUNTIME_ATTEMPTING.value,) or \
               st in _SYNCABLE:
                # Leader still mid-flight: keep polling until it settles.
                time.sleep(0.03)
                continue
            # PREPARED / unexpected still present -> leader did not (yet) reserve.
            if st == TransactionState.PREPARED.value:
                # another worker may have only just started; give it the window.
                time.sleep(0.03)
                continue
            # unknown fallthrough: honest non-destructive report of the raw state.
            return _state_result(out, row, OrchestrationStage.RUNTIME_OUTCOME.value,
                                 OrchestrationStatus.PENDING.value,
                                 f"attempt owned elsewhere; durable state {st}", False)
        # Rendezvous expired while the leader is still mid-flight.  Report the
        # CURRENT durable in-progress state non-destructively (never UNKNOWN).
        row = self.get_row(tx_id) or last or fallback
        st = row.get("state")
        if st == TransactionState.COMPLETED.value:
            return _compose_terminal(row, out)
        return _state_result(
            out, row, OrchestrationStage.RUNTIME_OUTCOME.value,
            OrchestrationStatus.PENDING.value,
            ("transaction attempt in progress by another orchestration; "
             "no outcome classified here (re-query status for the durable result)"),
            False)

    # ------------------------------------------------------------------ #
    def _compose_durable(self, out: OrchestrationResult, row: dict[str, Any],
                         plan: ConsequencePlan | None) -> OrchestrationResult:
        """Truthful report of a durable transaction row (reader / non-owner).

        Used by a worker that discovers it is not the attempt owner (or the row
        already moved off PREPARED): it must reflect reality, NEVER the outcome of
        an attempt it did not perform.  No runtime write, no outcome classification,
        no sync-plan invention.  Durable applied-but-unsynced rows are reported as
        PENDING (sync is an idempotent forward step any later caller may take);
        UNKNOWN/DIVERGENCE/NOT_APPLIED are reported fail-closed; a terminal row is
        reported as its terminal status."""
        state = row.get("state")
        # baseline durable fields (always truthful from the journal)
        out.attempt_count = int(row.get("attempt_count") or 0)
        out.runtime_outcome = row.get("runtime_outcome_class") or state
        out.sync_state = row.get("continuity_sync_state")
        out.manual_review_required = bool(row.get("manual_review_required"))
        out.retry_requires_new_tx = True

        if state in _TERMINAL:
            _compose_terminal(row, out)
        elif state in _NONAPPLIED or state == TransactionState.MANUAL_REVIEW.value:
            _compose_nonapplied(row, out)
        elif state == TransactionState.RUNTIME_ATTEMPTING.value:
            # Owner is (probably) live: this is ORCHESTRATION_IN_PROGRESS, not a
            # review sink.  A reader reports it as PENDING / in-progress; only a
            # true post-crash recover (solo, no live owner) converts it to manual.
            _state_result(out, row, OrchestrationStage.RUNTIME_ATTEMPTED.value,
                          OrchestrationStatus.PENDING.value,
                          "runtime attempt in progress by the owning orchestration "
                          "(re-query status for the durable result)", False)
        elif state == TransactionState.PREPARED.value:
            _state_result(out, row, OrchestrationStage.PREPARED.value,
                          OrchestrationStatus.PENDING.value,
                          "durable PREPARED row; no runtime attempt consumed here",
                          False)
        elif state in _SYNCABLE and state not in _TERMINAL:
            out.status = OrchestrationStatus.PENDING.value
            out.stage_reached = OrchestrationStage.SYNC_PHASE.value
            out.sync_state = row.get("continuity_sync_state")
            out.detail_bounded = (f"durable state {state}: continuity sync/outbox not "
                                  "yet delivered (re-query status / recover to advance)")
        else:
            out.status = OrchestrationStatus.PENDING.value
            out.stage_reached = OrchestrationStage.VALIDATED.value
            out.detail_bounded = f"durable state {state}: reader reports without classification"

        # THIS call is a READER / non-owner: it never invoked the runtime writer,
        # so per-call attempt/writer flags must stay False (an attempt_count of 1
        # in the durable row reflects another owner, not this call).
        out.runtime_attempted = False
        out.writer_invoked = False
        return out


# --------------------------------------------------------------------------- #
def build_sync_request(row: dict, plan: ConsequencePlan | None):
    """Reconstruct the digest-stable Phase 3C ContinuitySyncRequest from the
    durable journal evidence and the approved consequence plan."""
    from ..sync3c.contracts import ContinuitySyncRequest
    from ..sync3c.planner import request_claimed_digest
    consequences = list((plan.consequences if plan else None) or [])
    plver = (plan.plan_version if plan else None) or "phase3c-sync-v1"

    def _mk(claimed: str) -> ContinuitySyncRequest:
        return ContinuitySyncRequest(
            continuity_tx_id=row["continuity_tx_id"],
            runtime_outcome_class="CONFIRMED_APPLIED",
            observed_post_sha256=row.get("runtime_post_observed_sha256") or "",
            observed_post_semantic_digest=row.get("runtime_post_semantic_digest") or "",
            expected_candidate_digest=row.get("expected_candidate_digest")
            or row.get("runtime_expected_semantic_digest") or "exp",
            patch_digest=row.get("patch_digest") or "patch-x",
            branch_id=row.get("branch_id") or "default",
            source_provenance={"component": "phase3d-orchestrator"},
            request_provenance=row.get("request_provenance_json") or {},
            sync_plan_bytes_digest=claimed,
            consequences=consequences,
            plan_version=plver,
        )

    claimed = request_claimed_digest(_mk(""))
    return _mk(claimed)


def outbox_pending(con, tx: str) -> int:
    row = con.execute(
        "SELECT COUNT(*) AS c FROM history_outbox WHERE continuity_tx_id=? "
        "AND state='PENDING'", (tx,)).fetchone()
    return int(row["c"]) if row else 0


def _prove(request: OrchestrationRequest):
    vendor_dir, runtime_path = validate_and_prove(request)[0:2]
    return vendor_dir, runtime_path


# ---- same-tx attempt ownership gate (composition-only, Phase 3D) ------------- #
# Coordinates which Orchestrator drives the reservation->writer->observe->classify
# window for a (db, runtime) pair so a losing worker never classifies an outcome it
# does not own.  It is advisory/local (like 3B's own lock) and uses a DISTINCT lock
# file so it cannot collide with Phase 3B's writer advisory lock.
_GATE_WAIT = 8.0       # bounded seconds to acquire the attempt-owner gate
_AWAIT_WAIT = 6.0      # bounded rendezvous for a leader's durable result


def _orchestration_gate(db_path, runtime_path):
    import hashlib
    db_dir = Path(db_path).parent
    tail = hashlib.sha256(str(runtime_path).encode()).hexdigest()[:12]
    gate_path = db_dir / f".continuity-orch-{tail}.lock"
    from ..runtime3b.local_lock import LocalAdvisoryLock
    return LocalAdvisoryLock(gate_path)


def _default_plan(request: OrchestrationRequest):
    """A `request.consequence_plan` if the caller set one on the request."""
    return request.consequence_plan


def _validate_and_digest_plan(tx_id: str, branch_id: str,
                              plan: ConsequencePlan) -> str:
    """Validate the exact plan before PREPARED and return its durable identity."""
    if not isinstance(plan, ConsequencePlan):
        raise NoConsequencePlan("consequence plan has an invalid type")
    if plan.branch_id != branch_id:
        raise NoConsequencePlan("consequence plan branch differs from request branch")
    from ..sync3c.contracts import ContinuitySyncRequest
    from ..sync3c.planner import build_plan, request_claimed_digest
    req = ContinuitySyncRequest(
        continuity_tx_id=tx_id, runtime_outcome_class="CONFIRMED_APPLIED",
        observed_post_sha256="prepare-only", observed_post_semantic_digest="prepare-only",
        expected_candidate_digest="prepare-only", patch_digest="prepare-only",
        branch_id=branch_id, source_provenance={}, request_provenance={},
        sync_plan_bytes_digest="", consequences=list(plan.consequences),
        plan_version=plan.plan_version)
    try:
        build_plan(req)  # planner/ownership validation before any durable/runtime change
    except Exception as exc:
        if exc.__class__.__name__ == "PlanError":
            raise RequestRejected(str(exc)) from exc
        raise
    return request_claimed_digest(req)


def _durable_manual_gate(row: dict[str, Any]) -> bool:
    return (bool(row.get("manual_review_required"))
            or row.get("durability_status") in ("DIR_FSYNC_FAILED", "DIR_FSYNC_UNSUPPORTED"))


def _manual_gate_result(out: OrchestrationResult,
                        row: dict[str, Any]) -> OrchestrationResult:
    return _state_result(
        out, row, OrchestrationStage.MANUAL_REVIEW_REQUIRED.value,
        OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value,
        "durable runtime result requires manual review; continuity sync and "
        "completion are forbidden", True)


def _raise(exc: Exception):
    raise exc


def _fresh_id() -> str:
    import uuid
    return "orch-" + uuid.uuid4().hex[:24]


def _refuse(out: OrchestrationResult, exc: Exception) -> OrchestrationResult:
    out.status = OrchestrationStatus.REFUSED.value
    out.stage_reached = OrchestrationStage.REFUSED.value
    out.detail_bounded = str(exc)[:400]
    out.refused_reason = str(exc)[:400]
    out.error_class = exc.__class__.__name__
    return out


def _compose_terminal(row: dict, out: OrchestrationResult) -> OrchestrationResult:
    state = row["state"]
    out.manual_review_required = bool(row.get("manual_review_required"))
    out.attempt_count = int(row.get("attempt_count") or 0)
    out.runtime_outcome = row.get("runtime_outcome_class") or state
    out.sync_state = row.get("continuity_sync_state")
    if out.manual_review_required:
        out.status = OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value
        out.stage_reached = OrchestrationStage.MANUAL_REVIEW_REQUIRED.value
    elif state == TransactionState.COMPLETED.value:
        out.status = OrchestrationStatus.COMPLETED.value
        out.stage_reached = OrchestrationStage.FINALISED.value
        out.sync_state = "SYNCED"
    elif state == TransactionState.PRECONDITION_FAILED.value:
        out.status = OrchestrationStatus.PRECONDITION_FAILED.value
        out.runtime_attempted = False
        out.writer_invoked = False
    elif state in (TransactionState.CONFIRMED_NOT_APPLIED.value,
                   TransactionState.ABORTED_NOT_ATTEMPTED.value):
        out.status = OrchestrationStatus.ABORTED_NOT_ATTEMPTED.value
    else:  # MANUAL_REVIEW
        out.status = OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value
        out.stage_reached = OrchestrationStage.MANUAL_REVIEW_REQUIRED.value
        out.manual_review_required = True
    return out


def _compose_nonapplied(row: dict, out: OrchestrationResult) -> OrchestrationResult:
    state = row["state"]
    out.runtime_outcome = row.get("runtime_outcome_class") or state
    out.sync_state = row.get("continuity_sync_state")
    out.attempt_count = int(row.get("attempt_count") or 0)
    out.runtime_attempted = out.attempt_count > 0
    out.writer_invoked = out.attempt_count > 0
    out.manual_review_required = bool(row.get("manual_review_required"))
    if out.manual_review_required:
        out.status = OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value
        out.stage_reached = OrchestrationStage.MANUAL_REVIEW_REQUIRED.value
    elif state == TransactionState.PRECONDITION_FAILED.value:
        out.status = OrchestrationStatus.PRECONDITION_FAILED.value
        out.runtime_attempted = False
    elif state in (TransactionState.OUTCOME_UNKNOWN.value,
                   TransactionState.CONCURRENT_DIVERGENCE.value,
                   TransactionState.RECOVERY_REQUIRED.value):
        out.status = OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value
        out.stage_reached = OrchestrationStage.MANUAL_REVIEW_REQUIRED.value
        out.manual_review_required = True
        out.detail_bounded = (f"{state}: no historical sync, no same-tx retry; "
                              "manual/new-tx required.")
    else:  # CONFIRMED_NOT_APPLIED
        out.status = OrchestrationStatus.ABORTED_NOT_ATTEMPTED.value
    return out


def _state_result(out, row, stage, status, detail, manual) -> OrchestrationResult:
    out.status = status
    out.stage_reached = stage
    out.manual_review_required = bool(manual or row.get("manual_review_required"))
    out.detail_bounded = detail[:400]
    out.attempt_count = int(row.get("attempt_count") or 0)
    out.runtime_outcome = row.get("runtime_outcome_class") or row.get("state")
    out.sync_state = row.get("continuity_sync_state")
    return out


def orchestrate(request: OrchestrationRequest, *, db_path: Path | str,
                evidence_path: Path | str | None = None,
                consequence_plan: ConsequencePlan | None = None,
                tx_id_hint: str | None = None,
                fault_on: str | None = None,
                fault_impl=None) -> OrchestrationResult:
    orch = Orchestrator(db_path=db_path, evidence_path=evidence_path,
                        fault_on=fault_on, fault_impl=fault_impl)
    try:
        return orch.orchestrate(request, consequence_plan=consequence_plan,
                                tx_id_hint=tx_id_hint)
    finally:
        orch.close()
