"""Phase 3D — orchestration request safety + path guard (composition).

The mutation-safety invariants remain those enforced by Phase 3A (concrete
patch, player sovereignty, adult-authority non-inference) and Phase 3B
(disposable fixture proof, named-slot BLOCK, no-desired-outcome).  The
orchestration layer re-checks the *same* concrete rules up front so it never
reaches the product writer with a malformed or unsafe request, while delegating
the actual bytes/path proof to the phase modules it reuses.
"""
from __future__ import annotations
from pathlib import Path
from typing import Any

from ..transactions.errors import (
    PlayerSovereigntyViolation, InvalidArgument, UnsupportedNamedSlot,
)
from ..runtime3b.guard import (
    is_disposable_runtime, guard_unnamed_slot, guard_no_desired_outcome,
)
from .contracts import OrchestrationRequest, ConsequencePlan
from .errors import ProductionPathRefused, RequestRejected, NoConsequencePlan

# Production roots guarded mutation must never write into, even by accident.
PRODUCTION_RUNTIME_SENTINELS = (
    Path("/var/minis/workspace"),
    Path("/var/minis/memory"),
    Path("/var/minis/shared"),
    Path("/var/minis/mounts"),
)


def _require_concrete_patch(patch: Any) -> dict[str, Any]:
    """A concrete, non-empty, dict runtime patch is mandatory.  A bare
    natural-language desired outcome cannot satisfy this contract."""
    try:
        from ..transactions.preconditions import require_concrete_patch
        return require_concrete_patch(patch)
    except Exception as exc:
        # Mirror 3A contracts: no patch / not dict / sovereignty keys are all a
        # refuse-class contract violation surfaced at orchestration request time.
        raise RequestRejected(str(exc)) from exc


def validate_and_prove(request: OrchestrationRequest):
    """Validate the request contract + prove the mutation path is disposable.

    Returns (vendor_dir, runtime_path, proof) on success.  Raises
    RequestRejected / ProductionPathRefused / UnsupportedNamedSlot (3B) /
    PlayerSovereigntyViolation (3A) on any violation.  No state is changed.
    """
    # 1) runtime identity/path must be present (concrete request, not language).
    if not request.runtime_path:
        raise RequestRejected("runtime identity/path is required (concrete runtime patch target)")
    if not request.vendor_dir:
        raise RequestRejected("vendor_dir is required for the runtime context")

    # 2) concrete patch, player sovereignty, adult-authority non-inference,
    #    and no name-slot path.  (Compose Phase 3A + Phase 3B guards.)
    patch = _require_concrete_patch(request.patch)
    guard_unnamed_slot(request.runtime_path)
    guard_no_desired_outcome(patch)          # 3B: no natural-language belief synthesis
    try:
        from ..transactions.preconditions import guard_adult_authority_inference
        guard_adult_authority_inference(patch)
    except ImportError:  # pragma: no cover
        pass

    # 3) production real-save is disabled in development.  A disposable fixture
    #    proof is mandatory for a real mutation path (guard is lenient only when
    #    the caller has NO runtime change to make).
    if request.allow_production_write:
        raise ProductionPathRefused(
            "production real-save mutation is disabled in the Phase 3D development CLI")

    vendor_dir = Path(request.vendor_dir).resolve()
    runtime_path = Path(request.runtime_path).resolve()
    proof = is_disposable_runtime(vendor_dir, runtime_path)
    if not proof.ok:
        raise ProductionPathRefused(
            "runtime mutation refused on non-disposable path: " + proof.reason)

    return vendor_dir, runtime_path, patch


def require_consequence_plan(request: OrchestrationRequest) -> ConsequencePlan:
    """A concrete (possibly empty) consequence plan must be declared explicitly."""
    plan = request.consequence_plan
    if plan is None or not isinstance(plan, ConsequencePlan):
        raise NoConsequencePlan(
            "a consequence plan must be declared (explicit 'none' allowed only via "
            "an empty ConsequencePlan, never by omission)")
    if not isinstance(plan.consequences, (list, tuple)):
        raise NoConsequencePlan("consequence_plan consequences must be a list")
    return plan
