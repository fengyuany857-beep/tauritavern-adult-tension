"""Phase 3D — orchestration process-restart recovery (read-only of runtime).

Re-entry / restart recovery answers "after a crash, drive this saga forward from
durable state" WITHOUT ever re-invoking the runtime writer and WITHOUT guessing
from drift:

  - applied-but-unsynced (CONFIRMED_APPLIED / DURABILITY_PENDING / sync pending
    families): idempotent Phase 3C replay when a digest-stable consequence plan
    is re-offered (Phase 3C's own request-provider model) + outbox drain +
    finalisation;
  - UNKNOWN / DIVERGENCE / NOT_APPLIED / PRECONDITION_FAILED / MANUAL_REVIEW:
    never sync, never retry the same tx, emit manual-review semantics;
  - a completely absent record is an error (UnknownOrchestration).

Everything here is forward-only and reuses Phase 3C product internals; it does
not touch the vendor runtime file.
"""
from __future__ import annotations
import sqlite3
from pathlib import Path
from typing import Any, Callable

from ..transactions.contracts import TransactionState
from ..sync3c.recovery import RecoveryScanner, RecoveryAction, recover_forward
from ..sync3c.manual_packet import build_manual_packet
from ..sync3c.engine import ContinuitySyncEngine, SyncEngineError
from .contracts import (
    ConsequencePlan, OrchestrationResult, OrchestrationStage, OrchestrationStatus,
)
from .errors import UnknownOrchestration
from .orchestrator import build_sync_request, outbox_pending

_NONVALID = (
    TransactionState.PRECONDITION_FAILED.value,
    TransactionState.CONFIRMED_NOT_APPLIED.value,
)


def scan_recoverable_orchestrations(*, db_path: Path | str,
                                    limit: int = 100) -> list[dict[str, Any]]:
    """List recoverable nonterminal orchestration rows (durable-state only)."""
    from .status import scan_recoverable
    rows = scan_recoverable(db_path, limit=limit)
    return [dict(r) for r in rows]


def recover_orchestration(
    *,
    db_path: Path | str,
    tx_id: str,
    consequence_plan: ConsequencePlan | None = None,
    evidence_path: Path | str | None = None,
    auto_sync: bool = True,
) -> OrchestrationResult:
    """Recover / resume ONE orchestration from durable SQLite state.

    If the row is applied-family and a digest-stable `consequence_plan` is
    re-offered (default None -> the planner rejects re-sync unless the caller is
    replaying the exact approved consequences), recovery replays continuity sync
    + drains outbox + finalises — all idempotent, never a runtime write.

    For UNKNOWN / DIVERGENCE / NOT_APPLIED / PRECONDITION_FAILED / MANUAL_REVIEW
    it only reports the durable state (no sync / no retry / no override).

    Raises UnknownOrchestration when no row exists.
    """
    from .orchestrator import Orchestrator
    db_path = Path(db_path)
    con = _connect(db_path)
    row = None
    try:
        row = con.execute(
            "SELECT * FROM transaction_journal WHERE continuity_tx_id=?",
            (tx_id,)).fetchone()
    finally:
        con.close()
    if row is None:
        raise UnknownOrchestration(f"no durable transaction for tx {tx_id}")
    row = dict(row)
    state = row["state"]

    # If applied-family but NO re-offered plan: we still drain outbox / perform
    # a forward projector-only action but never *invent* a sync plan.
    applied_syncable = state in (TransactionState.CONFIRMED_APPLIED.value,
                                 TransactionState.DURABILITY_PENDING.value,
                                 TransactionState.CONTINUITY_SYNC_PENDING.value,
                                 TransactionState.CONTINUITY_SYNCING.value,
                                 TransactionState.CONTINUITY_SYNCED.value)

    out = OrchestrationResult(continuity_tx_id=tx_id,
                              runtime_outcome=row.get("runtime_outcome_class"),
                              sync_state=row.get("continuity_sync_state"),
                              attempt_count=int(row.get("attempt_count") or 0),
                              runtime_attempted=(int(row.get("attempt_count") or 0) > 0),
                              writer_invoked=(int(row.get("attempt_count") or 0) > 0),
                              retry_requires_new_tx=True)

    if (bool(row.get("manual_review_required"))
            or row.get("durability_status") in ("DIR_FSYNC_FAILED", "DIR_FSYNC_UNSUPPORTED")):
        out.status = OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value
        out.stage_reached = OrchestrationStage.MANUAL_REVIEW_REQUIRED.value
        out.manual_review_required = True
        out.detail_bounded = ("durable runtime result requires manual review; "
                              "continuity sync and completion are forbidden")
        return out

    if state in _NONVALID:
        # PRECONDITION_FAILED / CONFIRMED_NOT_APPLIED are terminal audit states:
        # no sync, no same-tx retry; a future user-requested retry = new tx.
        out.status = OrchestrationStatus.PRECONDITION_FAILED.value if \
            state == TransactionState.PRECONDITION_FAILED.value else \
            OrchestrationStatus.ABORTED_NOT_ATTEMPTED.value
        out.stage_reached = OrchestrationStage.RUNTIME_OUTCOME.value
        return out

    if state == TransactionState.COMPLETED.value:
        out.status = OrchestrationStatus.COMPLETED.value
        out.stage_reached = OrchestrationStage.FINALISED.value
        out.sync_state = "SYNCED"
        return out

    if state == TransactionState.MANUAL_REVIEW.value:
        out.status = OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value
        out.stage_reached = OrchestrationStage.MANUAL_REVIEW_REQUIRED.value
        out.manual_review_required = True
        return out

    if state in (TransactionState.OUTCOME_UNKNOWN.value,
                 TransactionState.CONCURRENT_DIVERGENCE.value,
                 TransactionState.RECOVERY_REQUIRED.value):
        out.status = OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value
        out.stage_reached = OrchestrationStage.MANUAL_REVIEW_REQUIRED.value
        out.manual_review_required = True
        out.detail_bounded = (f"{state}: recovery must not sync or retry the same tx; "
                              "manual/new-tx required.")
        return out

    if state == TransactionState.RUNTIME_ATTEMPTING.value:
        out.status = OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value
        out.stage_reached = OrchestrationStage.MANUAL_REVIEW_REQUIRED.value
        out.manual_review_required = True
        out.detail_bounded = ("tx mid-attempt with no durable outcome; never auto-retry "
                              "runtime. Manual / new-tx required.")
        return out

    # ----- durable PREPARED (no attempt yet) -> safe to resume normally ---------
    if state == TransactionState.PREPARED.value:
        # No runtime attempt consumed yet.  We are unable to re-run the runtime
        # writer as a "recovery" (that would be a contradiction in a post-crash
        # restart where the writer was not reached).  Report PREPARED; a caller
        # may call orchestrate() once to drive it from a PREPARED row.
        out.status = OrchestrationStatus.PENDING.value
        out.stage_reached = OrchestrationStage.PREPARED.value
        out.detail_bounded = ("durable PREPARED row; no runtime attempt yet. Re-run "
                              "orchestrate() to drive the single attempt.")
        return out

    # ----- applied-family: idempotent forward sync/outbox/finalise -------------
    if applied_syncable:
        if consequence_plan is None:
            # No re-offered plan => Phase 3C scanner emits manual/pylon review for
            # an appled+durable row that has no reconstructable consequences.
            co = _connect(db_path)
            try:
                sc = RecoveryScanner(co, evidence_path=Path(evidence_path) if evidence_path else
                                     (db_path.parent / "history" / "VOL-001.jsonl"),
                                     request_provider=None)
                obs = sc.scan()
            finally:
                co.close()
            r_info = [o for o in obs if o["continuity_tx_id"] == tx_id]
            out.sync_state = row.get("continuity_sync_state")
            # Authority may be done: drain outbox regardless (safe forward).
            drained = _drain_only(db_path, tx_id, evidence_path)
            if drained:
                out.detail_bounded = ("no re-offered consequence plan; outbox "
                                      "drained; sync/plan requires re-offer")
                out.status = OrchestrationStatus.PENDING.value
            else:
                out.detail_bounded = ("no re-offered consequence plan; cannot invent "
                                      "a consequence plan (manual review / re-offer "
                                      "identical plan).")
                out.status = OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value
                out.stage_reached = OrchestrationStage.MANUAL_REVIEW_REQUIRED.value
                out.manual_review_required = bool(r_info)
            return out

        # Re-offer the approved consequence plan -> Phase 3C idempotent sync.
        orch = Orchestrator(db_path=db_path, evidence_path=evidence_path)
        try:
            result = orch._sync_applied(out, row, consequence_plan)
        finally:
            orch.close()
        return result

    # Unknown other state fallback (e.g. CONTINUITY_SYNCED handled by applied family)
    result = OrchestrationResult(continuity_tx_id=tx_id, status="PENDING",
                                 stage_reached=OrchestrationStage.SYNC_PHASE.value,
                                 sync_state=row.get("continuity_sync_state"))
    return result


def _connect(db_path: Path) -> sqlite3.Connection:
    con = sqlite3.connect(str(Path(db_path)))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con


def _drain_only(db_path: Path, tx: str, evidence_path) -> int:
    from ..sync3c.projector import EvidenceProjector
    evidence = Path(evidence_path) if evidence_path else \
        db_path.parent / "history" / "VOL-001.jsonl"
    con = _connect(db_path)
    try:
        proj = EvidenceProjector(con, evidence)
        res = proj.drain()
    finally:
        con.close()
    return int(res.get("drained", 0))
