"""Phase 3D — orchestration error taxonomy (additive, layered onto Phase 3X).

Errors describe orchestration-level composition failures.  They never shadow the
concrete Phase 3A/3B/3C failures (TxError / DuplicateAttempt etc.); those
propagate into the OrchestrationResult envelope as a phase + status so a caller
can tell which sub-phase was reached.
"""
from __future__ import annotations

from ..errors import ContinuityError


class OrchestrationError(ContinuityError):
    """Base for the top-level orchestration layer."""


class RequestRejected(OrchestrationError):
    """The OrchestrationRequest itself is not well-formed / safe to run."""


class ProductionPathRefused(OrchestrationError):
    """A mutation was requested against a non-disposable production path."""


class NoConsequencePlan(OrchestrationError):
    """A consequence plan is required for apply+sync but is absent/empty."""


class UnknownOrchestration(OrchestrationError):
    """No durable journal row exists for the given continuity_tx_id."""


class NotReentrant(OrchestrationError):
    """Re-entry into the runtime phase was requested after the attempt was consumed."""


# Kept as an alias so callers that distinguish "the failure happened inside the
# single-file runtime phase (Phase 3B), not during validation" can catch this
# precise class instead of a bare ContinuityError.
RuntimePhaseError = OrchestrationError
