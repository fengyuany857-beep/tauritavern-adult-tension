"""Phase 3B — deterministic runtime outcome classifier.

Pure function: :func:`classify_runtime_outcome` maps observational evidence to
one of the protocol outcome dimensions.  It NEVER touches a file and NEVER
writes; identical evidence always yields the identical classification.

Only STRONG evidence (protocol §8 / §20) may conclude APPLIED or NOT_APPLIED:
  - unambiguous identity / regular file present;
  - parsed state exact equality with expected candidate AND canonical semantic
    digest equality to SE; when a deterministic-serializer capability is active
    additionally raw bytes equal HE  => CONFIRMED_APPLIED;
  - process clearly finished and post exactly equals pre (raw == H0, semantic
    == S0) with evidence placing the failure before replace => CONFIRMED_NOT_APPLIED;
  - second H0 mismatch detected before the writer => PRECONDITION_FAILED.

Everything else is OUTCOME_UNKNOWN or CONCURRENT_DIVERGENCE (never auto-retried).
A return code or exception is never, by itself, conclusive.
"""
from __future__ import annotations
from dataclasses import asdict
from typing import Any

from .contracts import (
    RuntimeObservationEvidence, RuntimeOutcomeDecision, ClassifierVerdict,
)


# Outcome classes that a PRECONDITION mismatch yields (terminal, no writer).
PRECONDITION_DECISION = RuntimeOutcomeDecision.PRECONDITION_FAILED
APPLIED_DECISION = RuntimeOutcomeDecision.CONFIRMED_APPLIED
NOT_APPLIED_DECISION = RuntimeOutcomeDecision.CONFIRMED_NOT_APPLIED
UNKNOWN_DECISION = RuntimeOutcomeDecision.OUTCOME_UNKNOWN
DIVERGENCE_DECISION = RuntimeOutcomeDecision.CONCURRENT_DIVERGENCE


def _keys(e: RuntimeObservationEvidence) -> dict[str, Any]:
    # Compact evidence dictionary for bounded summaries (never CoT).
    return {
        "raw_post": e.raw_sha256,
        "semantic_post": e.semantic_digest,
        "pre": e.pre_raw_sha256,
        "expected_semantic": e.expected_semantic_digest,
        "parse": e.parse_ok,
        "identity": e.identity_ok,
        "present": e.runtime_present,
        "read_error": e.read_error_class,
    }


def classify_runtime_outcome(evidence: RuntimeObservationEvidence,
                             writer_called: bool,
                             expected_sha_capable: bool = False,
                             precheck_passed: bool = True) -> ClassifierVerdict:
    """Map observation evidence to an outcome.  Pure and deterministic.

    Additional context that is NOT part of the evidence object:
      - `writer_called`   : whether the writer subprocess was started (informational,
                            and needed to distinguish "no attempt happened" windows).
      - `expected_sha_capable` : whether the deterministic-serializer capability is
                            active so we may also compare exact expected bytes HE.
      - `precheck_passed` : did the second pre-write H0 check return OK.  If the
                            caller already saw a mismatch BEFORE invoking the writer,
                            that is terminal PRECONDITION_FAILED with no writer call
                            (handled by execute(); we still reflect it here for tests).

    Returns a :class:`ClassifierVerdict`.
    """
    # The precondition-failure path is decided upstream by execute(); the
    # classifier keeps a mirror so a caller can call it directly.
    if not precheck_passed:
        return ClassifierVerdict(
            decision=PRECONDITION_DECISION,
            summary="second pre-write observation differed from prepared H0; writer not invoked",
            evidence_detail=_keys(evidence),
            writer_called=writer_called,
        )

    present = evidence.runtime_present
    parse_ok = evidence.parse_ok
    valid_ok = evidence.validation_ok
    identity_ok = evidence.identity_ok

    post_raw = evidence.raw_sha256
    post_sem = evidence.semantic_digest
    pre_raw = evidence.pre_raw_sha256
    exp_sem = evidence.expected_semantic_digest
    exp_raw = evidence.expected_raw_sha256

    # --- Robustness: file absent / unreadable / parse failure -> UNKNOWN ----
    if not present or not identity_ok or not parse_ok or not valid_ok:
        return _unknown_variant(evidence, writer_called,
                                "post file absent/unparsable/unvalidated; cannot conclude")

    # --- Stronger check: writer never invoked (informational) ----------------
    # If the writer never started we should never have got to classification with
    # a "post state" that differs meaningfully; but a caller could pass evidence
    # anyway.  Preserve correctness: if post equals pre, that is a genuine
    # not-attempted snapshot; otherwise UNKNOWN.
    if not writer_called:
        if post_raw == pre_raw and (post_sem or None) == evidence.pre_semantic_digest:
            return ClassifierVerdict(
                decision=NOT_APPLIED_DECISION,
                summary="writer never invoked and post equals prepared pre-state",
                evidence_detail=_keys(evidence), writer_called=False)
        return ClassifierVerdict(
            decision=UNKNOWN_DECISION,
            summary="writer never invoked yet post differs from pre; authorship ambiguous",
            evidence_detail=_keys(evidence), writer_called=False)

    # --- Now the writer did run.  Decide by strong equality. ----------------
    # CONFIRMED_APPLIED: full semantic equality to the expected candidate, and
    # (capability active) exact expected bytes.
    semantic_applied = (post_sem is not None and exp_sem is not None
                        and post_sem == exp_sem)
    if semantic_applied:
        if not expected_sha_capable:
            return ClassifierVerdict(
                decision=APPLIED_DECISION,
                summary="post semantic digest exactly equals expected candidate (semantic authority)",
                evidence_detail=_keys(evidence), writer_called=True)
        # If expected bytes are active, they must match; a mismatch here is a
        # divergence even though semantically equal (serializer drift or exotic
        # state would be suspicious).
        if exp_raw is not None and post_raw == exp_raw:
            return ClassifierVerdict(
                decision=APPLIED_DECISION,
                summary="post exact bytes == expected HE and semantic == SE",
                evidence_detail=_keys(evidence), writer_called=True)
        # Capability said deterministic but bytes differ => divergence/unknown.
        return ClassifierVerdict(
            decision=DIVERGENCE_DECISION,
            summary="semantically expected but raw bytes differ from deterministic HE; likely another writer raced",
            evidence_detail=_keys(evidence), writer_called=True)

    # CONFIRMED / NOT-APPLIED assessment for post == pre (writer ran).
    if post_raw == pre_raw and (post_sem or None) == evidence.pre_semantic_digest:
        # runtime byte/semantic identical to the prepared pre-state.  A real
        # successful single-file replace would normally change bytes (clock
        # advance / applied deltas), so an unchanged post is NOT itself an
        # applied state.  Whether it is provably NOT_APPLIED depends on strong
        # evidence that the writer never reached the replace (vendor pinned CLI
        # returns nonzero from load/commit/validation BEFORE any write).
        if evidence.pre_replace_strong_proof:
            return ClassifierVerdict(
                decision=NOT_APPLIED_DECISION,
                summary="runtime post == pre and evidence proves failure before replace",
                evidence_detail=_keys(evidence), writer_called=True)
        return ClassifierVerdict(
            decision=UNKNOWN_DECISION,
            summary="runtime unchanged but no proof of pre-replace failure; NOT_APPLIED not concluded",
            evidence_detail=_keys(evidence), writer_called=True,
            manual_review_required=True)

    # --- Neither pre nor expected -> divergence or unknown -------------------
    # A valid current state that is neither complete pre nor complete expected
    # candidate is DIVERGENCE (an external writer / race).  If we cannot even
    # confirm one vs. the other parse quality, OUTCOME_UNKNOWN.
    if (post_raw is not None and post_raw != pre_raw and post_sem is not None
            and post_sem != exp_sem):
        return ClassifierVerdict(
            decision=DIVERGENCE_DECISION,
            summary="valid post state is neither prepared pre nor expected candidate",
            evidence_detail=_keys(evidence), writer_called=True)

    return _unknown_variant(evidence, writer_called,
                            "post evidence class is ambiguous; reproducible strong proof required")


def _unknown_variant(evidence: RuntimeObservationEvidence, writer_called: bool,
                     reason: str) -> ClassifierVerdict:
    return ClassifierVerdict(
        decision=UNKNOWN_DECISION,
        summary=reason,
        evidence_detail=_keys(evidence),
        writer_called=writer_called,
        manual_review_required=True,
    )


def confirmed_not_applied_with_pre_replace_proof(
    evidence: RuntimeObservationEvidence, writer_called: bool,
    pre_replace_proof: bool,
) -> ClassifierVerdict:
    """Optional stricter scoring wrapper for the special "post == pre but writer
    returned success and candidate != pre" case (outcome matrix row C).

    A post==pre state alone is NOT a NOT_APPLIED proof.  NOT_APPLIED may be
    concluded only when there is additional evidence the failure happened
    strictly before the replacement (e.g. pinned CLI returned nonzero from
    preflight/validation, or a process-level duplicate-attempt record confirms
    the writer never entered the replace window)."""
    post_raw = evidence.raw_sha256
    pre_raw = evidence.pre_raw_sha256
    exp_sem = evidence.expected_semantic_digest
    same_as_pre = post_raw == pre_raw and (evidence.semantic_digest or None) == evidence.pre_semantic_digest
    if not same_as_pre:
        # fall through to the standard classifier
        return classify_runtime_outcome(evidence, writer_called)
    if pre_replace_proof:
        return ClassifierVerdict(
            decision=NOT_APPLIED_DECISION,
            summary="runtime unchanged and evidence confirms failure before replace",
            evidence_detail=_keys(evidence), writer_called=writer_called)
    return _unknown_variant(evidence, writer_called,
                            "runtime unchanged but no proof of pre-replace failure; NOT_APPLIED cannot be concluded")


def outcome_to_class(decision: RuntimeOutcomeDecision) -> str:
    from continuity.transactions.contracts import RuntimeOutcomeClass as RC
    return {
        PRECONDITION_DECISION: RC.PRECONDITION_FAILED.value,
        APPLIED_DECISION: RC.CONFIRMED_APPLIED.value,
        NOT_APPLIED_DECISION: RC.CONFIRMED_NOT_APPLIED.value,
        UNKNOWN_DECISION: RC.OUTCOME_UNKNOWN.value,
        DIVERGENCE_DECISION: RC.CONCURRENT_DIVERGENCE.value,
    }[decision]
