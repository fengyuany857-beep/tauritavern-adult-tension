"""Phase 3B — safe single-file runtime commit orchestration (execute path).

This is the ONLY Phase 3B entry that may (after a durable PREPARED row, a
second raw-H0 precondition re-check, and an atomic attempt reservation) invoke
the real pinned single-file vendor writer on a provably disposable runtime.

Protocol ordering (Sol §6 / §7, P8-P9) — this module enforces:
  1. second pre-write H0 observation (P8) immediately before the writer; a
     mismatch => PRECONDITION_FAILED terminal, attempt stays 0, writer never
     invoked, no auto-rebase;
  2. atomically reserve the single attempt (P9: attempt 0->1 + RUNTIME_ATTEMPTING
     + started_at) via the journal DB;
  3. acquire a *local advisory* lock (coordinates only compliant writers);
  4. invoke the pinned vendor single-file writer (bounded subprocess logs);
  5. IMMEDIATELY take a post observation (strong evidence), even on exception;
  6. classify via the pure classifier;
  7. journal the outcome + durability metadata.  Applied rows rest at
     DURABILITY_PENDING and NEVER sync (Phase 3C owns sync).

Output follows protocol §4: the envelope never contains runtime_revision /
rollback_available / exact_restore / atomic_cross_store_commit and always exposes
runtime_attempted / outcome / retry semantics.
"""
from __future__ import annotations
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..transactions.digests import patch_digest as _patch_digest
from ..transactions.journal import JournalDao
from ..transactions.contracts import (
    TransactionState, RuntimeOutcomeClass, ContinuitySyncState,
)
from ..transactions import runtime_observation as ro
from ..transactions.errors import (
    TxError, InvalidArgument, UnknownTx, DuplicateAttempt,
)
from .contracts import (
    MutationMode, MutationRequest, ClassifierVerdict, MutationPermit,
)
from .classifier import (
    classify_runtime_outcome, outcome_to_class, RuntimeOutcomeDecision,
)
from .adapter import SingleFileCommitAdapter, write_patch_file
from .guard import (
    is_disposable_runtime, guard_unnamed_slot, guard_no_desired_outcome,
)
from .durability import (perform_directory_fsync, probe_directory_fsync, now_iso,
                         DirFsyncStatus, durability_blocks_auto_sync)
from .local_lock import LocalAdvisoryLock, advisory_lock_path_for

REST_APPLIED_STATE = TransactionState.DURABILITY_PENDING.value

# Continuity-sync dimension marker used by Phase 3B: runtime state confirmed
# applied but continuity historical sync is NOT yet performed (Phase 3C owns it).
# Stored free-text "PENDING" (= not yet synced); deliberately NOT
# SYNC_PENDING/SYNCING/SYNCED so nobody mistakes 3B for having started sync.
NOT_YET_SYNCED = "PENDING"


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _connect(db_path: Path):
    db_path = Path(db_path)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    from ..migrations import migrate
    migrate(conn)
    return conn


@dataclass
class ExecuteEnvelope:
    """Protocol §4 output envelope for one executed single-file commit."""
    continuity_tx_id: str
    runtime_attempted: bool = False
    runtime_outcome: str = RuntimeOutcomeClass.RUNTIME_NOT_ATTEMPTED.value
    runtime_pre_observation: dict[str, Any] = field(default_factory=dict)
    runtime_post_observation: dict[str, Any] = field(default_factory=dict)
    durability_status: str | None = None
    continuity_sync_state: str | None = None
    manual_review_required: bool = False
    retry_allowed: bool = False
    retry_requires_new_tx: bool = True
    writer_invoked: bool = False
    writer_return_code: int | None = None
    writer_exception_class: str | None = None
    evidence_patch_digest: str | None = None
    status: str = "EXECUTED"
    detail_bounded: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "continuity_tx_id": self.continuity_tx_id,
            "runtime_attempted": self.runtime_attempted,
            "runtime_outcome": self.runtime_outcome,
            "runtime_pre_observation": self.runtime_pre_observation,
            "runtime_post_observation": self.runtime_post_observation,
            "durability_status": self.durability_status,
            "continuity_sync_state": self.continuity_sync_state,
            "manual_review_required": self.manual_review_required,
            "retry_allowed": self.retry_allowed,
            "retry_requires_new_tx": self.retry_requires_new_tx,
            "writer_invoked": self.writer_invoked,
            "writer_return_code": self.writer_return_code,
            "writer_exception_class": self.writer_exception_class,
            "patch_digest": self.evidence_patch_digest,
            "status": self.status,
            "detail_bounded": self.detail_bounded[:400],
        }

    def to_dict(self) -> dict[str, Any]:
        return self.as_dict()


def _outcome_to_state(decision: RuntimeOutcomeDecision) -> str:
    return {
        RuntimeOutcomeDecision.CONFIRMED_APPLIED: TransactionState.CONFIRMED_APPLIED.value,
        RuntimeOutcomeDecision.CONFIRMED_NOT_APPLIED: TransactionState.CONFIRMED_NOT_APPLIED.value,
        RuntimeOutcomeDecision.OUTCOME_UNKNOWN: TransactionState.OUTCOME_UNKNOWN.value,
        RuntimeOutcomeDecision.CONCURRENT_DIVERGENCE: TransactionState.CONCURRENT_DIVERGENCE.value,
        RuntimeOutcomeDecision.PRECONDITION_FAILED: TransactionState.PRECONDITION_FAILED.value,
    }[decision]


def _durability_status_str(fsync) -> str:
    if fsync.status == DirFsyncStatus.OK:
        return "DIR_FSYNC_OK"
    if fsync.status == DirFsyncStatus.UNSUPPORTED:
        return "DIR_FSYNC_UNSUPPORTED"
    if fsync.status == DirFsyncStatus.FAILED:
        return "DIR_FSYNC_FAILED"
    return "DIR_FSYNC_NONE"


class SingleFileCommitExecutor:
    """Drives PREPARED -> runtime attempt -> outcome -> durability on a
    provably disposable runtime (Phase 3B scope)."""

    def __init__(self, *, db_path: Path | str, vendor_dir: Path | str,
                 runtime_path: Path | str,
                 commit_script: str = "commit_turn.py",
                 python: str | None = None):
        self.db_path = Path(db_path)
        self.vendor_dir = Path(vendor_dir).resolve()
        self.runtime_path = Path(runtime_path).resolve()
        self.adapter = SingleFileCommitAdapter(self.vendor_dir,
                                               commit_script=commit_script,
                                               python=python)

    # ------------------------------------------------------------------ #
    def execute_commit(self, *, tx_id: str, patch: dict[str, Any]) -> ExecuteEnvelope:
        proof = is_disposable_runtime(self.vendor_dir, self.runtime_path)
        if not proof.ok:
            raise InvalidArgument("refusing runtime mutation on non-disposable path: " + proof.reason)
        guard_unnamed_slot(self.runtime_path)
        guard_no_desired_outcome(patch)

        conn = _connect(self.db_path)
        dao = JournalDao(conn)
        env = ExecuteEnvelope(continuity_tx_id=tx_id)
        try:
            row = dao.get(tx_id)
            if row is None:
                raise UnknownTx(tx_id)
            # --- patch digest must match the PREPARED journal ------------------
            pd = _patch_digest(patch)
            env.evidence_patch_digest = pd
            if row.get("patch_digest") and pd != row["patch_digest"]:
                raise InvalidArgument(
                    "patch passed to execute does not match the PREPARED transaction patch_digest")
            env.runtime_pre_observation = {
                "raw_sha256": row.get("runtime_pre_sha256"),
                "semantic_digest": row.get("runtime_pre_semantic_digest"),
            }
            if row["state"] != TransactionState.PREPARED.value:
                env.runtime_attempted = False
                env.status = "NOT_ELIGIBLE"
                env.detail_bounded = f"tx not in PREPARED (state={row['state']})"
                env.continuity_sync_state = ContinuitySyncState.NOT_ELIGIBLE.value
                env.retry_allowed = False
                return env

            # ---- durability capability preflight ------------------------------
            # V1 has no explicit weaker-durability risk-acceptance profile.
            # If the platform cannot fsync the parent directory, refuse before
            # consuming the single runtime-attempt slot (READ_ONLY_DEGRADED).
            durability_probe = probe_directory_fsync(self.runtime_path)
            if not durability_probe.capability_ok:
                dao.record_durability_capability_failure(
                    tx_id, detail=durability_probe.reason)
                env.runtime_attempted = False
                env.writer_invoked = False
                env.runtime_outcome = RuntimeOutcomeClass.PRECONDITION_FAILED.value
                env.durability_status = "DIR_FSYNC_UNSUPPORTED"
                env.manual_review_required = True
                env.status = "PRECONDITION_FAILED"
                env.continuity_sync_state = ContinuitySyncState.NOT_ELIGIBLE.value
                env.retry_allowed = False
                env.detail_bounded = (
                    "directory fsync capability unsupported; write-enabled mode "
                    "refused before runtime attempt")
                return env

            # ---- P8: second pre-write H0 recheck ------------------------------
            precheck_failed = self._precheck_or_fail(dao, tx_id, row)
            if precheck_failed:
                env.runtime_outcome = RuntimeOutcomeClass.PRECONDITION_FAILED.value
                env.runtime_pre_observation = {
                    "raw_sha256": row.get("runtime_pre_sha256"),
                }
                env.status = "PRECONDITION_FAILED"
                env.continuity_sync_state = ContinuitySyncState.NOT_ELIGIBLE.value
                env.retry_allowed = False
                env.detail_bounded = ("pre-write H0 mismatch; writer not invoked (attempt_count stays 0)")
                # precondition already journaled terminal by record_precondition_failure
                return env

            # ---- P9: atomic reservation --------------------------------------
            self._reserve_attempt(dao, tx_id)
            env.runtime_attempted = True
            # one attempt consumed: same-tx retry impossible
            env.retry_allowed = False

            # ---- local advisory lock ------------------------------------------
            lock_file = advisory_lock_path_for(self.db_path, self.runtime_path)
            adv_lock = LocalAdvisoryLock(lock_file)
            lock_outcome = adv_lock.try_lock(timeout=0.0)
            if not lock_outcome.acquired:
                self._journal_unknown_no_lock(dao, tx_id, env)
                return env
            try:
                outcome = self._invoke_and_observe(dao, tx_id, patch, row, env)
            finally:
                adv_lock.release()
            return outcome
        finally:
            conn.close()

    def _precheck_or_fail(self, dao: JournalDao, tx_id: str, row):
        """Return True if second H0 recheck failed (and already recorded
        PRECONDITION_FAILED terminal)."""
        try:
            obs, _ = ro.read_observation(self.vendor_dir, self.runtime_path)
        except TxError as exc:
            label = getattr(exc, "class_label", exc.__class__.__name__)
            dao.record_precondition_failure(
                tx_id, detail=f"pre-write re-read failed: {label} (writer not invoked)")
            return True
        if obs.raw_sha256 != row.get("runtime_pre_sha256"):
            dao.record_precondition_failure(
                tx_id, detail="second pre-write read differs from prepared H0")
            return True
        dao.set_precondition_ok(tx_id)
        return False

    def _reserve_attempt(self, dao: JournalDao, tx_id: str):
        try:
            dao.open_runtime_attempt(tx_id)   # atomic attempt 0->1 + ATTEMPTING
            dao.mark_attempt_started_at(tx_id)
            dao.require_runtime_attempting(tx_id)
        except DuplicateAttempt:
            raise  # re-raise: a well-behaved execution never double-reserves
        return dao.get(tx_id)

    def _invoke_and_observe(self, dao, tx_id, patch, row, env) -> ExecuteEnvelope:
        """Reservation done: write patch file, invoke, observe, classify, journal."""
        permit = MutationPermit(
            continuity_tx_id=tx_id, runtime_path=str(self.runtime_path),
            vendor_dir=str(self.vendor_dir), attempt_number=1, issued_at=_now())
        patch_file = write_patch_file(self.vendor_dir, tx_id, patch)
        # Invocation may itself raise (fault seam / lost child result).  Protocol
        # §13 requires we STILL attempt an immediate post observation and classify
        # from state evidence; an exception alone is never a NOT_APPLIED proof.
        from .contracts import WriterInvocationEvidence
        writer_evidence = WriterInvocationEvidence(continuity_tx_id=tx_id)
        try:
            writer_evidence = self.adapter.invoke(permit, patch_file, self.runtime_path)
        except Exception as exc:  # deterministic seams + unexpected child errors
            writer_evidence.writer_invoked = True   # the writer contract was entered
            writer_evidence.writer_exception_class = exc.__class__.__name__
            writer_evidence.writer_exception_detail = str(exc)[:400]
        env.writer_invoked = writer_evidence.writer_invoked
        env.writer_return_code = writer_evidence.writer_return_code
        env.writer_exception_class = writer_evidence.writer_exception_class

        # immediate post observation (best effort; never skipped)
        obs_ev, read_detail = self._post_observation(dao, tx_id)
        expected_capable = bool(row.get("runtime_expected_sha256"))
        # The pinned vendor CLI writes only after a successful commit()/validate
        # and returns nonzero for any pre-write failure.  A nonzero rc with an
        # unchanged post is therefore strong NOT-applied evidence.
        if (writer_evidence.writer_invoked and writer_evidence.writer_return_code is not None
                and writer_evidence.writer_return_code != 0):
            obs_ev.pre_replace_strong_proof = True
        env.runtime_post_observation = {
            "raw_sha256": obs_ev.raw_sha256,
            "semantic_digest": obs_ev.semantic_digest,
            "parse_ok": obs_ev.parse_ok,
            "validation_ok": obs_ev.validation_ok,
            "present": obs_ev.runtime_present,
            "read_detail": read_detail,
        }

        verdict = classify_runtime_outcome(
            obs_ev, writer_called=writer_evidence.writer_invoked,
            expected_sha_capable=expected_capable, precheck_passed=True)
        env.manual_review_required = verdict.manual_review_required
        env.runtime_outcome = outcome_to_class(verdict.decision)
        env.detail_bounded = verdict.summary

        self._journal_classified_outcome(dao, tx_id, verdict, obs_ev,
                                         finished_at=_now())
        return self._apply_durability_and_refresh(dao, tx_id, env, verdict)

    def _post_observation(self, dao, tx_id):
        from .contracts import RuntimeObservationEvidence
        row = dao.get(tx_id)
        ev = RuntimeObservationEvidence(
            continuity_tx_id=tx_id,
            pre_raw_sha256=row.get("runtime_pre_sha256"),
            pre_semantic_digest=row.get("runtime_pre_semantic_digest"),
            expected_raw_sha256=row.get("runtime_expected_sha256"),
            expected_semantic_digest=row.get("runtime_expected_semantic_digest")
            or row.get("expected_candidate_digest"),
        )
        detail = ""
        from ..transactions.errors import (
            RuntimeNotFound, RuntimeUnreadable, RuntimeParseError,
            RuntimeValidationError, UnsupportedRuntimeIdentity,
        )
        _POST_READ_ERRORS = (RuntimeNotFound, RuntimeUnreadable, RuntimeParseError,
                             RuntimeValidationError, UnsupportedRuntimeIdentity)
        try:
            obs, parsed = ro.read_observation(self.vendor_dir, self.runtime_path)
            ev.identity_ok = Path(obs.identity.path).resolve() == self.runtime_path.resolve()
            ev.runtime_present = True
            ev.parse_ok = (obs.parse_status.value == "OK")
            ev.validation_ok = (obs.validation_status.value == "OK")
            ev.raw_sha256 = obs.raw_sha256
            ev.semantic_digest = obs.semantic_digest
            _ = parsed
        except _POST_READ_ERRORS as exc:
            ev.runtime_present = False
            ev.parse_ok = False
            ev.validation_ok = False
            ev.read_error_class = getattr(exc, "class_label", exc.__class__.__name__)
            ev.read_error_detail_bounded = (str(exc))[:300]
            detail = ev.read_error_class
        return ev, detail

    def _journal_classified_outcome(self, dao, tx_id, verdict: ClassifierVerdict,
                                    obs_ev, finished_at):
        decision = verdict.decision
        to_state = _outcome_to_state(decision)
        if decision == RuntimeOutcomeDecision.CONFIRMED_APPLIED:
            sync_dim = NOT_YET_SYNCED  # 3B does NOT sync
        else:
            sync_dim = ContinuitySyncState.NOT_ELIGIBLE.value
        dao.record_runtime_outcome(
            tx_id, to_state=to_state,
            outcome_class=outcome_to_class(decision),
            post_raw_sha256=obs_ev.raw_sha256,
            post_semantic_digest=getattr(obs_ev, "semantic_digest", None),
            continuity_sync_state=sync_dim,
            manual_review_required=verdict.manual_review_required,
            last_error_class=("POST_" + (obs_ev.read_error_class or "OK") if obs_ev.read_error_class else None),
            last_error_detail=obs_ev.read_error_detail_bounded,
            finished_at=finished_at,
            evidence_summary={"decision": decision.value, "summary": verdict.summary})

    def _apply_durability_and_refresh(self, dao, tx_id, env: ExecuteEnvelope,
                                      verdict) -> ExecuteEnvelope:
        """Post-outcome durability metadata; only applied rows get a fsync gate."""
        row = dao.get(tx_id)
        if env.runtime_outcome == RuntimeOutcomeClass.CONFIRMED_APPLIED.value:
            if row["state"] == TransactionState.CONFIRMED_APPLIED.value:
                fsync = perform_directory_fsync(Path(self.runtime_path))
                ds = _durability_status_str(fsync)
                env.durability_status = ds
                # fsync failure never becomes a write-failure or rollback; we
                # simply record durability metadata and leave manual flag for
                # review if needed.
                env.manual_review_required = env.manual_review_required or (
                    durability_blocks_auto_sync(fsync.status))
                # protocol: applied + durability result -> rest at DURABILITY_PENDING.
                dao.move_applied_to_durability_pending(
                    tx_id,
                    durability_status=ds,
                    durability_json=fsync.as_dict(),
                    continuity_sync_state=NOT_YET_SYNCED,
                    manual_review_required=durability_blocks_auto_sync(fsync.status))
                env.continuity_sync_state = NOT_YET_SYNCED
            else:
                # already not in CONFIRMED_APPLIED (edge) — reflect row
                r = dao.get(tx_id)
                env.durability_status = r.get("durability_status")
                env.continuity_sync_state = r.get("continuity_sync_state")
        else:
            r = dao.get(tx_id)
            env.durability_status = r.get("durability_status")
            env.continuity_sync_state = r.get("continuity_sync_state")
            env.retry_allowed = env.runtime_outcome in (
                RuntimeOutcomeClass.OUTCOME_UNKNOWN.value,
                RuntimeOutcomeClass.CONCURRENT_DIVERGENCE.value)
        env.status = env.runtime_outcome
        return env

    def _journal_unknown_no_lock(self, dao, tx_id, env: ExecuteEnvelope):
        dao.record_outcome_unknown(tx_id, reason="advisory lock held by a compliant writer")
        env.runtime_outcome = RuntimeOutcomeClass.OUTCOME_UNKNOWN.value
        env.manual_review_required = True
        env.status = "OUTCOME_UNKNOWN"
        env.writer_invoked = False
        env.retry_allowed = False


# Convenience single-call entry point.
def commit_single_file(*, db_path, vendor_dir, runtime_path, tx_id,
                       patch, commit_script: str = "commit_turn.py",
                       python: str | None = None) -> ExecuteEnvelope:
    ex = SingleFileCommitExecutor(db_path=db_path, vendor_dir=vendor_dir,
                                  runtime_path=runtime_path,
                                  commit_script=commit_script, python=python)
    return ex.execute_commit(tx_id=tx_id, patch=patch)
