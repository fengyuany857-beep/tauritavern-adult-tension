"""Phase 3B — single-file runtime commit adapter.

Calls the pinned vendor single-file commit_turn writer through a *controlled
subprocess* so Phase 3B exercises the real production write path (load ->
commit() in-memory -> ``manage_saves.write_atomic`` -> os.replace) on a
canonical allowlisted ``current_state.yaml``, WITHOUT modifying vendor source.

The adapter never takes a natural-language outcome.  It receives exact input
bytes via a patch JSON file placed ONLY under an explicitly disposable fixture
root, invokes the pinned CLI with ``--state <canonical>`` (no ``--out`` and no
``--patch`` shell interpolation), records a bounded WriterInvocationEvidence,
and captures stdout/stderr heads for honest diagnosis (return code alone is
weak evidence, per protocol).

A JSON patch file transported by subprocess default (read from stdin or
--patch-file) keeps CLI parity; we use a protected temporary patch file inside
the disposable fixture so we neither interpolate the shell nor hand the patch
over argv.
"""
from __future__ import annotations
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .contracts import WriterInvocationEvidence, MutationPermit

MAX_CAPTURE = 4000

VENDOR_COMMIT_SCRIPT = "commit_turn.py"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _bounded(text: str, limit: int = MAX_CAPTURE) -> str:
    if not text:
        return ""
    return text[:limit]


def _resolve_python() -> str:
    return sys.executable


def write_patch_file(fixture_root: Path, tx_id: str, patch: dict[str, Any]) -> Path:
    """Write the concrete patch to a protected `.tmp` file inside a disposable
    fixture root.  Caller must guarantee `fixture_root` is provably disposable.
    """
    fixture_root = Path(fixture_root)
    fixture_root.mkdir(parents=True, exist_ok=True)
    patch_file = fixture_root / f".tx-{tx_id}-patch.json"
    patch_file.write_text(
        json.dumps(patch, ensure_ascii=False, sort_keys=False), encoding="utf-8")
    return patch_file


class SingleFileCommitAdapter:
    """Bootstrapped around a pinned vendor commit_turn.py CLI file.

    `vendor_dir` is expected to be a disposable vendor clone for tests; in a
    future operational deployment it would be the deployment-controlled writer
    root.  This class performs NO writes itself -- it only launches the vendor
    subprocess against a runtime path handed to it under a MutationPermit.
    """

    def __init__(self, vendor_dir: Path | str, commit_script: str = VENDOR_COMMIT_SCRIPT,
                 python: str | None = None):
        self.vendor_dir = Path(vendor_dir).resolve()
        self.commit_script = commit_script
        self.python = python or _resolve_python()

    def script_path(self) -> Path:
        return self.vendor_dir / "scripts" / self.commit_script

    def adapter_fingerprint(self) -> str:
        """Return the stable SHA-256 of the pinned commit_turn.py (as Phase 3A
        uses for adapter_fingerprint; matches preconditions._fingerprint)."""
        p = self.script_path()
        try:
            data = p.read_bytes()
        except OSError:
            return "unavailable"
        import hashlib
        return hashlib.sha256(data).hexdigest()

    def invoke(self, permit: MutationPermit, patch_file: Path,
               runtime_path: Path) -> WriterInvocationEvidence:
        """Run the vendor single-file commit on a canonical runtime path.

        Arguments:
            permit      : the reservation ticket (must already show the tx reserved).
            patch_file  : protected JSON patch file written under a disposable root.
            runtime_path: the canonical allowlisted current_state.yaml path.

        Returns WriterInvocationEvidence capturing timestamps and bounded streams.
        The write performed by the vendor process is a real os.replace on the
        single canonical file.
        """
        ev = WriterInvocationEvidence(continuity_tx_id=permit.continuity_tx_id)
        script = self.script_path()
        if not script.exists():
            ev.writer_invoked = False
            ev.writer_exception_class = "RuntimeNotFound"
            ev.writer_exception_detail = _bounded(f"missing vendor writer: {script}")
            return ev
        # No named-slot / --out path allowed by the protocol (V1 BLOCK).
        runtime_path = Path(runtime_path)
        # Security: runtime_path must be the canonical V1 file or we fail closed.
        canon = runtime_path
        has_canonical_suffix = canon.resolve().as_posix().endswith(
            "/saves/current_state.yaml")
        if not has_canonical_suffix:
            ev.writer_invoked = False
            ev.writer_exception_class = "UnsupportedRuntimeIdentity"
            ev.writer_exception_detail = _bounded("adapter refuses a non-canonical runtime path")
            return ev
        cmd = [self.python, str(script), "--state", str(runtime_path),
               "--patch-file", str(patch_file)]
        ev.writer_invoked = True
        ev.started_at = _now_iso()
        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, encoding="utf-8",
                errors="replace", timeout=120)
            ev.writer_return_code = proc.returncode
            ev.raw_stdout_head = _bounded(proc.stdout)
            ev.raw_stderr_head = _bounded(proc.stderr)
        except subprocess.TimeoutExpired as exc:
            ev.writer_exception_class = "subprocess.TimeoutExpired"
            ev.writer_exception_detail = _bounded(f"adapter timeout: {exc}")
        except Exception as exc:
            ev.writer_exception_class = exc.__class__.__name__
            ev.writer_exception_detail = _bounded(f"adapter exception: {exc}")
        ev.finished_at = _now_iso()
        return ev
