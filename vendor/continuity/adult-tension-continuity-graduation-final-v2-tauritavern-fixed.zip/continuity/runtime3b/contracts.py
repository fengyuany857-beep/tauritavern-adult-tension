"""Phase 3B — single-file runtime commit adapter contracts.

Defines the bounded *integration-surface* types that sit between a durable
Phase 3A PREPARED transaction and the pinned vendor single-file writer.  Phase
3B is the first phase permitted to perform a real runtime mutation — but ONLY
on a provably disposable runtime fixture and always through an explicit,
prepared-transaction guard.  No production caller may invoke the underlying
vendor writer directly or with a natural-language "desired outcome".

Honesty rules carried forward from the Sol protocol (§4 / §5 / §8):
- `observed_sha256` is a fingerprint of exact bytes at a path/time, never a
  runtime revision / CAS / writer-identity proof.
- a writer return code is weak evidence; an exception alone is not a
  "NOT_APPLIED" proof; a changed hash alone does not identify the writer.
- output envelopes never contain runtime_revision / rollback_available /
  atomic_cross_store_commit.
"""
from __future__ import annotations
import enum
from dataclasses import dataclass, field
from typing import Any


class MutationMode(str, enum.Enum):
    """Whether a caller may physically invoke the vendor writer.

    REFUSE_PRODUCTION is the default production posture: the guard refuses any
    runtime mutation not explicitly inside a disposable fixture.  Only when a
    caller supplies a provably disposable runtime identity (test/isolated
    copy) is mutation allowed.  This is a *test safety* boundary, not a future
    production identity mechanism.
    """
    REFUSE_PRODUCTION = "REFUSE_PRODUCTION"
    ALLOW_DISPOSABLE = "ALLOW_DISPOSABLE"


class PrewriteDecision(str, enum.Enum):
    """Outcome of the second raw-H0 check immediately before the writer."""
    OK = "OK"                                   # fresh bytes == prepared H0
    CHANGED = "CHANGED"                         # fresh bytes != prepared H0
    NOT_CHECKED = "NOT_CHECKED"
    UNREADABLE = "UNREADABLE"


class SerializerEvidence(str, enum.Enum):
    """Deterministic-serializer capability probe result (expected byte H util)."""
    DETERMINISTIC = "DETERMINISTIC"             # expected byte hash is trustworthy
    NOT_DETERMINISTIC = "NOT_DETERMINISTIC"     # never claim an expected byte hash
    NOT_PROBED = "NOT_PROBED"


# Bounded error detail etc. reuse the Phase 3A limits where applicable.
MAX_OUTCOME_EVIDENCE_FIELD = 4000
MAX_ERROR_DETAIL = 400


# --------------------------------------------------------------------------- #
# Mutation request / permit contract.  The production API accepts ONLY an
# already-prepared concrete tx (one that carries an expected candidate digest
# and matchable raw H0).  It does not accept a natural-language outcome.
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class MutationRequest:
    """Everything the commit adapter needs, down-selected from a PREPARED tx.

    The adapter is deliberately given already-checked digests, NOT raw runtime
    bytes or the ability to reason about "what the player wanted".  The plan /
    candidate was authored by Phase 3A prepare (upstream-authority-wrapped).
    """
    continuity_tx_id: str
    runtime_identity: str
    runtime_path: str                      # canonical allowlisted current-state path
    runtime_pre_sha256: str                # H0 recorded at prepare
    runtime_pre_semantic_digest: str
    expected_semantic_digest: str          # SE
    expected_sha256: str | None            # HE when serializer deterministic
    patch_digest: str
    branch_id: str
    operation: str
    # Durations/privacy-marker are NOT reconstructed here; adapter only needs
    # the writer subprocess pointer + a way to write candidate bytes.
    adapter_script: str = "commit_turn.py"   # pinned vendor writer script name
    vendor_dir: str = ""                     # private: pinned vendor root (disposable)
    pre_write_allowed: bool = False          # set true only by execute() after P8/P9

    # The permitted transition set is enforced by JournalDao; this is advisory only.
    mode: MutationMode = MutationMode.REFUSE_PRODUCTION


@dataclass(frozen=True)
class MutationPermit:
    """The narrow credential handed to the writer only when all gates pass.

    Carries no patch payload and no desired-outcome context: it is just the
    reservation ticket proving attempt_count was 0 and this tx may proceed.
    """
    continuity_tx_id: str
    runtime_path: str
    vendor_dir: str
    attempt_number: int = 1
    issued_at: str = ""
    permit_kind: str = "single_file_commit_turn"


# --------------------------------------------------------------------------- #
# Writer invocation evidence (bounded, no hidden reasoning).  Following §30 a
# journal-able record but defined here as a pure data object.
# --------------------------------------------------------------------------- #
@dataclass
class WriterInvocationEvidence:
    continuity_tx_id: str
    writer_invoked: bool = False
    writer_return_code: int | None = None      # weak evidence only
    writer_exception_class: str | None = None
    writer_exception_detail: str | None = None # bounded
    started_at: str | None = None
    finished_at: str | None = None
    raw_stdout_head: str | None = None
    raw_stderr_head: str | None = None

    def to_evidence_dict(self) -> dict[str, Any]:
        return {
            "continuity_tx_id": self.continuity_tx_id,
            "writer_invoked": self.writer_invoked,
            "writer_return_code": self.writer_return_code,
            "writer_exception_class": self.writer_exception_class,
            "writer_exception_detail": self.writer_exception_detail,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "raw_stdout_head": (self.raw_stdout_head or "")[:200],
            "raw_stderr_head": (self.raw_stderr_head or "")[:200],
        }

    def to_dict(self) -> dict[str, Any]:
        return self.to_evidence_dict()


# --------------------------------------------------------------------------- #
# Observation evidence used by the pure classifier.
# --------------------------------------------------------------------------- #
@dataclass
class RuntimeObservationEvidence:
    """Strong/medium/weak observational evidence assembled right after the
    writer returns or raises.  The classifier reads ONLY this (pure)."""
    continuity_tx_id: str
    identity_ok: bool = False                # canonical path still a regular file
    runtime_present: bool = False
    parse_ok: bool = False
    validation_ok: bool = False
    raw_sha256: str | None = None            # H1 immediate post (nil => missing)
    semantic_digest: str | None = None       # S1
    pre_raw_sha256: str | None = None        # H0 from prepared
    pre_semantic_digest: str | None = None
    expected_raw_sha256: str | None = None   # HE if capability active
    expected_semantic_digest: str | None = None
    read_error_class: str | None = None
    read_error_detail_bounded: str | None = None
    pre_replace_strong_proof: bool = False   # pin fails closed: nonzero CLI rc
                                              # from a validated pinned writer that
                                              # writes only after its own commit()

    def to_dict(self) -> dict[str, Any]:
        return {
            "identity_ok": self.identity_ok,
            "runtime_present": self.runtime_present,
            "parse_ok": self.parse_ok,
            "validation_ok": self.validation_ok,
            "raw_sha256": self.raw_sha256,
            "semantic_digest": self.semantic_digest,
            "pre_raw_sha256": self.pre_raw_sha256,
            "pre_semantic_digest": self.pre_semantic_digest,
            "expected_raw_sha256": self.expected_raw_sha256,
            "expected_semantic_digest": self.expected_semantic_digest,
            "read_error_class": self.read_error_class,
            "pre_replace_strong_proof": self.pre_replace_strong_proof,
    }


# --------------------------------------------------------------------------- #
# Classifier input / output type.
# --------------------------------------------------------------------------- #
class RuntimeOutcomeDecision(str, enum.Enum):
    """Phase 3B still models the same runtime dimension (never a generic
    SUCCESS).  These map onto the Phase3A RuntimeOutcomeClass values."""
    PRECONDITION_FAILED = "PRECONDITION_FAILED"
    CONFIRMED_APPLIED = "CONFIRMED_APPLIED"
    CONFIRMED_NOT_APPLIED = "CONFIRMED_NOT_APPLIED"
    OUTCOME_UNKNOWN = "OUTCOME_UNKNOWN"
    CONCURRENT_DIVERGENCE = "CONCURRENT_DIVERGENCE"


@dataclass(frozen=True)
class ClassifierVerdict:
    decision: RuntimeOutcomeDecision
    summary: str                 # bounded textual evidence summary (no CoT)
    evidence_detail: dict[str, Any] = field(default_factory=dict)
    manual_review_required: bool = False
    writer_called: bool = False  # never the deciding signal; informational

    def as_dict(self) -> dict[str, Any]:
        return {
            "decision": self.decision.value,
            "summary": self.summary[:MAX_OUTCOME_EVIDENCE_FIELD],
            "evidence_detail": {
                k: (v[:4000] if isinstance(v, str) else v)
                for k, v in self.evidence_detail.items()
            },
            "manual_review_required": self.manual_review_required,
            "writer_called": self.writer_called,
        }
