"""Phase 3B — sidecar local advisory lock (scoped to compliant orchestrators).

Protocol §18 / §14 / task §18 + §32(33/34):
The lock ONLY coordinates writers that voluntarily comply with this integration
layer (e.g. two of our sidecar orchestrators racing over the same tx or path).
It does NOT and cannot stop an external vendor process / manual edit / a
different toolchain.  Real protection against those still depends on the
pre-write H0 observation + immediate post observation + outcome classifier.

We therefore name the lock "advisory"/"local" and never call it a global runtime
lock.  This module provides:
  - LocalAdvisoryLock: a non-blocking acquire or explicit fail, keyed by path;
  - it holds an OS file lock on a sidecar lock file placed next to (or inside)
    a peer sidecar/DB dir; placement is documented as one compliant-layer lock.

The guard module decides when to honour an external-writer-bypass simulation:
if a caller indicates the advisory lock was bypassable (as it always is by an
external writer), correctness is NOT re-established by the lock; it is handled
by the classifier (DIVERGENCE / UNKNOWN).
"""
from __future__ import annotations
import os
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass
class AdvisoryLockOutcome:
    acquired: bool
    lock_path: str | None = None
    reason: str | None = None
    holder_self: bool = False     # informational: it is a local advisory lock

    def as_dict(self) -> dict[str, Any]:
        return {
            "acquired": self.acquired,
            "lock_path": self.lock_path,
            "reason": self.reason,
            "scope": "local_advisory_only",
        }


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class LocalAdvisoryLock:
    """Cross-process advisory lock over one lock file (POSIX flock-based,
    self-consistent only).  Non-blocking: register_attempt returns False the
    instant another compliant holder holds it, instead of waiting forever.
    """

    def __init__(self, lock_file: Path):
        self.lock_file = Path(lock_file)
        self._handle = None

    def _acquire(self, timeout: float = 0.0) -> bool:
        try:
            self.lock_file.parent.mkdir(parents=True, exist_ok=True)
            self._handle = self.lock_file.open("a+")  # append/create; never truncate
            if os.name == "nt":  # pragma: no cover - POSIX used here
                return False
            import fcntl

            block = False
            if timeout and timeout > 0:
                block = True
            try:
                if block:
                    # bounded blocking window; left for callers that truly need it
                    import time
                    end = time.monotonic() + timeout
                    while True:
                        try:
                            fcntl.flock(self._handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                            return True
                        except OSError:
                            if time.monotonic() >= end:
                                return False
                            time.sleep(0.02)
                else:
                    fcntl.flock(self._handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    return True
            except OSError:
                return False
        except OSError:
            if self._handle is not None:
                try:
                    self._handle.close()
                except OSError:
                    pass
                self._handle = None
            return False

    def try_lock(self, timeout: float = 0.0) -> AdvisoryLockOutcome:
        ok = self._acquire(timeout=timeout)
        if ok:
            # If we successfully flocked, keep file handle open until release()
            return AdvisoryLockOutcome(acquired=True, lock_path=str(self.lock_file),
                                       reason="advisory (compliant players only)",
                                       holder_self=True)
        return AdvisoryLockOutcome(acquired=False, lock_path=str(self.lock_file),
                                   reason="another compliant holder holds the advisory lock",
                                   holder_self=True)

    def release(self) -> None:
        if self._handle is not None:
            try:
                if os.name != "nt":  # pragma: no cover (POSIX only path)
                    import fcntl
                    fcntl.flock(self._handle.fileno(), fcntl.LOCK_UN)
            except OSError:
                pass
            try:
                self._handle.close()
            except OSError:
                pass
            self._handle = None


def advisory_lock_path_for(db_path: Path, runtime_path: Path) -> Path:
    """A predictable sidecar lock path keyed by the continuity db + runtime.

    The lock coordinates only our sidecar layer (per Sol protocol).  Its exact
    location is not authority: if an external writer ignores it, the classifier
    still observes post-state and will flag DIVERGENCE / UNKNOWN.
    """
    db_dir = Path(db_path).parent
    digest_tail = str(abs(hash(str(runtime_path))))[:12]
    return db_dir / f".continuity-adv-{digest_tail}.lock"
