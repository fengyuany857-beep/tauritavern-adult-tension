"""Phase 3B — mutation guard + disposable fixture safety + production refusal.

Guard for the first real runtime mutation of the project (§7 / §17 / §33 / §34).
The actual vendor writer is never invoked arbitrarily: it must be reached only
through a :class:`MutationRequest` built from a durable Phase 3A PREPARED row,
passing the second pre-write H0 check, and holding an attempt reservation.

Disposable-fixture safety (§8 / §33): before ANY mutation test we must prove the
runtime path is inside a provably disposable root.  The guard refuses paths that
point into the real vendor repo, the shared memory artifacts, the continuity
source tree, or a user home save archive.
"""
from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..transactions.errors import (
    UnsupportedNamedSlot, PlayerSovereigntyViolation, InvalidArgument,
)
from .contracts import MutationMode, MutationRequest

# Roots that guarded mutation must NEVER write into, even by accident.
PRODUCTION_RUNTIME_SENTINELS = (
    Path("/var/minis/workspace"),       # project/source/artifacts trees
    Path("/var/minis/memory"),          # shared memory artifacts / dev-bundles
    Path("/var/minis/shared"),
    Path("/var/minis/mounts"),
)
# Marker: any path under a temp dir is considered disposable-only if the caller
# proves it via is_disposable_runtime() (temp root + explicit runtime file).
TEMP_DISPOSABLE_PREFIXES = ("/tmp/",)
HOME_SAVE = Path.home() / "saves"


@dataclass(frozen=True)
class DisposableProof:
    ok: bool
    reason: str
    runtime_path: str | None = None
    vendor_dir: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {"ok": self.ok, "reason": self.reason,
                "runtime_path": self.runtime_path, "vendor_dir": self.vendor_dir}


def is_disposable_runtime(vendor_dir: Path, runtime_path: Path) -> DisposableProof:
    """Prove a runtime path is inside a disposable fixture root, i.e. it is NOT
    one of the real production/source/shared/home-save locations.

    Criteria: the canonical vendor root must live under an OS temporary root and
    must itself contain the canonical current_state.yaml, AND neither the vendor
    root nor the runtime path may be any production sentinel prefix.
    """
    vendor_dir = Path(vendor_dir).resolve()
    runtime_path = Path(runtime_path).resolve()
    for forbidden in PRODUCTION_RUNTIME_SENTINELS:
        if is_within(vendor_dir, forbidden) or is_within(runtime_path, forbidden):
            return DisposableProof(
                ok=False,
                reason=f"path resolves under production sentinel {forbidden}",
                runtime_path=str(runtime_path), vendor_dir=str(vendor_dir))
    # temp-root check on the vendor root (isolated disposable copy).
    tmp_ok = any(str(vendor_dir).startswith(p) for p in TEMP_DISPOSABLE_PREFIXES)
    # is it also under the device workspace TEMP var we may set? Keep explicit.
    if not tmp_ok:
        env_tmp = os.environ.get("TMPDIR") or ""
        if env_tmp and str(vendor_dir).startswith(env_tmp):
            tmp_ok = True
    if not tmp_ok:
        return DisposableProof(
            ok=False, reason="vendor root is not under a temp/disposable root",
            runtime_path=str(runtime_path), vendor_dir=str(vendor_dir))
    # canonical file present inside vendor/saves
    expected = vendor_dir / "saves" / "current_state.yaml"
    if runtime_path != expected:
        return DisposableProof(
            ok=False, reason="runtime path is not the canonical disposable current_state.yaml",
            runtime_path=str(runtime_path), vendor_dir=str(vendor_dir))
    if not expected.exists():
        return DisposableProof(
            ok=False, reason="disposable canonical file missing",
            runtime_path=str(runtime_path), vendor_dir=str(vendor_dir))
    # never write under the vendor repo tracked source itself (only the runtime
    # `.yaml` file under /saves is the single-file target).
    return DisposableProof(
        ok=True, reason="disposable runtime fixture under temp root",
        runtime_path=str(runtime_path), vendor_dir=str(vendor_dir))


def is_within(path: Path, ancestor: Path) -> bool:
    try:
        return Path(path).resolve() == ancestor.resolve() or ancestor.resolve() in Path(path).resolve().parents
    except OSError:
        return False


def build_mutation_request(
    *,
    tx_id: str,
    row: dict[str, Any],              # transaction_journal row from JournalDao.get
    vendor_dir: Path | str,
    runtime_path: Path | str,
    patch_digest: str | None = None,
    mode: MutationMode = MutationMode.REFUSE_PRODUCTION,
    disposable_proof: DisposableProof | None = None,
) -> MutationRequest:
    """Build the narrow mutation contract from a durable PREPARED transaction row.

    Enforces the *integration owns the decision* contract: it copies hashes from
    the journal, never re-plans and never reconstructs a "desired outcome".  Any
    prepared row that is not in state PREPARED or whose expected candidate is
    inconsistent with its own patch digest is rejected.
    """
    if row.get("state") != "PREPARED":
        raise InvalidArgument(
            f"mutation request requires a PREPARED transaction row, got {row.get('state')!r}")
    runtime_path = Path(runtime_path).resolve()
    vendor_dir = Path(vendor_dir).resolve()

    if mode != MutationMode.ALLOW_DISPOSABLE:
        if disposable_proof is None or not disposable_proof.ok:
            # Default safety is refuse production unless explicitly disposable.
            if mode == MutationMode.REFUSE_PRODUCTION:
                raise InvalidArgument(
                    "runtime mutation refused: must route through execute() with an "
                    "explicit disposable-managed runtime (production-mode not wired in Phase 3B)")
            if disposable_proof is None:
                raise InvalidArgument("mutation requires a disposable-proof")
        # dispose proof already checked
    if disposable_proof is None or not disposable_proof.ok:
        proof = is_disposable_runtime(vendor_dir, runtime_path)
        if not proof.ok:
            raise InvalidArgument("runtime mutation refused: " + proof.reason)

    # A concrete patch evidence digest should @ least match a stored patch_digest
    # when the caller supplies one; otherwise we can't trust the guide.
    if patch_digest is not None and row.get("patch_digest") and patch_digest != row.get("patch_digest"):
        raise InvalidArgument("patch_digest mismatch with PREPARED journal evidence")
    return MutationRequest(
        continuity_tx_id=tx_id,
        runtime_identity=str(row.get("runtime_identity") or "v1-current"),
        runtime_path=str(runtime_path),
        runtime_pre_sha256=str(row.get("runtime_pre_sha256") or ""),
        runtime_pre_semantic_digest=str(row.get("runtime_pre_semantic_digest") or ""),
        expected_semantic_digest=str(row.get("runtime_expected_semantic_digest")
                                     or row.get("expected_candidate_digest") or ""),
        expected_sha256=row.get("runtime_expected_sha256"),
        patch_digest=row.get("patch_digest") or "",
        branch_id=str(row.get("branch_id") or "default"),
        operation=str(row.get("operation") or "commit_turn"),
        adapter_script="commit_turn.py",
        vendor_dir=str(vendor_dir),
        mode=mode,
    )


def guard_unnamed_slot(runtime_path: Any) -> None:
    """A runtime target must never be a named-slot state/manifest pair.  V1
    returns BLOCK (protocol §16)."""
    p = Path(str(runtime_path))
    if p.name in ("state.yaml", "manifest.yaml") or "/slots/" in p.as_posix() or "/slot/" in p.as_posix():
        raise UnsupportedNamedSlot("named-slot mutation is BLOCKED in V1")
    if "manifest" in p.name.lower() or p.as_posix().endswith((".manifest.yaml",)):
        raise UnsupportedNamedSlot("named-slot mutation is BLOCKED in V1")


def guard_no_desired_outcome(patch: dict[str, Any]) -> None:
    """Natural language must never become an NPC-belief patch (§25)."""
    banned = {
        "desired_outcome", "then_believes", "make_npc_believe", "force_npc_result",
        "infer_belief", "result_prose", "consequence_from_player_wish",
    }
    got = sorted(k for k in patch if k in banned)
    if got:
        raise PlayerSovereigntyViolation(
            "player-desired-outcome keys cannot be a concrete upstream patch: " + ",".join(got))
