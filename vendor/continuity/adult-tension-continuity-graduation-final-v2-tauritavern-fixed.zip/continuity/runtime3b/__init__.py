"""Phase 3B — single-file runtime commit adapter + outcome classifier + durability.

This package implements the safe runtime-mutation half of the Sol protocol
(V1 write-enabled scope): a single allowlisted current_state.yaml, one runtime
attempt maximum per continuity_tx_id, a second raw-H0 precondition, a pure
outcome classifier, local advisory locking, and honest directory-fsync
durability metadata.  It does NOT perform any continuity historical sync.

Public surface:

- :class:`SingleFileCommitExecutor` / :func:`commit_single_file` — orchestration
- :func:`classify_runtime_outcome` — pure deterministic classifier
- :mod:`.contracts` — MutationRequest / MutationPermit / evidence types
- :mod:`.guard`      — disposable-runtime + named-slot + no-NL guards
- :mod:`.durability` — parent-directory fsync wrapper
- :mod:`.local_lock` — advisory (compliant-writers-only) lock
"""
from .contracts import (
    MutationMode, MutationRequest, MutationPermit,
    WriterInvocationEvidence, RuntimeObservationEvidence,
    RuntimeOutcomeDecision, ClassifierVerdict,
    PrewriteDecision, SerializerEvidence,
)
from .classifier import (
    classify_runtime_outcome,
    confirmed_not_applied_with_pre_replace_proof,
    outcome_to_class,
)
from .guard import (
    is_disposable_runtime, build_mutation_request, guard_unnamed_slot,
    guard_no_desired_outcome, DisposableProof,
)
from .execute import SingleFileCommitExecutor, commit_single_file, ExecuteEnvelope
from .durability import (
    DirFsyncStatus, DurabilityProbe, DirectoryFsyncResult,
    probe_directory_fsync, perform_directory_fsync,
)
from .local_lock import LocalAdvisoryLock, advisory_lock_path_for, AdvisoryLockOutcome
from .adapter import SingleFileCommitAdapter, write_patch_file

__all__ = [
    "MutationMode", "MutationRequest", "MutationPermit",
    "WriterInvocationEvidence", "RuntimeObservationEvidence",
    "RuntimeOutcomeDecision", "ClassifierVerdict",
    "PrewriteDecision", "SerializerEvidence",
    "classify_runtime_outcome", "confirmed_not_applied_with_pre_replace_proof",
    "outcome_to_class",
    "is_disposable_runtime", "build_mutation_request", "guard_unnamed_slot",
    "guard_no_desired_outcome", "DisposableProof",
    "SingleFileCommitExecutor", "commit_single_file", "ExecuteEnvelope",
    "DirFsyncStatus", "DurabilityProbe", "DirectoryFsyncResult",
    "probe_directory_fsync", "perform_directory_fsync",
    "LocalAdvisoryLock", "advisory_lock_path_for", "AdvisoryLockOutcome",
    "SingleFileCommitAdapter", "write_patch_file",
]
