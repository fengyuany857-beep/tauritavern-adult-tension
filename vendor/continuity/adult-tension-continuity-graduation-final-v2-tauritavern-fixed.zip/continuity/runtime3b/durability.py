"""Phase 3B — directory fsync durability hardening (wrapper only).

The pinned vendor single-file writer does `mkstemp -> file fsync -> os.replace`
but never fsyncs the parent directory.  Phase 3B adds a best-effort,
platform-safe parent-directory fsync wrapper performed AFTER the writer returns
(or raises).  It never claims cross-store atomicity and never treats a fsync
failure as equivalent to a runtime write failure.

Honesty (§9 / §19 / §20 of the Sol protocol):
- capability is probed on the actual target directory before write-enabled use;
- unsupported / failure => explicit durability metadata, never fabrication;
- success only *strengthens* single-file durability; runtime+SQLite are still
  not atomic.

Metadata fields recommended by the task (§19):
    directory_fsync_attempted / supported / succeeded / error_class
"""
from __future__ import annotations
import enum
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class DirFsyncStatus(str, enum.Enum):
    OK = "OK"                          # fsync of the parent directory succeeded
    UNSUPPORTED = "UNSUPPORTED"        # platform/OS has no open-dir fsync capability
    FAILED = "FAILED"                  # attempted but raised
    NOT_ATTEMPTED = "NOT_ATTEMPTED"    # wrapper not run (e.g. no path provided)


@dataclass(frozen=True)
class DurabilityProbe:
    capability_ok: bool
    reason: str
    path: str | None = None
    status: DirFsyncStatus = DirFsyncStatus.NOT_ATTEMPTED

    def as_dict(self) -> dict[str, Any]:
        return {
            "directory_fsync_capability_ok": self.capability_ok,
            "directory_fsync_capability_reason": self.reason,
            "directory_fsync_path": self.path,
            "directory_fsync_status": self.status.value,
        }


@dataclass(frozen=True)
class DirectoryFsyncResult:
    attempted: bool
    supported: bool
    succeeded: bool
    status: DirFsyncStatus
    error_class: str | None = None
    error_detail_bounded: str | None = None

    def as_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "directory_fsync_attempted": self.attempted,
            "directory_fsync_supported": self.supported,
            "directory_fsync_succeeded": self.succeeded,
            "directory_fsync_status": self.status.value,
            "directory_fsync_error_class": self.error_class,
            "directory_fsync_error_detail": self.error_detail_bounded,
        }
        return out


def _platform_supports_dir_fsync() -> bool:
    """Capability detect: open-a-directory + fsync is supported on POSIX
    (Linux / macOS).  On Windows (msvcrt/no os.O_DIRECTORY path) we report
    UNSUPPORTED and never claim durability we cannot provide."""
    # os.O_DIRECTORY is POSIX-only; a missing attribute => unsupported.
    if not hasattr(os, "O_DIRECTORY"):
        return False
    if not hasattr(os, "open"):
        return False
    try:
        os.O_DIRECTORY  # noqa: B018 - just existence check
    except Exception:  # pragma: no cover
        return False
    return True


def probe_directory_fsync(path: Path) -> DurabilityProbe:
    """Honest capability probe of the target file's parent directory."""
    path = Path(path)
    parent = path if path.is_dir() else path.parent
    if not parent.exists():
        return DurabilityProbe(
            capability_ok=False, reason="parent directory does not exist",
            path=str(parent), status=DirFsyncStatus.UNSUPPORTED)
    if hasattr(os, "O_DIRECTORY"):
        fd = None
        try:
            fd = os.open(str(parent), os.O_DIRECTORY | os.O_RDONLY)
            os.fsync(fd)
            return DurabilityProbe(
                capability_ok=True,
                reason="os.open(O_DIRECTORY|O_RDONLY) + fsync succeeds",
                path=str(parent), status=DirFsyncStatus.OK)
        except OSError as exc:
            return DurabilityProbe(
                capability_ok=False,
                reason=f"directory fsync capability failed: {exc.__class__.__name__}",
                path=str(parent), status=DirFsyncStatus.UNSUPPORTED)
        finally:
            if fd is not None:
                try:
                    os.close(fd)
                except OSError:  # pragma: no cover - diagnostic only
                    pass
    return DurabilityProbe(
        capability_ok=False, reason="no O_DIRECTORY support on this platform",
        path=str(parent), status=DirFsyncStatus.UNSUPPORTED)


def _bounded_error(exc: BaseException, limit: int = 300) -> str:
    return f"{exc.__class__.__name__}: {exc}"[:limit]


def perform_directory_fsync(path: Path) -> DirectoryFsyncResult:
    """Best-effort parent-directory fsync.

    Uses os.open(O_DIRECTORY|O_RDONLY) then os.fsync on POSIX.  If capability is
    missing (probe negative) returns UNSUPPORTED *without* raising.  Failures
    are returned as structured metadata — never silently swallowed as success,
    and never promoted to a runtime-write failure.
    """
    path = Path(path)
    parent = path if path.is_dir() else path.parent
    if not _platform_supports_dir_fsync() or not hasattr(os, "O_DIRECTORY"):
        return DirectoryFsyncResult(
            attempted=False, supported=False, succeeded=False,
            status=DirFsyncStatus.UNSUPPORTED,
            error_class=None,
            error_detail_bounded="directory fsync unsupported on this platform")
    if not parent.exists():
        return DirectoryFsyncResult(
            attempted=True, supported=True, succeeded=False,
            status=DirFsyncStatus.FAILED,
            error_class="OSError", error_detail_bounded="parent directory missing")
    fd = None
    try:
        fd = os.open(str(parent), os.O_DIRECTORY | os.O_RDONLY)
    except OSError as exc:
        return DirectoryFsyncResult(
            attempted=True, supported=True, succeeded=False,
            status=DirFsyncStatus.FAILED,
            error_class=exc.__class__.__name__,
            error_detail_bounded=_bounded_error(exc))
    try:
        os.fsync(fd)
    except OSError as exc:
        return DirectoryFsyncResult(
            attempted=True, supported=True, succeeded=False,
            status=DirFsyncStatus.FAILED,
            error_class=exc.__class__.__name__,
            error_detail_bounded=_bounded_error(exc))
    finally:
        try:
            os.close(fd)
        except OSError:  # pragma: no cover - diagnostic only
            pass
    return DirectoryFsyncResult(
        attempted=True, supported=True, succeeded=True,
        status=DirFsyncStatus.OK,
        error_class=None, error_detail_bounded=None)



def durability_blocks_auto_sync(status: object) -> bool:
    """True when directory durability is not strong enough for automatic sync.

    Both a real fsync failure and a platform/capability UNSUPPORTED result are
    fail-closed by default.  A future weaker-durability deployment profile must
    be explicit and separately authorised; no such profile exists in V1.
    """
    value = getattr(status, "value", status)
    return str(value) in {
        DirFsyncStatus.FAILED.value, DirFsyncStatus.UNSUPPORTED.value,
        "DIR_FSYNC_FAILED", "DIR_FSYNC_UNSUPPORTED",
    }

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
