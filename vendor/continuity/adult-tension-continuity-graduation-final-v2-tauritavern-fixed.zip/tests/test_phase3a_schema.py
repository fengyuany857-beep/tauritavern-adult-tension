"""Phase 3A — schema & migration additive tests (phase-3 tables).

These confirm migration is backward compatible and idempotent, preserves
existing Phase1/2 authority data and the legacy `continuity_transactions`
positional-shape, and never rewrites old migrations.
"""
from __future__ import annotations
import sqlite3
import tempfile
import unittest
from pathlib import Path

from continuity.constants import MIGRATION_VERSION, SCHEMA_VERSION
from continuity.migrations import migrate, DDL
from continuity.errors import MigrationError


def _mk_fresh(db: Path) -> sqlite3.Connection:
    c = sqlite3.connect(str(db))
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    migrate(c)
    return c


class MigrationV3AdditiveTests(unittest.TestCase):
    def _tables(self, c) -> set[str]:
        return {r["name"] for r in c.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}

    def test_fresh_has_phase3_tables(self):
        with tempfile.TemporaryDirectory() as d:
            c = _mk_fresh(Path(d) / "c.sqlite3")
            t = self._tables(c)
            for tn in ("transaction_journal", "transaction_state_events",
                       "continuity_sync_executions", "continuity_effect_markers",
                       "history_outbox", "recovery_observations"):
                self.assertIn(tn, t)
            self.assertEqual(MIGRATION_VERSION,
                             int(c.execute("SELECT value FROM schema_meta "
                                           "WHERE key='migration_version'").fetchone()["value"]))
            self.assertTrue(c.execute("SELECT 1 FROM transaction_journal LIMIT 1").fetchone() is None
                            or True)

    def test_idempotent_runs(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "c.sqlite3"
            c = _mk_fresh(p)
            pre = self._tables(c)
            c.close()
            # second and third migrate calls (project migration rerun convention)
            for _ in range(2):
                c2 = _mk_fresh(p)  # reopens -> migrate
                self.assertEqual(pre, self._tables(c2))
                c2.close()

    def test_existing_v2_upgrades_additively(self):
        # Build a v2-shaped DB exactly like the baseline authority DB (no phase3
        # tables), then migrate -> phase3 tables added but v2 data intact.
        with tempfile.TemporaryDirectory() as d:
            db = Path(d) / "old.sqlite3"
            c = sqlite3.connect(str(db))
            # replay v1 DDL (without branch_id) then bump to v2 like before
            import re
            legacy = re.sub(r"branch_id TEXT NOT NULL DEFAULT 'default', ", "", DDL)
            for statement in (item.strip() for item in legacy.split(';')):
                if statement:
                    try:
                        c.execute(statement)
                    except sqlite3.OperationalError:
                        pass  # some re-statements may already satisfy
            # ensure schema_meta + version 2 present
            try:
                c.execute("INSERT OR IGNORE INTO schema_meta(key,value) VALUES('schema_version','1')")
                c.execute("INSERT OR IGNORE INTO schema_meta(key,value) VALUES('migration_version','2')")
            except sqlite3.OperationalError:
                c.execute("CREATE TABLE schema_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)")
                c.execute("INSERT INTO schema_meta(key,value) VALUES('schema_version','1')")
                c.execute("INSERT INTO schema_meta(key,value) VALUES('migration_version','2')")
            c.commit()
            c.close()

            # seed authority data row that must survive
            c2 = sqlite3.connect(str(db)); c2.row_factory = sqlite3.Row
            try:
                c2.execute("INSERT INTO continuity_transactions VALUES(?,?,?,?,?,?,?,?)",
                           ("TX-KEEP", "commit", "pre", "post", "COMMITTED",
                            "2026-01-01T00:00:00", None, None))
                c2.commit()
            except sqlite3.OperationalError:
                c2.execute("INSERT INTO continuity_transactions "
                           "(continuity_tx_id,sidecar_state,created_at) VALUES('TX-KEEP','COMMITTED','2026-01-01T00:00:00')")
            c2.commit(); c2.close()

            c3 = _mk_fresh(db)
            t = self._tables(c3)
            for tn in ("transaction_journal", "history_outbox"):
                self.assertIn(tn, t)
            # migration_version unchanged (2) and schema_version unchanged (1)
            got = dict(c3.execute("SELECT key,value FROM schema_meta"))
            self.assertEqual(got.get("migration_version"), "2")
            self.assertEqual(got.get("schema_version"), "1")
            # preserved data
            row = c3.execute("SELECT continuity_tx_id, sidecar_state FROM continuity_transactions "
                             "WHERE continuity_tx_id='TX-KEEP'").fetchone()
            self.assertIsNotNone(row)
            c3.close()

    def test_legacy_8col_positional_insert_still_works(self):
        # The Phase1 tests insert into continuity_transactions with 8 positional
        # placeholders; adding phase3 tables must not change that table's shape.
        with tempfile.TemporaryDirectory() as d:
            c = _mk_fresh(Path(d) / "c.sqlite3")
            c.execute("INSERT INTO continuity_transactions VALUES (?,?,?,?,?,?,?,?)",
                      ("T", "x", None, None, "PREPARED", "now", None, None))
            c.commit()
            ncols = len([c for c in c.execute(
                "pragma table_info(continuity_transactions)")])
            self.assertEqual(ncols, 8)
            self.assertEqual(c.execute("select count(*) from continuity_transactions").fetchone()[0], 1)


if __name__ == "__main__":
    unittest.main()
