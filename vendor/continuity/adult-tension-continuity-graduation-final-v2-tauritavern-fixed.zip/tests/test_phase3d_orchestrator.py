"""Phase 3D — orchestrator composition + guard tests.

Builds a fresh disposable vendor/db and drives the Orchestrator through
prepare (3A) -> single-file commit (3B) -> continuity sync (3C).  Verifies the
composition contract and safety guards:
  - result envelope distinguishes runtime / sync / outbox / manual phases;
  - concrete patch required; natural-language desired outcome rejected;
  - named-slot blocked; production paths refused; disposable path accepted;
  - happy path completes; runtime changed exactly once; attempt_count==1;
  - post hash is stored (durable evidence); effect/outbox once-only; COMPLETED;
  - re-entry idempotent (never re-writes runtime, resumes sync only).
"""
from __future__ import annotations
import sqlite3
import sys
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3b_fixture import (
    make_disposable_vendor, simple_patch, current_bytes,
    assert_disposable_runtime_path,
)
from tests.phase3d_fixture import sample_consequences

from continuity.orchestration import orchestrate, orchestration_status
from continuity.orchestration.contracts import (
    OrchestrationRequest, ConsequencePlan, OrchestrationStatus,
)
from continuity.orchestration.errors import UnknownOrchestration
from continuity.migrations import migrate

ROOT = Path(__file__).resolve().parents[1]


def _fresh_db(root: Path, name: str = "continuity.sqlite3") -> Path:
    db = root / "state" / name
    db.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON"); con.execute("PRAGMA journal_mode=WAL")
    migrate(con); con.close()
    return db


def _fixture():
    """Fresh disposable runtime + empty phase-3 schema DB."""
    root, vendor, runtime = make_disposable_vendor()
    db = _fresh_db(root)
    return root, vendor, runtime, db


def _req(vendor, runtime, patch=None, **kw):
    return OrchestrationRequest(
        patch=patch if patch is not None else simple_patch(),
        vendor_dir=str(vendor), runtime_path=str(runtime),
        consequence_plan=ConsequencePlan(consequences=sample_consequences()),
        **kw)


def _count(db, table) -> int:
    con = sqlite3.connect(str(db))
    n = con.execute(f"SELECT COUNT(*) AS c FROM {table}").fetchone()[0]
    con.close()
    return int(n)


class OrchestratorHappyPathTest(unittest.TestCase):
    def test01_result_envelope_distinguishes_phases(self):
        from continuity.orchestration.contracts import OrchestrationResult
        d = OrchestrationResult().as_dict()
        for key in ("status", "stage_reached", "runtime_attempted",
                    "runtime_outcome", "writer_invoked", "sync_state",
                    "outbox_pending", "manual_review_required",
                    "retry_requires_new_tx", "effect_counts", "durability_status"):
            self.assertIn(key, d)

    def test02_concrete_patch_required(self):
        for bad_patch in ({}, None):
            root, vendor, runtime, db = _fixture()
            req = OrchestrationRequest(
                patch=bad_patch or {}, vendor_dir=str(vendor),
                runtime_path=str(runtime),
                consequence_plan=ConsequencePlan(consequences=sample_consequences()))
            out = orchestrate(req, db_path=db)
            self.assertEqual(out.status, OrchestrationStatus.REFUSED.value)
            self.assertIn("concrete", (out.refused_reason or "").lower())

    def test03_natural_language_desired_outcome_rejected(self):
        root, vendor, runtime, db = _fixture()
        req = OrchestrationRequest(
            patch={"desired_outcome": "she believes me"}, vendor_dir=str(vendor),
            runtime_path=str(runtime),
            consequence_plan=ConsequencePlan(consequences=sample_consequences()))
        out = orchestrate(req, db_path=db)
        self.assertEqual(out.status, OrchestrationStatus.REFUSED.value)
        # no runtime mutation happened
        self.assertEqual(_count(db, "transaction_journal"), 0)

    def test04_consequence_plan_required(self):
        root, vendor, runtime, db = _fixture()
        req = OrchestrationRequest(
            patch=simple_patch(), vendor_dir=str(vendor), runtime_path=str(runtime),
            consequence_plan=None)
        out = orchestrate(req, db_path=db)
        self.assertEqual(out.status, OrchestrationStatus.REFUSED.value)
        self.assertIn("consequence", (out.refused_reason or "").lower())

    def test05_named_slot_blocked(self):
        root, vendor, runtime, db = _fixture()
        slot = vendor / "saves" / "state.yaml"
        slot.parent.mkdir(parents=True, exist_ok=True)
        slot.write_bytes(runtime.read_bytes())
        req = _req(vendor, slot)
        out = orchestrate(req, db_path=db)
        self.assertEqual(out.status, OrchestrationStatus.REFUSED.value)
        self.assertIn("named-slot".lower(), (out.refused_reason or "").lower())
        self.assertEqual(_count(db, "transaction_journal"), 0)

    def test06_non_disposable_refused(self):
        root, vendor, runtime, db = _fixture()
        # a vendor root NOT under /tmp => not disposable
        fake_vendor = Path(ROOT) / "vendor" / "dsh-adult-tension"
        req = OrchestrationRequest(
            patch=simple_patch(), vendor_dir=str(fake_vendor),
            runtime_path=str(fake_vendor / "saves" / "current_state.yaml"),
            consequence_plan=ConsequencePlan(consequences=sample_consequences()))
        out = orchestrate(req, db_path=db)
        self.assertEqual(out.status, OrchestrationStatus.REFUSED.value)
        self.assertIn("disposable", (out.refused_reason or "").lower())

    def test_disposable_accepted(self):
        root, vendor, runtime, db = _fixture()
        assert_disposable_runtime_path(runtime)
        req = _req(vendor, runtime)
        out = orchestrate(req, db_path=db)
        self.assertEqual(out.status, OrchestrationStatus.COMPLETED.value)

    def test10_happy_path_completes_and_runtime_changed_once(self):
        root, vendor, runtime, db = _fixture()
        pre = current_bytes(vendor)
        req = _req(vendor, runtime)
        out = orchestrate(req, db_path=db)
        post = current_bytes(vendor)
        self.assertEqual(out.status, OrchestrationStatus.COMPLETED.value)
        self.assertEqual(out.runtime_outcome, "CONFIRMED_APPLIED")
        self.assertEqual(out.attempt_count, 1)
        self.assertTrue(out.writer_invoked)
        self.assertNotEqual(pre, post)          # applied exactly once driving change
        self.assertEqual(out.effect_counts.get("effects"), 1)
        self.assertEqual(_count(db, "continuity_sync_executions"), 1)
        self.assertEqual(_count(db, "continuity_effect_markers"), 1)
        self.assertEqual(_count(db, "history_outbox"), 1)

    def test_status_completed(self):
        root, vendor, runtime, db = _fixture()
        req = _req(vendor, runtime)
        out = orchestrate(req, db_path=db)
        st = orchestration_status(db_path=db, tx_id=out.continuity_tx_id)
        self.assertEqual(st["state"], "COMPLETED")
        self.assertEqual(st["attempt_count"], 1)
        self.assertTrue(st["writer_invoked"])
        self.assertEqual(st["runtime_outcome_class"], "CONFIRMED_APPLIED")
        self.assertNotEqual(st["pre_sha256"], st["post_sha256"])
        self.assertTrue(st["retry_requires_new_tx"])
        with self.assertRaises(UnknownOrchestration):
            orchestration_status(db_path=db, tx_id="definitely-not-here")

    def test17_repeat_completed_is_noop(self):
        root, vendor, runtime, db = _fixture()
        req = _req(vendor, runtime)
        out1 = orchestrate(req, db_path=db)
        post1 = current_bytes(vendor)
        out2 = orchestrate(_req(vendor, runtime), db_path=db,
                           tx_id_hint=out1.continuity_tx_id)
        self.assertEqual(out2.status, OrchestrationStatus.COMPLETED.value)
        self.assertEqual(current_bytes(vendor), post1)   # no second runtime write
        con = sqlite3.connect(str(db))
        ac = con.execute("SELECT attempt_count FROM transaction_journal "
                         "WHERE continuity_tx_id=?", (out1.continuity_tx_id,)).fetchone()[0]
        con.close()
        self.assertEqual(int(ac), 1)                      # still a single attempt
        self.assertEqual(_count(db, "continuity_sync_executions"), 1)  # no double sync

    def test18_confirm_applied_resumes_sync_only(self):
        """A crash right after runtime-confirm (F8) leaves applied+durable, then
        a fresh orchestrate call resumes ONLY continuity sync (never re-writes)."""
        from continuity.orchestration.orchestrator import Orchestrator
        root, vendor, runtime, db = _fixture()
        orch = Orchestrator(db_path=db, fault_on="F8",
                            fault_impl=lambda _s: (_ for _ in ()).throw(RuntimeError("crash")))
        try:
            with self.assertRaises(RuntimeError):
                orch.orchestrate(_req(vendor, runtime))   # simulated process death
        finally:
            orch.close()
        # Durable: applied but not synced (attempt consumed, runtime mutated once).
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        row = dict(con.execute(
            "SELECT continuity_tx_id, state, attempt_count, runtime_outcome_class "
            "FROM transaction_journal ORDER BY created_at LIMIT 1").fetchone())
        con.close()
        self.assertIn(row["state"], ("DURABILITY_PENDING", "CONFIRMED_APPLIED",
                                    "CONTINUITY_SYNC_PENDING"))
        self.assertEqual(int(row["attempt_count"]), 1)
        post1 = current_bytes(vendor)
        # Fresh (fault-free) orchestrate on the SAME tx resumes sync -> COMPLETED.
        final = orchestrate(_req(vendor, runtime), db_path=db,
                            tx_id_hint=row["continuity_tx_id"])
        self.assertEqual(final.status, OrchestrationStatus.COMPLETED.value)
        self.assertEqual(current_bytes(vendor), post1)   # sync-only resume, no rewrite

    def test19_same_tx_never_rewrites_runtime(self):
        root, vendor, runtime, db = _fixture()
        out1 = orchestrate(_req(vendor, runtime), db_path=db)
        post = current_bytes(vendor)
        for _ in range(3):
            orchestrate(_req(vendor, runtime), db_path=db,
                        tx_id_hint=out1.continuity_tx_id)
            self.assertEqual(current_bytes(vendor), post)


if __name__ == "__main__":
    unittest.main()
