"""Phase 2B-2 context-pack integration & safety guards (SPEC §18-§23, §26, §28).

These tests feed the ReentryPlan's candidates into the SAME ContextPackBuilder
as Phase 2B-1 to verify the re-entry path cannot bypass reveal/anti_merge,
observer, temporal recorded_at, wrong-branch, superseded, or the adult authority
guard, and that determinism / zero-authority-mutation hold.
"""
from __future__ import annotations
import hashlib
import json
import sqlite3
import unittest
from pathlib import Path

from tests import reentry_fixture as F
from continuity.reentry import ReentryPlanner, ReentryRequest
from continuity.reentry.planner import plan_to_reentry_candidates, to_card_candidate
from continuity.routing import ContextPackBuilder, PackStatus, RoutingRequest


class _Base(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base, self.cards = F.build()
        self.planner = ReentryPlanner(self.base)

    def tearDown(self):
        try:
            self.tmp.cleanup()
        except Exception:
            pass

    def plan_alex(self, last_seen=4, event_turn=200):
        snap = F.make_runtime(self.base, roster=("ALEX", "PLR"))
        req = ReentryRequest(runtime_npc_id="alex-x", branch_id="default",
                             last_seen_turn=last_seen, event_turn=event_turn,
                             reentry_reason="router_deep_resolved", mode="DEEP",
                             current_participant_entity_ids=("ALEX", "PLR"),
                             query_id="rp1")
        return self.planner.plan(req, snap), snap

    def build_pack(self, mode_override=None, text="", budget=None):
        plan, snap = self.plan_alex()
        cands = plan_to_reentry_candidates(plan)
        card = to_card_candidate(plan)
        if card is not None:
            cands = tuple([card] + list(cands))
        req = RoutingRequest(branch_id="default", raw_text=text or "Alex回来了",
                             mode_override=mode_override, token_budget=budget)
        pack = ContextPackBuilder(self.base).build(req, runtime_state=snap,
                                                   reentry_candidates=cands)
        return pack, snap

    @staticmethod
    def table_digest(base, table):
        con = sqlite3.connect(str(base / "state" / "continuity.sqlite3"))
        rows = con.execute(f"SELECT * FROM {table} ORDER BY rowid").fetchall()
        con.close()
        return hashlib.sha256(repr(rows).encode("utf-8")).hexdigest()


class SafetyGuards(_Base):
    def _text(self, pack):
        return " ".join(i.content or "" for i in pack.items).lower()

    def test_reveal_never_leaks_payload_to_pack(self):
        plan, _ = self.plan_alex()
        pack = self.build_pack()[0]
        self.assertNotIn("secret-cache", self._text(pack))
        blob = " ".join(e.reason or "" for e in plan.activation_traces)
        self.assertNotIn("secret-cache", blob)

    def test_anti_merge_still_separate(self):
        pack = self.build_pack()[0]
        am = [i for i in pack.items
              if "anti-merge" in (i.activation_reason or "").lower()
              or "must not be merged" in (i.content or "").lower()]
        self.assertTrue(am)

    def test_observer_restriction_cannot_be_bypassed(self):
        plan, _ = self.plan_alex()
        kb = [e for e in plan.activation_traces
              if e.source_ref in ("K-B-SECRET", "K-B-RESTRICT")]
        self.assertEqual(len(kb), 0)

    def test_wrong_branch_cannot_bypass(self):
        plan = self.planner.plan(ReentryRequest(
            runtime_npc_id="alex-x", branch_id="default", reentry_reason="router_deep_resolved",
            mode="DEEP"), F.make_runtime(self.base, roster=("ALEX", "PLR")))
        self.assertEqual(set(plan.episode_refs) & {"EP-WB"}, set())
        refs = {e.source_ref for e in plan.activation_traces}
        self.assertNotIn("F-BOB-WB", refs)

    def test_superseded_and_candidate_excluded(self):
        plan, _ = self.plan_alex()
        refs = {e.source_ref for e in plan.activation_traces}
        self.assertNotIn("F-ALEX-SUP", refs)
        self.assertNotIn("Candidate", " ".join(str(e.classification) for e in plan.activation_traces))

    def test_pack_determinism(self):
        p1 = self.build_pack()[0]
        p2 = self.build_pack()[0]
        self.assertEqual(p1.semantic_digest, p2.semantic_digest)
        self.assertEqual([i.item_id for i in p1.items],
                         [i.item_id for i in p2.items])

    def test_budget_respected(self):
        pack = self.build_pack(budget=60)[0]
        self.assertLessEqual(pack.estimated_token_used, 4000)


class AdultIsolation(_Base):
    def test_no_current_permission_anywhere(self):
        plan, _ = self.plan_alex()
        pack = self.build_pack()[0]
        low = " ".join(e.reason or "" for e in plan.activation_traces).lower()
        low += " " + " ".join(i.content or "" for i in pack.items).lower()
        # The pack must never *claim* a current permission/authority grant for the
        # return; the only place "permission" may appear is inside our own negative
        # meta marker "__no_current_permission_synthesized".
        for tok in ("consent", "granted", "grant a", " grant", " boundary", " safety",
                    "sexuality", " intimacy"):
            self.assertNotIn(tok, low)
        # It may never state that anyone "has permission" / "is allowed".
        self.assertNotIn(" is permitted", low)
        for claim in ("alex has permission", "player consents", "permission granted",
                      "now may", "allowed to engage"):
            self.assertNotIn(claim, low)

    def test_only_observed_hash_reference(self):
        plan, _ = self.plan_alex()
        self.assertIsNotNone(plan.runtime_observed_sha256)
        pack = self.build_pack()[0]
        has_ref = any(i.source_type == "ENTITY" and "runtime" in (i.content or "").lower()
                      for i in pack.items)
        self.assertTrue(has_ref)

    def test_no_history_consent_becomes_current(self):
        plan, _ = self.plan_alex()
        ids = " ".join(e.activation_id for e in plan.activation_traces)
        blob = " ".join(e.reason or "" for e in plan.activation_traces)
        self.assertTrue("no-required-plot-action" in ids or "sovereign" in ids or
                        "historical-only" in ids or "does_not_require_plot" in blob)


class AntiOverfunctionAndSovereignty(_Base):
    def test_reentry_does_not_require_plot_action(self):
        plan, _ = self.plan_alex()
        guard = [e for e in plan.activation_traces
                 if e.activation_id == "guard:no-required-plot-action"
                 or "does_not_require_plot" in (e.reason or "")]
        self.assertTrue(guard)

    def test_player_internal_state_not_synthesized(self):
        plan, _ = self.plan_alex()
        blob = " ".join(e.reason or "" for e in plan.activation_traces)
        for phrase in ("feels sad", "decided to", "wants to leave", "is angry"):
            self.assertNotIn(phrase, blob)

    def test_player_sovereignty_guard_present(self):
        plan, _ = self.plan_alex()
        self.assertTrue(
            any(e.activation_id == "guard:player-sovereignty"
                for e in plan.activation_traces))


class ZeroMutation(_Base):
    AUTHORITY_TABLES = ["entities", "facts", "knowledge", "relationships",
                        "commitments", "threads", "thread_requires",
                        "thread_anti_merge", "episodes", "episode_entity_links",
                        "continuity_transactions", "admission_candidates",
                        "admission_decisions", "checkpoints"]

    def test_reentry_plan_plus_pack_zero_mutation(self):
        before = {}
        for t in set(self.AUTHORITY_TABLES):
            before[t] = self.table_digest(self.base, t)
        self.plan_alex()
        pack = self.build_pack()[0]
        self.build_pack()
        for t, dg in before.items():
            self.assertEqual(self.table_digest(self.base, t), dg, f"table {t} mutated")

    def test_no_auto_promotion(self):
        con = sqlite3.connect(str(self.base / "state" / "continuity.sqlite3"))
        base_known = con.execute("SELECT state FROM knowledge WHERE knowledge_id='K-B-RESTRICT'").fetchall()
        self.build_pack()
        after = con.execute("SELECT state FROM knowledge WHERE knowledge_id='K-B-RESTRICT'").fetchall()
        con.close()
        self.assertEqual(base_known, after)


class PackIntegrationLifecycle(_Base):
    def test_reentry_pack_built_via_single_authority(self):
        plan, snap = self.plan_alex()
        cands = plan_to_reentry_candidates(plan)
        req = RoutingRequest(branch_id="default", raw_text="Alex回来了")
        pack = ContextPackBuilder(self.base).build(req, runtime_state=snap,
                                                   reentry_candidates=cands)
        self.assertIn(pack.status, (PackStatus.OK, PackStatus.PARTIAL))
        reentry_ref = [i for i in pack.items
                       if i.activation_reason.startswith("returning NPC runtime card")
                       or i.source_type in ("GUARD", "KNOWLEDGE", "RELATIONSHIP", "COMMITMENT")]
        self.assertTrue(reentry_ref)

    def test_runtime_card_ref_pinned_hot(self):
        plan, snap = self.plan_alex()
        cand = to_card_candidate(plan)
        self.assertIsNotNone(cand)
        self.assertEqual(cand.hard_pin, True)


if __name__ == "__main__":
    unittest.main()
