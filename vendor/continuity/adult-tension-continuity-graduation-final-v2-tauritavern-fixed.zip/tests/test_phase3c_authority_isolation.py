"""Phase 3C — authority/ownership isolation (adult, sovereignty, no current dup).

Covers task §19/§20/§21 and §27 items 46-58:
- an adult historical event / episode memory reference may be recorded;
- historical consent is NOT current consent; trust never synthesises permission;
- a payload that writes current-permission / current-boundary / intimacy_current
  as current authority is refused;
- adult payload is never shadow-stored (no current-* keys in what is applied);
- player intent / private feeling / dialogue is never synthesised;
- a runtime current-relationship write (write_current=True) is refused;
- commitment is not auto-resolved without an explicit status_transition + effect;
- thread is not auto-advanced without an explicit state_transition + effect;
- knowledge is observer-scoped (grant_to_additional / PLAYER_VISIBLE rejected);
- manual-review packet has bounded detail, forbidden-action codes and no CoT;
- an existing effect marker with a different payload digest is refused
  (EFFECT_DIGEST_CONFLICT -> manual review).

Pure planner / sqlwriter / packet checks so tests are fast and deterministic.
"""
from __future__ import annotations
import json
import sqlite3
import sys
import unittest

from continuity.sync3c.planner import build_plan, PlanError
from continuity.sync3c.contracts import (
    ContinuitySyncRequest, EffectKind, canonical_effect_id,
)
from continuity.sync3c.sqlwriter import effect_sql, EffectApplyError
from continuity.sync3c.manual_packet import build_manual_packet


def _mk_req(cons):
    return ContinuitySyncRequest(
        continuity_tx_id="tx-o", runtime_outcome_class="CONFIRMED_APPLIED",
        observed_post_sha256="0" * 64, observed_post_semantic_digest="0" * 64,
        expected_candidate_digest="e", patch_digest="p", branch_id="default",
        source_provenance={}, request_provenance={}, sync_plan_bytes_digest="",
        consequences=cons)


def _c(kind, payload):
    return {"kind": kind, "payload": payload}


class OwnershipIsolationTests(unittest.TestCase):
    def test_adult_historical_event_reference_allowed(self):
        cons = [_c("EPISODE_APPEND", {
            "summary": "character memory of a past event",
            "scene_ref": "INT-2", "history_pointer": "VOL-001/HP-7",
        })]
        plan = build_plan(_mk_req(cons))
        self.assertEqual(plan.effects[0].effect_kind, EffectKind.EPISODE_APPEND)

    def test_adult_current_permission_write_rejected(self):
        cons = [_c("FACT_INSERT", {
            "subject_ref": "E-A", "predicate": "consent_grant",
            "object": {"boundary": "full"}, "current_permission": True,
        })]
        with self.assertRaises(PlanError):
            build_plan(_mk_req(cons))

    def test_write_current_relationship_rejected(self):
        cons = [_c("RELATIONSHIP_SEMANTIC_UPDATE", {
            "source_ref": "E-A", "target_ref": "E-PL", "write_current": True,
        })]
        with self.assertRaises(PlanError):
            build_plan(_mk_req(cons))

    def test_adult_payload_not_shadow_stored(self):
        cons = [_c("RELATIONSHIP_SEMANTIC_UPDATE", {
            "source_ref": "E-A", "target_ref": "E-PL",
            "semantic_name": "shared_memory", "history_pointer": "HP-9",
        })]
        plan = build_plan(_mk_req(cons))
        lowered = json.dumps(plan.effects[0].payload).lower()
        for word in ("intimacy_current", "consent_current", "permission_current",
                     "safe_limits", "current_boundary"):
            self.assertNotIn(word, lowered)

    def test_player_sovereignty_not_synthesized(self):
        # cannot invent player private state / intention in a fact
        with self.assertRaises(PlanError):
            build_plan(_mk_req([_c("FACT_INSERT", {
                "subject_ref": "E-PL", "predicate": "player_intends",
                "object": {"intent": ""},})]))
        # PLAYER_VISIBLE plane is not given to an NPC writer
        with self.assertRaises(PlanError):
            build_plan(_mk_req([_c("KNOWLEDGE_UPDATE", {
                "subject_ref": "E-PL", "proposition_ref": "PROP-X",
                "state": "knows", "plane": "PLAYER_VISIBLE",})]))

    def test_knowledge_observer_scoped_reject_widen(self):
        with self.assertRaises((PlanError,)):
            build_plan(_mk_req([_c("KNOWLEDGE_UPDATE", {
                "subject_ref": "E-B", "proposition_ref": "SECRET",
                "state": "knows", "plane": "CHARACTER",
                "grant_to_additional": ["E-C"],})]))

    def test_commitment_not_auto_resolved_without_explicit(self):
        # allowed-kind, but a plan lacking explicit effect_type/status is refused
        # at the ownership/apply boundary, never auto-resolved.
        plan = None
        try:
            plan = build_plan(_mk_req([_c("COMMITMENT_HISTORICAL_EFFECT",
                                          {"commitment_id": "COM-A"})]))
        except PlanError:
            plan = None
        self.assertIsNone(plan)

    def test_thread_not_auto_advanced_without_explicit(self):
        plan = None
        try:
            plan = build_plan(_mk_req([_c("THREAD_HISTORICAL_EFFECT",
                                          {"thread_id": "TH-1"})]))
        except PlanError:
            plan = None
        self.assertIsNone(plan)

    def test_manual_packet_no_cot_bounded(self):
        packet = build_manual_packet(
            continuity_tx_id="tx-1", runtime_outcome_class="OUTCOME_UNKNOWN",
            state="OUTCOME_UNKNOWN", reason="cannot conclude", review_tag="UNKNOWN",
            last_error_detail="x" * 5000)
        data = json.loads(packet)
        self.assertLessEqual(len(data["last_error_detail"]), 2000)
        self.assertIn("forbidden_actions", data)
        low = packet.lower()
        for word in ("chain_of_thought", "scratchpad", "hidden_reasoning"):
            self.assertNotIn(word, low)

    def test_effect_id_stable(self):
        self.assertEqual(
            canonical_effect_id(EffectKind.FACT_INSERT, "k"),
            canonical_effect_id(EffectKind.FACT_INSERT, "k"))

    def test_sql_surface_applies_an_explicit_commitment_effect(self):
        # positive path: explicit fulfilment writes the transition and nothing else
        con = sqlite3.connect(":memory:")
        con.row_factory = sqlite3.Row
        con.execute("CREATE TABLE commitments (commitment_id TEXT PRIMARY KEY, "
                    "status TEXT, branch_id TEXT, kind TEXT, issuer_ref TEXT, "
                    "beneficiary_refs_json TEXT, content TEXT, runtime_event_ref TEXT, "
                    "provenance_json TEXT)")
        con.execute("INSERT INTO commitments VALUES ('COM-A','open','default',"
                    "'promise','','[]','will',NULL,'{}')")
        with con:
            effect_sql(con, EffectKind.COMMITMENT_HISTORICAL_EFFECT,
                       {"commitment_id": "COM-A", "effect_type": "fulfilled",
                        "status_transition": "resolved"},
                       {"continuity_tx_id": "tx-o", "branch_id": "default",
                        "plan_digest": "d", "effect_id": "id"})
        self.assertEqual(con.execute(
            "SELECT status FROM commitments WHERE commitment_id='COM-A'"
        ).fetchone()["status"], "resolved")


if __name__ == "__main__":
    unittest.main()
