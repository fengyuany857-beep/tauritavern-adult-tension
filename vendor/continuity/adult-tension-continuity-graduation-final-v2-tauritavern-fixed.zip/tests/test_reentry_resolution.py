"""Phase 2B-2 resolution / role / absence tests (SPEC §6-§9, §24, §25, §14).

Covers the listed resolver and planner-black-box behaviours (items 1-10).
"""
from __future__ import annotations
import json
import unittest
from pathlib import Path

from tests import reentry_fixture as F
from continuity.reentry.contracts import ReentryRequest, ReentryStatus
from continuity.reentry.planner import ReentryPlanner
from continuity.reentry.resolver import (
    _ResolveDao, resolve_runtime_entity, classify_role,
)
from continuity.reentry.contracts import NpcClass, ResolutionStatus


class _Base(unittest.TestCase):
    tmp = None

    def setUp(self):
        self.tmp, self.base, self.cards = F.build()
        self.planner = ReentryPlanner(self.base)

    def tearDown(self):
        try:
            if self.tmp:
                self.tmp.cleanup()
        except Exception:
            pass

    def plan(self, runtime_id=None, mention=None, *, roster=("ALEX", "PLR"),
             last_seen=None, event_turn=None, mode="DEEP",
             reason="router_deep_resolved"):
        snap = F.make_runtime(self.base, roster=roster)
        req = ReentryRequest(
            runtime_npc_id=runtime_id, mention_text=mention, branch_id="default",
            last_seen_turn=last_seen, event_turn=event_turn, reentry_reason=reason,
            mode=mode, query_id="t", current_participant_entity_ids=tuple(roster))
        return self.planner.plan(req, snap), snap


class RoleClassification(unittest.TestCase):
    def test_main_and_important_and_minor(self):
        self.assertEqual(classify_role("main"), NpcClass.MAIN)
        self.assertEqual(classify_role("important_supporting"),
                         NpcClass.IMPORTANT_SUPPORTING)
        self.assertEqual(classify_role("minor"), NpcClass.MINOR)
        self.assertEqual(classify_role(None), NpcClass.UNKNOWN)
        self.assertEqual(classify_role(""), NpcClass.UNKNOWN)
        self.assertEqual(classify_role("supporting"), NpcClass.IMPORTANT_SUPPORTING)


class ResolverUnit(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base, self.cards = F.build()
        self.dao = _ResolveDao(self.base)

    def tearDown(self):
        self.dao.close()
        try:
            if self.tmp:
                self.tmp.cleanup()
        except Exception:
            pass

    def resolve(self, rid=None, mention=None):
        return resolve_runtime_entity(rid, mention, self.dao, "default")

    def test_runtime_external_ref_maps_stable_entity(self):
        r = self.resolve(rid="alex-x")
        self.assertEqual(r.resolution_status, ResolutionStatus.RESOLVED)
        self.assertEqual(r.entity_id, "ALEX")
        self.assertEqual(r.matched_by, "runtime_external_ref")

    def test_unmapped_runtime_npc_is_not_found(self):
        r = self.resolve(rid="ghost-x")
        self.assertEqual(r.resolution_status, ResolutionStatus.NOT_FOUND)

    def test_confirmed_alias_resolves(self):
        r = self.resolve(mention="Dr. Rey")
        self.assertEqual(r.resolution_status, ResolutionStatus.RESOLVED)
        self.assertEqual(r.entity_id, "NORA")
        self.assertEqual(r.matched_by, "confirmed_alias")

    def test_merge_candidate_not_resolved(self):
        r = self.resolve(mention="Bailey")
        self.assertNotEqual(r.resolution_status, ResolutionStatus.RESOLVED)
        self.assertEqual(r.resolution_status, ResolutionStatus.AMBIGUOUS)

    def test_same_name_ambiguity_no_lexical_pick(self):
        r1 = self.resolve(rid="alex-x")
        self.assertEqual(r1.entity_id, "ALEX")
        r = self.resolve(mention="Alex")
        self.assertEqual(r.resolution_status, ResolutionStatus.AMBIGUOUS)


class ReentryPlannerPlanning(_Base):
    def test_main_long_absence_reentry_planned(self):
        plan, _ = self.plan(runtime_id="alex-x", roster=("ALEX", "PLR"),
                            last_seen=4, event_turn=200)
        self.assertEqual(plan.status, ReentryStatus.OK)
        self.assertEqual(plan.npc_class, NpcClass.MAIN.value)
        self.assertGreaterEqual(len(plan.activation_traces), 6)

    def test_important_supporting_long_absence_planned(self):
        plan, _ = self.plan(runtime_id="bina-x", roster=("BINA", "ALEX"),
                            last_seen=3, event_turn=150)
        self.assertEqual(plan.status, ReentryStatus.OK)
        self.assertEqual(plan.npc_class, "important_supporting")

    def test_minor_npc_no_auto_heavy(self):
        plan, _ = self.plan(runtime_id="mini-x", roster=("MINI", "ALEX", "PLR"),
                            last_seen=2, event_turn=180)
        self.assertEqual(plan.status, ReentryStatus.OK)
        self.assertEqual(plan.npc_class, NpcClass.MINOR.value)
        self.assertEqual(set(plan.episode_refs), set())
        self.assertLessEqual(len(plan.activation_traces), 10)

    def test_missing_runtime_card_missing_status(self):
        snap = F.make_runtime(self.base, roster=("ALEX",))
        # registry intentionally lacks MINI card (roster "ALEX" only) while query
        # asks for a separate NPC -> absent. Here we ask for an id not present.
        snap2 = F.make_runtime(self.base, roster=("NORA",))
        req = ReentryRequest(runtime_npc_id="alex-x", branch_id="default",
                             reentry_reason="router_deep_resolved", mode="DEEP")
        plan = self.planner.plan(req, snap2)
        self.assertEqual(plan.status, ReentryStatus.RUNTIME_CARD_MISSING)

    def test_registry_card_available_for_offscreen(self):
        # roster does not include NORA as participant, but her card is in the full
        # registry file we pass; planning still reads the full registry card.
        snap = F.make_runtime(self.base, roster=("NORA", "PLR"))
        req = ReentryRequest(runtime_npc_id="nora-x", branch_id="default",
                             reentry_reason="explicit_historical_recall", mode="DEEP")
        plan = self.planner.plan(req, snap)
        self.assertEqual(plan.status, ReentryStatus.OK)
        self.assertEqual(plan.target_entity_id, "NORA")

    def test_no_snapshot_conservative(self):
        req = ReentryRequest(runtime_npc_id="alex-x", branch_id="default",
                             reentry_reason="router_deep_resolved", mode="DEEP")
        plan = self.planner.plan(req, None)
        self.assertEqual(plan.status, ReentryStatus.RUNTIME_CARD_MISSING)

    def test_ambiguous_same_name_marks_plan_ambiguous(self):
        # mention ambiguity through the stable mapper is AMBIGUOUS in resolver;
        # planner reports plan-status AMBIGUOUS without auto-picking.
        req = ReentryRequest(mention_text="Alex", branch_id="default",
                             reentry_reason="router_deep_resolved", mode="DEEP")
        plan = self.planner.plan(req, F.make_runtime(self.base, roster=("ALEXA",)))
        self.assertEqual(plan.status, ReentryStatus.AMBIGUOUS)


if __name__ == "__main__":
    unittest.main()
