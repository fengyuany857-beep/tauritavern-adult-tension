import json
import unittest
from continuity.history import append_envelope
from continuity.retrieval import EvidenceRetriever, RetrievalQuery, RetrievalStatus
from retrieval_seed import open_ctx, seed_base


def add_extra(base, name, env):
    append_envelope(base / "history" / name, env)


class T(unittest.TestCase):
    def setUp(self):
        self.tmp, base = seed_base()
        self.addCleanup(self.tmp.cleanup)
        add_extra(base, "VOL-003.jsonl", {
            "branch_id": "default", "episode_id": "EP-X", "transaction_id": "TX-X",
            "runtime_pre_hash": "p", "runtime_post_hash": "q",
            "payload_classification": "HISTORICAL_EVIDENCE", "source_references": ["evt-9"],
            "scene_id": "SC-X", "participants": ["E-C"], "turn_start": 20, "turn_end": 21,
            "summary": "exact scene x evidence", "payload": {"quote": "the sapphire stays hidden"},
        })
        # corrupt line appended raw (checksum absent) inside VOL-004
        (base / "history" / "VOL-004.jsonl").write_text(
            json.dumps({"branch_id": "default", "episode_id": "EP-BAD", "scene_id": "SC-COR",
                        "payload_classification": "HISTORICAL_EVIDENCE", "source_references": []}) + "\n",
            encoding="utf-8")
        self.ctx = open_ctx(base)
        self.ev = EvidenceRetriever()

    def test_evidence_lookup_exact_scene(self):
        r = self.ev.retrieve(RetrievalQuery(scene_id="SC-X", query_id="q"), self.ctx)
        self.assertIn("EP-X", [i.item_id for i in r.items])

    def test_evidence_checksum_verified(self):
        r = self.ev.retrieve(RetrievalQuery(scene_id="SC-X", query_id="q"), self.ctx)
        self.assertTrue(all(i.provenance for i in r.items))

    def test_corrupted_evidence_returns_corrupt(self):
        r = self.ev.retrieve(RetrievalQuery(scene_id="SC-COR", query_id="q"), self.ctx)
        self.assertEqual(RetrievalStatus.EVIDENCE_CORRUPT, r.status)

    def test_missing_exact_evidence_insufficient(self):
        r = self.ev.retrieve(RetrievalQuery(scene_id="SC-NONE", exact_evidence_required=True, query_id="q"), self.ctx)
        self.assertEqual(RetrievalStatus.EVIDENCE_INSUFFICIENT, r.status)
        self.assertEqual([], [i for i in r.items])
