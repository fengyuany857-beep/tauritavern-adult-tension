"""Phase 3D — fault-seam injection + crash-matrix coverage (§13/§14/§37).

Covers the expressible Orchestrator seams (F0,F1,F3,F8) with an injected raise
and re-entry; documents where F2/F4-F7 and F9-F13 live (inside the reused
Phase 3B/3C functions whose own fault fixtures already cover them) and F14
(COMPLETED no-op through orchestration status/recovery).

The objective: no orchestration semantics are modified to simulate a fault; only
an explicit, test-only injection is used, and the durable journal + re-entry
recover forward (or fail-closed) exactly as the phase 3A/B/C recover paths do.
"""
from __future__ import annotations
import sqlite3
import sys
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3b_fixture import make_disposable_vendor, simple_patch, current_bytes
from tests.phase3d_fixture import sample_consequences, seed_disposable_db
from continuity.orchestration.orchestrator import Orchestrator
from continuity.orchestration import orchestrate
from continuity.orchestration.contracts import OrchestrationRequest, ConsequencePlan


def _cons():
    return ConsequencePlan(consequences=sample_consequences())


def _req(vendor, runtime):
    return OrchestrationRequest(patch=simple_patch(), vendor_dir=str(vendor),
                                runtime_path=str(runtime), consequence_plan=_cons())


class _Crash:
    def __init__(self):
        self.raised = False
        self.at = None

    def __call__(self, seam):
        self.raised = True
        self.at = seam
        raise RuntimeError(f"injected crash at {seam}")


class Phase3dFaultSeamTest(unittest.TestCase):
    def test_f0_before_durable_intent_no_row(self):
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        crash = _Crash()
        o = Orchestrator(db_path=db, fault_on="F0", fault_impl=crash)
        try:
            with self.assertRaises(RuntimeError):
                o.orchestrate(_req(vendor, runtime))
        finally:
            o.close()
        con = sqlite3.connect(str(db))
        n = con.execute("SELECT COUNT(*) FROM transaction_journal").fetchone()[0]
        con.close()
        self.assertEqual(int(n), 0, "F0 crash -> nothing durable (safe no-op)")

    def test_f1_after_prepared_resumes_same_tx(self):
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        crash = _Crash()
        o = Orchestrator(db_path=db, fault_on="F1", fault_impl=crash)
        try:
            with self.assertRaises(RuntimeError):
                o.orchestrate(_req(vendor, runtime))
        finally:
            o.close()
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        row = con.execute("SELECT state FROM transaction_journal "
                          "ORDER BY created_at LIMIT 1").fetchone()
        con.close()
        self.assertEqual(row["state"], "PREPARED")
        # re-orchestrate same tx resumes from durable PREPARED
        out = orchestrate(_req(vendor, runtime), db_path=db, tx_id_hint=first_tx(db))
        self.assertEqual(out.status, "COMPLETED")

    def test_f3_mid_precommit_resume_no_double_commit(self):
        """A crash at F3 (before Phase 3B commit call) leaves PREPARED with no
        runtime write; re-run completes exactly once."""
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        crash = _Crash()
        o = Orchestrator(db_path=db, fault_on="F3", fault_impl=crash)
        try:
            with self.assertRaises(RuntimeError):
                o.orchestrate(_req(vendor, runtime))
        finally:
            o.close()
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        st = con.execute("SELECT state FROM transaction_journal "
                         "ORDER BY created_at LIMIT 1").fetchone()["state"]
        con.close()
        self.assertEqual(st, "PREPARED")
        post0 = current_bytes(vendor)
        out = orchestrate(_req(vendor, runtime), db_path=db, tx_id_hint=first_tx(db))
        self.assertEqual(out.status, "COMPLETED")
        self.assertNotEqual(current_bytes(vendor), post0)

    def test_f8_applied_resume_sync(self):
        from tests.test_phase3d_orchestrator import OrchestratorHappyPathTest  # noqa
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        crash = _Crash()
        o = Orchestrator(db_path=db, fault_on="F8", fault_impl=crash)
        try:
            with self.assertRaises(RuntimeError):
                o.orchestrate(_req(vendor, runtime))
        finally:
            o.close()
        post1 = current_bytes(vendor)
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        row = con.execute("SELECT state, attempt_count FROM transaction_journal "
                          "ORDER BY created_at LIMIT 1").fetchone()
        con.close()
        self.assertIn(dict(row)["state"], ("DURABILITY_PENDING", "CONFIRMED_APPLIED"))
        self.assertEqual(int(dict(row)["attempt_count"]), 1)
        out = orchestrate(_req(vendor, runtime), db_path=db, tx_id_hint=first_tx(db))
        self.assertEqual(out.status, "COMPLETED")
        self.assertEqual(current_bytes(vendor), post1)

    def test_f14_completed_noop_status_only(self):
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        out = orchestrate(_req(vendor, runtime), db_path=db)
        self.assertEqual(out.status, "COMPLETED")
        # COMPLETED is the terminal no-op: recovery returns status only, no write.
        post = current_bytes(vendor)
        from continuity.orchestration.recovery import recover_orchestration
        r = recover_orchestration(db_path=db, tx_id=out.continuity_tx_id,
                                  consequence_plan=_cons())
        self.assertEqual(r.status, "COMPLETED")
        self.assertEqual(current_bytes(vendor), post)


def first_tx(db):
    con = sqlite3.connect(str(db))
    r = con.execute("SELECT continuity_tx_id FROM transaction_journal "
                    "ORDER BY created_at LIMIT 1").fetchone()
    con.close()
    return r[0] if r else None


if __name__ == "__main__":
    unittest.main()
