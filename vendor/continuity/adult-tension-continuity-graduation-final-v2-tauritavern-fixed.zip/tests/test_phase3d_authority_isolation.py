"""Phase 3D — authority / sovereignty isolation through the orchestrator layer.

Safety of the *composition*: adult current-permission is never duplicated or
synthesised and player mental state / desired outcomes never become effects, even
when they sneak inside a consequence plan.  The orchestrator carries them to the
Phase 3C planner which refuses (ownership filter); at no point is a continuity
"current-authority" row created.  This test is a thin guard each time a Phase 3D
path is exercised.
"""
from __future__ import annotations
import json
import sqlite3
import sys
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3b_fixture import make_disposable_vendor, simple_patch
from tests.phase3d_fixture import seed_disposable_db
from continuity.orchestration import orchestrate
from continuity.orchestration.contracts import (
    OrchestrationRequest, ConsequencePlan, OrchestrationStatus,
)


def _cons(extra):
    cons = [{"kind": "EPISODE_APPEND",
             "payload": {"summary": "harmless", "scene_ref": "S"}}]
    cons[0]["payload"].update(extra)
    return ConsequencePlan(consequences=cons)


def _base():
    root, vendor, runtime = make_disposable_vendor()
    db = seed_disposable_db(root)
    return root, vendor, runtime, db


class Phase3dAuthorityIsolationTest(unittest.TestCase):
    def test_no_adult_current_permission_rows_ever(self):
        """Even a consequence payload that tries to smuggle current adult keys is
        not turned into a current-permission row (planner refuses)."""
        samples = [
            {"grant_consent": True, "consent_current": "yes"},
            {"current_permission": "intimacy"},
            {"sexuality_current": "active", "safe_limits": "low"},
        ]
        for payload in samples:
            root, vendor, runtime, db = _base()
            req = OrchestrationRequest(patch=simple_patch(), vendor_dir=str(vendor),
                                       runtime_path=str(runtime),
                                       consequence_plan=_cons(payload))
            out = orchestrate(req, db_path=db)
            # Planner (Phase 3C ownership) rejects any claim-to-current content;
            # an applied runtime is fine but NO continuity effect marker lands.
            con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
            marks = con.execute("SELECT COUNT(*) c FROM continuity_effect_markers").fetchone()["c"]
            episodes = con.execute("SELECT COUNT(*) c FROM episodes").fetchone()["c"]
            tables = con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'").fetchall()
            names = {r["name"] for r in tables}
            con.close()
            self.assertEqual(int(marks), 0,
                             "adult-current payload must never apply a continuity effect")
            self.assertEqual(int(episodes), 0)
            for banned in ("current_permissions", "current_consent",
                           "current_grants", "current_boundaries",
                           "adult_authority_row"):
                self.assertNotIn(banned, names)

    def test_player_nl_does_not_synthesize_relief(self):
        root, vendor, runtime, db = _base()
        req = OrchestrationRequest(
            patch={"then_believes": "she trusts me more"}, vendor_dir=str(vendor),
            runtime_path=str(runtime),
            consequence_plan=ConsequencePlan(consequences=[
                {"kind": "KNOWLEDGE_UPDATE",
                 "payload": {"plane": "CHARACTER", "observer": "E-A",
                             "proposition": "she trusts me more"}}]))
        out = orchestrate(req, db_path=db)
        self.assertEqual(out.status, OrchestrationStatus.REFUSED.value)
        self.assertEqual(int(sqlite3.connect(str(db)).execute(
            "SELECT COUNT(*) FROM knowledge").fetchone()[0]), 0,
            "player desired outcome must never build continuity knowledge")


if __name__ == "__main__":
    unittest.main()
