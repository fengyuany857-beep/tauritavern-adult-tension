"""Phase 3D — boundary scan of the orchestration package + CLIs.

Ensures the top-level orchestrator layer is a pure *composition*:
  - it REUSES Phase 3B commit_single_file and Phase 3C engine — no independent
    runtime/sync writer, classifier, or planner re-written inside orchestration;
  - no os.replace / subprocess / commit_turn invocation directly;
  - no LLM / vector / graph "recovery";
  - the CLIs do not expose any outcome-override / same-tx-retry / rollback /
    assume-applied / force / skip-outcome-check flags;
  - production real-save default refused + disposable guard present.
"""
from __future__ import annotations
import ast
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT / "continuity" / "orchestration"
CLI = {
    "turn": ROOT / "scripts" / "orchestrate_turn.py",
    "status": ROOT / "scripts" / "orchestration_status.py",
    "recover": ROOT / "scripts" / "recover_orchestration.py",
}

FORBIDDEN_FLAGS = (
    "--force", "--ignore-precondition", "--retry-same-tx", "--rollback-runtime",
    "--assume-applied", "--assume-not-applied", "--skip-outcome-check",
)
# Runtime/sync writer machinery that must NOT appear in the composition package
# (it is owned by the correctly-gated lower phases it re-uses).
FORBIDDEN_MACHINERY = (
    "subprocess.run", "Popen", "os.replace(", "commit_turn.module", "write_text(",
    "write_bytes(", "mkstemp(", "OpenAI", "ChatCompletion", "Anthropic",
    "execute_commit", "async_import",
)


def _files(search: Path):
    return [p for p in search.rglob("*.py") if p.name != "__init__.py"]


def _module_calls_names(path: Path):
    try:
        tree = ast.parse(path.read_text())
    except SyntaxError:
        return set(), set()
    calls, names = set(), set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Attribute):
                calls.add(node.func.attr)
            elif isinstance(node.func, ast.Name):
                calls.add(node.func.id)
        if isinstance(node, ast.Import):
            for a in node.names:
                names.add(a.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            names.add(node.module or "")
    return calls, names


class Phase3dBoundaryScanTest(unittest.TestCase):
    def test_orchestration_reuses_phase3b_and_phase3c(self):
        """The package must import & call the real Runtime/3C entry points."""
        blob = "\n".join(p.read_text() for p in _files(PKG))
        self.assertIn("from ..runtime3b.execute import commit_single_file", blob)
        self.assertIn("ContinuitySyncEngine", blob)
        self.assertIn("prepare_transaction", blob)      # reuse 3A (indirect via orchestrator)

    def test_no_independent_writer_plumbing(self):
        """Orchestration itself never spawns runtime/sync writes or LLM calls."""
        for p in _files(PKG):
            text = p.read_text()
            calls, names = _module_calls_names(p)
            for mach in FORBIDDEN_MACHINERY:
                self.assertNotIn(mach, text, f"{p.name}: forbidden machinery {mach}")
            self.assertFalse(calls & {"Popen", "subprocess"})
            self.assertFalse(names & {"openai", "anthropic", "langchain"})

    def test_cli_does_not_register_forbidden_flags(self):
        """Forbidden flags must not be registered as CLI options (even if the
        module docstring explains they are forbidden)."""
        for name, f in CLI.items():
            if not f.exists():
                continue
            tree = ast.parse(f.read_text())
            for node in ast.walk(tree):
                if isinstance(node, ast.Call) and getattr(node.func, "id", "") == "add_argument":
                    for a in node.args:
                        if isinstance(a, ast.Constant) and isinstance(a.value, str):
                            self.assertNotIn(a.value, FORBIDDEN_FLAGS,
                                             f"{f.name}: forbidden option {a.value}")
            if "turn" in name:
                text = f.read_text().lower()
                self.assertIn("--disposable-runtime", text)
                self.assertIn("refuse", text)

    def test_code_no_force_assume_override(self):
        """Any "assume_applied" string is only in comments/error text about it
        being forbidden — never a callable force mechanism."""
        calls, _ = _module_calls_names(PKG / "orchestrator.py")
        self.assertNotIn("assume_applied", calls)
        self.assertNotIn("mark_applied", calls)
        self.assertNotIn("force_apply", calls)
        self.assertNotIn("operator_override", calls)

    def test_cli_default_no_real_save_mutation(self):
        txt = (CLI["turn"].read_text() if CLI["turn"].exists() else "").lower()
        self.assertIn("fail-safe", txt)
        self.assertIn("refuse", txt)

    def test_error_no_chain_of_thought_factory(self):
        blob = "\n".join(p.read_text() for p in _files(PKG))
        for word in ("chain_of_thought", "hidden_reasoning", "scratchpad"):
            self.assertNotIn(word, blob)


if __name__ == "__main__":
    unittest.main()
