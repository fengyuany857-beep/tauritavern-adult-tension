"""Focused regressions for the graduation blocker repair.

All fixtures are ordinary synthetic state/identity data.  No narrative or
sensitive behavior is generated or exercised.
"""
from __future__ import annotations

import json
import os
import sqlite3
import unittest
from pathlib import Path
from unittest import mock

from continuity.orchestration import orchestrate
from continuity.orchestration.contracts import OrchestrationRequest, ConsequencePlan
from continuity.orchestration.orchestrator import Orchestrator
from continuity.retrieval import Context, RetrievalQuery, TemporalRetriever
from continuity.routing import ContextPackBuilder, RoutingRequest
from continuity.runtime3b.durability import DirectoryFsyncResult, DirFsyncStatus
from continuity.sync3c.contracts import EffectKind
from continuity.sync3c.engine import ContinuitySyncEngine
from continuity.sync3c.planner import PlanError, build_plan
from continuity.sync3c.projector import EvidenceProjector, scan_volume
from continuity.sync3c.sqlwriter import EffectApplyError, effect_sql
from tests.context_builder_fixture import build_context_base, runtime_state_path
from tests.phase3b_fixture import make_disposable_vendor, simple_patch, current_bytes
from tests.phase3c_fixture import (build_request, connect, make_journal_state,
                                   seed_disposable_db_current)
from tests.phase3d_fixture import seed_disposable_db


def _node(predicate: str, **payload):
    return {"kind": "FACT_INSERT", "payload": {
        "subject_ref": "E-A", "predicate": predicate,
        "object": {"synthetic": True}, **payload}}


def _sync_request(nodes):
    return build_request(
        tx_id="tx-structural", branch_id="default", consequences=nodes,
        observed_post_sha256="a" * 64,
        observed_post_semantic_digest="b" * 64,
        expected_candidate_digest="c" * 64)


def _plan(summary: str, *, reverse_keys: bool = False) -> ConsequencePlan:
    payload = ({"scene_ref": "SYNTH", "summary": summary}
               if reverse_keys else {"summary": summary, "scene_ref": "SYNTH"})
    return ConsequencePlan(consequences=[{
        "kind": "EPISODE_APPEND", "payload": payload}])


def _request(vendor: Path, runtime: Path, plan: ConsequencePlan) -> OrchestrationRequest:
    return OrchestrationRequest(
        patch=simple_patch(), vendor_dir=str(vendor), runtime_path=str(runtime),
        consequence_plan=plan)


def _first_tx(db: Path) -> str:
    con = sqlite3.connect(str(db))
    try:
        return con.execute(
            "SELECT continuity_tx_id FROM transaction_journal ORDER BY created_at"
        ).fetchone()[0]
    finally:
        con.close()


class StructuralAuthorityFirewall(unittest.TestCase):
    def test_planner_rejects_structural_variants_and_spoofing(self):
        bad = [
            _node("boundary.current"),
            _node("current.boundary"),
            _node("runtime.synthetic.current"),
            _node("player.synthetic_desire", subject_ref="E-PL"),
            _node("synthetic_desire", subject_ref="E-PL"),
            _node("ordinary.fact", plane="PLAYER_VISIBLE"),
            _node("ordinary.fact", classification="DERIVED_REBUILDABLE"),
        ]
        for node in bad:
            with self.subTest(node=node), self.assertRaises(PlanError):
                build_plan(_sync_request([node]))

    def test_writer_revalidates_without_planner(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            db = seed_disposable_db_current(Path(td))
            con = connect(db)
            con.execute(
                "INSERT INTO entities VALUES (?,?,?,?,?,?,?)",
                ("opaque-player", "default", "player", "plr-ext", "confirmed", "{}", "[]"))
            scope = {"continuity_tx_id": "tx-writer", "branch_id": "default",
                     "effect_id": "effect-writer", "plan_digest": "d", "turn": 1}
            with self.assertRaises(EffectApplyError):
                effect_sql(con, EffectKind.FACT_INSERT, {
                    "subject_ref": "opaque-player", "predicate": "synthetic_desire",
                    "object": {"synthetic": True}}, scope)
            with self.assertRaises(EffectApplyError):
                effect_sql(con, EffectKind.FACT_INSERT, {
                    "subject_ref": "E-A", "predicate": "current.boundary",
                    "object": {"synthetic": True}}, scope)
            self.assertEqual(con.execute("SELECT COUNT(*) FROM facts").fetchone()[0], 0)
            con.close()

    def test_legacy_bad_rows_do_not_surface_in_retrieval_or_context_pack(self):
        tmp, base = build_context_base()
        self.addCleanup(tmp.cleanup)
        db = base / "state" / "continuity.sqlite3"
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        rows = [
            ("F-BAD-A", "E-A", "boundary.current"),
            ("F-BAD-P", "E-PL", "synthetic_desire"),
        ]
        for fid, subject, predicate in rows:
            con.execute(
                "INSERT INTO facts (fact_id,branch_id,subject_ref,predicate,object_json,"
                "plane,admission_state,truth_status,valid_from_turn,invalid_at_turn,"
                "recorded_at_turn,recorded_at,provenance_json,classification) "
                "VALUES (?,?,?,?,?,'OBJECTIVE','COMMITTED','ACTIVE',1,NULL,1,?,?,?)",
                (fid, "default", subject, predicate, json.dumps({"synthetic": True}),
                 "2026-01-01T00:00:00+00:00", "{}", "AUTHORITY"))
        con.commit()
        ctx = Context(conn=con, base=base,
                      index_path=base / "indexes" / "retrieval_fts.sqlite3")
        result = TemporalRetriever().retrieve(
            RetrievalQuery(branch_id="default", event_turn=10, query_id="shadow"), ctx)
        ids = {item.item_id for item in result.items}
        self.assertFalse({"F-BAD-A", "F-BAD-P"} & ids)
        con.close()

        pack = ContextPackBuilder(base).build(
            RoutingRequest(raw_text="synthetic check", branch_id="default",
                           query_id="shadow-pack", scene_entity_ids=("E-A", "E-PL"),
                           observer_entity_id="E-A"),
            runtime_state=runtime_state_path(base))
        refs = {item.source_ref for item in pack.items}
        self.assertFalse({"F-BAD-A", "F-BAD-P"} & refs)


class PreparedPlanBinding(unittest.TestCase):
    def test_f8_changed_plan_fails_closed_without_runtime_retry_or_sync(self):
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        plan_a, plan_b = _plan("synthetic A"), _plan("synthetic B")
        with self.assertRaises(RuntimeError):
            Orchestrator(db_path=db, fault_on="F8").orchestrate(
                _request(vendor, runtime, plan_a))
        tx = _first_tx(db)
        post = current_bytes(vendor)
        out = orchestrate(_request(vendor, runtime, plan_b), db_path=db,
                          tx_id_hint=tx)
        self.assertEqual(out.status, "MANUAL_REVIEW_REQUIRED")
        self.assertEqual(current_bytes(vendor), post)
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        row = con.execute("SELECT attempt_count, staged_sync_digest, state FROM "
                          "transaction_journal WHERE continuity_tx_id=?", (tx,)).fetchone()
        self.assertEqual(row["attempt_count"], 1)
        self.assertTrue(row["staged_sync_digest"])
        self.assertNotEqual(row["state"], "COMPLETED")
        self.assertEqual(con.execute("SELECT COUNT(*) FROM continuity_sync_executions").fetchone()[0], 0)
        con.close()

    def test_f8_canonical_equivalent_plan_resumes(self):
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        with self.assertRaises(RuntimeError):
            Orchestrator(db_path=db, fault_on="F8").orchestrate(
                _request(vendor, runtime, _plan("synthetic A")))
        tx = _first_tx(db)
        post = current_bytes(vendor)
        out = orchestrate(_request(vendor, runtime,
                                   _plan("synthetic A", reverse_keys=True)),
                          db_path=db, tx_id_hint=tx)
        self.assertEqual(out.status, "COMPLETED")
        self.assertEqual(current_bytes(vendor), post)


class EvidenceFsyncGate(unittest.TestCase):
    def _pending(self):
        cons = [_node("ordinary.note")]
        db, tx, _, req = make_journal_state(
            "CONTINUITY_SYNC_PENDING", consequences=cons)
        vol = Path(db).parent / "history" / "VOL-001.jsonl"
        con = connect(db)
        eng = ContinuitySyncEngine(con, evidence_path=vol, auto_project=False)
        eng.sync_applied_transaction(req)
        return db, tx, vol, con, eng

    def test_append_fsync_failure_stays_pending_then_delivers_once(self):
        db, tx, vol, con, eng = self._pending()
        with mock.patch("continuity.sync3c.projector.os.fsync",
                        side_effect=OSError("synthetic fsync failure")):
            result = eng.drain_outbox()
        self.assertTrue(result["errors"])
        self.assertEqual(con.execute("SELECT state FROM history_outbox").fetchone()[0], "PENDING")
        self.assertNotEqual(con.execute("SELECT state FROM transaction_journal").fetchone()[0], "COMPLETED")
        eng.drain_outbox()
        eng.finalize_if_ready(tx, {})
        records, _, _ = scan_volume(vol)
        self.assertEqual(len(records), 1)
        self.assertEqual(con.execute("SELECT state FROM history_outbox").fetchone()[0], "DELIVERED")
        con.close()

    def test_truncation_fsync_failure_is_quarantined_without_delivery(self):
        db, tx, vol, con, eng = self._pending()
        vol.parent.mkdir(parents=True, exist_ok=True)
        vol.write_bytes(b'{"envelope_id":"partial"')
        with mock.patch("continuity.sync3c.projector.os.fsync",
                        side_effect=OSError("synthetic truncate fsync failure")):
            result = eng.drain_outbox()
        self.assertTrue(result["quarantines"])
        self.assertEqual(con.execute("SELECT state FROM history_outbox").fetchone()[0], "PENDING")
        self.assertNotEqual(con.execute("SELECT state FROM transaction_journal").fetchone()[0], "COMPLETED")
        con.close()


class DirectoryFsyncManualGate(unittest.TestCase):
    def test_failed_directory_fsync_blocks_sync_and_completion(self):
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        failed = DirectoryFsyncResult(
            attempted=True, supported=True, succeeded=False,
            status=DirFsyncStatus.FAILED, error_class="OSError",
            error_detail_bounded="synthetic directory fsync failure")
        with mock.patch("continuity.runtime3b.execute.perform_directory_fsync",
                        return_value=failed):
            out = orchestrate(_request(vendor, runtime, _plan("synthetic")), db_path=db)
        self.assertEqual(out.status, "MANUAL_REVIEW_REQUIRED")
        self.assertTrue(out.manual_review_required)
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        row = con.execute("SELECT * FROM transaction_journal").fetchone()
        self.assertEqual(row["attempt_count"], 1)
        self.assertEqual(row["durability_status"], "DIR_FSYNC_FAILED")
        self.assertEqual(row["manual_review_required"], 1)
        self.assertNotEqual(row["state"], "COMPLETED")
        self.assertEqual(con.execute("SELECT COUNT(*) FROM continuity_sync_executions").fetchone()[0], 0)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM history_outbox").fetchone()[0], 0)
        post = current_bytes(vendor)
        out2 = orchestrate(_request(vendor, runtime, _plan("synthetic")),
                           db_path=db, tx_id_hint=row["continuity_tx_id"])
        self.assertEqual(out2.status, "MANUAL_REVIEW_REQUIRED")
        self.assertTrue(out2.manual_review_required)
        self.assertEqual(current_bytes(vendor), post)
        self.assertEqual(con.execute("SELECT attempt_count FROM transaction_journal").fetchone()[0], 1)
        con.close()


class BoundedJsonValidity(unittest.TestCase):
    def test_oversized_object_is_rejected_without_invalid_json(self):
        db, tx, _, req = make_journal_state(
            "CONTINUITY_SYNC_PENDING",
            consequences=[_node("ordinary.large", object={"v": "x" * 5000})])
        con = connect(db)
        eng = ContinuitySyncEngine(con, auto_project=False)
        with self.assertRaises(Exception):
            eng.sync_applied_transaction(req)
        rows = con.execute("SELECT object_json FROM facts").fetchall()
        self.assertTrue(all(json.loads(row[0]) is not None for row in rows))
        self.assertEqual(len(rows), 0)
        con.close()


if __name__ == "__main__":
    unittest.main()
