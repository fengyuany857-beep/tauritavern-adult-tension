import tempfile,unittest
from pathlib import Path
from continuity.db import connect
from continuity.manifest import build,write,load
class T(unittest.TestCase):
 def test_manifest(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);c=connect(p/'d.sqlite3');c.close();m=build(p/'d.sqlite3',p/'V.jsonl',{'x':'y'});write(p/'m.json',m);self.assertEqual(1,load(p/'m.json')['schema_version'])
