"""Shared fixture factory for Phase 2B-1 Context Pack tests (read-only)."""
from __future__ import annotations
import json
import tempfile
from pathlib import Path

from continuity.db import connect
from continuity.history import HistoryIntegrityError, append_envelope


def _ins(cur, sql, *p):
    cur.execute(sql, p)


def build_context_base():
    """Return (tmpdir, base) of a fresh sidecar DB + history volume seeded with
    a scenario configured for builder unit tests.

    Scenario:
      entities E-PL (player), E-A (npc A), E-B (npc B), E-OLD (long-absent),
      E-OFF (offscreen npc, not a current participant).
      A knows SECRET (CHARACTER, 'knows'); A also has an EXPLICIT did-not-know
      restriction on PROP-B; B has no knowledge rows at all.
      E-A non-capabilities: {"roar"}.
      A current relationship to player (high trust/attraction dims) + a *2A-style*
      relationship edge with an intimacy/consent historical ref.
      Commitments: A->player open promise due; B->player unrelated open promise.
      threads TH-S w/ reveal gate (prereq a superseeded/absent ref) -> gate unmet;
      TH-OK with no gate; anti-merge between TH-OK and TH-S.
      facts: canonical current on branch 'default' valid (turn 10..None rec 8),
        one ACTIVE off-scene/branch 'default' for nonparticipant E-OFF,
        one SUPERSEDED lineage fact F-SUP / F-SUP2,
        one future-recorded fact valid_from_turn=200 but recorded at turn 500,
        one fact in wrong branch 'alt'.
      history episode EP-new recent (con. tx) and EP-old older (same or next tx),
        EP-wrong branch excluded.
    """
    tmp = tempfile.TemporaryDirectory()
    base = Path(tmp.name)
    for sub in ("state", "indexes", "manifests", "history"):
        (base / sub).mkdir(parents=True, exist_ok=True)
    conn = connect(base / "state" / "continuity.sqlite3")
    cur = conn.cursor()

    def entity(eid, branch="default", cap=None, non=()):
        nonj = json.dumps(list(non))
        if cap is None:
            cap = json.dumps({"canonical_name": eid})
        _ins(cur, "INSERT INTO entities (entity_id,branch_id,kind,runtime_external_ref,identity_status,anchors_json,explicit_non_capabilities_json) VALUES (?,?,?,?,?,?,?)",
             eid, branch, "npc" if not eid.startswith("E-PL") else "player",
             eid + "-ext", "confirmed", cap, nonj)

    entity("E-PL", non=())
    entity("E-A", non=["roar"])
    entity("E-B", non=[])
    entity("E-OLD", non=[])
    entity("E-OFF", non=[])

    def fact(fid, subject, pred, obj, *,
             truth="ACTIVE", vf=None, inv=None, rec=None, branch="default",
             plane="OBJECTIVE", cls="AUTHORITY"):
        if rec is None:
            rec = vf if vf is not None else 1
        if inv is not None and truth != "ACTIVE":
            inv = None
        _ins(cur,
             "INSERT INTO facts (fact_id,branch_id,subject_ref,predicate,object_json,plane,admission_state,truth_status,"
             "valid_from_turn,invalid_at_turn,recorded_at_turn,recorded_at,provenance_json,classification) "
             "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
             fid, branch, subject, pred, json.dumps(obj), plane, "COMMITTED", truth,
             vf, inv, rec, "2026-01-01T00:00:00+00:00", json.dumps({"source": "ctx"}), cls)

    # canonical current facts
    fact("F-EA-CANON", "E-A", "works", {"place": "CLINIC"}, vf=10, rec=8)
    fact("F-PL-K", "E-PL", "lives", {"city": "harbor"}, vf=2, rec=2)
    fact("F-OFF", "E-OFF", "guards", {"site": "vault"}, vf=2, rec=2)          # offscreen
    fact("F-OBJD", "E-B", "owns", {"tool": "knife"}, vf=1, rec=1)           # B canon
    # superseded lineage on branch default
    fact("F-SUP", "E-A", "was.called", {"name": "OldName"}, truth="SUPERSEDED", vf=1, inv=20, rec=20)
    fact("F-SUP2", "E-A", "was.called", {"name": "NewName"}, truth="ACTIVE", vf=20, rec=20)
    # future-recorded (retroactive) fact: valid from turn 200 but only recorded at 500
    fact("F-RETRO", "E-A", "entered", {"where": "contract"}, vf=200, rec=500)
    # wrong branch
    fact("F-ALT", "E-OLD", "guarded", {"branch": "gate"}, branch="alt", vf=1, rec=1)

    def know(kid, subject, state, prop, turn=1, plane="CHARACTER"):
        _ins(cur, "INSERT INTO knowledge (knowledge_id,branch_id,subject_ref,proposition_ref,state,plane,source,promotion_basis,turn,provenance_json) "
                  "VALUES (?,?,?,?,?,?,?,?,?,?)",
             kid, "default", subject, prop, state, plane, "witnessed", "witnessed", turn, "{}")

    know("K-A-SEC", "E-A", "knows", "PROP-secret", turn=5)          # A knows secret
    know("K-A-RESTRICT", "E-A", "does_not_know", "PROP-B", turn=5)  # explicit restriction
    know("K-A-FB", "E-A", "false_belief", "PROP-door", turn=5)      # false belief POV
    know("K-PL", "E-PL", "knows", "PROP-own-apple", turn=2)          # player knows own
    know("K-PV", "narrator", "knows", "PROP-hint", turn=3, plane="PLAYER_VISIBLE")  # narration plane
    # no E-B knowledge rows (for isolation / does_not_know-not-inferred tests)

    def rel(rid, s, t, phase):
        _ins(cur, "INSERT INTO relationships (relationship_id,branch_id,source_ref,target_ref,runtime_refs_json,public_surface,actual_relation,phase,provenance_json) "
                  "VALUES (?,?,?,?,?,?,?,?,?)",
             rid, "default", s, t, json.dumps([{"kind": s + "history", "ref": "EP-H"}]), "warm", "close", phase, "{}")
        for dim_name, val in (("trust", "high"), ("attraction", "high")):
            _ins(cur, "INSERT INTO relationship_dimensions (dimension_id,relationship_id,name,value_json,classification) "
                      "VALUES (?,?,?,?,?)",
                 f"dim-{rid}-{dim_name}", rid, dim_name, json.dumps(val), "AUTHORITY")

    rel("REL-A", "E-A", "E-PL", "intimate")   # historical intimacy edge (context only)
    rel("REL-B", "E-B", "E-PL", "colleague")

    def commit(cid, issuer, content, status="open", bens=None):
        bens = [] if bens is None else list(bens)
        _ins(cur, "INSERT INTO commitments (commitment_id,branch_id,kind,issuer_ref,beneficiary_refs_json,content,status,runtime_event_ref,provenance_json) "
                  "VALUES (?,?,?,?,?,?,?,?,?)",
             cid, "default", "promise" if status != "debt" else "debt",
             issuer, json.dumps(bens), content, status, None, "{}")

    commit("COM-A", "E-A", "will call at new year", bens=["E-PL"])     # due/open
    commit("COM-B", "E-B", "return a book", status="open", bens=["E-PL"])  # unrelated-ish B
    commit("COM-RES", "E-A", "old resolved", status="resolved", bens=["E-PL"])  # resolved

    # threads: TH-S has unmet reveal gate (requires missing F-NOPE), anti-merge with TH-OK
    for tid, gate in (("TH-S", {"requires": ["F-NOPE"]}), ("TH-OK", {})):
        _ins(cur,
             "INSERT INTO threads (thread_id,branch_id,status,author_state,objective_state,player_visible_state,reveal_gate_json,presentation_json,provenance_json) "
             "VALUES (?,?,?,?,?,?,?,?,?)",
             tid, "default", "active", "a", "o" if tid == "TH-OK" else "secret-sapphire-cache",
             "p", json.dumps(gate), "{}", "{}")
    _ins(cur, "INSERT INTO thread_requires (require_id,thread_id,ref,expected_state,plane) VALUES (?,?,?,?,?)",
         "TR-NOPE", "TH-S", "F-NOPE", "ACTIVE", "OBJECTIVE")
    _ins(cur, "INSERT INTO thread_anti_merge (anti_merge_id,thread_id,blocked_ref,reason) VALUES (?,?,?,?)",
         "AM-S", "TH-S", "TH-OK", "two distinct mysteries")

    # continuity transactions + episodes (recent vs old; wrong branch excluded)
    tx = [
        ("TX-EP-NEW", "2026-06-01T00:00:00+00:00", "EP-new", "SC-3", 8, 9),
        ("TX-EP-OLD", "2026-01-01T00:00:00+00:00", "EP-old", "SC-1", 2, 3),
        ("TX-EP-W", "2026-02-01T00:00:00+00:00", "EP-alt", "SC-9", 4, 5),
    ]
    for tid_, created, ep, scene, t0, t1 in tx:
        _ins(cur, "INSERT INTO continuity_transactions VALUES (?,?,?,?,?,?,?,?)",
             tid_, "commit", "pre", "post", "COMMITTED", created, None, None)
        _ins(cur, "INSERT INTO episodes (episode_id,continuity_tx_id,branch_id,runtime_pre_hash,runtime_post_hash,history_pointer,checksum) "
                  "VALUES (?,?,?,?,?,?,?)",
             ep, tid_, "default" if ep != "EP-alt" else "alt", "pre", "post",
             f"VOL-{ep}.jsonl", "x")
    conn.commit()

    # one history volume with the recent and old episodes so EvidenceRetriever works
    labels = [
        ("EP-new", "TX-EP-NEW", "quiet talk about sapphire cache revealed"),
        ("EP-old", "TX-EP-OLD", "earliest conversation in the harbor clinic"),
        ("EP-alt", "TX-EP-W", "gate scene on the wrong branch"),
    ]
    for ep, txid, smry in labels:
        append_envelope(base / "history" / (txid + ".jsonl"), {
            "branch_id": "default" if ep != "EP-alt" else "alt",
            "episode_id": ep, "transaction_id": txid,
            "runtime_pre_hash": "pre", "runtime_post_hash": "post",
            "payload_classification": "HISTORICAL_EVIDENCE", "source_references": [],
            "scene_id": "SC-1" if ep == "EP-old" else ("SC-3" if ep != "EP-alt" else "SC-9"),
            "participants": ["E-A", "E-PL"] if ep != "EP-alt" else ["E-OLD"],
            "turn_start": 8 if ep == "EP-new" else (2 if ep == "EP-old" else 4),
            "turn_end": 9 if ep == "EP-new" else (3 if ep == "EP-old" else 5),
            "summary": smry,
        })
    conn.close()
    return tmp, base


def runtime_state_path(base: Path, *, participants=("E-A", "E-PL"), turn=8) -> Path:
    snap = {
        "meta": {"turn": turn},
        "world": {"clock": "2026-06-01T00:00:00+00:00"},
        "current_node": {"scene_id": "SC-3", "participants": list(participants)},
        "player": {"id": "E-PL", "knowledge": []},
        "npcs": [{"id": p, "knowledge": [], "recent_memories": []}
                 for p in participants if p != "E-PL"],
        "relationships": [],
        "consent": {"grants": []},
        "boundaries": [],
        "checkpoint": {},
    }
    path = base / "state" / "runtime_fixture.json"
    path.write_text(json.dumps(snap, sort_keys=True), encoding="utf-8")
    return path
