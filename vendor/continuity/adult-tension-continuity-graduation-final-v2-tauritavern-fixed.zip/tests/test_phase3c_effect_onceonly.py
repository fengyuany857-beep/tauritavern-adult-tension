"""Phase 3C — effect once-only, atomic SQLite sync, replay equivalence.

Covers §27 items 11-20 + the Sol §10 invariant:
  after any N>=1 sync invocations of one CONFIRMED_APPLIED tx, the authority
  table multiset, effect-marker set, episode identity, outbox set equal those
  after N=1.

- first sync applies every effect;
- second replay creates 0 duplicates (episode once-only, fact once-only,
  relationship historical once-only, commitment effect once-only, thread once);
- a failure inside the single SQLite authority transaction (an effect that
  raises partway) leaves NO half-authority writes (atomicity + rollback).
"""
from __future__ import annotations
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
import json

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3c_fixture import make_journal_state, seed_authority_base, connect
from continuity.sync3c.engine import ContinuitySyncEngine, SyncEngineError
from continuity.sync3c.sqlwriter import effect_sql, EffectApplyError
from continuity.transactions.contracts import TransactionState


def _cons(kind, payload):
    return {"kind": kind, "payload": payload}


def sample_consequences():
    return [
        _cons("EPISODE_APPEND", {"summary": "event 1 continued", "scene_ref": "SC-1"}),
        _cons("FACT_INSERT", {"subject_ref": "E-A", "predicate": "visited",
                              "object": {"place": "harbor"}, "valid_from_turn": 1}),
        _cons("FACT_INSERT", {"subject_ref": "E-B", "predicate": "borrowed",
                              "object": {"tool": "book"}, "valid_from_turn": 2}),
        _cons("RELATIONSHIP_SEMANTIC_UPDATE",
              {"source_ref": "E-A", "target_ref": "E-PL",
               "semantic_name": "shared_harbor_moment", "history_pointer": "HP-1"}),
        _cons("COMMITMENT_HISTORICAL_EFFECT",
              {"commitment_id": "COM-A", "effect_type": "fulfilled",
               "status_transition": "resolved"}),
    ]


class EffectOnceOnlyTests(unittest.TestCase):
    def _db_row_counts(self, con):
        out = {}
        for t in ("episodes", "facts", "episode_entity_links", "episode_fact_links",
                  "fact_supersessions", "knowledge", "relationships",
                  "relationship_dimensions", "commitments", "threads",
                  "continuity_transactions"):
            out[t] = con.execute(f"SELECT COUNT(*) c FROM {t}").fetchone()["c"]
        return out

    def _run_engine(self, db, req, hist_parent):
        con = connect(db)
        eng = ContinuitySyncEngine(con, evidence_path=hist_parent)
        return eng, con

    def test_first_sync_applies_then_replay_zero_duplicates(self):
        db, tx, row, req = make_journal_state(
            "CONTINUITY_SYNC_PENDING", consequences=sample_consequences())
        hist = Path(db).parent / "history"
        hist.mkdir(parents=True, exist_ok=True)
        vol = hist / "VOL-001.jsonl"
        con = connect(db)
        # authority base the effects reference
        seed_authority_base(db, entities=("E-A", "E-B"),
                            commit_ids=[("COM-A", "E-A", "will return book", "open")])
        eng = ContinuitySyncEngine(con, evidence_path=vol)
        res1 = eng.sync_applied_transaction(req)
        self.assertEqual(res1["n_effects"], 5)
        self.assertEqual(res1["status"], "COMPLETED")

        after1 = self._db_row_counts(con)
        marker_after1 = con.execute("SELECT COUNT(*) c FROM continuity_effect_markers "
                                    "WHERE continuity_tx_id=?", (tx,)).fetchone()["c"]
        ep_ids1 = {r[0] for r in con.execute("SELECT episode_id FROM episodes")}
        outbox1 = {r[0] for r in con.execute("SELECT envelope_id FROM history_outbox")}

        # second identical replay -> 0 duplicates
        res2 = eng.sync_applied_transaction(req)
        self.assertTrue(res2.get("replay"))
        self.assertEqual(res2["status"], "ALREADY_SYNCED")
        after2 = self._db_row_counts(con)
        marker_after2 = con.execute(
            "SELECT COUNT(*) c FROM continuity_effect_markers WHERE continuity_tx_id=?",
            (tx,)).fetchone()["c"]
        ep_ids2 = {r[0] for r in con.execute("SELECT episode_id FROM episodes")}
        outbox2 = {r[0] for r in con.execute("SELECT envelope_id FROM history_outbox")}
        self.assertEqual(after1, after2)
        self.assertEqual(marker_after1, marker_after2)
        self.assertEqual(ep_ids1, ep_ids2)
        self.assertEqual(outbox1, outbox2)
        # even a third independent invoker sees the same multiset (N=3 == N=1)
        con.close()

    def test_runtime_bytes_unchanged_during_sync(self):
        db, tx, row, req = make_journal_state("CONTINUITY_SYNC_PENDING",
                                              consequences=sample_consequences())
        seed_authority_base(db, commit_ids=[("COM-A", "E-A", "will return book", "open")])
        vol = Path(db).parent / "history" / "VOL-001.jsonl"
        con = connect(db)
        eng = ContinuitySyncEngine(con, evidence_path=vol)
        eng.sync_applied_transaction(req)
        # engine completed; runtime is never written during a Phase 3C sync
        self.assertEqual(con.execute("SELECT COUNT(*) c FROM continuity_sync_executions "
                                     "WHERE continuity_tx_id=?", (tx,)).fetchone()["c"], 1)
        con.close()

    def test_atomic_sqlite_transaction_rollback_on_effect_failure(self):
        # First effect succeeds, second (malformed relationship semantic) fails.
        # The whole single tx must roll back leaving zero authority writes.
        db, tx, row, req = make_journal_state(
            "CONTINUITY_SYNC_PENDING",
            consequences=[
                _cons("EPISODE_APPEND", {"summary": "half", "scene_ref": "SC-2"}),
                _cons("RELATIONSHIP_SEMANTIC_UPDATE",
                      {"source_ref": "E-A", "target_ref": "E-PL"}),  # no semantic_name -> error
            ])
        vol = Path(db).parent / "history" / "VOL-001.jsonl"
        con = connect(db)
        eng = ContinuitySyncEngine(con, evidence_path=vol)
        with self.assertRaises(SyncEngineError) as cm:
            eng.sync_applied_transaction(req)
        self.assertEqual(cm.exception.review_reason, "OWNERSHIP")
        # no half-authority write, no markers committed, no sync_execution
        self.assertEqual(con.execute("SELECT COUNT(*) c FROM episodes").fetchone()["c"], 0)
        self.assertEqual(con.execute("SELECT COUNT(*) c FROM facts").fetchone()["c"], 0)
        self.assertEqual(con.execute("SELECT COUNT(*) c FROM continuity_effect_markers "
                                     "WHERE continuity_tx_id=?", (tx,)).fetchone()["c"], 0)
        self.assertEqual(con.execute("SELECT COUNT(*) c FROM continuity_sync_executions "
                                     "WHERE continuity_tx_id=?", (tx,)).fetchone()["c"], 0)
        # journal must be rolled back to CONTINUITY_SYNC_PENDING (replay-safe)
        st = dict(con.execute("SELECT state FROM transaction_journal WHERE continuity_tx_id=?",
                              (tx,)).fetchone())
        self.assertEqual(st["state"], TransactionState.CONTINUITY_SYNC_PENDING.value)
        con.close()


def _rebuild(req, cons):
    from continuity.sync3c.contracts import ContinuitySyncRequest
    return ContinuitySyncRequest(
        continuity_tx_id=req.continuity_tx_id,
        runtime_outcome_class="CONFIRMED_APPLIED",
        observed_post_sha256=req.observed_post_sha256,
        observed_post_semantic_digest=req.observed_post_semantic_digest,
        expected_candidate_digest=req.expected_candidate_digest,
        patch_digest=req.patch_digest, branch_id="default",
        source_provenance=req.source_provenance,
        request_provenance=req.request_provenance,
        sync_plan_bytes_digest="", consequences=cons)


if __name__ == "__main__":
    unittest.main()
