"""Focused regressions for final GPT graduation Fix2.

Only synthetic structural data is used. No narrative/adult-content behavior is
constructed or exercised.
"""
from __future__ import annotations

import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from continuity.constants import AdmissionState, Classification, Plane, TruthStatus
from continuity.models import FactInput
from continuity.orchestration import orchestrate
from continuity.orchestration.contracts import OrchestrationRequest, ConsequencePlan
from continuity.retrieval import Context, RetrievalQuery, TemporalRetriever, LexicalRetriever, LedgerRetriever
from continuity.routing import ContextPackBuilder, RoutingRequest
from continuity.runtime3b.durability import DurabilityProbe, DirectoryFsyncResult, DirFsyncStatus
from continuity.validation import (insert_fact, is_runtime_owned_predicate,
                                   is_player_internal_predicate)
from continuity.errors import AuthorityError
from tests.context_builder_fixture import build_context_base, runtime_state_path
from tests.phase3b_fixture import make_disposable_vendor, simple_patch, current_bytes
from tests.phase3c_fixture import seed_disposable_db_current
from tests.phase3d_fixture import seed_disposable_db


BAD_RUNTIME_PREDICATES = (
    "boundary.current", "current.boundary", "current_boundary", "CurrentBoundary",
    "currentboundary", "currentpermission", "currentsafety", "currenttrust",
    "currentrelationship", "currentemotion", "currentgoal", "currentlocation",
    "currentscene", "currentturn", "sexuality_profile", "sexualityprofile",
    "trust", "trust.level", "emotion", "goal.current_value", "location",
)
BAD_PLAYER_PREDICATES = (
    "playerfeeling", "playerintention", "playerdesire", "playermental",
    "playerinternal", "privateintent",
)


def _plan_fact(predicate: str, subject: str = "E-A") -> ConsequencePlan:
    return ConsequencePlan(consequences=[{
        "kind": "FACT_INSERT",
        "payload": {"subject_ref": subject, "predicate": predicate,
                    "object": {"synthetic": True}},
    }])


def _request(vendor: Path, runtime: Path, plan: ConsequencePlan) -> OrchestrationRequest:
    return OrchestrationRequest(
        patch=simple_patch(), vendor_dir=str(vendor), runtime_path=str(runtime),
        consequence_plan=plan)


class CompactAuthorityFirewallFix2(unittest.TestCase):
    def test_compact_predicate_classifier_closes_reported_matrix(self):
        for predicate in BAD_RUNTIME_PREDICATES:
            with self.subTest(predicate=predicate):
                self.assertTrue(is_runtime_owned_predicate(predicate))
        for predicate in BAD_PLAYER_PREDICATES:
            with self.subTest(predicate=predicate):
                self.assertTrue(is_player_internal_predicate(predicate))

    def test_phase1_insert_rejects_compact_runtime_and_opaque_player_internal(self):
        with tempfile.TemporaryDirectory() as td:
            db = seed_disposable_db_current(Path(td))
            con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
            con.execute("PRAGMA foreign_keys=ON")
            con.execute(
                "INSERT INTO entities VALUES (?,?,?,?,?,?,?)",
                ("opaque-player", "default", "player", "p-ext", "confirmed", "{}", "[]"))
            base = dict(
                object_json=json.dumps({"synthetic": True}), plane=Plane.OBJECTIVE,
                admission_state=AdmissionState.COMMITTED, truth_status=TruthStatus.ACTIVE,
                valid_from_turn=1, invalid_at_turn=None, recorded_at_turn=1,
                provenance_json="{}", classification=Classification.AUTHORITY)
            for i, pred in enumerate(("currentboundary", "sexualityprofile"), 1):
                f = FactInput(fact_id=f"F-R-{i}", subject_ref="E-A", predicate=pred, **base)
                with self.subTest(pred=pred), self.assertRaises(AuthorityError):
                    insert_fact(con, f)
            f = FactInput(fact_id="F-P", subject_ref="opaque-player",
                          predicate="playerfeeling", **base)
            with self.assertRaises(AuthorityError):
                insert_fact(con, f)
            self.assertEqual(con.execute("SELECT COUNT(*) FROM facts").fetchone()[0], 0)
            con.close()

    def test_public_phase3d_rejects_compact_runtime_and_player_claims_before_write(self):
        for predicate, subject in (("currentboundary", "E-A"),
                                   ("playerfeeling", "E-PL")):
            root, vendor, runtime = make_disposable_vendor()
            db = seed_disposable_db(root)
            before = current_bytes(vendor)
            out = orchestrate(_request(vendor, runtime, _plan_fact(predicate, subject)), db_path=db)
            self.assertEqual(out.status, "REFUSED")
            self.assertFalse(out.runtime_attempted)
            self.assertEqual(current_bytes(vendor), before)
            con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
            self.assertEqual(con.execute("SELECT COUNT(*) FROM facts").fetchone()[0], 0)
            self.assertEqual(con.execute("SELECT COUNT(*) FROM transaction_journal").fetchone()[0], 0)
            con.close()

    def test_all_fact_retrievers_and_context_pack_block_legacy_compact_shadow_rows(self):
        tmp, base = build_context_base(); self.addCleanup(tmp.cleanup)
        db = base / "state" / "continuity.sqlite3"
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        rows = [
            ("F-COMPACT-A", "E-A", "currentboundary"),
            ("F-COMPACT-P", "E-PL", "playerfeeling"),
        ]
        for fid, subject, predicate in rows:
            con.execute(
                "INSERT INTO facts (fact_id,branch_id,subject_ref,predicate,object_json,"
                "plane,admission_state,truth_status,valid_from_turn,invalid_at_turn,"
                "recorded_at_turn,recorded_at,provenance_json,classification) "
                "VALUES (?,?,?,?,?,'OBJECTIVE','COMMITTED','ACTIVE',1,NULL,1,?,?,?)",
                (fid, "default", subject, predicate, json.dumps({"synthetic": True}),
                 "2026-01-01T00:00:00+00:00", "{}", "AUTHORITY"))
        con.commit()
        ctx = Context(conn=con, base=base,
                      index_path=base / "indexes" / "retrieval_fts.sqlite3")
        ids = {r[0] for r in rows}
        temporal = TemporalRetriever().retrieve(
            RetrievalQuery(branch_id="default", event_turn=10, query_id="t"), ctx)
        self.assertFalse(ids & {x.item_id for x in temporal.items})
        lexical = LexicalRetriever().retrieve(
            RetrievalQuery(raw_text="currentboundary", branch_id="default", event_turn=10,
                           query_id="l"), ctx)
        self.assertFalse(ids & {x.item_id for x in lexical.items})
        ledger = LedgerRetriever().retrieve(
            RetrievalQuery(branch_id="default", event_turn=10,
                           fact_ids=tuple(ids), query_id="g"), ctx)
        self.assertFalse(ids & {x.item_id for x in ledger.items})
        con.close()

        pack = ContextPackBuilder(base).build(
            RoutingRequest(raw_text="currentboundary playerfeeling", branch_id="default",
                           query_id="pack", scene_entity_ids=("E-A", "E-PL"),
                           observer_entity_id="E-A"),
            runtime_state=runtime_state_path(base))
        self.assertFalse(ids & {item.source_ref for item in pack.items})


class DirectoryFsyncUnsupportedFix2(unittest.TestCase):
    def test_preflight_unsupported_refuses_before_attempt(self):
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        before = current_bytes(vendor)
        unsupported = DurabilityProbe(
            capability_ok=False, reason="synthetic unsupported", path=str(runtime.parent),
            status=DirFsyncStatus.UNSUPPORTED)
        plan = ConsequencePlan(consequences=[{
            "kind": "EPISODE_APPEND",
            "payload": {"summary": "synthetic", "scene_ref": "S"}}])
        with mock.patch("continuity.runtime3b.execute.probe_directory_fsync",
                        return_value=unsupported):
            out = orchestrate(_request(vendor, runtime, plan), db_path=db)
        self.assertEqual(out.status, "MANUAL_REVIEW_REQUIRED")
        self.assertFalse(out.runtime_attempted)
        self.assertTrue(out.manual_review_required)
        self.assertEqual(current_bytes(vendor), before)
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        row = con.execute("SELECT * FROM transaction_journal").fetchone()
        self.assertEqual(row["attempt_count"], 0)
        self.assertEqual(row["durability_status"], "DIR_FSYNC_UNSUPPORTED")
        self.assertEqual(row["manual_review_required"], 1)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM continuity_sync_executions").fetchone()[0], 0)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM history_outbox").fetchone()[0], 0)
        con.close()

    def test_post_apply_unsupported_is_manual_and_never_syncs_or_completes(self):
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        ok = DurabilityProbe(capability_ok=True, reason="ok", path=str(runtime.parent),
                             status=DirFsyncStatus.OK)
        unsupported = DirectoryFsyncResult(
            attempted=False, supported=False, succeeded=False,
            status=DirFsyncStatus.UNSUPPORTED, error_class=None,
            error_detail_bounded="synthetic unsupported")
        plan = ConsequencePlan(consequences=[{
            "kind": "EPISODE_APPEND",
            "payload": {"summary": "synthetic", "scene_ref": "S"}}])
        with mock.patch("continuity.runtime3b.execute.probe_directory_fsync", return_value=ok), \
             mock.patch("continuity.runtime3b.execute.perform_directory_fsync",
                        return_value=unsupported):
            out = orchestrate(_request(vendor, runtime, plan), db_path=db)
        self.assertEqual(out.status, "MANUAL_REVIEW_REQUIRED")
        self.assertTrue(out.manual_review_required)
        self.assertTrue(out.runtime_attempted)
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        row = con.execute("SELECT * FROM transaction_journal").fetchone()
        self.assertEqual(row["attempt_count"], 1)
        self.assertEqual(row["durability_status"], "DIR_FSYNC_UNSUPPORTED")
        self.assertEqual(row["manual_review_required"], 1)
        self.assertNotEqual(row["state"], "COMPLETED")
        self.assertEqual(con.execute("SELECT COUNT(*) FROM continuity_sync_executions").fetchone()[0], 0)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM history_outbox").fetchone()[0], 0)
        post = current_bytes(vendor)
        out2 = orchestrate(_request(vendor, runtime, plan), db_path=db,
                           tx_id_hint=row["continuity_tx_id"])
        self.assertEqual(out2.status, "MANUAL_REVIEW_REQUIRED")
        self.assertTrue(out2.manual_review_required)
        self.assertEqual(current_bytes(vendor), post)
        self.assertEqual(con.execute("SELECT attempt_count FROM transaction_journal").fetchone()[0], 1)
        con.close()


class SmallReliabilityCleanupFix2(unittest.TestCase):
    def test_reentry_relationship_membership_is_exact_and_none_safe(self):
        from continuity.reentry.activator import ReentryActivator
        class Dao:
            def q(self, sql, params=()):
                return [{"relationship_id": "R", "source_ref": "T", "target_ref": "E",
                         "phase": "x", "public_surface": "p", "actual_relation": "a"}]
        none_player = ReentryActivator(Dao(), player_entity_id=None)
        rows = none_player.relationships("T")
        self.assertEqual(len(rows), 1)
        self.assertFalse(rows[0].included)
        substring_player = ReentryActivator(Dao(), player_entity_id="E-PL")
        rows2 = substring_player.relationships("T")
        self.assertFalse(rows2[0].included)
        exact_player = ReentryActivator(Dao(), player_entity_id="E")
        rows3 = exact_player.relationships("T")
        self.assertTrue(rows3[0].included)

    def test_recovery_observation_ids_do_not_collide_same_second(self):
        from continuity.sync3c.recovery import RecoveryScanner
        from tests.phase3c_fixture import make_journal_state, connect
        db, tx, _, _ = make_journal_state("CONTINUITY_SYNC_PENDING")
        con = connect(db)
        scanner = RecoveryScanner(con)
        with mock.patch("continuity.sync3c.recovery._now",
                        return_value="2026-01-01T00:00:00+00:00"):
            scanner._record_observation(tx, "A", "first")
            scanner._record_observation(tx, "B", "second")
        rows = con.execute(
            "SELECT observation_id FROM recovery_observations WHERE continuity_tx_id=?",
            (tx,)).fetchall()
        self.assertEqual(len(rows), 2)
        self.assertNotEqual(rows[0][0], rows[1][0])
        con.close()


if __name__ == "__main__":
    unittest.main()
