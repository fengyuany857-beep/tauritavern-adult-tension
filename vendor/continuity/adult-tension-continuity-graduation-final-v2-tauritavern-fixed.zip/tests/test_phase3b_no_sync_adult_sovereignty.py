"""Phase 3B — no historical sync on confirmed applied + adult-authority isolation
+ player sovereignty + continuity-sync honesty (§23-25, §32 40-49, 53).

Even when runtime outcome is CONFIRMED_APPLIED, Phase 3B must NOT:
  - insert episode / fact consequence,
  - mutate relationship semantics / resolve commitment / advance thread,
  - append historical JSONL consequence,
  - store continuity current-adult-permission shadow payload,
  - let trust / attraction / historical consent modify the candidate patch,
  - turn natural-language desires into NPC-belief patches.

And the journal must show continuity_sync_state PENDING / NOT-STARTED for
applied runs (never COMPLETED), with manual_review set on unknown/divergence.
"""
from __future__ import annotations
import json
import hashlib
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3b_fixture import (
    make_disposable_vendor, seed_disposable_db, simple_patch, current_bytes,
)
from continuity.transactions.journal import (
    JournalDao, AUTHORITY_TABLES,
    JOURNAL_TABLES,
)
from continuity.transactions.preconditions import prepare_transaction
from continuity.runtime3b.execute import commit_single_file
from continuity.transactions.contracts import RuntimeOutcomeClass, TransactionState


def _hash_rows(db: Path, table: str) -> str:
    con = sqlite3.connect(str(db))
    try:
        rows = con.execute(f"SELECT * FROM {table}").fetchall()
        return hashlib.sha256(repr(rows).encode("utf-8")).hexdigest()
    except sqlite3.OperationalError:
        return "absent"
    finally:
        con.close()


class Phase3BNoSyncAdultSovereigntyTests(unittest.TestCase):

    def setUp(self):
        self._root, self.vendor, self.runtime = make_disposable_vendor()
        self.db = seed_disposable_db(self._root)

    def _commit(self, patch=None):
        patch = patch if patch is not None else simple_patch()
        pe = prepare_transaction(vendor_dir=self.vendor, db_path=self.db,
                                 runtime_path=self.runtime, patch=patch)
        env = commit_single_file(db_path=self.db, vendor_dir=self.vendor,
                                 runtime_path=self.runtime, tx_id=pe.continuity_tx_id,
                                 patch=patch)
        return env, pe

    # 40,41: confirmed applied does not sync facts / episode
    def test_applied_does_not_insert_episode_or_fact(self):
        env, _ = self._commit()
        self.assertEqual(env.runtime_outcome, RuntimeOutcomeClass.CONFIRMED_APPLIED.value)
        con = sqlite3.connect(str(self.db))
        eps = con.execute("SELECT count(*) FROM episodes").fetchone()[0]
        con.close()
        self.assertEqual(eps, 0)
        # continuous journal sync state stays PENDING / not started
        con = sqlite3.connect(str(self.db)); con.row_factory = sqlite3.Row
        r = con.execute("SELECT continuity_sync_state,state FROM transaction_journal").fetchone()
        con.close()
        self.assertEqual(r["continuity_sync_state"], "PENDING")
        self.assertIn(r["state"], (TransactionState.DURABILITY_PENDING.value,
                                   TransactionState.CONFIRMED_APPLIED.value))

    # 42,43,44: no relationship / commitment / thread mutations by 3B
    def test_applied_does_not_mutate_relationships_commitments_or_threads(self):
        # these tables are part of AUTHORITY_TABLES; nothing should ever insert
        for tbl in ("relationships", "commitments", "threads"):
            before = _hash_rows(self.db, tbl)
            env, _ = self._commit()
            after = _hash_rows(self.db, tbl)
            self.assertEqual(before, after, f"{tbl} mutated by Phase 3B sync")

    # 45: adult patch not shadow-stored -------------------------------------
    def test_journal_never_shadow_stores_adult_payload(self):
        marker = "TOP-SECRET-ALICE-SAFETY-PAYLOAD-a11f"
        patch = {"delta_minutes": 5, "last_committed_result": marker}
        env, pe = self._commit(patch=patch)
        # even if runtime candidate legitimately reaches the runtime fixture, the
        # journal stores only hashes/digests/refs, never the full payload text.
        con = sqlite3.connect(str(self.db)); con.row_factory = sqlite3.Row
        row = con.execute(
            "SELECT * FROM transaction_journal WHERE continuity_tx_id=?",
            (pe.continuity_tx_id,)).fetchone()
        r = con.execute(
            "SELECT manual_review_json FROM (SELECT manual_review_json FROM transaction_journal "
            "WHERE continuity_tx_id=?) ", (pe.continuity_tx_id,)).fetchone()
        con.close()
        blob = repr(dict(row))
        self.assertNotIn(marker, blob)
        self.assertNotIn("TOP-SECRET", blob)

    # 46,47,48: trust / attraction / historical consent do not modify patch
    def test_trust_attraction_historical_never_alter_patch(self):
        import copy
        patch = simple_patch()
        original = copy.deepcopy(patch)
        env, _ = self._commit(patch=patch)
        self.assertEqual(patch, original)   # in-memory candidate patch unchanged

    # 49: natural-language desired outcome rejected
    def test_natlang_desired_outcome_rejected_at_prepare(self):
        from continuity.transactions.errors import PlayerSovereigntyViolation
        with self.assertRaises(PlayerSovereigntyViolation):
            prepare_transaction(vendor_dir=self.vendor, db_path=self.db,
                                runtime_path=self.runtime,
                                patch={"desired_outcome": "make the NPC believe me"})

    # 53: unknown/divergence fail-closed -> manual review path and one-attempt frozen
    def test_unknown_manual_review_and_one_attempt_frozen(self):
        from continuity.transactions.journal import JournalDao
        from continuity.transactions.errors import DuplicateAttempt
        pe = prepare_transaction(vendor_dir=self.vendor, db_path=self.db,
                                 runtime_path=self.runtime, patch=simple_patch())
        con = sqlite3.connect(str(self.db)); con.row_factory = sqlite3.Row
        dao = JournalDao(con)
        dao.open_runtime_attempt(pe.continuity_tx_id)      # attempt 1
        dao.record_outcome_unknown(pe.continuity_tx_id)    # no auto retry
        # a re-invocation reservation is refused (attempt stays 1)
        with self.assertRaises(DuplicateAttempt):
            dao.open_runtime_attempt(pe.continuity_tx_id)
        dao.mark_manual_review(pe.continuity_tx_id,
                               evidence_summary={"decision": "UNKNOWN",
                                                 "summary": "automation cannot conclude"},
                               safe_actions=["new_tx_required", "manual_inspect"])
        r = con.execute("SELECT manual_review_required, state, continuity_sync_state, "
                        "attempt_count FROM transaction_journal WHERE continuity_tx_id=?",
                        (pe.continuity_tx_id,)).fetchone()
        con.close()
        self.assertEqual(r["state"], TransactionState.MANUAL_REVIEW.value)
        self.assertEqual(r["manual_review_required"], 1)
        self.assertEqual(r["attempt_count"], 1)

    # 57: no CoT fields in journal manual packets
    def test_manual_review_packet_has_no_cot_and_bounded(self):
        from continuity.transactions.journal import JournalDao
        pe = prepare_transaction(vendor_dir=self.vendor, db_path=self.db,
                                 runtime_path=self.runtime, patch=simple_patch())
        con = sqlite3.connect(str(self.db)); con.row_factory = sqlite3.Row
        dao = JournalDao(con)
        dao.open_runtime_attempt(pe.continuity_tx_id)
        dao.record_outcome_unknown(pe.continuity_tx_id)
        dao.mark_manual_review(pe.continuity_tx_id,
                               evidence_summary={"decision": "UNKNOWN",
                                                 "summary": "automation cannot conclude"},
                               safe_actions=["new_tx_required", "manual_inspect"])
        row = con.execute("SELECT manual_review_json FROM transaction_journal "
                          "WHERE continuity_tx_id=?", (pe.continuity_tx_id,)).fetchone()
        con.close()
        packet = json.loads(row["manual_review_json"])
        self.assertNotIn("reasoning", str(packet).lower())
        self.assertNotIn("chain_of_thought", str(packet).lower())
        self.assertIn("unsafe_actions", packet)
        self.assertLessEqual(len(json.dumps(packet)), 4000)


if __name__ == "__main__":
    unittest.main()
