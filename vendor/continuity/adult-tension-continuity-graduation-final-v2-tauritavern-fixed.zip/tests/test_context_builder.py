"""Phase 2B-1 Context Pack builder unit tests.

Covers residency (HOT/WARM/COLD), observer isolation, presentation/reveal
guards, anti-merge, budget allocation, adult compatibility, determinism and the
non-authoritative / no-mutation properties of the read-only ContextPackBuilder.
"""
from __future__ import annotations
import contextlib
import json
import sqlite3
import unittest
from pathlib import Path

from continuity.routing import (
    ContextMode, ContextPack, ContextPackBuilder, PackStatus, ResidencyTier,
    RoutingRequest,
)
from tests.context_builder_fixture import build_context_base, runtime_state_path


def _build(tmp, base, text="我喝了口水", **kw) -> ContextPack:
    runtime_state = kw.pop("runtime_state", None)
    req = RoutingRequest(raw_text=text, branch_id="default", query_id="t", **kw)
    builder = ContextPackBuilder(base)
    return builder.build(req, runtime_state=runtime_state)


class BuilderLifecycle(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base = build_context_base()
        self.addCleanup(self.tmp.cleanup)

    # ------------------------------------------------------------------ #
    def _items(self, pack):
        return pack.items

    def _by_resid(self, pack, tier):
        return [i for i in pack.items if i.residency == tier.value]

    def _content(self, pack):
        return " ".join(i.content for i in pack.items)

    def _observer_pack(self, observer, scene=("E-A", "E-PL"), **kw):
        p = _build(self.tmp, self.base,
                   scene_entity_ids=scene, observer_entity_id=observer, **kw)
        return p

    # ---- mode classification forwarded to pack -------------------------
    def test_fast_mode_in_pack(self):
        p = self._observer_pack("E-A")
        self.assertEqual(p.final_mode, "FAST")

    # ---- #8 current participant anchor HOT ------------------------------
    def test_participant_anchor_hot(self):
        p = self._observer_pack("E-A", scene=("E-A", "E-PL"))
        anchors = [i for i in p.items
                   if i.source_type == "ENTITY" and i.content.startswith("current participant anchor")]
        self.assertTrue(anchors, "participant anchor must exist")
        self.assertIn("E-A", anchors[0].content)
        self.assertEqual(anchors[0].residency, "HOT")
        self.assertEqual(anchors[0].hard_or_soft, "hard")

    # ---- #9 explicit non-capability is HOT ------------------------------
    def test_explicit_noncap_hot(self):
        p = self._observer_pack("E-PL", scene=("E-A", "E-PL"))
        noncap = [i for i in p.items if "explicit non-capabilities" in i.content]
        self.assertTrue(noncap)
        self.assertEqual(noncap[0].residency, "HOT")
        self.assertTrue(all("roar" in i.content for i in noncap))

    # ---- #10 due commitment HOT ----------------------------------------
    def test_due_commitment_hot(self):
        p = self._observer_pack("E-PL", scene=("E-A", "E-PL"))
        due = [i for i in p.items if i.source_type == "COMMITMENT"
               and "will call at new year" in i.content]
        self.assertTrue(due)
        self.assertIn("HOT", due[0].residency)
        self.assertEqual(due[0].hard_or_soft, "hard")

    # ---- #8 can't be silently dropped under a budget --------------------
    def test_hot_anchors_survive_tight_budget(self):
        unlimited = self._observer_pack("E-A", scene=("E-A",), token_budget=None)
        hardcost = unlimited.hard_cost
        self.assertGreater(hardcost, 0)
        # budget exactly large enough for all hard items (no soft budget room)
        p = self._observer_pack("E-A", scene=("E-A",), token_budget=hardcost)
        self.assertEqual(p.status, PackStatus.OK)
        ids = {i.item_id for i in p.items}
        self.assertIn("E-A", ids)   # participant anchor preserved under pressure
        self.assertTrue(all(("BUDGET" in d.reason or "COLD_EXCLUDED" in d.reason)
                            for d in p.dropped) or not p.dropped)

    # ---- #11 unrelated old scene absent from FAST -------------------------
    def test_unrelated_old_episode_not_in_fast(self):
        p = self._observer_pack("E-A", scene=("E-A", "E-PL"))
        ep_content = self._content(p)
        # EP-old is an older scene; with recent scenes so far the window only
        # considers top episodes the builder enables.
        self.assertNotIn("harbor clinic", ep_content)

    # ---- #12 recent scene appears as WARM pointer -------------------------
    def test_recent_scene_warm_pointer(self):
        p = self._observer_pack("E-A", scene=("E-A", "E-PL"), runtime_state=runtime_state_path(self.base))
        recent = [i for i in p.items if i.source_type == "EPISODE" and i.content.startswith("recent scene pointer")]
        self.assertTrue(recent)
        self.assertEqual(recent[0].residency, "WARM")

    # ---- #13 evidence item COLD, activated under EVIDENCE -----------------
    def test_evidence_cold_activated_only_in_evidence_mode(self):
        # DEEP/X query does not surface evidence; EVIDENCE does.
        p_deep = self._observer_pack("E-A", scene=("E-A", "E-PL"),
                                text="那个很久没见的医生后来怎么样了？")
        self.assertEqual(p_deep.final_mode, ContextMode.DEEP.value)
        # evidence pointers are COLD surfacing in evidence only; here deep usage
        # allowed COLD-surfaced objects but we assert a *usable* pointer appears.
        p_ev = self._observer_pack("E-A", scene=("E-A", "E-PL"),
                              text="她上次原话到底是什么？")
        self.assertEqual(p_ev.final_mode, ContextMode.EVIDENCE.value)
        ev = [i for i in p_ev.items if i.source_type == "HISTORICAL_EVIDENCE"]
        # EvidenceRetriever found our seeded episode stream (EP-new).
        self.assertTrue(any("sapphire" in i.content for i in ev))

    # ---- #14 hard HOT survives budget pressure -----------------------------
    def _footprint(self):
        db = self.base / "state" / "continuity.sqlite3"
        c = sqlite3.connect(str(db))
        c.row_factory = sqlite3.Row
        tables = ["facts", "knowledge", "relationships", "relationship_dimensions",
                  "commitments", "threads", "thread_requires", "thread_links",
                  "thread_anti_merge", "episodes", "admission_candidates",
                  "admission_decisions", "continuity_transactions"]
        before = {}
        for t in tables:
            rows = [dict(r) for r in c.execute(f"SELECT * FROM {t}")]
            before[t] = json.dumps(rows, sort_keys=True)
        c.rollback()
        c.close()
        return before

    # ---- #35 build causes zero authority mutation --------------------------
    def test_pack_build_no_mutation(self):
        p0 = self._footprint()
        p = self._observer_pack("E-A", scene=("E-A", "E-PL"),
                           text="她上次原话到底是什么？")
        p1 = self._footprint()
        self.assertEqual(p0, p1, "builder must not modify any authority table")

    # ---- #34 non-authoritative -------------------------------------------
    def test_non_authoritative(self):
        p = self._observer_pack("E-A", scene=("E-A",))
        self.assertEqual(p.authoritativeness, "EPHEMERAL / NON_AUTHORITY")

    # ---- #32/33 runtime observed hash included, not as a revision ---------
    def test_runtime_hash_referenced_not_revision(self):
        rp = runtime_state_path(self.base)
        p = self._observer_pack("E-A", runtime_state=rp, scene=())
        rt_items = [i for i in p.items if "SHA-256 reference" in i.content]
        self.assertTrue(rt_items, "runtime hash reference not found")
        for i in rt_items:
            self.assertTrue("SHA-256 reference:" in i.content)
            self.assertNotIn("revision", i.content.lower())
            self.assertEqual(i.residency, "HOT")
            self.assertEqual(i.hard_or_soft, "hard")

    # ---- #37 every item has activation reason -----------------------------
    def test_activation_reason_present_everywhere(self):
        p = self._observer_pack("E-A", scene=("E-A", "E-PL"))
        self.assertTrue(all(i.activation_reason for i in p.items))

    # ---- #38 same inputs -> same semantic digest ---------------------------
    def test_same_inputs_same_digest(self):
        # identical independent builds (fresh builder each time)
        a = self._observer_pack("E-A", scene=("E-A", "E-PL"))
        b = self._observer_pack2("E-A", scene=("E-A", "E-PL"))
        self.assertEqual(a.semantic_digest, b.semantic_digest)
        self.assertEqual([(i.source_ref, i.residency) for i in a.items],
                         [(i.source_ref, i.residency) for i in b.items])

    def _observer_pack2(self, observer, **kw):
        req = RoutingRequest(raw_text="我喝了口水", branch_id="default", query_id="t",
                             observer_entity_id=observer, scene_entity_ids=kw["scene"]
                             if "scene" in kw else ("E-A", "E-PL"))
        return ContextPackBuilder(self.base).build(req)

    # ---- #39 stable item ordering across builds ----------------------------
    def test_stable_ordering_across_builds(self):
        a = self._observer_pack("E-A", scene=("E-A", "E-PL"))
        b = ContextPackBuilder(self.base).build(RoutingRequest(
            raw_text="我喝了口水", branch_id="default", query_id="t",
            observer_entity_id="E-A", scene_entity_ids=("E-A", "E-PL")))
        self.assertEqual([i.source_ref for i in a.items],
                         [i.source_ref for i in b.items])

    # ---- #37 covered; also no random id in digest --------------------------
    def test_digest_ignores_random_pack_id(self):
        a = self._observer_pack("E-A", scene=("E-A",))
        self.assertNotIn(a.pack_id, a.semantic_digest)


if __name__ == "__main__":
    unittest.main()
