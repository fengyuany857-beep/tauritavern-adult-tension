"""Phase 3C — sync gate, deterministic plan, effect keys / conflict policy.

Covers §27 test list items 1-10 and Sol §10/§13 gate conditions:
- only CONFIRMED_APPLIED may sync (invariant 1);
- PREPARED / PRECONDITION_FAILED / NOT_APPLIED / OUTCOME_UNKNOWN /
  CONCURRENT_DIVERGENCE cannot sync (invariant 4/5);
- deterministic sync-plan digest; a changed plan on the same tx is blocked;
- effect id deterministic and marker unique; digest conflict -> manual.
"""
from __future__ import annotations
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
import json

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3c_fixture import make_journal_state, seed_authority_base, connect
from continuity.sync3c.planner import build_plan, request_claimed_digest, payload_digest, PlanError
from continuity.sync3c.contracts import ContinuitySyncRequest, EffectKind, canonical_effect_id
from continuity.sync3c.engine import ContinuitySyncEngine, SyncEngineError
from continuity.transactions.contracts import TransactionState


def _cons(kind, payload):
    return {"kind": kind, "payload": payload}


class SyncGateTests(unittest.TestCase):
    def _engine(self, db, hist=None):
        con = connect(db)
        h = hist or (Path(db).parent / "history" / "VOL-001.jsonl")
        return ContinuitySyncEngine(con, evidence_path=h)

    def test_sync_only_confirmed_applied(self):
        db, tx, row, req = make_journal_state("CONFIRMED_APPLIED")
        eng = self._engine(db)
        # zero-effect plan still drives a valid atomic sync -> COMPLETED state
        res = eng.sync_applied_transaction(req)
        self.assertEqual(res["status"], "COMPLETED")
        con = connect(db)
        st = dict(con.execute("SELECT state,continuity_sync_state FROM transaction_journal "
                              "WHERE continuity_tx_id=?", (tx,)).fetchone())
        self.assertEqual(st["state"], TransactionState.COMPLETED.value)

    def test_prepared_cannot_sync(self):
        db, tx, row, req = make_journal_state("PREPARED")
        if req is None:
            eng = self._engine(db)
            with self.assertRaises(SyncEngineError) as cm:
                eng.sync_applied_transaction(_starve_req(tx))
            return
        self.fail("pending unprepared row unexpectedly returned a request")

    def test_outcome_not_applied_cannot_sync(self):
        for outcome in ("OUTCOME_UNKNOWN", "CONCURRENT_DIVERGENCE",
                        "CONFIRMED_NOT_APPLIED"):
            db, tx, row, req = make_journal_state(outcome)
            eng = self._engine(db)
            with self.assertRaises(SyncEngineError):
                eng.sync_applied_transaction(_starve_req(tx))
            # journal must remain untouched by a sync attempt
            con = connect(db)
            st = dict(con.execute("SELECT state FROM transaction_journal "
                                  "WHERE continuity_tx_id=?", (tx,)).fetchone())
            self.assertEqual(st["state"], outcome)
            self.assertEqual(con.execute("SELECT COUNT(*) c FROM continuity_effect_markers "
                                         "WHERE continuity_tx_id=?", (tx,)).fetchone()["c"], 0)

    def test_precondition_failed_cannot_sync(self):
        db, tx, row, req = make_journal_state("PRECONDITION_FAILED")
        eng = self._engine(db)
        with self.assertRaises(SyncEngineError):
            eng.sync_applied_transaction(_starve_req(tx))

    def test_sync_plan_digest_deterministic(self):
        cons = [_cons("EPISODE_APPEND", {"summary": "a", "scene_ref": "s1"}),
                _cons("FACT_INSERT", {"subject_ref": "E-A", "predicate": "q",
                                      "object": {"v": 1}})]
        d1 = request_claimed_digest(_synthetic(cons))
        d2 = request_claimed_digest(_synthetic(cons))
        self.assertEqual(d1, d2)
        d3 = request_claimed_digest(_synthetic(cons + [_cons("FACT_INSERT", {"kind2": 1})]))
        self.assertNotEqual(d1, d3)

    def test_changed_plan_same_tx_blocked(self):
        # applying an altered request after a staged digest on the journal must
        # be refused (engines compare against stored staged_sync_digest).
        db, tx, row, req = make_journal_state("CONTINUITY_SYNC_PENDING",
                                              consequences=[_cons("EPISODE_APPEND",
                                                                  {"summary": "real"})])
        alt = _clone_with_diff(req, _cons("FACT_INSERT", {"subject_ref": "E-A",
                                                          "predicate": "other"}))
        eng = self._engine(db)
        with self.assertRaises(SyncEngineError) as cm:
            eng.sync_applied_transaction(alt)
        self.assertIn("changed" if "changed" in str(cm.exception) else "digest",
                      str(cm.exception).lower())

    def test_effect_id_deterministic_effect_marker_unique(self):
        cons = [_cons("EPISODE_APPEND", {"summary": "x", "scene_ref": "s"}),
                _cons("EPISODE_APPEND", {"summary": "x", "scene_ref": "s"})]
        req = _synthetic(cons)
        p1 = build_plan(req)
        req2 = _synthetic(cons)
        p2 = build_plan(req2)
        self.assertEqual([e.effect_key for e in p1.effects],
                         [e.effect_key for e in p2.effects])
        # identical duplicate payload nodes collapse deterministically to one
        self.assertEqual(len(p1.effects), 1)
        # full effect-id stable across runs
        self.assertEqual(canonical_effect_id(EffectKind.EPISODE_APPEND, p1.effects[0].effect_key),
                         p1.effects[0].effect_id)


def _starve_req(tx):
    return ContinuitySyncRequest(
        continuity_tx_id=tx, runtime_outcome_class="CONFIRMED_APPLIED",
        observed_post_sha256="0" * 64, observed_post_semantic_digest="0" * 64,
        expected_candidate_digest="x", patch_digest="y", branch_id="default",
        source_provenance={}, request_provenance={}, sync_plan_bytes_digest="z",
        consequences=[])


def _synthetic(cons):
    return ContinuitySyncRequest(
        continuity_tx_id="tx-synth",
        runtime_outcome_class="CONFIRMED_APPLIED",
        observed_post_sha256="a" * 64,
        observed_post_semantic_digest="b" * 64,
        expected_candidate_digest="c", patch_digest="p",
        branch_id="default", source_provenance={}, request_provenance={},
        sync_plan_bytes_digest="", consequences=cons)


def _clone_with_diff(req, add_cons):
    import copy
    new = copy.copy(req)
    new_cons = list(req.consequences) + [add_cons]
    return ContinuitySyncRequest(
        continuity_tx_id=req.continuity_tx_id,
        runtime_outcome_class=req.runtime_outcome_class,
        observed_post_sha256=req.observed_post_sha256,
        observed_post_semantic_digest=req.observed_post_semantic_digest,
        expected_candidate_digest=req.expected_candidate_digest,
        patch_digest=req.patch_digest, branch_id=req.branch_id,
        source_provenance=req.source_provenance,
        request_provenance=req.request_provenance,
        sync_plan_bytes_digest="", consequences=new_cons)


if __name__ == "__main__":
    unittest.main()
