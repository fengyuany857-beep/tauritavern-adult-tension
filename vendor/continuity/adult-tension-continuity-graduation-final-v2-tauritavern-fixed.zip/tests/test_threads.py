import unittest
from continuity.validation import assert_reveal_allowed
from continuity.errors import ValidationError
from util import tmpdb
class T(unittest.TestCase):
 def test_unmet_requires_blocks(self):
  d,c=tmpdb();self.addCleanup(d.cleanup)
  c.execute("insert into threads (thread_id,branch_id,status,author_state,objective_state,player_visible_state,reveal_gate_json,presentation_json,provenance_json) values('T','default','active','','','','{}','{}','{}')");c.execute("insert into thread_requires values('R','T','FACT-x','ACTIVE','OBJECTIVE')")
  with self.assertRaisesRegex(ValidationError,'REVEAL_BLOCKED'):assert_reveal_allowed(c,'T',set())
