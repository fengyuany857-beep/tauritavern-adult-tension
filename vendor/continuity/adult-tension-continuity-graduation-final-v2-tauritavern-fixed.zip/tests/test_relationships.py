import unittest
from continuity.errors import AuthorityError
from continuity.validation import unsupported_merge
from util import tmpdb
class T(unittest.TestCase):
 def test_same_name_separate_and_merge_closed(self):
  d,c=tmpdb();self.addCleanup(d.cleanup)
  c.execute("insert into entities (entity_id,branch_id,kind,runtime_external_ref,identity_status,anchors_json,explicit_non_capabilities_json) values('E1','default','npc','npc-1','confirmed','{}','[]')")
  c.execute("insert into entities (entity_id,branch_id,kind,runtime_external_ref,identity_status,anchors_json,explicit_non_capabilities_json) values('E2','default','npc','npc-2','merge_candidate','{}','[]')")
  self.assertEqual(2,c.execute("select count(*) from entities").fetchone()[0])
  with self.assertRaises(Exception):unsupported_merge()
 def test_trust_attraction_no_permission_api(self):
  d,c=tmpdb();self.addCleanup(d.cleanup)
  c.execute("insert into relationships (relationship_id,branch_id,source_ref,target_ref,runtime_refs_json,public_surface,actual_relation,phase,provenance_json) values('R','default','E1','E2','[]','high','high','phase','{}')")
  c.execute("insert into relationship_dimensions values('D','R','attraction','\"high\"','AUTHORITY')")
  self.assertEqual(0,c.execute("select count(*) from facts where predicate like 'consent.%'").fetchone()[0])
