import subprocess, tempfile, unittest
from pathlib import Path
from continuity.constants import AUDITED_VENDOR_HEAD
from continuity.doctor import check
from continuity.db import connect
from continuity.manifest import build,write
class T(unittest.TestCase):
 def make_base(self, vendor):
  d=tempfile.TemporaryDirectory(); b=Path(d.name); (b/'state').mkdir(); (b/'manifests').mkdir(); (b/'history').mkdir(); c=connect(b/'state/continuity.sqlite3'); c.close(); write(b/'manifests/manifest.json',build(b/'state/continuity.sqlite3',b/'history/VOL-001.jsonl',{})); return d,b
 def test_clean_correct_pass(self):
  d,b=self.make_base(Path('/var/minis/workspace/vendor/dsh-adult-tension')); self.addCleanup(d.cleanup); self.assertIn(check(b,Path('/var/minis/workspace/vendor/dsh-adult-tension'))[0],{'PASS','WARN'})
 def test_dirty_warns(self):
  with tempfile.TemporaryDirectory() as d:
   v=Path(d)/'v'; v.mkdir(); subprocess.run(['git','init','-q',str(v)],check=True); subprocess.run(['git','-C',str(v),'config','user.email','t@x'],check=True); subprocess.run(['git','-C',str(v),'config','user.name','t'],check=True); (v/'x').write_text('x'); subprocess.run(['git','-C',str(v),'add','x']); subprocess.run(['git','-C',str(v),'commit','-qm','x']);
   # doctor requires audited HEAD, so isolate the dirty behavior via patched constant
   import continuity.doctor as doc; old=doc.AUDITED_VENDOR_HEAD; doc.AUDITED_VENDOR_HEAD=subprocess.check_output(['git','-C',str(v),'rev-parse','HEAD'],text=True).strip(); d2,b=self.make_base(v); self.addCleanup(d2.cleanup); (v/'x').write_text('dirty'); self.assertEqual('WARN',check(b,v)[0]); doc.AUDITED_VENDOR_HEAD=old
 def test_mismatch_blocked(self):
  with tempfile.TemporaryDirectory() as d:
   v=Path(d)/'v'; v.mkdir(); subprocess.run(['git','init','-q',str(v)],check=True); d2,b=self.make_base(v); self.addCleanup(d2.cleanup); self.assertEqual('BLOCKED',check(b,v)[0])
 def test_missing_and_non_git_blocked(self):
  d,b=self.make_base(Path('/tmp/no-such-vendor')); self.addCleanup(d.cleanup); self.assertEqual('BLOCKED',check(b,Path('/tmp/no-such-vendor'))[0])
  with tempfile.TemporaryDirectory() as x:
   d2,b2=self.make_base(Path(x)); self.addCleanup(d2.cleanup); self.assertEqual('BLOCKED',check(b2,Path(x))[0])
