import hashlib
import sqlite3
import unittest
from continuity.retrieval import (
    ApproximateTokenEstimator, FtsIndex, HybridRetriever,
    LedgerRetriever, LexicalRetriever, RetrievalQuery,
)
from retrieval_seed import open_ctx, seed_base


def hybrid():
    return HybridRetriever([LexicalRetriever(), LedgerRetriever()])


class T(unittest.TestCase):
    def setUp(self):
        self.tmp, base = seed_base()
        self.addCleanup(self.tmp.cleanup)
        self.ctx = open_ctx(base)
        self.hy = hybrid()

    def test_anti_merge_survives_hybrid(self):
        r = self.hy.retrieve(RetrievalQuery(thread_ids=("TH-1",), query_id="q"), self.ctx)
        ids = [i.item_id for i in r.items]
        self.assertNotIn("TH-2", ids)

    def test_wrong_branch_excluded(self):
        r = self.hy.retrieve(RetrievalQuery(raw_text="gate", query_id="q"), self.ctx)
        self.assertNotIn("FACT-BR2", [i.item_id for i in r.items])
        alt = self.hy.retrieve(RetrievalQuery(raw_text="gate", branch_id="alt", query_id="q"), self.ctx)
        self.assertIn("FACT-BR2", [i.item_id for i in alt.items])

    def test_hybrid_deterministic_and_repeatable(self):
        q = RetrievalQuery(raw_text="sapphire Lin", query_id="fixed")
        a = self.hy.retrieve(q, self.ctx)
        b = self.hy.retrieve(q, self.ctx)
        self.assertEqual([i.item_id for i in a.items], [i.item_id for i in b.items])
        fa = [round(t.final_score, 6) for t in a.traces if t.included and t.retriever == "HybridRetriever"]
        fb = [round(t.final_score, 6) for t in b.traces if t.included and t.retriever == "HybridRetriever"]
        self.assertEqual(fa, fb)

    def test_hard_filter_beats_lexical(self):
        r = self.hy.retrieve(RetrievalQuery(raw_text="OldName", query_id="q"), self.ctx)
        self.assertNotIn("FACT-SUP", [i.item_id for i in r.items])

    def test_token_estimator_deterministic(self):
        e = ApproximateTokenEstimator()
        self.assertEqual(e.estimate("hello world"), e.estimate("hello world"))

    def test_budget_does_not_resurrect_excluded(self):
        r = self.hy.retrieve(RetrievalQuery(raw_text="sapphire", token_budget=1, query_id="q"), self.ctx)
        self.assertTrue(r.items)
        self.assertNotIn("FACT-CAND", [i.item_id for i in r.items])

    def test_trace_for_included_item(self):
        r = self.hy.retrieve(RetrievalQuery(raw_text="sapphire", query_id="q"), self.ctx)
        for item in r.items:
            self.assertTrue(any(t.candidate_item_id == item.item_id and t.included for t in r.traces), item.item_id)

    def test_trace_records_excluded_reason(self):
        r = self.hy.retrieve(RetrievalQuery(raw_text="OldName", query_id="q"), self.ctx)
        tr = [t for t in r.traces if t.candidate_item_id == "FACT-SUP" and not t.included]
        self.assertTrue(tr and tr[0].exclusion_reason is not None)

    def test_adult_reference_not_current_permission(self):
        r = self.hy.retrieve(RetrievalQuery(entity_ids=("E-A",), query_id="q"), self.ctx)
        blob = " ".join(i.content for i in r.items).lower()
        self.assertNotIn("consent", blob)
        self.assertNotIn("grant", blob)
        self.assertNotIn("boundary", blob)

    def test_trust_attraction_not_consent(self):
        r = self.hy.retrieve(RetrievalQuery(raw_text="attraction trust", query_id="q"), self.ctx)
        self.assertNotIn("REL-1", [i.item_id for i in r.items])

    def test_retrieval_no_db_mutation(self):
        before = self.fingerprint()
        for _ in range(3):
            self.hy.retrieve(RetrievalQuery(raw_text="sapphire Lin", query_id="q"), self.ctx)
        self.assertEqual(before, self.fingerprint())

    def test_fts_rebuild_reproduces_results_and_delete_keeps_authority(self):
        writable = sqlite3.connect(str(self.ctx.base / "state" / "continuity.sqlite3"))
        idx = FtsIndex(self.ctx.index_path)
        idx.rebuild(writable, self.ctx.base)
        first = sorted(idx.search())
        idx.rebuild(writable, self.ctx.base)
        self.assertEqual(first, sorted(idx.search()))
        count = writable.execute("select count(*) from facts").fetchone()[0]
        idx.path.unlink()
        self.assertFalse(idx.exists())
        idx.rebuild(writable, self.ctx.base)
        self.assertEqual(first, sorted(idx.search()))
        writable.close()
        self.assertGreater(count, 0)

    def fingerprint(self) -> str:
        digest = hashlib.sha256()
        for line in self.ctx.conn.iterdump():
            digest.update(line.encode())
        return digest.hexdigest()
