"""Phase 3A — contracts / state machine / guard unit tests (pure, no DB, no runtime)."""
from __future__ import annotations
import unittest

from continuity.transactions.contracts import (
    TransactionState,
    can_transition,
    is_terminal,
    is_nonterminal,
    allowed_next,
    RuntimeOutcomeClass,
    ContinuitySyncState,
    PreconditionStatus,
    RecoveryDisposition,
    ManualReviewFlag,
)


class StateMachineTests(unittest.TestCase):
    def test_terminal_states(self):
        terminal = {TransactionState.PRECONDITION_FAILED,
                    TransactionState.CONFIRMED_NOT_APPLIED,
                    TransactionState.ABORTED_NOT_ATTEMPTED,
                    TransactionState.COMPLETED}
        for st in terminal:
            self.assertTrue(is_terminal(st), f'{st} should be terminal')
        self.assertFalse(is_terminal(TransactionState.PREPARED))
        self.assertFalse(is_terminal(TransactionState.RUNTIME_ATTEMPTING))
        self.assertTrue(is_nonterminal(TransactionState.PREPARED))
        self.assertFalse(is_nonterminal(TransactionState.COMPLETED))

    def test_protocol_transitions(self):
        # PREPARED legal targets
        self.assertTrue(can_transition(TransactionState.PREPARED, TransactionState.RUNTIME_ATTEMPTING.value))
        self.assertTrue(can_transition(TransactionState.PREPARED, TransactionState.ABORTED_NOT_ATTEMPTED.value))
        # Runtime attempt never re-enters RUNTIME_ATTEMPTING from UNKNOWN/DIVERGE
        self.assertFalse(can_transition(TransactionState.OUTCOME_UNKNOWN, TransactionState.RUNTIME_ATTEMPTING.value))
        self.assertFalse(can_transition(TransactionState.CONCURRENT_DIVERGENCE, TransactionState.RUNTIME_ATTEMPTING.value))
        # PREPARED -> completion is illegal (must go through runtime/sync)
        self.assertFalse(can_transition(TransactionState.PREPARED, TransactionState.COMPLETED.value))

    def test_no_single_success_mix(self):
        # There must be no generic SUCCESS. Runtime outcome classes and sync
        # states are distinct enumerated dimensions.
        self.assertNotEqual(RuntimeOutcomeClass.CONFIRMED_APPLIED.value, "" )
        self.assertNotIn("SUCCESS", {c.value for c in RuntimeOutcomeClass})
        self.assertNotIn("SUCCESS", {c.value for c in ContinuitySyncState})
        self.assertIn("CONFIRMED_APPLIED", [c.value for c in RuntimeOutcomeClass])
        self.assertIn("SYNCED", [c.value for c in ContinuitySyncState])

    def test_runtime_and_sync_are_distinct_enums(self):
        # Same-named value would be a mixture error; ensure separate homes for
        # runtime vs sync by distinct enum membership.
        for c in RuntimeOutcomeClass:
            self.assertNotIn(c.value, [s.value for s in ContinuitySyncState], "no conflation")

    def test_unknown_never_auto_retries(self):
        for st in (TransactionState.OUTCOME_UNKNOWN, TransactionState.CONCURRENT_DIVERGENCE):
            self.assertNotIn(TransactionState.RUNTIME_ATTEMPTING.value,
                             allowed_next(st), f'{st} must never auto-retry')

    def test_explicit_transitions_present(self):
        # The allowed transitions dict must be non-empty and cover each reachable
        # state (explicit transitions so invalid transitions fail closed).
        for st in (TransactionState.PREPARED, TransactionState.RUNTIME_ATTEMPTING,
                   TransactionState.CONFIRMED_APPLIED,
                   TransactionState.CONTINUITY_SYNC_PENDING,
                   TransactionState.CONTINUITY_SYNCING,
                   TransactionState.CONTINUITY_SYNCED):
            self.assertTrue(len(allowed_next(st)) >= 0)


if __name__ == "__main__":
    unittest.main()
