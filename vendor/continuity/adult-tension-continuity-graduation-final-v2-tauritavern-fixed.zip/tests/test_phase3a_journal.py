"""Phase 3A — transaction journal DAO & lifecycle tests.

Exercise the durable sidecar journal (transaction tables only).  All use fresh
temp sidecars produced by the project migrate; no runtime files.
"""
from __future__ import annotations
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from continuity.migrations import migrate
from continuity.transactions.journal import JournalDao
from continuity.transactions.errors import (
    InvalidTransition, UnknownTx, DuplicateAttempt, TxErrorCode, TxError,
)
from continuity.transactions.contracts import TransactionState, PreconditionStatus


def _make_conn(db: Path) -> sqlite3.Connection:
    db.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(str(db))
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    migrate(c)
    return c


def prep_kw(tx_id="TX"):
    return dict(
        tx_id=tx_id, operation="prepare_turn", branch_id="default",
        protocol_version="phase3-safe-saga-v1",
        runtime_identity="campaign-v1/current",
        runtime_path_ref="/tmp/v/saves/current_state.yaml",
        runtime_pre_sha256="a" * 64, runtime_pre_semantic_digest="b" * 64,
        patch_digest="c" * 64, canonicalisation_version="phase3-canonic-json-v1",
        expected_candidate_digest="d" * 64,
        runtime_expected_semantic_digest="e" * 64,
    )


class JournalDaoTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.con = _make_conn(Path(self.tmp.name) / "j.sqlite3")

    def tearDown(self):
        try:
            self.con.close()
        finally:
            self.tmp.cleanup()

    def dao(self) -> JournalDao:
        return JournalDao(self.con)

    def test_tx_id_unique_and_not_runtime_id(self):
        dao = self.dao()
        dao.create_prepared(**prep_kw("TX-U1"))
        with self.assertRaises(TxError) as cm:
            dao.create_prepared(**prep_kw("TX-U1"))
        self.assertEqual(cm.exception.code, TxErrorCode.DUPLICATE_TX)
        self.assertIn("continuity_tx_id", dao.get("TX-U1"))

    def test_prepared_row_persists(self):
        dao = self.dao()
        row = dao.create_prepared(**prep_kw("TX-P"))
        self.assertEqual(row["state"], TransactionState.PREPARED.value)
        self.assertEqual(row["attempt_count"], 0)
        self.assertEqual(dao.get("TX-P")["precondition_status"], "NOT_YET_CHECKED")

    def test_invalid_transition_rejected(self):
        dao = self.dao()
        dao.create_prepared(**prep_kw("TX-I"))
        with self.assertRaises(InvalidTransition):
            dao._transition("TX-I", TransactionState.COMPLETED.value)
        self.assertEqual(dao.state_of("TX-I"), TransactionState.PREPARED.value)

    def test_terminal_nonterminal_available(self):
        dao = self.dao()
        dao.create_prepared(**prep_kw("TX-T"))
        self.assertEqual(dao.nonterminal("TX-T"), True)
        self.assertEqual(dao.terminal("TX-T"), False)
        dao.record_precondition_failure("TX-T", "changed before write")
        self.assertEqual(dao.terminal("TX-T"), True)
        self.assertTrue(dao.is_terminal_state(TransactionState.PRECONDITION_FAILED))
        self.assertFalse(dao.is_terminal_state(TransactionState.OUTCOME_UNKNOWN))

    def test_unknown_no_retry_transition(self):
        dao = self.dao()
        dao.create_prepared(**prep_kw("TX-UNK"))
        dao.open_runtime_attempt("TX-UNK")
        dao.record_outcome_unknown("TX-UNK", "cannot conclude")
        self.assertEqual(dao.state_of("TX-UNK"), TransactionState.OUTCOME_UNKNOWN.value)
        with self.assertRaises(InvalidTransition):
            dao._transition("TX-UNK", TransactionState.RUNTIME_ATTEMPTING.value)

    def test_one_runtime_attempt_max(self):
        dao = self.dao()
        dao.create_prepared(**prep_kw("TX-A"))
        entry = dao.open_runtime_attempt("TX-A")
        self.assertEqual(entry["state"], TransactionState.RUNTIME_ATTEMPTING.value)
        self.assertEqual(entry["attempt_count"], 1)
        with self.assertRaises(DuplicateAttempt):
            dao.open_runtime_attempt("TX-A")

    def test_second_attempt_rejected_and_new_tx_required(self):
        dao = self.dao()
        dao.create_prepared(**prep_kw("TX-B"))
        dao.open_runtime_attempt("TX-B")
        with self.assertRaises(DuplicateAttempt):
            dao.open_runtime_attempt("TX-B")
        dao.create_prepared(**prep_kw("TX-B2"))
        e2 = dao.open_runtime_attempt("TX-B2")
        self.assertEqual(e2["attempt_count"], 1)

    def test_precondition_ok_and_failure(self):
        dao = self.dao()
        dao.create_prepared(**prep_kw("TX-C"))
        dao.set_precondition_ok("TX-C")
        self.assertEqual(dao.get("TX-C")["precondition_status"],
                         PreconditionStatus.PRECONDITION_OK.value)
        dao2 = self.dao()
        dao2.create_prepared(**prep_kw("TX-D"))
        dao2.record_precondition_failure("TX-D", "second read differed")
        self.assertEqual(dao2.state_of("TX-D"), TransactionState.PRECONDITION_FAILED.value)

    def test_list_nonterminal(self):
        dao = self.dao()
        dao.create_prepared(**prep_kw("TX-L1"))
        dao.create_prepared(**prep_kw("TX-L2"))
        dao.create_prepared(**prep_kw("TX-L3"))
        dao.record_precondition_failure("TX-L3", "mismatch")
        ids = {r["continuity_tx_id"] for r in dao.nonterminal_rows()}
        self.assertIn("TX-L1", ids)
        self.assertIn("TX-L2", ids)
        self.assertNotIn("TX-L3", ids)

    def test_bounded_error_detail(self):
        dao = self.dao()
        dao.create_prepared(**prep_kw("TX-E"))
        dao.record_error("TX-E", "TEST_ERROR", "x" * 5000)
        detail = dao.get("TX-E")["last_error_detail"]
        self.assertLessEqual(len(detail), 400)

    def test_manual_review_stores_no_cot_field(self):
        dao = self.dao()
        dao.create_prepared(**prep_kw("TX-M"))
        dao.open_runtime_attempt("TX-M")
        dao.record_outcome_unknown("TX-M", "ambiguous")
        mrow = dao.mark_manual_review(
            "TX-M",
            evidence_summary={"pre": "h0", "expected": "se"},
            safe_actions=["obtain_independent_strong_evidence", "mark_permanently_unknown"])
        packet = json.loads(mrow["manual_review_json"])
        self.assertNotIn("chain_of_thought", packet)
        self.assertNotIn("reasoning", packet)
        self.assertIn("safe_action_codes", packet)
        self.assertEqual(mrow["manual_review_required"], 1)

    def test_helpers_reject_unknown_tx(self):
        dao = self.dao()
        with self.assertRaises(UnknownTx):
            dao.open_runtime_attempt("DOES-NOT-EXIST")

    def test_exception_mid_journal_mutation_rollback(self):
        dao = self.dao()
        dao.create_prepared(**prep_kw("TX-RB"))
        before_events = len(dao.state_events("TX-RB"))
        with self.assertRaises(InvalidTransition):
            dao._transition("TX-RB", TransactionState.COMPLETED.value)
        self.assertEqual(dao.state_of("TX-RB"), TransactionState.PREPARED.value)
        self.assertEqual(len(dao.state_events("TX-RB")), before_events)


if __name__ == "__main__":
    unittest.main()
