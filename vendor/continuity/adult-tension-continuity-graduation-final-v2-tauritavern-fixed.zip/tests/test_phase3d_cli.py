"""Phase 3D — orchestration CLI safety + round-trip (§23/§50/§54).

The three new CLIs are present, production-runtime-refusing by default, and the
real-mutation CLI operates only on a disposable fixture with a concrete patch +
explicit consequence plan.  `orchestration_status` and `orchestration recovery`
are read-only / resume-only of the durable layer.
"""
from __future__ import annotations
import json
import os
import sqlite3
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tests.phase3b_fixture import make_disposable_vendor, simple_patch, current_bytes

SCRIPTS = ROOT / "scripts"


def _run_cli(args, cwd=ROOT):
    return subprocess.run([sys.executable] + args, cwd=str(cwd),
                          capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=300)


class Phase3dCliTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.turn = SCRIPTS / "orchestrate_turn.py"
        cls.status = SCRIPTS / "orchestration_status.py"
        cls.recover = SCRIPTS / "recover_orchestration.py"
        _ = cls.status.exists(), cls.recover.exists()

    def _cli_log(self, r):
        return (r.stdout or "")[-600:] + "\nSTDERR:\n" + (r.stderr or "")[-600:]

    def test_clis_present(self):
        for p in (self.turn, self.status, self.recover):
            self.assertTrue(p.exists(), p)

    def test_cli_refuses_production_without_disposable_flag(self):
        root, vendor, runtime = make_disposable_vendor()
        db = root / "state" / "c.sqlite3"; db.parent.mkdir(parents=True, exist_ok=True)
        cons = json.dumps([{"kind": "EPISODE_APPEND",
                            "payload": {"summary": "x", "scene_ref": "S"}}])
        patchf = root / "patch.json"
        patchf.write_text(json.dumps(simple_patch()))
        consf = root / "cons.json"; consf.write_text(cons)
        r = _run_cli([str(self.turn), "--db", str(db), "--vendor", str(vendor),
                      "--runtime", str(runtime), "--patch", str(patchf),
                      "--consequences", str(consf)])
        self.assertNotEqual(r.returncode, 0, self._cli_log(r))
        self.assertIn("REFUSE", (r.stdout + r.stderr).upper())

    def test_cli_dry_run_no_mutation(self):
        root, vendor, runtime = make_disposable_vendor()
        db = root / "state" / "c.sqlite3"; db.parent.mkdir(parents=True, exist_ok=True)
        pre = current_bytes(vendor)
        r = _run_cli([str(self.turn), "--db", str(db), "--vendor", str(vendor),
                      "--runtime", str(runtime),
                      "--no-consequences", "--disposable-runtime", "--dry-run"])
        self.assertEqual(r.returncode, 0, self._cli_log(r))
        self.assertEqual(current_bytes(vendor), pre, "dry-run must not touch runtime")

    def test_cli_rejects_non_disposable_vendor_even_with_flag(self):
        root, vendor, runtime = make_disposable_vendor()
        # point at a NON /tmp source-like root => is_disposable_runtime fails
        db = root / "state" / "c.sqlite3"; db.parent.mkdir(parents=True, exist_ok=True)
        r = _run_cli([str(self.turn), "--db", str(db), "--vendor", str(ROOT),
                      "--runtime", str(ROOT / "saves" / "current_state.yaml"),
                      "--patch", "x", "--no-consequences", "--disposable-runtime"])
        self.assertNotEqual(r.returncode, 0)

    def test_cli_full_disposable_happy_path(self):
        root, vendor, runtime = make_disposable_vendor()
        db = root / "state" / "c.sqlite3"; db.parent.mkdir(parents=True, exist_ok=True)
        patchf = root / "patch.json"; patchf.write_text(json.dumps(simple_patch()))
        consf = root / "cons.json"
        consf.write_text(json.dumps([{"kind": "EPISODE_APPEND",
                                      "payload": {"summary": "cli ep", "scene_ref": "C1"}}]))
        r = _run_cli([str(self.turn), "--db", str(db), "--vendor", str(vendor),
                      "--runtime", str(runtime), "--patch", str(patchf),
                      "--consequences", str(consf), "--disposable-runtime", "--json"])
        self.assertEqual(r.returncode, 0, self._cli_log(r))
        data = json.loads(r.stdout)
        self.assertEqual(data["status"], "COMPLETED")
        tx = data["continuity_tx_id"]
        # status CLI shows COMPLETED
        s = _run_cli([str(self.status), "--db", str(db), "--tx", tx])
        st = json.loads(s.stdout)
        self.assertEqual(st["state"], "COMPLETED")
        self.assertEqual(st["attempt_count"], 1)
        # recover on COMPLETED is a safe no-op status read (terminal row)
        rec = _run_cli([str(self.recover), "--db", str(db), "--tx", tx,
                        "--consequences", str(consf)])
        self.assertEqual(rec.returncode, 0, self._cli_log(rec))
        self.assertEqual(json.loads(rec.stdout)["status"], "COMPLETED")

    def test_status_cli_handles_unknown_tx(self):
        root, vendor, runtime = make_disposable_vendor()
        db = root / "state" / "c.sqlite3"; db.parent.mkdir(parents=True, exist_ok=True)
        s = _run_cli([str(self.status), "--db", str(db), "--tx", "does-not-exist"])
        self.assertEqual(s.returncode, 1)
        self.assertIn("not_found", s.stdout)


if __name__ == "__main__":
    unittest.main()
