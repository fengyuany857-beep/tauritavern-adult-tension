"""Generated regressions for Graduation Fix3 compact cross-family authority gaps.

All fixtures are synthetic structural data. No adult narrative/content is used.
"""
from __future__ import annotations

import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from continuity.constants import AdmissionState, Classification, Plane, TruthStatus
from continuity.errors import AuthorityError
from continuity.models import FactInput
from continuity.orchestration import orchestrate
from continuity.orchestration.contracts import ConsequencePlan, OrchestrationRequest
from continuity.retrieval import Context, LedgerRetriever, LexicalRetriever, RetrievalQuery, TemporalRetriever
from continuity.routing import ContextPackBuilder, RoutingRequest
from continuity.sync3c.contracts import ContinuitySyncRequest, EffectKind
from continuity.sync3c.planner import PlanError, build_plan
from continuity.sync3c.sqlwriter import EffectApplyError, effect_sql
from continuity.validation import insert_fact, is_runtime_owned_predicate
from tests.context_builder_fixture import build_context_base, runtime_state_path
from tests.phase3b_fixture import current_bytes, make_disposable_vendor, simple_patch
from tests.phase3c_fixture import seed_disposable_db_current
from tests.phase3d_fixture import seed_disposable_db

CURRENT_FIELDS = (
    "boundary", "permission", "safety", "trust", "relationship", "emotion",
    "goal", "location", "scene", "turn",
)
RUNTIME_SCOPES = ("player", "pc", "plr", "npc", "npcs", "runtime", "current")
RE_GATE_MINIMUM = (
    "playeremotion", "playergoal", "playertrust", "playerrelationship",
    "playerpermission", "playerboundary", "npcemotion", "npcgoal", "npctrust",
    "npcrelationship", "npcpermission", "npcboundary",
)


def _fact_plan(predicate: str, subject: str) -> ConsequencePlan:
    return ConsequencePlan(consequences=[{
        "kind": "FACT_INSERT",
        "payload": {"subject_ref": subject, "predicate": predicate,
                    "object": {"synthetic": True}},
    }])


def _orch_request(vendor: Path, runtime: Path, plan: ConsequencePlan) -> OrchestrationRequest:
    return OrchestrationRequest(
        patch=simple_patch(), vendor_dir=str(vendor), runtime_path=str(runtime),
        consequence_plan=plan)


def _sync_req(predicate: str, subject: str) -> ContinuitySyncRequest:
    return ContinuitySyncRequest(
        continuity_tx_id="tx-fix3", runtime_outcome_class="CONFIRMED_APPLIED",
        observed_post_sha256="0" * 64, observed_post_semantic_digest="0" * 64,
        expected_candidate_digest="e", patch_digest="p", branch_id="default",
        source_provenance={}, request_provenance={}, sync_plan_bytes_digest="",
        consequences=[{"kind": "FACT_INSERT", "payload": {
            "subject_ref": subject, "predicate": predicate,
            "object": {"synthetic": True}}}],
    )


class GeneratedCompactAuthorityFix3(unittest.TestCase):
    def test_generated_scope_field_compacts_are_runtime_owned(self):
        # Generated matrix is intentionally broader than the exact prior probe.
        for scope in RUNTIME_SCOPES:
            for field in CURRENT_FIELDS:
                for predicate in (scope + field, field + scope,
                                  scope + "current" + field,
                                  "current" + scope + field):
                    with self.subTest(predicate=predicate):
                        self.assertTrue(is_runtime_owned_predicate(predicate))
        for predicate in RE_GATE_MINIMUM:
            with self.subTest(minimum=predicate):
                self.assertTrue(is_runtime_owned_predicate(predicate))

    def test_nonreserved_compacts_are_not_accidentally_blocked(self):
        for predicate in ("favoritecolor", "anniversarynote", "visitedmuseum",
                          "historicalpromise", "weatheredphoto"):
            with self.subTest(predicate=predicate):
                self.assertFalse(is_runtime_owned_predicate(predicate))

    def test_phase1_and_planner_reject_cross_family_compacts(self):
        with tempfile.TemporaryDirectory() as td:
            db = seed_disposable_db_current(Path(td))
            con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
            con.execute("PRAGMA foreign_keys=ON")
            base = dict(
                object_json=json.dumps({"synthetic": True}), plane=Plane.OBJECTIVE,
                admission_state=AdmissionState.COMMITTED, truth_status=TruthStatus.ACTIVE,
                valid_from_turn=1, invalid_at_turn=None, recorded_at_turn=1,
                provenance_json="{}", classification=Classification.AUTHORITY)
            for i, predicate in enumerate(RE_GATE_MINIMUM):
                subject = "E-PL" if predicate.startswith("player") else "E-A"
                fact = FactInput(fact_id=f"F-{i}", subject_ref=subject,
                                 predicate=predicate, **base)
                with self.subTest(phase1=predicate), self.assertRaises(AuthorityError):
                    insert_fact(con, fact)
                with self.subTest(planner=predicate), self.assertRaises(PlanError):
                    build_plan(_sync_req(predicate, subject))
            self.assertEqual(con.execute("SELECT COUNT(*) FROM facts").fetchone()[0], 0)
            con.close()

    def test_writer_boundary_rejects_cross_family_compacts(self):
        with tempfile.TemporaryDirectory() as td:
            db = seed_disposable_db_current(Path(td))
            con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
            con.execute("PRAGMA foreign_keys=ON")
            scope = {"continuity_tx_id": "tx-w", "branch_id": "default",
                     "effect_id": "effect-w", "plan_digest": "d", "turn": 1}
            for predicate in RE_GATE_MINIMUM:
                subject = "E-PL" if predicate.startswith("player") else "E-A"
                with self.subTest(predicate=predicate), self.assertRaises(EffectApplyError):
                    effect_sql(con, EffectKind.FACT_INSERT,
                               {"subject_ref": subject, "predicate": predicate,
                                "object": {"synthetic": True}}, scope)
            self.assertEqual(con.execute("SELECT COUNT(*) FROM facts").fetchone()[0], 0)
            con.close()

    def test_public_phase3d_rejects_required_cross_family_matrix_before_runtime(self):
        for predicate in RE_GATE_MINIMUM:
            subject = "E-PL" if predicate.startswith("player") else "E-A"
            root, vendor, runtime = make_disposable_vendor()
            db = seed_disposable_db(root)
            before = current_bytes(vendor)
            out = orchestrate(_orch_request(vendor, runtime, _fact_plan(predicate, subject)),
                              db_path=db)
            with self.subTest(predicate=predicate):
                self.assertEqual(out.status, "REFUSED")
                self.assertFalse(out.runtime_attempted)
                self.assertEqual(current_bytes(vendor), before)
            con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
            self.assertEqual(con.execute("SELECT COUNT(*) FROM facts").fetchone()[0], 0)
            self.assertEqual(con.execute("SELECT COUNT(*) FROM transaction_journal").fetchone()[0], 0)
            con.close()

    def test_all_fact_retrievers_and_context_pack_block_cross_family_legacy_rows(self):
        tmp, base = build_context_base(); self.addCleanup(tmp.cleanup)
        db = base / "state" / "continuity.sqlite3"
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        rows = []
        for i, predicate in enumerate(RE_GATE_MINIMUM):
            subject = "E-PL" if predicate.startswith("player") else "E-A"
            fid = f"F-FIX3-{i}"
            rows.append((fid, subject, predicate))
            con.execute(
                "INSERT INTO facts (fact_id,branch_id,subject_ref,predicate,object_json,"
                "plane,admission_state,truth_status,valid_from_turn,invalid_at_turn,"
                "recorded_at_turn,recorded_at,provenance_json,classification) "
                "VALUES (?,?,?,?,?,'OBJECTIVE','COMMITTED','ACTIVE',1,NULL,1,?,?,?)",
                (fid, "default", subject, predicate, json.dumps({"synthetic": True}),
                 "2026-01-01T00:00:00+00:00", "{}", "AUTHORITY"))
        con.commit()
        ctx = Context(conn=con, base=base,
                      index_path=base / "indexes" / "retrieval_fts.sqlite3")
        ids = {r[0] for r in rows}

        temporal = TemporalRetriever().retrieve(
            RetrievalQuery(branch_id="default", event_turn=10, limit=100, query_id="t"), ctx)
        self.assertFalse(ids & {x.item_id for x in temporal.items})

        ledger = LedgerRetriever().retrieve(
            RetrievalQuery(branch_id="default", event_turn=10, limit=100,
                           fact_ids=tuple(ids), query_id="g"), ctx)
        self.assertFalse(ids & {x.item_id for x in ledger.items})

        for fid, _, predicate in rows:
            lexical = LexicalRetriever().retrieve(
                RetrievalQuery(raw_text=predicate, branch_id="default", event_turn=10,
                               limit=100, query_id=f"l-{fid}"), ctx)
            with self.subTest(lexical=predicate):
                self.assertNotIn(fid, {x.item_id for x in lexical.items})
        con.close()

        pack = ContextPackBuilder(base).build(
            RoutingRequest(raw_text=" ".join(RE_GATE_MINIMUM), branch_id="default",
                           query_id="pack", scene_entity_ids=("E-A", "E-PL"),
                           observer_entity_id="E-A"),
            runtime_state=runtime_state_path(base))
        self.assertFalse(ids & {item.source_ref for item in pack.items})


if __name__ == "__main__":
    unittest.main()
