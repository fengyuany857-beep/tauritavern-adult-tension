"""Shared Phase 2B-2 fixture factory (read-only tests for re-entry planning).

Self-contained shadow-continuum scenario created fresh per test so each test
starts from the same deterministic authority DB and a runtime snapshot file it
can reference / read-only.
"""
from __future__ import annotations
import json
import tempfile
from pathlib import Path

from continuity.db import connect

# stable continuity entity ids
PLR = "PLR"
ALEX = "ALEX"          # main                          ext alex-x
BINA = "BINA"          # important_supporting          ext bina-x
MINI = "MINI"          # minor                         ext mini-x
ALEXA = "ALEXA"        # same display name Alex-A       ext alexa-x
ALEXB = "ALEXB"        # same display name Alex-B       ext alexb-x
NORA = "NORA"          # (confirmed alias "Dr. Rey")    ext nora-x
BOB = "BOB"            # offscreen unrelated            ext bob-x

_CARDS = {}

_EXT = {"ALEX": "alex-x", "BINA": "bina-x", "MINI": "mini-x",
        "ALEXA": "alexa-x", "ALEXB": "alexb-x", "NORA": "nora-x", "BOB": "bob-x"}


def _json(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True)


def _ins(cur, sql, *p):
    cur.execute(sql, p)


def _cards():
    """Full runtime NPC cards keyed by continuity entity id (registry source)."""
    if _CARDS:
        return _CARDS
    _CARDS.update({
        PLR: {"id": "player-p".replace("player-p", "plr-x"), "name": "You",
              "role_level": "player", "knowledge": []},
        ALEX: {"id": _EXT[ALEX], "name": "Alex", "role_level": "main",
               "core_personality": "quiet dry", "voice_filter": "dry",
               "goal": "", "knowledge": [], "recent_memories": []},
        BINA: {"id": _EXT[BINA], "name": "Bina", "role_level": "important_supporting",
               "core_personality": "patient", "voice_filter": "soft",
               "goal": "", "knowledge": [], "recent_memories": []},
        MINI: {"id": _EXT[MINI], "name": "Mini", "role_level": "minor",
               "core_personality": "", "voice_filter": "small",
               "goal": "", "knowledge": [], "recent_memories": []},
        ALEXA: {"id": _EXT[ALEXA], "name": "Alex", "role_level": "minor",
                "core_personality": "", "voice_filter": "harsh",
                "goal": "", "knowledge": [], "recent_memories": []},
        ALEXB: {"id": _EXT[ALEXB], "name": "Alex", "role_level": "minor",
                "core_personality": "", "voice_filter": "flat",
                "goal": "", "knowledge": [], "recent_memories": []},
        NORA: {"id": _EXT[NORA], "name": "Nora", "role_level": "important_supporting",
               "core_personality": "guarded", "voice_filter": "low",
               "goal": "", "knowledge": [], "recent_memories": []},
        BOB: {"id": _EXT[BOB], "name": "Bob", "role_level": "minor",
              "core_personality": "", "voice_filter": "gruff",
              "goal": "", "knowledge": [], "recent_memories": []},
    })
    # ensure player card id stable
    _CARDS[PLR] = {"id": "plr-x", "name": "You", "role_level": "player",
                   "knowledge": [], "recent_memories": []}
    return _CARDS


def build():
    """Return (tmpdir, base, run_cards)."""
    tmp = tempfile.TemporaryDirectory()
    base = Path(tmp.name)
    for sub in ("state", "indexes", "manifests", "history"):
        (base / sub).mkdir(parents=True, exist_ok=True)
    conn = connect(base / "state" / "continuity.sqlite3")
    cur = conn.cursor()
    cards = _cards()

    def entity(eid, kind="npc", cap=None, non=(), xref=None):
        xref = xref or (cards[eid]["id"] if eid in cards else (_EXT.get(eid) or eid + "-x"))
        capj = _json(cap if cap is not None else {"canonical_name": eid})
        _ins(cur,
             "INSERT INTO entities (entity_id,branch_id,kind,runtime_external_ref,identity_status,anchors_json,explicit_non_capabilities_json) VALUES (?,?,?,?,?,?,?)",
             eid, "default", kind, xref, "confirmed", capj, _json(list(non)))

    entity(PLR, kind="player")
    entity(ALEX, cap={"canonical_name": "Alex", "voice": "quiet dry", "normal_mode": "steady"},
           non=["unable_to_roar"])
    entity(BINA, cap={"canonical_name": "Bina", "voice": "patient"})
    entity(MINI, cap={"canonical_name": "Mini"})
    entity(ALEXA, cap={"canonical_name": "Alex"})      # -> same display name as ALEX
    entity(ALEXB, cap={"canonical_name": "Alex"})
    entity(NORA, cap={"canonical_name": "Nora"})
    entity(BOB, cap={"canonical_name": "Bob"})

    # ---- aliases -----------------------------------------------------------
    al = [("AL-A1", ALEX, "Alex", "confirmed"),
          ("AL-REY", NORA, "Dr. Rey", "confirmed"),
          ("AL-A2", ALEXB, "Alex", "confirmed"),         # >1 confirmed name claim
          ("AL-MG", ALEXB, "Bailey", "merge_candidate")] # merge_candidate not identity
    for aid, ent, alias, status in al:
        _ins(cur, "INSERT INTO entity_aliases (alias_id,entity_id,alias,status,provenance_json) "
                  "VALUES (?,?,?,?,?)", aid, ent, alias, status, _json({}))

    # ---- facts -------------------------------------------------------------
    def fact(fid, subject, pred, obj, branch="default", truth="ACTIVE", vf=None,
             rec=None, inv=None):
        rec = vf if rec is None else rec
        _ins(cur,
             "INSERT INTO facts (fact_id,branch_id,subject_ref,predicate,object_json,plane,admission_state,truth_status,valid_from_turn,invalid_at_turn,recorded_at_turn,recorded_at,provenance_json,classification) "
             "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
             fid, branch, subject, pred, _json(obj), "OBJECTIVE", "COMMITTED", truth,
             vf, inv, rec, "2026-01-01T00:00:00", _json({}), "AUTHORITY")

    fact("F-ALEX-C", ALEX, "works_at", {"place": "clinic"}, vf=10, rec=8)
    fact("F-ALEX-SUP", ALEX, "was.called", {"name": "OldName"}, truth="SUPERSEDED",
         vf=1, rec=20, inv=20)
    fact("F-BOB-WB", BOB, "guards", {"branch": "gate"}, branch="alt", vf=1, rec=1)

    # ---- knowledge (character-scoped + canary rows) -------------------------
    for kid, subject, state, prop in (("K-A-KNOW", ALEX, "knows", "PROP-mystery"),
                                      ("K-A-FB", ALEX, "false_belief", "PROP-door"),
                                      ("K-B-SECRET", BOB, "knows", "PROP-bobs"),
                                      ("K-B-RESTRICT", BOB, "does_not_know", "PROP-xx")):
        _ins(cur, "INSERT INTO knowledge (knowledge_id,branch_id,subject_ref,proposition_ref,state,plane,source,promotion_basis,turn,provenance_json) "
                  "VALUES (?,?,?,?,?,?,?,?,?,?)",
             kid, "default", subject, prop, state, "CHARACTER", "witnessed", "witnessed", 5, _json({}))
    # PLAYER_VISIBLE / AUTHOR must never become target in-character knowledge
    _ins(cur, "INSERT INTO knowledge (knowledge_id,branch_id,subject_ref,proposition_ref,state,plane,source,promotion_basis,turn,provenance_json) "
              "VALUES ('K-PV','narrator','knows','PROP-hint','knows','PLAYER_VISIBLE','w','w',3,'{}')")
    _ins(cur, "INSERT INTO knowledge (knowledge_id,branch_id,subject_ref,proposition_ref,state,plane,source,promotion_basis,turn,provenance_json) "
              "VALUES ('K-AUT','author','knows','PROP-plan','knows','AUTHOR','a','a',1,'{}')")

    # ---- relationships -------------------------------------------------------
    def rel(rid, s, t, pub, phase):
        _ins(cur, "INSERT INTO relationships (relationship_id,branch_id,source_ref,target_ref,runtime_refs_json,public_surface,actual_relation,phase,provenance_json) "
                  "VALUES (?,?,?,?,?,?,?,?,?)",
             rid, "default", s, t, _json([]), pub, "close", phase, _json({}))
    rel("R-ALEX-PLR", ALEX, PLR, "intimate", "intimate")
    rel("R-BOB-PLR", BOB, PLR, "colleague", "colleague")
    rel("R-ALEX-BOB", ALEX, BOB, "colleague", "colleague")
    _ins(cur, "INSERT INTO relationship_dimensions (dimension_id,relationship_id,name,value_json,classification) "
              "VALUES ('RDM-t','R-ALEX-PLR','trust',?, 'AUTHORITY')", _json("high"))
    _ins(cur, "INSERT INTO relationship_dimensions (dimension_id,relationship_id,name,value_json,classification) "
              "VALUES ('RDM-a','R-ALEX-PLR','attraction',?, 'AUTHORITY')", _json("high"))

    # ---- commitments -----------------------------------------------------------
    def com(cid, issuer, bens, kind, content, status):
        _ins(cur, "INSERT INTO commitments (commitment_id,branch_id,kind,issuer_ref,beneficiary_refs_json,content,status,runtime_event_ref,provenance_json) "
                  "VALUES (?,?,?,?,?,?,?,?,?)",
             cid, "default", kind, issuer, _json(list(bens)), content, status, None, _json({}))
    com("C-ALEX-PLR", ALEX, [PLR], "promise", "will call at new year", "due")
    com("C-PLR-ALEX", PLR, [ALEX], "debt", "return the borrowed compass", "open")
    com("C-ALEX-RES", ALEX, [PLR], "promise", "old resolved thing", "resolved")
    com("C-BOB-PLR", BOB, [PLR], "promise", "grab coffee", "open")
    com("C-ALEX-UNREL", ALEX, [BOB], "promise", "offscreen lantern thing", "open")

    # ---- threads ---------------------------------------------------------------
    def thread(tid, status, author, obj):
        _ins(cur, "INSERT INTO threads (thread_id,branch_id,status,author_state,objective_state,player_visible_state,reveal_gate_json,presentation_json,provenance_json) "
                  "VALUES (?,?,?,?,?,?,?,?,?)",
             tid, "default", status, author, obj, "p", _json({}), _json({}), _json({}))
    thread("TH-OPEN-A", "active", ALEX, "secret-cache")
    thread("TH-OTHER-A", "active", ALEX, "o2")
    # TH-GATED-A: ALEX-linked active thread WITH an unmet reveal gate + anti-merge
    _ins(cur, "INSERT INTO threads (thread_id,branch_id,status,author_state,objective_state,player_visible_state,reveal_gate_json,presentation_json,provenance_json) "
              "VALUES ('TH-GATED-A','default','active',?,?,'p',?,?,?)",
         ALEX, "secret-cache",
         _json({"requires": ["F-NOPE"]}), _json({"kind": "restricted"}), _json({}))
    thread("TH-UNREL-B", "active", BOB, "o")
    _ins(cur, "INSERT INTO thread_requires (require_id,thread_id,ref,expected_state,plane) "
              "VALUES ('TR-G','TH-GATED-A','F-NOPE','ACTIVE','OBJECTIVE')")
    _ins(cur, "INSERT INTO thread_anti_merge (anti_merge_id,thread_id,blocked_ref,reason) "
              "VALUES ('AM-G','TH-GATED-A','TH-OTHER-A','separate ops')")

    # ---- continuity transactions / episodes / links --------------------------
    # ALEX has several shared episodes across time (caps tested), BINA one
    # relationship-changing scene earlier in the timeline.
    ep_tx = [
        ("TX-N", "2026-06-02T00:00:00", "EP-NEW", "SC-20", [ALEX, PLR], "default"),
        ("TX-F", "2026-03-05T00:00:00", "EP-CLIMACTIC", "SC-5", [ALEX, PLR], "default"),
        ("TX-C", "2026-02-11T00:00:00", "EP-COMMIT", "SC-6", [ALEX, PLR], "default"),
        ("TX-R", "2026-01-22T00:00:00", "EP-REL", "SC-7", [BINA, ALEX], "default"),
        ("TX-O", "2026-01-01T00:00:00", "EP-OLD", "SC-1", [ALEX, PLR], "default"),
        ("TX-W", "2026-02-01T00:00:00", "EP-WB", "SC-9", [BOB], "alt"),
    ]
    for txid, created, ep, scene, participants, branch in ep_tx:
        _ins(cur, "INSERT INTO continuity_transactions VALUES (?,?,?,?,?,?,?,?)",
             txid, "commit", "pre", "post", "COMMITTED", created, None, None)
        _ins(cur, "INSERT INTO episodes (episode_id,continuity_tx_id,branch_id,runtime_pre_hash,runtime_post_hash,history_pointer,checksum) "
                  "VALUES (?,?,?,?,?,?,?)",
             ep, txid, branch, "pre", "post", "VOL-" + ep + ".jsonl", "x")
        for p in participants:
            _ins(cur, "INSERT INTO episode_entity_links (episode_id,entity_id) VALUES (?,?)", ep, p)
    conn.commit()
    conn.close()
    return tmp, base, cards


def make_runtime(base: Path, *, roster: tuple[str, ...],
                 turn: int = 200, scene: str = "SC-LATE") -> Path:
    """Write a JSON-subset runtime snapshot whose ``npcs`` registry holds full
    cards for the supplied continuity entity ids plus the player.  Sorted keys =>
    deterministic file hash for a given roster."""
    cards = _cards()
    rosterset = tuple(dict.fromkeys([e for e in roster if e != PLR]))
    node_participants = [cards[e]["id"] for e in rosterset]
    snap = {
        "meta": {"turn": turn},
        "world": {"clock": "2026-06-10T12:00:00"},
        "current_node": {"scene_id": scene, "participants": node_participants},
        "player": {"id": "plr-x", "knowledge": []},
        "npcs": [cards[e] for e in rosterset],
        "relationships": [], "events": [],
        "consent": {"grants": []}, "boundaries": [], "checkpoint": {},
    }
    p = base / "state" / ("rt_" + "." .join(sorted(rosterset))) 
    p = p.with_suffix(".json")
    p.write_text(json.dumps(snap, sort_keys=True), encoding="utf-8")
    return p
