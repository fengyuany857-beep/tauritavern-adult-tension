import json,unittest
from continuity.constants import *
from continuity.models import FactInput
from continuity.validation import insert_fact,current_facts,supersede
from continuity.errors import ValidationError
from util import tmpdb
class T(unittest.TestCase):
 def test_author_plan_not_objective(self):
  d,c=tmpdb(); self.addCleanup(d.cleanup)
  f=FactInput('F1','E1','canon.secret','{}',Plane.OBJECTIVE,AdmissionState.COMMITTED,TruthStatus.AUTHOR_PLAN,None,None,1,'{}')
  with self.assertRaises(ValidationError): insert_fact(c,f)
 def test_candidate_not_current_and_supersede_kept(self):
  d,c=tmpdb(); self.addCleanup(d.cleanup)
  a=FactInput('F1','E1','canon.x','{}',Plane.OBJECTIVE,AdmissionState.COMMITTED,TruthStatus.ACTIVE,1,None,1,'{"x":1}')
  b=FactInput('F2','E1','canon.x','{}',Plane.OBJECTIVE,AdmissionState.CANDIDATE,TruthStatus.ACTIVE,2,None,2,'{}')
  insert_fact(c,a);insert_fact(c,b);self.assertEqual(['F1'],[x['fact_id'] for x in current_facts(c)])
  c.execute("INSERT INTO continuity_transactions VALUES('T','x',NULL,NULL,'PREPARED','now',NULL,NULL)");supersede(c,'F1','F2','T');self.assertEqual([],current_facts(c));self.assertEqual('SUPERSEDED',c.execute("select truth_status from facts where fact_id='F1'").fetchone()[0])
