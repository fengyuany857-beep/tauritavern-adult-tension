"""Phase 3B — attempt reservation, one-attempt invariant, second pre-write.

Focus on protocol P9 / invariant 1-4 + §32(6,7,8,9,10,11,12,13,14,30,31,50,51,52).
The tests operate against a disposable vendor clone with a real runtime file.
Mutation (real single-file vendor writer) is exercised only via commit_single_file
on a disposable runtime.
"""
from __future__ import annotations
import copy
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3b_fixture import (
    make_disposable_vendor, seed_disposable_db, simple_patch, current_bytes,
)

from continuity.transactions.preconditions import prepare_transaction
from continuity.transactions.journal import JournalDao
from continuity.transactions.errors import DuplicateAttempt
from continuity.runtime3b.execute import commit_single_file
from continuity.runtime3b.classifier import outcome_to_class, RuntimeOutcomeDecision
from continuity.transactions.contracts import (
    TransactionState, RuntimeOutcomeClass,
)


def _connect(db: Path):
    con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con


class Phase3BAttemptReservationTests(unittest.TestCase):
    def make_isolated(self):
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        pe = prepare_transaction(vendor_dir=vendor, db_path=db, runtime_path=runtime,
                                 patch=simple_patch(), branch_id="default")
        return root, vendor, runtime, db, pe

    # 6. attempt_count initially 0 -----------------------------------
    def test_attempt_count_initial_zero(self):
        _, _, _, db, pe = self.make_isolated()
        con = _connect(db)
        self.assertEqual(con.execute(
            "SELECT attempt_count FROM transaction_journal WHERE continuity_tx_id=?",
            (pe.continuity_tx_id,)).fetchone()[0], 0)
        con.close()

    def test_attempt_reservation_and_one_attempt_invariant(self):
        _, vendor, runtime, db, pe = self.make_isolated()
        self.assertTrue((vendor / "saves" / "current_state.yaml").exists())
        env = commit_single_file(db_path=db, vendor_dir=vendor,
                                 runtime_path=runtime, tx_id=pe.continuity_tx_id,
                                 patch=simple_patch())
        self.assertEqual(env.runtime_outcome, RuntimeOutcomeClass.CONFIRMED_APPLIED.value)
        con = _connect(db)
        r = con.execute("SELECT state, attempt_count FROM transaction_journal "
                        "WHERE continuity_tx_id=?", (pe.continuity_tx_id,)).fetchone()
        # Applied tx rest at DURABILITY_PENDING; attempt == 1.
        self.assertIn(r["state"], (TransactionState.DURABILITY_PENDING.value,
                                   TransactionState.CONFIRMED_APPLIED.value))
        self.assertEqual(r["attempt_count"], 1)
        con.close()
        # same-tx second reservation is impossible
        dao = JournalDao(_connect(db))
        with self.assertRaises(DuplicateAttempt):
            dao.open_runtime_attempt(pe.continuity_tx_id)

    # 9 + 10 one-attempt after UNKNOWN / NOT_APPLIED -----------------
    def test_one_attempt_invariant_after_precondition_failed_state(self):
        # a second single-file attempt on a terminal tx must be refused through
        # the executor (returns NOT_ELIGIBLE; writer never re-invoked)
        _, vendor, runtime, db, pe = self.make_isolated()
        # mutate runtime to fail P8 prewrite so attempt stays 0
        rt = vendor / "saves" / "current_state.yaml"
        rt.write_bytes(rt.read_bytes() + b"\n# touched externally\n")
        env = commit_single_file(db_path=db, vendor_dir=vendor,
                                 runtime_path=runtime, tx_id=pe.continuity_tx_id,
                                 patch=simple_patch())
        self.assertEqual(env.runtime_outcome, RuntimeOutcomeClass.PRECONDITION_FAILED.value)
        con = _connect(db)
        self.assertEqual(con.execute(
            "SELECT attempt_count from transaction_journal WHERE continuity_tx_id=?",
            (pe.continuity_tx_id,)).fetchone()[0], 0)   # precondition leaves attempt 0
        con.close()

    # 11 + 12 + 14: prewrite same-H0 allows writer; changed H0 blocks ---------
    def test_prewrite_same_h0_allows_writer_path(self):
        root, vendor, runtime, db, pe = self.make_isolated()
        before = current_bytes(vendor)
        env = commit_single_file(db_path=db, vendor_dir=vendor,
                                 runtime_path=runtime, tx_id=pe.continuity_tx_id,
                                 patch=simple_patch())
        self.assertTrue(env.writer_invoked)
        self.assertNotEqual(current_bytes(vendor), before)

    def test_prewrite_changed_h0_blocks_writer_and_invocation_zero(self):
        root, vendor, runtime, db, pe = self.make_isolated()
        rt = vendor / "saves" / "current_state.yaml"
        before = current_bytes(vendor)
        rt.write_bytes(before + b"\n# raw format change by external writer\n")  # raw-byte-only change
        # 13 + 14: a raw-byte-only formatting change still blocks precondition
        env = commit_single_file(db_path=db, vendor_dir=vendor,
                                 runtime_path=runtime, tx_id=pe.continuity_tx_id,
                                 patch=simple_patch())
        self.assertEqual(env.runtime_outcome, RuntimeOutcomeClass.PRECONDITION_FAILED.value)
        self.assertFalse(env.writer_invoked)
        # raw-byte-only change did not alter the actual file afterwards
        self.assertEqual(current_bytes(vendor), before + b"\n# raw format change by external writer\n")

    # ----------- §32 (31) two tx same H0: second loses precondition -------
    def test_two_tx_same_h0_second_loses_after_first_writes(self):
        root, vendor, runtime, db, pea = self.make_isolated()
        peb = prepare_transaction(vendor_dir=vendor, db_path=db,
                                  runtime_path=runtime, patch=simple_patch(),
                                  branch_id="default")
        env_a = commit_single_file(db_path=db, vendor_dir=vendor,
                                   runtime_path=runtime, tx_id=pea.continuity_tx_id,
                                   patch=simple_patch())
        self.assertEqual(env_a.runtime_outcome, RuntimeOutcomeClass.CONFIRMED_APPLIED.value)
        # second tx targets the same H0 => prewrite mismatch, blocked
        env_b = commit_single_file(db_path=db, vendor_dir=vendor,
                                   runtime_path=runtime, tx_id=peb.continuity_tx_id,
                                   patch=simple_patch())
        self.assertEqual(env_b.runtime_outcome, RuntimeOutcomeClass.PRECONDITION_FAILED.value)
        self.assertFalse(env_b.writer_invoked)

    # 54/55 timestamps & post observation recorded -------------------------
    def test_writer_timestamps_and_post_observation_recorded(self):
        _, vendor, runtime, db, pe = self.make_isolated()
        before = current_bytes(vendor)
        env = commit_single_file(db_path=db, vendor_dir=vendor,
                                 runtime_path=runtime, tx_id=pe.continuity_tx_id,
                                 patch=simple_patch())
        con = _connect(db)
        r = con.execute("SELECT runtime_attempt_started_at, runtime_attempt_finished_at,"
                        "       runtime_post_observed_sha256, runtime_post_semantic_digest,"
                        "       attempt_count FROM transaction_journal WHERE continuity_tx_id=?",
                        (pe.continuity_tx_id,)).fetchone()
        con.close()
        self.assertIsNotNone(r["runtime_attempt_started_at"])
        self.assertIsNotNone(r["runtime_attempt_finished_at"])
        self.assertIsNotNone(r["runtime_post_observed_sha256"])
        self.assertIsNotNone(r["runtime_post_semantic_digest"])
        # The post observed sha is the actual new bytes in the runtime file
        self.assertEqual(r["runtime_post_observed_sha256"],
                         __import__("hashlib").sha256(current_bytes(vendor)).hexdigest())
        self.assertNotEqual(before, current_bytes(vendor))

    # evidence recorded but no hidden reasoning (56/57)
    def test_journal_evidence_bounded_no_cot(self):
        _, vendor, runtime, db, pe = self.make_isolated()
        env = commit_single_file(db_path=db, vendor_dir=vendor,
                                 runtime_path=runtime, tx_id=pe.continuity_tx_id,
                                 patch=simple_patch())
        con = _connect(db)
        row = con.execute("SELECT manual_review_json, last_error_detail,"
                          "runtime_post_semantic_digest, continuity_sync_state "
                          "FROM transaction_journal "
                          "WHERE continuity_tx_id=?", (pe.continuity_tx_id,)).fetchone()
        con.close()
        blob = repr(dict(row))
        self.assertLessEqual(len(str(blob)), 12000)
        # No chain-of-thought / reasoning keys persisted as raw text
        self.assertNotIn("hidden", blob)
        self.assertNotIn("reasoning", blob.lower())

    # 50/51: UNKNOWN/NOT_APPLIED same-tx retry is impossible after consuming
    # 52 fresh-retry requires new tx: attempt stays frozen 1, runtime outcome terminal
    def test_unknown_retry_guard_journal_state(self):
        # UNKNOWN / NOT_APPLIED outcomes freeze the tx; we verify a terminal row
        # cannot be re-attempted by open_runtime_attempt through the journal.
        root, vendor, runtime, db, pe = self.make_isolated()
        # drive the tried row manually into RUNTIME_ATTEMPTING then leave UNKNOWN:
        con = _connect(db)
        dao = JournalDao(con)
        dao.open_runtime_attempt(pe.continuity_tx_id)
        dao.record_outcome_unknown(pe.continuity_tx_id)
        con.close()
        # attempt_count stays 1; a fresh reservation refused
        con = _connect(db)
        self.assertEqual(con.execute("SELECT attempt_count FROM transaction_journal WHERE "
                                     "continuity_tx_id=?", (pe.continuity_tx_id,)).fetchone()[0], 1)
        dao = JournalDao(con)
        with self.assertRaises(DuplicateAttempt):
            dao.open_runtime_attempt(pe.continuity_tx_id)
        con.close()


if __name__ == "__main__":
    unittest.main()
