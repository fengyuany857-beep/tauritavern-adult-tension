import unittest
from util import tmpdb
class T(unittest.TestCase):
 def test_runtime_event_reference_only(self):
  d,c=tmpdb();self.addCleanup(d.cleanup)
  c.execute("insert into commitments (commitment_id,branch_id,kind,issuer_ref,beneficiary_refs_json,content,status,runtime_event_ref,provenance_json) values('C','default','promise','E1','[\"E2\"]','call','open','evt-001','{}')")
  r=c.execute("select runtime_event_ref from commitments").fetchone()[0];self.assertEqual('evt-001',r)
