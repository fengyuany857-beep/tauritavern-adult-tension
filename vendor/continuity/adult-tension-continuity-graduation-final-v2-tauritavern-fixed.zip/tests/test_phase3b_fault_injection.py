"""Phase 3B — isolated fault-injection seams (§21) and §32(19, 27, 32, 50, 51, 52).

Convention: deterministic seams monkeypatch the *adapter wrapper only*, never
production code (the vendor scripts and journal are untouched).  Tests therefore
clearly separate real vendor integration (in outcome_classifier module) from
fault-model simulation (here).

Seams exercised:
  - writer RAISES after a real replace but post observation == expected
    => still CONFIRMED_APPLIED (exception alone never means NOT_APPLIED);
  - writer returns successful rc but the immediate post read is "neither pre nor
    expected" => CONCURRENT_DIVERGENCE / never applied from rc alone;
  - two orchestrators race the same continuity_tx_id -> only one attempt reserved.
"""
from __future__ import annotations
import sqlite3
import sys
import tempfile
import threading
import unittest
import time
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3b_fixture import (
    make_disposable_vendor, seed_disposable_db, simple_patch, current_bytes,
)
from continuity.transactions.preconditions import prepare_transaction
from continuity.runtime3b.execute import commit_single_file, SingleFileCommitExecutor
from continuity.runtime3b.adapter import SingleFileCommitAdapter
from continuity.transactions.contracts import (
    RuntimeOutcomeClass, TransactionState,
)
from continuity.transactions.journal import JournalDao
from continuity.transactions.errors import DuplicateAttempt


class RaiseAfterWriteAdapter(SingleFileCommitAdapter):
    """Fault-model seam: run the real vendor write, then RAISE to simulate a
    process result lost after the replace.  Post observation still sees the
    applied expected state."""
    def __init__(self, *a, **k):
        super().__init__(*a, **k)

    def invoke(self, permit, patch_file, runtime_path):
        from continuity.runtime3b.contracts import WriterInvocationEvidence
        ev = super().invoke(permit, patch_file, runtime_path)  # real write
        # now raise as if the caller lost the child result after replace
        raise OSError("simulated lost child result after replace")


class RaiseBeforeWriteAdapter(SingleFileCommitAdapter):
    """Fault-model seam: raise BEFORE any vendor invocation happens."""
    def invoke(self, permit, patch_file, runtime_path):
        from continuity.runtime3b.contracts import WriterInvocationEvidence
        ev = WriterInvocationEvidence(continuity_tx_id=permit.continuity_tx_id,
                                      writer_invoked=False)
        ev.writer_exception_class = "SimulatedBeforeWrite"
        return ev


class Phase3BFaultInjectionTests(unittest.TestCase):

    def _fresh(self):
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        return root, vendor, runtime, db

    # §16-B integrated: writer RAISES but immediate post == expected => applied
    def test_raise_after_real_write_still_applied(self):
        root, vendor, runtime, db = self._fresh()
        patch = simple_patch()
        pe = prepare_transaction(vendor_dir=vendor, db_path=db, runtime_path=runtime,
                                 patch=patch)
        ex = SingleFileCommitExecutor(db_path=db, vendor_dir=vendor,
                                      runtime_path=runtime)
        # swap in the fault seam adapter
        ex.adapter = RaiseAfterWriteAdapter(vendor, "commit_turn.py")
        env = ex.execute_commit(tx_id=pe.continuity_tx_id, patch=patch)
        self.assertEqual(env.runtime_outcome, RuntimeOutcomeClass.CONFIRMED_APPLIED.value)
        self.assertTrue(env.writer_invoked)
        self.assertEqual(env.writer_exception_class, "OSError")
        # runtime really did mutate (the write physically occurred before the raise)
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        r = con.execute("SELECT attempt_count, state FROM transaction_journal "
                        "WHERE continuity_tx_id=?", (pe.continuity_tx_id,)).fetchone()
        con.close()
        self.assertEqual(r["attempt_count"], 1)
        self.assertNotEqual(r["state"], TransactionState.CONFIRMED_NOT_APPLIED.value)

    # §16-C remote: rc0 + post==pre and candidate != pre => never applied from rc
    def test_rc0_alone_never_claims_applied(self):
        from continuity.runtime3b.classifier import classify_runtime_outcome, RuntimeOutcomeDecision
        from continuity.runtime3b.contracts import RuntimeObservationEvidence
        ev = RuntimeObservationEvidence(
            continuity_tx_id="t", identity_ok=True, runtime_present=True,
            parse_ok=True, validation_ok=True,
            pre_raw_sha256="H" * 64, pre_semantic_digest="A" * 64,
            expected_semantic_digest="C" * 64,
            raw_sha256="H" * 64, semantic_digest="A" * 64)
        # even a "success return code" context can't make unchanged post == applied
        v = classify_runtime_outcome(ev, writer_called=True, expected_sha_capable=False)
        self.assertIn(v.decision, (RuntimeOutcomeDecision.OUTCOME_UNKNOWN,
                                   RuntimeOutcomeDecision.CONCURRENT_DIVERGENCE))

    # writer returns rc0 but post state is neither pre nor expected (external raced)
    def test_rc0_post_divergent_is_not_applied(self):
        from continuity.runtime3b.classifier import classify_runtime_outcome, RuntimeOutcomeDecision
        from continuity.runtime3b.contracts import RuntimeObservationEvidence
        ev = RuntimeObservationEvidence(
            continuity_tx_id="t", identity_ok=True, runtime_present=True,
            parse_ok=True, validation_ok=True,
            raw_sha256="Z" * 64, semantic_digest="Y" * 64,
            pre_raw_sha256="H" * 64, pre_semantic_digest="A" * 64,
            expected_semantic_digest="C" * 64)
        v = classify_runtime_outcome(ev, writer_called=True)
        self.assertEqual(v.decision, RuntimeOutcomeDecision.CONCURRENT_DIVERGENCE)

    # writer "raises before write": tx is reserved but writer never ran; the
    # executor should fail closed => NOT_APPLIED/UNKNOWN, never auto-retry
    def test_writer_raise_before_write_fails_closed(self):
        root, vendor, runtime, db = self._fresh()
        patch = simple_patch()
        pe = prepare_transaction(vendor_dir=vendor, db_path=db, runtime_path=runtime,
                                 patch=patch)
        ex = SingleFileCommitExecutor(db_path=db, vendor_dir=vendor, runtime_path=runtime)
        ex.adapter = RaiseBeforeWriteAdapter(vendor, "commit_turn.py")
        env = ex.execute_commit(tx_id=pe.continuity_tx_id, patch=patch)
        # no second attempt may ever run for this tx even though outcome not applied
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        a = con.execute("SELECT attempt_count FROM transaction_journal WHERE "
                        "continuity_tx_id=?", (pe.continuity_tx_id,)).fetchone()[0]
        con.close()
        self.assertEqual(a, 1)   # reservation consumed, one-attempt intact
        # a fresh re-invocation on same tx is refused
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        dao = JournalDao(con)
        with self.assertRaises(DuplicateAttempt):
            dao.open_runtime_attempt(pe.continuity_tx_id)
        con.close()

    # §17-4 two sidecar orchestrators race same tx -> only one attempt
    def test_two_orchestrators_race_same_tx_only_one_attempt(self):
        root, vendor, runtime, db = self._fresh()
        patch = simple_patch()
        pe = prepare_transaction(vendor_dir=vendor, db_path=db, runtime_path=runtime,
                                 patch=patch)
        barrier = threading.Barrier(2)
        outcomes = {}

        def orchestra(id_):
            barrier.wait()
            try:
                env = commit_single_file(db_path=db, vendor_dir=vendor,
                                         runtime_path=runtime,
                                         tx_id=pe.continuity_tx_id, patch=patch)
                outcomes[id_] = env.runtime_outcome
            except Exception as exc:  # pragma: no cover
                outcomes[id_] = "ERR:" + exc.__class__.__name__

        t1 = threading.Thread(target=orchestra, args=("A",))
        t2 = threading.Thread(target=orchestra, args=("B",))
        t1.start(); t2.start(); t1.join(); t2.join()
        con = sqlite3.connect(str(db))
        a = con.execute("SELECT attempt_count FROM transaction_journal WHERE "
                        "continuity_tx_id=?", (pe.continuity_tx_id,)).fetchone()[0]
        con.close()
        self.assertEqual(a, 1)
        # exactly one CONFIRMED_APPLIED may exist; never two
        applied_count = sum(1 for v in outcomes.values()
                            if v == RuntimeOutcomeClass.CONFIRMED_APPLIED.value)
        self.assertLessEqual(applied_count, 1)


if __name__ == "__main__":
    unittest.main()
