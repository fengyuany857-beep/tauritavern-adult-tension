import unittest
from continuity.constants import *
from continuity.models import FactInput
from continuity.validation import insert_fact
from util import tmpdb
class T(unittest.TestCase):
 def test_retroactive_discovery(self):
  d,c=tmpdb();self.addCleanup(d.cleanup)
  f=FactInput('F','E','canon.job','{}',Plane.OBJECTIVE,AdmissionState.COMMITTED,TruthStatus.HISTORICAL_FACT,120,300,500,'{"source":"e"}')
  insert_fact(c,f);r=c.execute('select valid_from_turn,recorded_at_turn from facts').fetchone();self.assertEqual((120,500),tuple(r))
