"""Builds a rich read-only retrieval fixture inside a temporary base directory."""
from __future__ import annotations
import json
import tempfile
from pathlib import Path

from continuity.db import connect
from continuity.history import append_envelope
from continuity.retrieval import Context


def seed_base() -> tuple[tempfile.TemporaryDirectory, Path]:
    tmp = tempfile.TemporaryDirectory()
    base = Path(tmp.name)
    (base / "state").mkdir()
    (base / "history").mkdir()
    (base / "indexes").mkdir()
    (base / "manifests").mkdir()
    conn = connect(base / "state" / "continuity.sqlite3")
    cur = conn.cursor()

    def q(sql: str, *params: object) -> None:
        cur.execute(sql, params)

    q("INSERT INTO entities (entity_id,branch_id,kind,runtime_external_ref,identity_status,anchors_json,explicit_non_capabilities_json) VALUES (?,?,?,?,?,?,?)",
      "E-A", "default", "npc", "npc-001", "confirmed", json.dumps({"canonical_name": "Lin"}, ensure_ascii=False), "[]")
    q("INSERT INTO entities (entity_id,branch_id,kind,runtime_external_ref,identity_status,anchors_json,explicit_non_capabilities_json) VALUES (?,?,?,?,?,?,?)",
      "E-B", "default", "npc", "npc-002", "confirmed", json.dumps({"canonical_name": "Lin"}, ensure_ascii=False), "[]")
    q("INSERT INTO entities (entity_id,branch_id,kind,runtime_external_ref,identity_status,anchors_json,explicit_non_capabilities_json) VALUES (?,?,?,?,?,?,?)",
      "E-C", "default", "npc", "npc-003", "confirmed", json.dumps({"canonical_name": "Mei"}, ensure_ascii=False), "[]")
    q("INSERT INTO entities (entity_id,branch_id,kind,runtime_external_ref,identity_status,anchors_json,explicit_non_capabilities_json) VALUES (?,?,?,?,?,?,?)",
      "E-PL", "default", "player", "player-001", "confirmed", json.dumps({"canonical_name": "Player"}, ensure_ascii=False), "[]")
    q("INSERT INTO entities (entity_id,branch_id,kind,runtime_external_ref,identity_status,anchors_json,explicit_non_capabilities_json) VALUES (?,?,?,?,?,?,?)",
      "E-ALT", "alt", "npc", "npc-099", "confirmed", json.dumps({"canonical_name": "Other"}, ensure_ascii=False), "[]")

    q("INSERT INTO entity_aliases (alias_id,entity_id,alias,status,provenance_json) VALUES (?,?,?,?,?)", "AL-1", "E-C", "Mystery", "confirmed", "{}")
    q("INSERT INTO entity_aliases (alias_id,entity_id,alias,status,provenance_json) VALUES (?,?,?,?,?)", "AL-2", "E-A", "Ghost", "merge_candidate", "{}")

    def fact(fid: str, branch: str, subject: str, pred: str, obj: str, truth: str, vf: int | None, ia: int | None, rt: int) -> None:
        q("INSERT INTO facts (fact_id,branch_id,subject_ref,predicate,object_json,plane,admission_state,truth_status,valid_from_turn,invalid_at_turn,recorded_at_turn,recorded_at,provenance_json,classification) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
          fid, branch, subject, pred, obj, "OBJECTIVE", "COMMITTED", truth, vf, ia, rt, "2026-01-01T00:00:00+00:00", json.dumps({"source": "seed"}), "AUTHORITY")

    fact("FACT-SAP", "default", "E-C", "holds", json.dumps({"item": "sapphire"}),
         "ACTIVE", 1, None, 1)
    fact("FACT-OLD", "default", "E-C", "lived.in", json.dumps({"place": "harbor"}),
         "HISTORICAL_FACT", 10, 50, 50)
    fact("FACT-RETRO", "default", "E-C", "resigned.from", json.dumps({"job": "bank"}),
         "ACTIVE", 120, None, 500)
    fact("FACT-SUP", "default", "E-C", "was.called", json.dumps({"name": "OldName"}),
         "SUPERSEDED", 1, 30, 30)
    fact("FACT-SUP2", "default", "E-C", "was.called", json.dumps({"name": "NewName"}),
         "ACTIVE", 30, None, 30)
    fact("FACT-BR2", "alt", "E-ALT", "guards", json.dumps({"place": "gate"}),
         "ACTIVE", 1, None, 1)
    fact("FACT-REQ", "default", "E-C", "revealed", json.dumps({"what": "truth"}),
         "ACTIVE", 1, None, 1)
    q("INSERT INTO continuity_transactions VALUES (?,?,?,?,?,?,?,?)", "TX-1", "seed", "h0", "h1", "COMMITTED", "2026-01-01T00:00:00+00:00", None, None)
    q("INSERT INTO fact_supersessions VALUES (?,?,?)", "FACT-SUP", "FACT-SUP2", "TX-1")

    q("INSERT INTO facts (fact_id,branch_id,subject_ref,predicate,object_json,plane,admission_state,truth_status,valid_from_turn,invalid_at_turn,recorded_at_turn,recorded_at,provenance_json,classification) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
      "FACT-CAND", "default", "E-C", "sapphire.candidate", json.dumps({"x": 1}), "OBJECTIVE", "CANDIDATE", "PENDING", 1, None, 1, "t", "{}", "CANDIDATE")
    q("INSERT INTO facts (fact_id,branch_id,subject_ref,predicate,object_json,plane,admission_state,truth_status,valid_from_turn,invalid_at_turn,recorded_at_turn,recorded_at,provenance_json,classification) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
      "FACT-REJ", "default", "E-C", "sapphire.rejected", json.dumps({"x": 2}), "OBJECTIVE", "REJECTED", "PENDING", 1, None, 1, "t", "{}", "CANDIDATE")

    q("INSERT INTO knowledge (knowledge_id,branch_id,subject_ref,proposition_ref,state,plane,source,promotion_basis,turn,provenance_json) VALUES (?,?,?,?,?,?,?,?,?,?)",
      "K-A-SEC", "default", "E-A", "PROP-secret", "knows", "CHARACTER", "witnessed", "witnessed", 100, "{}")
    q("INSERT INTO knowledge (knowledge_id,branch_id,subject_ref,proposition_ref,state,plane,source,promotion_basis,turn,provenance_json) VALUES (?,?,?,?,?,?,?,?,?,?)",
      "K-FB", "default", "E-C", "PROP-door", "false_belief", "CHARACTER", "inferred", "inferred", 60, "{}")
    q("INSERT INTO knowledge (knowledge_id,branch_id,subject_ref,proposition_ref,state,plane,source,promotion_basis,turn,provenance_json) VALUES (?,?,?,?,?,?,?,?,?,?)",
      "K-PV", "default", "narrator", "PROP-secret-hint", "knows", "PLAYER_VISIBLE", "shown", "shown", 90, "{}")
    q("INSERT INTO knowledge (knowledge_id,branch_id,subject_ref,proposition_ref,state,plane,source,promotion_basis,turn,provenance_json) VALUES (?,?,?,?,?,?,?,?,?,?)",
      "K-FUT", "default", "E-C", "PROP-later", "knows", "CHARACTER", "witnessed", "witnessed", 400, "{}")

    q("INSERT INTO relationships (relationship_id,branch_id,source_ref,target_ref,runtime_refs_json,public_surface,actual_relation,phase,provenance_json) VALUES (?,?,?,?,?,?,?,?,?)",
      "REL-1", "default", "E-A", "E-PL", json.dumps([{"kind": "historical_consent", "ref": "EP-1"}], ensure_ascii=False), "warm", "wary", "phase2", "{}")
    q("INSERT INTO relationship_dimensions (dimension_id,relationship_id,name,value_json,classification) VALUES (?,?,?,?,?)", "DIM-1", "REL-1", "attraction", json.dumps("high"), "AUTHORITY")
    q("INSERT INTO relationship_dimensions (dimension_id,relationship_id,name,value_json,classification) VALUES (?,?,?,?,?)", "DIM-2", "REL-1", "trust", json.dumps("high"), "AUTHORITY")

    q("INSERT INTO commitments (commitment_id,branch_id,kind,issuer_ref,beneficiary_refs_json,content,status,runtime_event_ref,provenance_json) VALUES (?,?,?,?,?,?,?,?,?)",
      "COM-P", "default", "promise", "E-C", json.dumps(["E-PL"], ensure_ascii=False), "will call at new year", "open", None, "{}")
    q("INSERT INTO commitments (commitment_id,branch_id,kind,issuer_ref,beneficiary_refs_json,content,status,runtime_event_ref,provenance_json) VALUES (?,?,?,?,?,?,?,?,?)",
      "COM-ALT", "alt", "debt", "E-ALT", "[]", "borrowed knife", "open", None, "{}")

    q("INSERT INTO threads (thread_id,branch_id,status,author_state,objective_state,player_visible_state,reveal_gate_json,presentation_json,provenance_json) VALUES (?,?,?,?,?,?,?,?,?)",
      "TH-1", "default", "active", "a", "o", "p", json.dumps({"requires": ["FACT-REQ"]}, ensure_ascii=False), "{}", "{}")
    q("INSERT INTO threads (thread_id,branch_id,status,author_state,objective_state,player_visible_state,reveal_gate_json,presentation_json,provenance_json) VALUES (?,?,?,?,?,?,?,?,?)",
      "TH-2", "default", "resolved", "a", "o", "p", "{}", "{}", "{}")
    q("INSERT INTO thread_requires (require_id,thread_id,ref,expected_state,plane) VALUES (?,?,?,?,?)", "TR-1", "TH-1", "FACT-REQ", "ACTIVE", "OBJECTIVE")
    q("INSERT INTO thread_links (link_id,thread_id,other_thread_ref,status,confidence) VALUES (?,?,?,?,?)", "TL-1", "TH-1", "TH-2", "candidate", 0.9)
    q("INSERT INTO thread_anti_merge (anti_merge_id,thread_id,blocked_ref,reason) VALUES (?,?,?,?)", "AM-1", "TH-1", "TH-2", "two different mysteries")

    q("INSERT INTO episodes (episode_id,continuity_tx_id,branch_id,runtime_pre_hash,runtime_post_hash,history_pointer,checksum) VALUES (?,?,?,?,?,?,?)",
      "EP-1", "TX-1", "default", "pre1", "post1", "VOL-001.jsonl", "x")
    q("INSERT INTO episodes (episode_id,continuity_tx_id,branch_id,runtime_pre_hash,runtime_post_hash,history_pointer,checksum) VALUES (?,?,?,?,?,?,?)",
      "EP-ALT", "TX-1", "alt", "pre2", "post2", "VOL-002.jsonl", "y")
    conn.commit()

    append_envelope(base / "history" / "VOL-001.jsonl", {
        "branch_id": "default", "episode_id": "EP-1", "transaction_id": "TX-1",
        "runtime_pre_hash": "pre1", "runtime_post_hash": "post1",
        "payload_classification": "HISTORICAL_EVIDENCE", "source_references": ["evt-001"],
        "scene_id": "SC-1", "participants": ["E-A", "E-C"], "turn_start": 10, "turn_end": 12,
        "summary": "quiet talk about the sapphire in the harbor room",
    })
    append_envelope(base / "history" / "VOL-002.jsonl", {
        "branch_id": "alt", "episode_id": "EP-ALT", "transaction_id": "TX-1",
        "runtime_pre_hash": "pre2", "runtime_post_hash": "post2",
        "payload_classification": "HISTORICAL_EVIDENCE", "source_references": [],
        "scene_id": "SC-ALT", "participants": ["E-ALT"], "turn_start": 3, "turn_end": 4,
        "summary": "other branch scene at the gate",
    })
    conn.close()
    return tmp, base


def open_ctx(base: Path) -> Context:
    ctx = Context.open(base)
    from continuity.retrieval import FtsIndex
    idx = FtsIndex(ctx.index_path)
    # derived index is rebuildable; build lazily through a writable connection
    if not idx.exists():
        writable = connect(base / "state" / "continuity.sqlite3")
        idx.rebuild(writable, base)
        writable.close()
    return ctx
