import unittest
from continuity.constants import JournalState
from continuity.journal import transition
from continuity.errors import JournalTransitionError
class T(unittest.TestCase):
 def test_illegal_transition(self):
  with self.assertRaises(JournalTransitionError):transition(JournalState.PREPARED,JournalState.COMMITTED)
 def test_valid_transition(self):self.assertEqual(JournalState.RUNTIME_OUTCOME_UNKNOWN,transition(JournalState.PREPARED,JournalState.RUNTIME_OUTCOME_UNKNOWN))
