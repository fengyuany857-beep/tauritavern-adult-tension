"""Phase 3A — developer CLI (scripts/prepare_transaction.py) subprocess tests.

The CLI must be read-only w.r.t. runtime and persist only the PREPARED journal.
"""
from __future__ import annotations
import json
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from tests import phase3a_fixture as PF
ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "prepare_transaction.py"


def _run(args, cwd):
    return subprocess.run([sys.executable, str(CLI)] + args,
                          capture_output=True, text=True, cwd=str(cwd), timeout=240)


class PrepareCliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._vendor = PF.make_vendor_runtime(None)

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        self.vendor = base / "vendor"
        shutil.copytree(self._vendor, self.vendor)
        self.runtime = self.vendor / "saves" / "current_state.yaml"
        self.base = base
        (base / "state").mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        self.tmp.cleanup()

    def _db(self):
        return self.base / "state" / "continuity.sqlite3"

    def test_prepare_readonly_rc0_json(self):
        rb = self.runtime.read_bytes()
        patch = '{"delta_minutes": 5, "last_committed_result": "she continued."}'
        r = _run(["--base", str(self.base), "--vendor", str(self.vendor),
                  "--runtime", str(self.runtime), "--patch", patch, "--json"], ROOT)
        self.assertEqual(r.returncode, 0, r.stderr)
        payload = json.loads(r.stdout)
        self.assertEqual(payload["state"], "PREPARED")
        self.assertIn("continuity_tx_id", payload)
        self.assertEqual(payload["runtime_attempted"], False)
        # runtime bytes are unchanged (read-only)
        self.assertEqual(self.runtime.read_bytes(), rb)
        # sidecar has exactly one PREPARED row
        con = sqlite3.connect(str(self._db()))
        row = con.execute("SELECT state, attempt_count FROM transaction_journal").fetchone()
        self.assertEqual(row[0], "PREPARED")
        self.assertEqual(row[1], 0)
        con.close()

    def test_check_flag_ok(self):
        patch = '{"delta_minutes": 2}'
        p = _run(["--base", str(self.base), "--vendor", str(self.vendor),
                  "--runtime", str(self.runtime), "--patch", patch, "--json"], ROOT)
        self.assertEqual(p.returncode, 0, p.stderr)
        tx = json.loads(p.stdout)["continuity_tx_id"]
        chk = _run(["--base", str(self.base), "--vendor", str(self.vendor),
                    "--runtime", str(self.runtime), "--check", "--tx", tx, "--json"], ROOT)
        self.assertEqual(chk.returncode, 0, chk.stderr)
        out = json.loads(chk.stdout)
        self.assertEqual(out["precondition_status"], "PRECONDITION_OK")

    def test_missing_patch_is_error(self):
        r = _run(["--base", str(self.base), "--vendor", str(self.vendor),
                  "--runtime", str(self.runtime)], ROOT)
        self.assertEqual(r.returncode, 2)


if __name__ == "__main__":
    unittest.main()
