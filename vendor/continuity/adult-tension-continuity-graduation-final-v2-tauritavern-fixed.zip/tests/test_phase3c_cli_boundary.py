"""Phase 3C — developer CLI + static boundary scan.

- scripts/sync_continuity.py and recover_transactions.py are present.
- They never expose --retry-runtime / --rollback-runtime / --commit-runtime.
- The sync3c package + CLIs carry none of the runtime-write / LLM / vector /
  adult-permission-evaluator machinery (only retrieval fixtures may).
- The continuity/transactions (Phase 3A) and runtime3b (Phase 3B) packages are
  NOT the home of 3C sync machinery, preserving earlier boundary scans.
"""
from __future__ import annotations
import ast
import sys
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
PKG = SRC / "continuity" / "sync3c"
CLI_SYNC = SRC / "scripts" / "sync_continuity.py"
CLI_RECOV = SRC / "scripts" / "recover_transactions.py"


def _files(pkg: Path):
    return [p for p in pkg.glob("*.py") if p.name != "__init__.py"]


def _join(path):
    return path.read_text(encoding="utf-8")


class Phase3CBoundaryTests(unittest.TestCase):
    def test_cli_exists(self):
        self.assertTrue(CLI_SYNC.exists())
        self.assertTrue(CLI_RECOV.exists())

    def test_cli_no_forbidden_runtime_flags(self):
        for cli in (CLI_SYNC, CLI_RECOV):
            text = _join(cli)
            for banned in ("--retry-runtime", "--rollback-runtime",
                           "--commit-runtime", "commit_turn(",
                           "os.replace(runtime", "write_H0_back"):
                self.assertNotIn(banned, text)
            self.assertIn("no runtime write", text.lower())

    def test_engine_cli_no_prohibited_machinery(self):
        # sync engine code may only coordinate continuity; not run runtimes/LLM.
        joined = "\n".join(_join(p) for p in _files(PKG))
        for banned in ("subprocess.run", "Popen", "commit_turn.", "os.replace(",
                       "adult_permission_inference", "synthesize_consent",
                       "openai", "anthropic", "embedding", "vectorstore"):
            self.assertNotIn(banned, joined)

    def test_sync3c_package_home_for_3c(self):
        # ensure the new 3C source lives in sync3c and not in transactions or
        # runtime3b (so the earlier Phase checks stay meaningful).
        self.assertTrue(PKG.exists())
        expected = {"contracts.py", "planner.py", "sqlwriter.py", "engine.py",
                    "projector.py", "recovery.py", "manual_packet.py"}
        present = {p.name for p in PKG.glob("*.py")}
        self.assertTrue(expected.issubset(present))

    def test_no_side_by_side_3c_sync_machinery_in_tx_runtime3b(self):
        for p in (SRC / "continuity" / "transactions").glob("*.py"):
            text = _join(p)
            for bad in ("INSERT INTO episodes", "INSERT OR IGNORE INTO history_outbox",
                        "advance_thread(", "resolve_commitment("):
                self.assertNotIn(bad, text)
    def test_doctor_runs(self):
        # every module compiles/imports cleanly
        import importlib
        for m in ("continuity.sync3c",):
            importlib.import_module(m)
        import subprocess
        for cli in (CLI_SYNC, CLI_RECOV):
            r = subprocess.run([sys.executable, str(cli), "--help"],
                               capture_output=True)
            self.assertTrue(r.returncode == 0, str(cli))


if __name__ == "__main__":
    unittest.main()
