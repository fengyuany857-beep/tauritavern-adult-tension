import tempfile,unittest
from pathlib import Path
from continuity.runtime_readonly import observe,npc_card
from continuity.hashing import sha256_file
from util import fixture
VENDOR=Path('/var/minis/workspace/vendor/dsh-adult-tension')
class T(unittest.TestCase):
 def test_observe_never_writes_and_card(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'fixture.yaml';fixture(p);before=sha256_file(p);o=observe(VENDOR,p);self.assertEqual(before,o.observed_runtime_sha256);self.assertEqual(before,sha256_file(p));self.assertEqual('npc-002',npc_card(VENDOR,p,'npc-002')['id'])
 def test_hash_changes_and_is_not_revision(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'fixture.yaml';fixture(p);a=observe(VENDOR,p).observed_runtime_sha256;p.write_text(p.read_text()+' ',encoding='utf-8');o=observe(VENDOR,p);self.assertNotEqual(a,o.observed_runtime_sha256);self.assertFalse(hasattr(o,'runtime_revision'))
