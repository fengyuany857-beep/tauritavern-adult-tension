import unittest
from continuity.retrieval import LedgerRetriever, RetrievalQuery, RetrievalStatus
from retrieval_seed import open_ctx, seed_base


class T(unittest.TestCase):
    def setUp(self):
        self.tmp, base = seed_base()
        self.addCleanup(self.tmp.cleanup)
        self.ctx = open_ctx(base)
        self.led = LedgerRetriever()

    def items(self, q):
        return list(self.led.retrieve(q, self.ctx).items)

    def test_a_knowledge_not_returned_for_b(self):
        got = self.items(RetrievalQuery(observer_entity_id="E-B", query_id="q"))
        self.assertNotIn("K-A-SEC", [i.item_id for i in got])

    def test_missing_knowledge_row_not_does_not_know(self):
        r = self.led.retrieve(RetrievalQuery(observer_entity_id="E-C", raw_text="PROP-none", query_id="q"), self.ctx)
        self.assertEqual([], [i for i in r.items if "does_not_know" in i.content])

    def test_false_belief_retrievable_only_as_character_belief(self):
        got = self.items(RetrievalQuery(observer_entity_id="E-C", query_id="q"))
        self.assertIn("K-FB", [i.item_id for i in got])
        other = self.items(RetrievalQuery(observer_entity_id="E-PL", query_id="q"))
        self.assertNotIn("K-FB", [i.item_id for i in other])

    def test_commitment_retrieved_by_actor(self):
        got = self.items(RetrievalQuery(entity_ids=("E-C",), query_id="q"))
        self.assertIn("COM-P", [i.item_id for i in got])

    def test_commitment_after_long_turn_gap(self):
        got = self.items(RetrievalQuery(entity_ids=("E-PL",), event_turn=5000, query_id="q"))
        self.assertIn("COM-P", [i.item_id for i in got])

    def test_thread_requires_metadata_retrievable(self):
        got = self.items(RetrievalQuery(thread_ids=("TH-1",), query_id="q"))
        self.assertTrue(any("FACT-REQ" in i.content for i in got))

    def test_candidate_never_in_authority_retrieval(self):
        got = self.items(RetrievalQuery(fact_ids=("FACT-CAND", "FACT-REJ"), query_id="q"))
        self.assertNotIn("FACT-CAND", [i.item_id for i in got])
        self.assertNotIn("FACT-REJ", [i.item_id for i in got])

    def test_presentation_restriction_preserved(self):
        got = self.items(RetrievalQuery(thread_ids=("TH-1",), query_id="q"))
        thread_items = [i for i in got if i.item_id == "TH-1"]
        self.assertTrue(thread_items and "PRESENTATION_RESTRICTED" in thread_items[0].flags)
