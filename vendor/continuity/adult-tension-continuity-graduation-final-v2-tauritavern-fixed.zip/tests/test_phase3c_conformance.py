"""Phase 3C — conformance checks for §8/§27 mixed once-only kinds + final order.

Drives a single applied tx whose plan has one of every ownership class through
first sync + immediate replay, asserting each kind is once-only and that
COMPLETED is only reached once the outbox is delivered.
"""
from __future__ import annotations
import sqlite3
import sys
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3c_fixture import make_journal_state, seed_authority_base, connect
from continuity.sync3c.engine import ContinuitySyncEngine
from continuity.transactions.contracts import TransactionState


def _cons(kind, payload):
    return {"kind": kind, "payload": payload}


class ConformanceTests(unittest.TestCase):
    def test_full_mixed_plan_once_only(self):
        cs = [
            _cons("EPISODE_APPEND", {"summary": "one scene", "scene_ref": "SC-5"}),
            _cons("FACT_INSERT", {"subject_ref": "E-A", "predicate": "p1",
                                  "object": {"a": 1}, "valid_from_turn": 1}),
            _cons("FACT_INSERT", {"subject_ref": "E-B", "predicate": "p2",
                                  "object": {"b": 2}, "valid_from_turn": 1}),
            _cons("RELATIONSHIP_SEMANTIC_UPDATE", {
                "source_ref": "E-A", "target_ref": "E-PL",
                "semantic_name": "shared_a_moment", "history_pointer": "HP1"}),
            _cons("COMMITMENT_HISTORICAL_EFFECT", {
                "commitment_id": "COM-5", "effect_type": "disclosure"}),
            _cons("THREAD_HISTORICAL_EFFECT", {
                "thread_id": "TH-5", "effect_type": "relevant_event",
                "history_pointer": "HP1"}),
        ]
        db, tx, row, req = make_journal_state("CONTINUITY_SYNC_PENDING",
                                              consequences=cs)
        seed_authority_base(db, entities=("E-A", "E-B", "E-PL"),
                            commit_ids=[("COM-5", "E-A", "disclosure", "open")],
                            threads=["TH-5"])
        vol = Path(db).parent / "history" / "VOL-001.jsonl"
        con = connect(db)
        eng = ContinuitySyncEngine(con, evidence_path=vol)
        r1 = eng.sync_applied_transaction(req)
        self.assertEqual(r1["status"], "COMPLETED")

        def snapshot():
            return {
                "episodes": con.execute("SELECT COUNT(*) c FROM episodes").fetchone()["c"],
                "facts": con.execute("SELECT COUNT(*) c FROM facts").fetchone()["c"],
                "rel_sem": con.execute(
                    "SELECT COUNT(*) c FROM relationship_dimensions "
                    "WHERE classification='HISTORICAL'").fetchone()["c"],
                "commit_state": dict(con.execute(
                    "SELECT status, provenance_json FROM commitments "
                    "WHERE commitment_id='COM-5'").fetchone()),
                "thread_state": dict(con.execute(
                    "SELECT status FROM threads WHERE thread_id='TH-5'").fetchone()),
                "markers": con.execute(
                    "SELECT COUNT(*) c FROM continuity_effect_markers "
                    "WHERE continuity_tx_id=?", (tx,)).fetchone()["c"],
                "sync_ex": con.execute(
                    "SELECT COUNT(*) c FROM continuity_sync_executions "
                    "WHERE continuity_tx_id=?", (tx,)).fetchone()["c"],
                "outbox": con.execute(
                    "SELECT COUNT(*) c FROM history_outbox "
                    "WHERE continuity_tx_id=?", (tx,)).fetchone()["c"],
                "final_state": con.execute(
                    "SELECT state FROM transaction_journal WHERE continuity_tx_id=?",
                    (tx,)).fetchone()["state"],
            }
        s1 = snapshot()
        r2 = eng.sync_applied_transaction(req)
        self.assertTrue(r2.get("replay"))
        s2 = snapshot()
        self.assertEqual(s1, s2)
        self.assertEqual(s1["episodes"], 1)
        self.assertEqual(s1["facts"], 2)
        self.assertEqual(s1["rel_sem"], 1)
        self.assertIsNotNone(s1["commit_state"])
        self.assertEqual(s1["markers"], 6)
        self.assertEqual(s1["sync_ex"], 1)
        self.assertEqual(s1["outbox"], 1)
        self.assertEqual(s1["final_state"], TransactionState.COMPLETED.value)
        con.close()

    def test_no_final_marker_until_outbox_delivered(self):
        cs = [_cons("EPISODE_APPEND", {"summary": "x", "scene_ref": "SC-A"})]
        db, tx, row, req = make_journal_state("CONTINUITY_SYNC_PENDING",
                                              consequences=cs)
        con = connect(db)
        vol = Path(db).parent / "history" / "VOL-001.jsonl"
        eng = ContinuitySyncEngine(con, evidence_path=vol, auto_project=False)
        eng.sync_applied_transaction(req)          # authority synced, outbox pending
        st = con.execute("SELECT state FROM transaction_journal "
                         "WHERE continuity_tx_id=?", (tx,)).fetchone()
        self.assertEqual(st["state"], TransactionState.CONTINUITY_SYNCED.value)
        out = con.execute("SELECT state FROM history_outbox WHERE continuity_tx_id=?",
                          (tx,)).fetchone()["state"]
        self.assertEqual(out, "PENDING")
        eng.drain_outbox()
        eng.finalize_if_ready(tx, {})
        st = con.execute("SELECT state FROM transaction_journal WHERE continuity_tx_id=?",
                         (tx,)).fetchone()["state"]
        self.assertEqual(st, TransactionState.COMPLETED.value)
        con.close()


if __name__ == "__main__":
    unittest.main()
