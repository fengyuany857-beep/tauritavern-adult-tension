"""Phase 3B — deterministic outcome classifier matrix (protocol §8 / §16 A-H)
and the real disposable vendor single-file mutation disclosure test (§22).

The classifier is pure: identical evidence -> identical outcome.  It never
writes.  Real vendor integration is a separate, isolated disposable test that
calls the actual pinned commit_turn CLI (the proof of first real phase-3B
mutation) and confirms: pre bytes, expected candidate, actual post, classifier
outcome, journal attempt_count, mutation happened, original fixture untouched.
"""
from __future__ import annotations
import copy
import hashlib
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3b_fixture import (
    make_disposable_vendor, seed_disposable_db, simple_patch, current_bytes,
    sha256_of,
)
from continuity.runtime3b.contracts import RuntimeObservationEvidence
from continuity.runtime3b.classifier import (
    classify_runtime_outcome, RuntimeOutcomeDecision,
)
from continuity.transactions.preconditions import prepare_transaction
from continuity.runtime3b.execute import commit_single_file
from continuity.transactions.contracts import RuntimeOutcomeClass


def evidence(**kw):
    base = dict(continuity_tx_id="tx-x", identity_ok=True, runtime_present=True,
                parse_ok=True, validation_ok=True,
                pre_raw_sha256="H0" * 32, pre_semantic_digest="S0" * 32,
                expected_semantic_digest="SE" * 32,
                expected_raw_sha256=None, pre_replace_strong_proof=False)
    base.update(kw)
    return RuntimeObservationEvidence(**base)


class Phase3BClassifierTests(unittest.TestCase):
    # A. writer success + post == expected => applied
    def test_A_success_post_expected_of_expected_sha(self):
        ev = evidence(raw_sha256="HE"*32, semantic_digest="SE"*32,
                      expected_raw_sha256="HE"*32, expected_semantic_digest="SE"*32)
        v = classify_runtime_outcome(ev, writer_called=True, expected_sha_capable=True)
        self.assertEqual(v.decision, RuntimeOutcomeDecision.CONFIRMED_APPLIED)

    # A2 semantic equal => applied even without HE capability
    def test_A2_semantic_applied_without_byte_capability(self):
        ev = evidence(raw_sha256="zz"*24, semantic_digest="SE"*32,
                      expected_raw_sha256=None, expected_semantic_digest="SE"*32)
        v = classify_runtime_outcome(ev, writer_called=True, expected_sha_capable=False)
        self.assertEqual(v.decision, RuntimeOutcomeDecision.CONFIRMED_APPLIED)

    # B. exception + post == expected => still applied (exception != not_applied)
    def test_B_exception_post_expected_applied(self):
        ev = evidence(raw_sha256="HE"*32, semantic_digest="SE"*32,
                      expected_raw_sha256="HE"*32, expected_semantic_digest="SE"*32)
        v = classify_runtime_outcome(ev, writer_called=True, expected_sha_capable=True)
        self.assertEqual(v.decision, RuntimeOutcomeDecision.CONFIRMED_APPLIED)

    # C + D pre_replace proof variants for post==pre
    def test_C_success_post_pre_no_proof_unknown(self):
        # success + post == pre and candidate != pre => without proof UNKNOWN
        ev = evidence(raw_sha256="H0"*32, semantic_digest="S0"*32,
                      pre_raw_sha256="H0"*32, pre_semantic_digest="S0"*32)
        v = classify_runtime_outcome(ev, writer_called=True)
        self.assertEqual(v.decision, RuntimeOutcomeDecision.OUTCOME_UNKNOWN)
        self.assertTrue(v.manual_review_required)

    def test_D_exception_post_pre_with_proof_not_applied(self):
        # exception + post == pre + strong pre-replace proof => NOT_APPLIED
        ev = evidence(raw_sha256="H0"*32, semantic_digest="S0"*32,
                      pre_raw_sha256="H0"*32, pre_semantic_digest="S0"*32,
                      pre_replace_strong_proof=True)
        v = classify_runtime_outcome(ev, writer_called=True)
        self.assertEqual(v.decision, RuntimeOutcomeDecision.CONFIRMED_NOT_APPLIED)

    def test_E_post_neither_pre_nor_expected_divergence(self):
        ev = evidence(raw_sha256="DD"*24, semantic_digest="D1"*24,
                      pre_raw_sha256="H0"*32, pre_semantic_digest="S0"*32,
                      expected_semantic_digest="SE"*32)
        v = classify_runtime_outcome(ev, writer_called=True)
        self.assertEqual(v.decision, RuntimeOutcomeDecision.CONCURRENT_DIVERGENCE)

    def test_F_post_read_failure_unknown(self):
        ev = evidence(runtime_present=False, parse_ok=False, validation_ok=False,
                      raw_sha256=None, semantic_digest=None, read_error_class="RuntimeNotFound")
        v = classify_runtime_outcome(ev, writer_called=True)
        self.assertEqual(v.decision, RuntimeOutcomeDecision.OUTCOME_UNKNOWN)
        self.assertTrue(v.manual_review_required)

    def test_G_runtime_disappears_unknown(self):
        ev = evidence(runtime_present=False, parse_ok=False, validation_ok=False)
        v = classify_runtime_outcome(ev, writer_called=True)
        self.assertEqual(v.decision, RuntimeOutcomeDecision.OUTCOME_UNKNOWN)

    def test_H_precheck_failed_precedence(self):
        # pre-write mismatch independently -> PRECONDITION_FAILED regardless
        ev = evidence(raw_sha256="zz", semantic_digest="x")
        v = classify_runtime_outcome(ev, writer_called=False, precheck_passed=False)
        self.assertEqual(v.decision, RuntimeOutcomeDecision.PRECONDITION_FAILED)

    # 26 return-code alone never decides applied
    def test_weak_return_code_alone_never_decides(self):
        # different raw/semantic but same rc path -> divergence, not applied
        ev = evidence(raw_sha256="ZZ"*24, semantic_digest="Y1"*24,
                      expected_semantic_digest="SE"*32)
        v = classify_runtime_outcome(ev, writer_called=True)
        self.assertNotEqual(v.decision, RuntimeOutcomeDecision.CONFIRMED_APPLIED)

    # 29 deterministic
    def test_classifier_deterministic(self):
        ev = evidence(raw_sha256="HE"*32, semantic_digest="SE"*32,
                      expected_raw_sha256="HE"*32, expected_semantic_digest="SE"*32)
        outs = {classify_runtime_outcome(ev, writer_called=True,
                                         expected_sha_capable=True).decision.value
                for _ in range(50)}
        self.assertEqual(outs, {RuntimeOutcomeDecision.CONFIRMED_APPLIED.value})

    def test_return_code_zero_does_not_claim_applied_on_bad_post(self):
        ev = evidence(raw_sha256="MM"*24, semantic_digest="?M"*24,
                      pre_raw_sha256="H0"*32, pre_semantic_digest="S0"*32,
                      expected_semantic_digest="SE"*32)
        # even rc0 "success" doesn't create APPLIED when post is not expected
        v = classify_runtime_outcome(ev, writer_called=True)
        self.assertNotEqual(v.decision, RuntimeOutcomeDecision.CONFIRMED_APPLIED)


class Phase3BRealVendorMutationTests(unittest.TestCase):
    """The Phase 3B first-real-mutation proof (§22): a disposable vendor clone,
    a genuine pinned commit_turn write, strong post observation."""

    def test_real_disposable_vendor_write_succeeds_and_observes(self):
        root, vendor, runtime = make_disposable_vendor()
        src_bytes = (vendor.parent / "source-note").write_bytes(b"immutable-source") \
            if False else None
        db = seed_disposable_db(root)
        before = current_bytes(vendor)
        seed_path = Path("/var/minis/workspace/vendor/dsh-adult-tension") / "tests" / "fixtures" / "_opening_synthetic_v3.yaml"
        original_seed = seed_path.read_bytes()

        patch = simple_patch()
        pe = prepare_transaction(vendor_dir=vendor, db_path=db, runtime_path=runtime,
                                 patch=patch, branch_id="default")

        env = commit_single_file(db_path=db, vendor_dir=vendor, runtime_path=runtime,
                                 tx_id=pe.continuity_tx_id, patch=patch)

        # strong outcome: applied
        after = current_bytes(vendor)
        self.assertNotEqual(before, after)
        self.assertEqual(env.runtime_outcome, RuntimeOutcomeClass.CONFIRMED_APPLIED.value)
        self.assertTrue(env.writer_invoked)
        self.assertEqual(env.runtime_post_observation["raw_sha256"],
                         hashlib.sha256(after).hexdigest())
        # source fixture original unchanged
        self.assertEqual(seed_path.read_bytes(), original_seed)
        # journal attempt_count == 1 and the applied row rests at durability pending
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        r = con.execute("SELECT state, attempt_count, runtime_outcome_class, "
                        "continuity_sync_state FROM transaction_journal "
                        "WHERE continuity_tx_id=?", (pe.continuity_tx_id,)).fetchone()
        con.close()
        self.assertEqual(r["attempt_count"], 1)
        self.assertEqual(r["runtime_outcome_class"], RuntimeOutcomeClass.CONFIRMED_APPLIED.value)
        # Phase 3B does NOT sync continuity history: continuity_sync_state != SYNCED
        self.assertNotEqual(r["continuity_sync_state"], "SYNCED")
        self.assertNotEqual(r["continuity_sync_state"], "SYNCING")

    def test_source_and_vendor_repo_preserved(self):
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        # capture script hashes before any real mutation anywhere
        import hashlib
        vendor_script_before = {}
        for p in (Path("/var/minis/workspace/vendor/dsh-adult-tension")/"scripts").iterdir():
            if p.is_file():
                vendor_script_before[p.name] = hashlib.sha256(p.read_bytes()).hexdigest()
        patch = simple_patch()
        pe = prepare_transaction(vendor_dir=vendor, db_path=db, runtime_path=runtime, patch=patch)
        env = commit_single_file(db_path=db, vendor_dir=vendor, runtime_path=runtime,
                                 tx_id=pe.continuity_tx_id, patch=patch)
        self.assertEqual(env.runtime_outcome, RuntimeOutcomeClass.CONFIRMED_APPLIED.value)
        # only the disposable runtime yaml changed; nothing in the vendor source repo did
        for p in (Path("/var/minis/workspace/vendor/dsh-adult-tension")/"scripts").iterdir():
            if p.is_file():
                self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),
                                 vendor_script_before[p.name],
                                 "vendor repo source mutated")

    def test_confirmed_applied_never_syncs_authority_tables(self):
        # § no historical sync (contents untouched even though runtime changed)
        from continuity.transactions.journal import AUTHORITY_TABLES
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        def hashes():
            con = sqlite3.connect(str(db))
            out={}
            for t in AUTHORITY_TABLES:
                try:
                    out[t]=hashlib.sha256(repr(con.execute(f"SELECT * FROM {t}").fetchall()).encode()).hexdigest()
                except sqlite3.OperationalError:
                    out[t]="absent"
            con.close(); return out
        patch = simple_patch()
        pe = prepare_transaction(vendor_dir=vendor, db_path=db, runtime_path=runtime, patch=patch)
        pre = hashes()
        env = commit_single_file(db_path=db, vendor_dir=vendor, runtime_path=runtime,
                                 tx_id=pe.continuity_tx_id, patch=patch)
        self.assertEqual(env.runtime_outcome, RuntimeOutcomeClass.CONFIRMED_APPLIED.value)
        post = hashes()
        self.assertEqual(pre, post, "confirmed applied runtime mutation must not touch continuity/history")


if __name__ == "__main__":
    unittest.main()
