import tempfile,unittest
from pathlib import Path
from continuity.history import append_envelope,validate_volume
from continuity.errors import HistoryIntegrityError
class T(unittest.TestCase):
 def test_append_and_mutation_detected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'V.jsonl';e={'branch_id':'B','episode_id':'E','transaction_id':'T','runtime_pre_hash':'a','runtime_post_hash':'b','payload_classification':'HISTORICAL_EVIDENCE','source_references':[]}
   append_envelope(p,e);self.assertTrue(validate_volume(p));p.write_text(p.read_text().replace('"a"','"x"'),encoding='utf-8')
   with self.assertRaises(HistoryIntegrityError):validate_volume(p)
