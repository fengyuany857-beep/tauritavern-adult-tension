"""Hermetic Phase 3C fixture.

Constructs a disposable prepared transaction on a *provably disposable* temp
vendor clone, drives it through the real Phase 3B single-file commit adapter to
a durable CONFIRMED_APPLIED outcome (the only lawful runtime mutation is inside
the disposable fixture), then moves the journal into CONTINUITY_SYNC_PENDING and
stages a deterministic sync-request digest.  Phase 3C product code inside this
repo never writes runtime; the mutation you see here is the *Phase 3B test
harness* mutating a throwaway copy under /tmp, exactly as prior phases allow.

All authority tables the sync fixture needs (a seeded base of entities / facts /
commitment / thread the effects may reference) are created on demand so the
consumer tests own the shape they want.
"""
from __future__ import annotations
import json
import sqlite3
import sys
import os
import tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3b_fixture import make_disposable_vendor, simple_patch

from continuity.migrations import migrate
from continuity.transactions.journal import JournalDao
from continuity.transactions.contracts import TransactionState, RuntimeOutcomeClass
from continuity.runtime3b.execute import commit_single_file
from continuity.runtime3b.classifier import outcome_to_class, RuntimeOutcomeDecision
from continuity.sync3c.planner import request_claimed_digest
from continuity.sync3c.contracts import ContinuitySyncRequest

__all__ = [
    "make_applied_tx", "seed_authority_base", "build_request", "request_claimed_digest",
    "connect", "apply_digest_detail",
]


def connect(db: Path) -> sqlite3.Connection:
    con = sqlite3.connect(str(db))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con


def seed_disposable_db_current(root: Path, name: str = "continuity.sqlite3") -> Path:
    db = root / "state" / name
    db.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(db))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    migrate(con)
    con.close()
    return db


def build_request(*, tx_id: str, branch_id: str, consequences: list[dict],
                  observed_post_sha256: str, observed_post_semantic_digest: str,
                  expected_candidate_digest: str, patch_digest: str = "patch-x",
                  plan_version: str = "phase3c-sync-v1",
                  request_provenance: dict | None = None) -> ContinuitySyncRequest:
    return ContinuitySyncRequest(
        continuity_tx_id=tx_id,
        runtime_outcome_class="CONFIRMED_APPLIED",
        observed_post_sha256=observed_post_sha256,
        observed_post_semantic_digest=observed_post_semantic_digest,
        expected_candidate_digest=expected_candidate_digest,
        patch_digest=patch_digest,
        branch_id=branch_id,
        source_provenance={"component": "opening-tests", "kind": "unit"},
        request_provenance=request_provenance or {"component": "phase3c-fixture"},
        sync_plan_bytes_digest=request_claimed_digest(
            ContinuitySyncRequest(
                continuity_tx_id=tx_id,
                runtime_outcome_class="CONFIRMED_APPLIED",
                observed_post_sha256=observed_post_sha256,
                observed_post_semantic_digest=observed_post_semantic_digest,
                expected_candidate_digest=expected_candidate_digest,
                patch_digest=patch_digest,
                branch_id=branch_id,
                source_provenance={},
                request_provenance={},
                sync_plan_bytes_digest="",
                consequences=consequences,
                plan_version=plan_version,
            )),
        consequences=consequences,
        plan_version=plan_version,
    )


def make_applied_tx(*, consequences: list[dict], branch_id: str = "default",
                    extra_patch=None, turn: int | None = None):
    """Create a durable CONFIRMED_APPLIED saga on a disposable vendor/DB.

    Returns (root, db_path, request, pe_dict) with the row left in
    DURABILITY_PENDING / CONFIRMED_APPLIED and its runtime post refs stored,
    ready to be advanced to CONTINUITY_SYNC_PENDING by the caller if desired.
    """
    root, vendor, runtime = make_disposable_vendor()
    db = seed_disposable_db_current(root)
    patch = extra_patch or simple_patch()
    # Phase 3A prepare (no runtime write), Phase 3B single-file commit in the
    # disposable fixture -> confirmed applied.  It is the ONLY runtime touch and
    # occurs on a disposable copy.
    from continuity.transactions.preconditions import prepare_transaction
    pe = prepare_transaction(vendor_dir=vendor, db_path=db,
                             runtime_path=runtime, patch=patch, branch_id=branch_id)
    try:
        env = commit_single_file(db_path=db, vendor_dir=vendor,
                                 runtime_path=runtime, tx_id=pe.continuity_tx_id,
                                 patch=patch)
    except Exception as exc:  # abnormal vendor failure on disposable fixture
        raise RuntimeError(f"disposable vendor writer failed: {exc}")

    dao = JournalDao(connect(db))
    row = dao.get(pe.continuity_tx_id)
    request = build_request(
        tx_id=pe.continuity_tx_id,
        branch_id=branch_id,
        consequences=consequences,
        observed_post_sha256=row["runtime_post_observed_sha256"],
        observed_post_semantic_digest=row["runtime_post_semantic_digest"],
        expected_candidate_digest=row["expected_candidate_digest"] or "exp",
        patch_digest=row["patch_digest"] or "patch-x")
    # stage the deterministic digest into the prepared row so engine validates
    _stage_request_digest(connect(db), request)
    return root, db, request, dict(row)


def _stage_request_digest(con: sqlite3.Connection, request: ContinuitySyncRequest) -> None:
    with con:
        con.execute(
            "UPDATE transaction_journal SET staged_sync_digest=? "
            "WHERE continuity_tx_id=?",
            (request_claimed_digest(request), request.continuity_tx_id))


def make_journal_state(state: str, *, consequences: list | None = None,
                       branch_id: str = "default"):
    """Return (db_path, tx_id, row, request_or_None) for a tx in `state`.

    CONFIRMED_APPLIED-family states go through the real disposable runtime path
    (Phase 3B single-file writer only ever on a throwaway copy under /tmp) so
    the row is honest.  Every non-applied / pre-applied state is driven purely
    by journal bookkeeping (no runtime mutation) -- Phase 3C itself never calls
    a runtime writer.  A request (with staged digest) is returned alongside the
    applied-family row so callers can invoke the engine.
    """
    state_s = state.value if not isinstance(state, str) else state
    applied_family = {"CONFIRMED_APPLIED", "DURABILITY_PENDING",
                      "CONTINUITY_SYNC_PENDING", "CONTINUITY_SYNCING"}
    if state_s in applied_family:
        # honest: durable confirm implies the Phase 3B writer already ran once on
        # a disposable fixture (this is out of Phase 3C's runtime boundary).
        _, db, request, _ = make_applied_tx(consequences=consequences or [],
                                            branch_id=branch_id)
        tx = request.continuity_tx_id
        con = connect(db)
        dao = JournalDao(con)
        if state_s == "CONTINUITY_SYNC_PENDING":
            advance_to_sync_pending(db, tx)
        elif state_s == "CONTINUITY_SYNCING":
            advance_to_sync_pending(db, tx)
            if dao.state_of(tx) == TransactionState.CONTINUITY_SYNC_PENDING.value:
                dao._transition(tx, TransactionState.CONTINUITY_SYNCING.value)
        row = dao.get(tx)
        con.close()
        return db, tx, row, request

    # non-applied / pre-applied gate + recovery states: pure journal bookkeeping.
    root = Path(tempfile.mkdtemp(prefix="phase3c_noruntime_"))
    db = seed_disposable_db_current(root)
    con = connect(db)
    dao = JournalDao(con)
    tx = _prepared_no_runtime(con, dao, "tx-" + os.urandom(6).hex(), branch_id)
    _advance_to(con, dao, tx, state_s)
    row = dao.get(tx)
    con.close()
    return db, tx, row, None


def _prepared_no_runtime(con: sqlite3.Connection, dao: "JournalDao", tx: str,
                         branch: str) -> str:
    hasher = __import__("hashlib").sha256((tx + ":pre").encode()).hexdigest()
    dao.create_prepared(
        tx_id=tx, operation="test", branch_id=branch, protocol_version="v1",
        runtime_identity="disposable", runtime_path_ref="/tmp/state.yaml",
        runtime_pre_sha256=hasher, runtime_pre_semantic_digest=hasher,
        patch_digest=("patch-" + tx[-8:]), canonicalisation_version="v1",
        expected_candidate_digest=("exp-" + tx[-8:]),
        runtime_expected_sha256=None, runtime_expected_semantic_digest=None)
    return tx


def _advance_to(con: sqlite3.Connection, dao: "JournalDao", tx: str, state: str) -> None:
    """Drive a prepared row to `state` via JournalDao so gate/negative tests see a
    realistic (but runtime-untouched) journal.  Only PRECONDITION_FAILED is
    reachable from PREPARED with attempt_count still 0 (no writer invocation)."""
    if state == TransactionState.PREPARED.value:
        return
    if state == TransactionState.PRECONDITION_FAILED.value:
        dao.record_precondition_failure(tx, "simulated second H0 read")
        return
    # every other lifecycle state below presumes the single attempt slot was
    # consumed (attempt_count 1) through the journal guard.
    dao.open_runtime_attempt(tx)
    if state == TransactionState.RUNTIME_ATTEMPTING.value:
        return
    if state in (TransactionState.OUTCOME_UNKNOWN.value,
                 TransactionState.CONCURRENT_DIVERGENCE.value,
                 TransactionState.CONFIRMED_NOT_APPLIED.value,
                 TransactionState.MANUAL_REVIEW.value):
        outcome_state = state
        dao.record_runtime_outcome(tx, to_state=outcome_state, outcome_class=outcome_state)
        if outcome_state == TransactionState.MANUAL_REVIEW.value:
            dao.mark_manual_review(tx, evidence_summary={}, safe_actions=["read"])
        return


def advance_to_sync_pending(db: Path, tx_id: str) -> None:
    """Move a durable CONFIRMED_APPLIED/DURABILITY_PENDING row to CONTINUITY_SYNC_PENDING.

    Pure sidecar bookkeeping: transitions journal only, never touches runtime."""
    con = connect(db)
    dao = JournalDao(con)
    state = dao.state_of(tx_id)
    if state == TransactionState.CONFIRMED_APPLIED.value:
        dao.move_applied_to_durability_pending(
            tx_id, durability_status="DIR_FSYNC_OK",
            continuity_sync_state="SYNC_PENDING")
        state = dao.state_of(tx_id)
    if state == TransactionState.DURABILITY_PENDING.value:
        dao._transition(tx_id, TransactionState.CONTINUITY_SYNC_PENDING.value)
    con.close()


def seed_authority_base(db: Path, *, entities=("E-A", "E-B"), facts=(), commit_ids=(),
                        threads=(), relations=()):
    """Insert a minimal but valid authority base the plan effects may reference.
    All inserts are continuity-owned historical/world references we create by the
    same column rules as the main repo seeds; no runtime state is touched."""
    con = connect(db)
    with con:
        cur = con.cursor()
        for eid in entities:
            cur.execute(
                "INSERT OR IGNORE INTO entities "
                "(entity_id,branch_id,kind,runtime_external_ref,identity_status,"
                " anchors_json,explicit_non_capabilities_json) "
                "VALUES (?,?,?,?,?,?,?)",
                (eid, "default", "npc", eid + "-ext", "confirmed",
                 json.dumps({"canonical_name": eid}), "[]"))
        for fid, subj, pred, obj in facts:
            cur.execute(
                "INSERT OR IGNORE INTO facts "
                "(fact_id,branch_id,subject_ref,predicate,object_json,plane,"
                " admission_state,truth_status,valid_from_turn,invalid_at_turn,"
                " recorded_at_turn,recorded_at,provenance_json,classification) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (fid, "default", subj, pred, json.dumps(obj), "OBJECTIVE",
                 "COMMITTED", "ACTIVE", 1, None, 1,
                 "2026-01-01T00:00:00+00:00", '{"src":"3c"}', "AUTHORITY"))
        for kid, issuer, content, status in commit_ids:
            cur.execute(
                "INSERT OR IGNORE INTO commitments "
                "(commitment_id,branch_id,kind,issuer_ref,beneficiary_refs_json,"
                " content,status,runtime_event_ref,provenance_json) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (kid, "default", "promise", issuer, json.dumps(["E-PL"]),
                 content, status, None, "{}"))
        for tid in threads:
            cur.execute(
                "INSERT OR IGNORE INTO threads "
                "(thread_id,branch_id,status,author_state,objective_state,"
                " player_visible_state,reveal_gate_json,presentation_json,"
                " provenance_json) VALUES (?,?,?,?,?,?,?,?,?)",
                (tid, "default", "active", "a", "o", "p", "{}", "{}", "{}"))
        for rid, s, t in relations:
            cur.execute(
                "INSERT OR IGNORE INTO relationships "
                "(relationship_id,branch_id,source_ref,target_ref,runtime_refs_json,"
                " public_surface,actual_relation,phase,provenance_json) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (rid, "default", s, t, "[]", "warm", "known", "amicable", "{}"))
    con.close()
