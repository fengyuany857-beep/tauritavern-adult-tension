import unittest
from continuity.retrieval import RetrievalQuery, TemporalRetriever
from retrieval_seed import open_ctx, seed_base


class T(unittest.TestCase):
    def setUp(self):
        self.tmp, base = seed_base()
        self.addCleanup(self.tmp.cleanup)
        self.ctx = open_ctx(base)
        self.temp = TemporalRetriever()

    def ids(self, q):
        return [i.item_id for i in self.temp.retrieve(q, self.ctx).items]

    def test_current_validity(self):
        got = self.ids(RetrievalQuery(event_turn=200, query_id="q"))
        self.assertIn("FACT-SAP", got)
        self.assertNotIn("FACT-OLD", got)

    def test_historical_valid_interval(self):
        got = self.ids(RetrievalQuery(event_turn=20, include_historical=True, query_id="q"))
        self.assertIn("FACT-OLD", got)
        self.assertNotIn("FACT-OLD", self.ids(RetrievalQuery(event_turn=60, include_historical=True, query_id="q")))

    def test_retroactive_fact_at_event_time(self):
        got = self.ids(RetrievalQuery(event_turn=200, query_id="q"))
        self.assertIn("FACT-RETRO", got)

    def test_as_known_at_prevents_future_knowledge_leak(self):
        q_early = RetrievalQuery(as_known_at=200, observer_entity_id="E-C", event_turn=200, query_id="q")
        got_early = self.ids(q_early)
        self.assertNotIn("K-FUT", got_early)
        got_later = self.ids(RetrievalQuery(as_known_at=450, observer_entity_id="E-C", event_turn=450, query_id="q"))
        self.assertIn("K-FUT", got_later)
