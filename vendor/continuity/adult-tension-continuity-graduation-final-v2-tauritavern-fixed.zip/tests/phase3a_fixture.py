"""Hermetic Phase 3A fixture factory.

Produces, per setUpClass, one temp pinned vendor clone + one full validating
current runtime state at `<tmpvendor>/saves/current_state.yaml` + a fresh
migrated sidecar (with Phase 3A tables).  Each test may copy the vendor dir it
owns to isolate byte-level mutations.

Reuse:
    from tests import phase3a_fixture as PF
"""
from __future__ import annotations
import importlib.util
import shutil
import sqlite3
import tempfile
import json
from pathlib import Path

DEV_VENDOR = Path("/var/minis/workspace/vendor/dsh-adult-tension")
DEV_CONT = Path("/var/minis/workspace/adult-tension-continuity")
_CONT_FP_PREFIX = "phase3a"


__all__ = ["make_base", "current_bytes", "fresh_base", "dev_continuity"]


def dev_continuity() -> Path:
    return DEV_CONT


def _vendor_scripts(tmpvendor: Path) -> None:
    """Clone the minimal vendor scripts + data needed by loaders/commit."""
    src = DEV_VENDOR / "scripts"
    dst = tmpvendor / "scripts"
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)
    (tmpvendor / "saves").mkdir(exist_ok=True)


def _vm(tmpvendor: Path, rel: str):
    spec = importlib.util.spec_from_file_location(
        "phase3a_fixture_vendor_" + rel.replace("/", "_").replace(".py", ""),
        tmpvendor / "scripts" / rel)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load vendor script " + rel)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def build_full_state() -> dict:
    """Full validating runtime state via the vendor's own builder/fillers."""
    tmp = Path(tempfile.mkdtemp(prefix="phase3a_statebuild_"))
    _vendor_scripts(tmp)
    build = _vm(tmp, "build_opening.py")
    fill = _vm(tmp, "fill_opening.py")
    roll = build.build_roll(7, {"压力来源": "舆论发酵", "处境": "资源断供"}, {}, False, False)
    state = fill.fill_opening(build.build_skeleton(roll), roll)
    return state


def make_vendor_runtime(tmpvendor: Path, state: dict | None = None) -> Path:
    """Write a full validating current_state.yaml under a vendor clone."""
    tmp = Path(tempfile.mkdtemp(prefix=_CONT_FP_PREFIX + "_vr_"))
    _vendor_scripts(tmp)
    (tmp / "saves").mkdir(exist_ok=True, parents=True)
    if state is None:
        state = build_full_state()
    common = _vm(tmp, "_common.py")
    rt = tmp / "saves" / "current_state.yaml"
    rt.write_text(common.yaml_text(state), encoding="utf-8")
    return tmp  # the vendor dir with canonical runtime


def current_bytes(vendor: Path) -> bytes:
    return (vendor / "saves" / "current_state.yaml").read_bytes()


def fresh_base(vendor: Path | None = None, *, with_runtime: bool = True,
               seed_state: dict | None = None):
    """Return (named_temp_root, vendor_path, db_path, runtime_path)."""
    root = Path(tempfile.mkdtemp(prefix=_CONT_FP_PREFIX + "_base_"))
    if vendor is None:
        if with_runtime:
            rt_dir = make_vendor_runtime(root, seed_state)
            vendor = rt_dir
        else:
            vendor = root / "vendor"
            _vendor_scripts(vendor)
    db = root / "state" / "continuity.sqlite3"
    return root, vendor, db


def make_sidecar(db_path: Path) -> sqlite3.Connection:
    """Build a fresh Phase-3A sidecar DB via the project's migrate()."""
    from continuity.migrations import migrate
    import sqlite3
    db_path.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(db_path)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA journal_mode=WAL")
    migrate(c)
    return c
