"""Phase 2B-2 activation-level tests: knowledge/relationship/commitment/thread/
episode selection for the returning character (SPEC §11-§17).

Each test call plans a re-entry for the target and inspects the resulting
ReentryPlan (target-scoped activation only).
"""
from __future__ import annotations
import unittest

from tests import reentry_fixture as F
from continuity.reentry.contracts import (
    ActivationKind, ReentryRequest, ReentryStatus,
)
from continuity.reentry.planner import ReentryPlanner

class _Base(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base, self.cards = F.build()
        self.planner = ReentryPlanner(self.base)

    def tearDown(self):
        try:
            self.tmp.cleanup()
        except Exception:
            pass

    def plan_alex(self, last_seen=4, event_turn=200):
        snap = F.make_runtime(self.base, roster=("ALEX", "PLR"))
        req = ReentryRequest(runtime_npc_id="alex-x", branch_id="default",
                             last_seen_turn=last_seen, event_turn=event_turn,
                             reentry_reason="router_deep_resolved", mode="DEEP",
                             current_participant_entity_ids=("ALEX", "PLR"))
        return self.planner.plan(req, snap)


class KnowledgeRecall(_Base):
    def _ids(self, plan, src_type):
        return {e.source_ref for e in plan.activation_traces
                if e.source_type == src_type and e.included}

    # ---- §11 item 14/15 : target (A) knowledge loaded, B-not-leaked to A -----
    def test_target_knowledge_loaded(self):
        plan = self.plan_alex()
        self.assertIn("K-A-KNOW", self._ids(plan, "KNOWLEDGE"))

    def test_b_knowledge_not_leaked_to_a(self):
        plan = self.plan_alex()
        k = self._ids(plan, "KNOWLEDGE")
        self.assertNotIn("K-B-SECRET", k)
        self.assertNotIn("K-B-RESTRICT", k)

    # ---- §11 false_belief stays CHARACTER; not turned objective -----------
    def test_false_belief_stays_character_plane(self):
        plan = self.plan_alex()
        fb = [e for e in plan.activation_traces
              if e.source_ref == "K-A-FB" and e.included]
        self.assertEqual(len(fb), 1)
        self.assertEqual(fb[0].plane, "CHARACTER")

    # ---- §11 PLAYER_VISIBLE / AUTHOR not target knowledge ------------------
    def test_player_visible_and_author_not_target(self):
        plan = self.plan_alex()
        refs = {e.source_ref for e in plan.activation_traces}
        self.assertNotIn("K-PV", refs)
        self.assertNotIn("K-AUT", refs)


class AnchorAndRelationshipRecall(_Base):
    def _traces(self, plan, kind=None):
        return [e for e in plan.activation_traces
                if (kind is None or e.activation_type == kind)]

    def test_hard_identity_anchor_included(self):
        plan = self.plan_alex()
        anchors = self._traces(plan, ActivationKind.ANCHOR)
        self.assertGreaterEqual(len(anchors), 1)
        ids = {a.activation_id for a in anchors}
        self.assertTrue(any(a.startswith("anc:") for a in ids))

    def test_explicit_noncapability_hard(self):
        plan = self.plan_alex()
        nc = [a for a in self._traces(plan, ActivationKind.ANCHOR)
              if a.activation_id.startswith("nc:")]
        self.assertEqual(len(nc), 1)          # ALEX non-cap: unable_to_roar
        self.assertEqual(nc[0].hard_or_soft.value, "HARD")

    def test_soft_personality_not_misclassified_hard(self):
        plan = self.plan_alex()
        soft = [a for a in self._traces(plan, ActivationKind.ANCHOR)
                if a.activation_id.startswith("soft:")]
        # ALEX anchors voice / normal_mode => at least one soft tendency
        self.assertGreaterEqual(len(soft), 1)
        for s in soft:
            self.assertEqual(s.hard_or_soft.value, "SOFT")

    def test_target_player_relationship_loaded(self):
        plan = self.plan_alex()
        rels = [e for e in plan.activation_traces
                if e.source_type == "RELATIONSHIP" and e.included]
        self.assertTrue(any("R-ALEX-PLR" == r.source_ref for r in rels))

    def test_unrelated_offscreen_relationship_excluded(self):
        plan = self.plan_alex()
        rel = {e.source_ref for e in plan.activation_traces
               if e.source_type == "RELATIONSHIP"}
        # R-BOB-PLR is BOB<->PLR — unrelated to the returning ALEX
        self.assertNotIn("R-BOB-PLR", rel)


class CommitmentActivation(_Base):
    def _acts(self, plan, status=None):
        acts = [e for e in plan.activation_traces
                if e.activation_type == ActivationKind.COMMITMENT]
        seen = {}
        for a in acts:
            seen[a.source_ref] = a            # last wins by id deterministic
        return dict(sorted(seen.items()))

    def test_open_due_player_scoped_commitments_activated(self):
        plan = self.plan_alex()
        acts = self._acts(plan)
        self.assertEqual(set(acts), {"C-ALEX-PLR", "C-PLR-ALEX"})

    def test_target_player_open_promise(self):
        plan = self.plan_alex()
        acts = self._acts(plan)
        self.assertEqual(acts["C-ALEX-PLR"].activation_status.value, "ACTIVE_NOW")

    def test_player_to_target_open_debt(self):
        plan = self.plan_alex()
        acts = self._acts(plan)
        self.assertEqual(acts["C-PLR-ALEX"].activation_status.value, "ACTIVE_NOW")

    def test_unrelated_offscreen_commitment_not_activated(self):
        plan = self.plan_alex()
        acts = self._acts(plan)
        self.assertNotIn("C-BOB-PLR", acts)
        # C-ALEX-UNREL (ALEX->BOB offscreen) excluded too
        self.assertNotIn("C-ALEX-UNREL", set(acts))

    def test_resolved_not_activated(self):
        plan = self.plan_alex()
        acts = self._acts(plan)
        self.assertNotIn("C-ALEX-RES", set(acts))

    def test_no_ledger_status_write(self):
        import sqlite3
        con = sqlite3.connect(str(self.base / "state" / "continuity.sqlite3"))
        before = con.execute("SELECT status FROM commitments ORDER BY commitment_id").fetchall()
        self.plan_alex()
        after = con.execute("SELECT status FROM commitments ORDER BY commitment_id").fetchall()
        con.close()
        self.assertEqual(before, after)


class ThreadActivation(_Base):
    def test_target_linked_active_thread_activated(self):
        plan = self.plan_alex()
        refs = {e.source_ref for e in plan.activation_traces
                if e.source_type == "THREAD" and e.included}
        self.assertIn("TH-OPEN-A", refs)
        self.assertIn("TH-OTHER-A", refs)

    def test_unrelated_thread_excluded(self):
        plan = self.plan_alex()
        refs = {e.source_ref for e in plan.activation_traces
                if e.source_type == "THREAD" and e.included}
        self.assertNotIn("TH-UNREL-B", refs)

    def test_unmet_requires_loads_guard_not_payload(self):
        plan = self.plan_alex()
        guards = [e for e in plan.activation_traces
                  if e.activation_id.startswith("thread:guard:TH-GATED-A")]
        self.assertTrue(guards)
        # guard reason never carries the reveal payload objective state
        self.assertNotIn("secret-cache", " ".join(e.reason for e in guards))

    def test_anti_merge_no_synthetic_merge(self):
        plan = self.plan_alex()
        am = [e for e in plan.activation_traces if e.activation_id.startswith("am:")]
        self.assertTrue(am)
        # both guard/thread reference the blocked partner but never merge them
        self.assertNotIn("synthetic", " ".join(e.reason for e in am).lower())

    def test_reveal_never_table_to_traces_fulltext(self):
        # The fixture full reveal payload text ('secret-cache') never appears in
        # any activation content because payloads are not read into the plan.
        plan = self.plan_alex()
        blob = " ".join(e.reason for e in plan.activation_traces)
        self.assertNotIn("secret-cache", blob)


class EpisodeDeliberateRecall(_Base):
    def test_episode_caps_prevent_full_history_dump(self):
        plan = self.plan_alex()
        self.assertLessEqual(len(plan.episode_refs), 10)
        self.assertLessEqual(len(plan.episode_refs), 3)

    def test_wrong_branch_episode_excluded(self):
        plan = self.plan_alex()
        old = {e.source_ref for e in plan.activation_traces
               if e.source_type == "EPISODE"}
        self.assertNotIn("EP-WB", old)

    def test_relationship_semantics_not_adult_text(self):
        plan = self.plan_alex()
        for e in plan.activation_traces:
            low = (e.reason or "").lower()
            for tok in ("consent", "granted", "sex", "intimacy"):
                self.assertNotIn(tok, low)


if __name__ == "__main__":
    unittest.main()
