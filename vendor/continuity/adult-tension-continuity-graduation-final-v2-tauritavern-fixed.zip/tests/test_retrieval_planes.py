import unittest
from continuity.retrieval import LedgerRetriever, RetrievalQuery
from retrieval_seed import open_ctx, seed_base


class T(unittest.TestCase):
    def setUp(self):
        self.tmp, base = seed_base()
        self.addCleanup(self.tmp.cleanup)
        self.ctx = open_ctx(base)
        self.led = LedgerRetriever()

    def ids(self, q):
        return [i.item_id for i in self.led.retrieve(q, self.ctx).items]

    def test_player_visible_not_character_knowledge(self):
        got = self.ids(RetrievalQuery(observer_entity_id="E-C", query_id="q"))
        self.assertNotIn("K-PV", got)

    def test_objective_fact_not_returned_for_character_plane_query(self):
        got = self.ids(RetrievalQuery(fact_ids=("FACT-SAP",), requested_planes=frozenset({"CHARACTER"}), query_id="q"))
        self.assertNotIn("FACT-SAP", got)

    def test_observer_knowledge_scoped(self):
        got = self.ids(RetrievalQuery(observer_entity_id="E-A", query_id="q"))
        self.assertIn("K-A-SEC", got)
        self.assertNotIn("K-FB", got)
