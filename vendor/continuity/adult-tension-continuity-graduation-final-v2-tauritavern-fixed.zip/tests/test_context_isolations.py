"""Phase 2B-1 isolation, budget, evidence and adult-compat builder tests."""
from __future__ import annotations
import hashlib
import os
import sqlite3
import unittest
from pathlib import Path

from continuity.routing import (
    ContextMode, ContextPack, ContextPackBuilder, PackStatus, ResidencyTier,
    RoutingRequest,
)
from tests.context_builder_fixture import build_context_base, runtime_state_path


def _new(base, **req):
    if "text" in req:
        req["raw_text"] = req.pop("text")
    req.setdefault("branch_id", "default")
    return RoutingRequest(query_id="t", **req)


def _b(base, req=None, runtime_state=None, **kw):
    if req is None:
        req = _new(base, **kw)
    return ContextPackBuilder(base).build(req, runtime_state=runtime_state)


class ObserverAndPlanes(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base = build_context_base()
        self.addCleanup(self.tmp.cleanup)

    def _p(self, text="我喝了口水", observer=None, scene=("E-A", "E-PL"),
           **kw):
        return _b(self.base, raw_text=text, observer_entity_id=observer,
                  scene_entity_ids=scene, **kw)

    # ---- #18 A-knowledge is not in B pack --------------------------------
    def test_a_knowledge_not_in_b_pack(self):
        pa = self._p(observer="E-A")
        contentA = " ".join(i.content for i in pa.items)
        self.assertIn("knows PROP-secret", contentA)      # A sees its own secret
        pb = self._p(observer="E-B")
        contentB = " ".join(i.content for i in pb.items)
        self.assertNotIn("PROP-secret", contentB)          # B never sees A's

    # ---- #19 missing knowledge row is not converted to does_not_know ------
    def test_missing_row_not_doesnotknow(self):
        # E-B has NO knowledge rows at all.  Its pack must not fabricate a
        # does_not_know restriction.
        pb = self._p(observer="E-B")
        kb = [i for i in pb.items if i.source_type == "KNOWLEDGE"]
        for i in kb:
            self.assertNotIn("does_not_know", i.content)

    # ---- #20 false belief stays CHARACTER (not promoted to OBJECTIVE) ------
    def test_false_belief_stays_character(self):
        p = self._p(observer="E-A")
        fb = [i for i in p.items if "false_belief" in i.content or i.source_type == "KNOWLEDGE" and "PROP-door" in i.content]
        self.assertTrue(fb)
        for i in fb:
            self.assertIn("CHARACTER", i.classification)
            self.assertEqual(i.plane, "CHARACTER")
            self.assertIn("false_belief", i.content)

    # ---- #21 PLAYER_VISIBLE does not become character knowledge -----------
    def test_player_visible_never_character_knowledge(self):
        p = self._p(observer="E-A")
        # K-PV was PLAYER_VISIBLE (narrator).  It must not appear as
        # CHARACTER-grounded knowledge in any character's pack content.
        for i in p.items:
            self.assertNotIn("PROP-hint", i.content)

    # ---- #24/48 reveal gate unmet blocks full reveal ----------------------
    def test_reveal_gate_blocks_full_reveal_payload(self):
        p = self._p(text="我喝了口水", observer="E-A",
                    scene=("E-A", "E-PL"), explicit_historical_request=True)
        gate_records = [i for i in p.items if "reveal gate on thread TH-S unmet" in i.content]
        self.assertTrue(gate_records, "gate record must exist when prereq unmet")
        for i in p.items:
            self.assertNotIn("secret-sapphire-cache", i.content)
            self.assertNotIn("author_state", i.content)

    # ---- #48 lexical high match cannot bypass reveal gate ------------------
    def test_lexical_high_score_cannot_bypass_reveal(self):
        # Build an EVIDENCE pack whose raw query literally names the secret term.
        # Even though the gated thread's author_state contains that term on disk,
        # the pack materialises gate metadata only.
        p = _b(self.base, raw_text="SapphireCache 原话是什么", observer_entity_id="E-A",
               scene_entity_ids=("E-A", "E-PL"))
        revealed = [i for i in p.items if "sapphire-cache" in i.content.lower()]
        self.assertFalse(revealed, "lexical match must not materialise a gated secret")

    # ---- #25 anti-merge prevents synthetic merge --------------------------
    def test_anti_merge_prevents_synthetic_merge(self):
        p = _b(self.base, text="那个秘密现在怎么样了", observer_entity_id="E-A",
               scene_entity_ids=("E-A", "E-PL"), mode_override=ContextMode.DEEP)
        guards = [i for i in p.items if "anti-merge guard" in i.content
                  and "TH-OK" in i.content]
        self.assertTrue(guards)
        # two distinct mysteries must stay as separate records, no combined truth
        combined = [i for i in p.items if "TH-S" in i.content and "TH-OK" in i.content
                    and "anti-merge guard" not in i.content]
        self.assertFalse(combined, "builder must not fabricate a merged thread")

    # ---- #22 AUTHOR plan excluded from an IC pack --------------------------
    def test_author_plan_excluded_from_ic(self):
        conn = sqlite3.connect(str(self.base / "state" / "continuity.sqlite3"))
        conn.execute(
            "INSERT INTO facts (fact_id,branch_id,subject_ref,predicate,object_json,plane,admission_state,truth_status,"
            "valid_from_turn,invalid_at_turn,recorded_at_turn,recorded_at,provenance_json,classification) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            ("F-PLAN", "default", "E-PL", "plans.to", '{"goal":"marry"}', "OBJECTIVE",
             "COMMITTED", "AUTHOR_PLAN", 1, None, 1, "t", "{}", "AUTHOR"))
        conn.commit()
        conn.close()
        p = self._p(observer="E-PL", scene=("E-A", "E-PL"))
        content = " ".join(i.content for i in p.items)
        self.assertNotIn("marry", content)

    # ---- #41 historical consent can't become current permission ------------
    def test_historical_consent_not_current_permission(self):
        p = self._p(observer="E-A", scene=("E-A", "E-PL"))
        # REL-A is an intimate edge w/ historical consent-style runtime refs.
        content = " ".join(i.content for i in p.items)
        self.assertNotIn("consent:", content)
        self.assertNotIn("grant", content)
        self.assertNotIn("intimacy allowed", content)
        self.assertNotIn("permission", content)

    # ---- #42 high trust/attraction cannot produce permission --------------
    def test_trust_attraction_never_permission(self):
        p = self._p(observer="E-A", scene=("E-A", "E-PL"))
        for i in p.items:
            # relationship context refers to relationship* only (no consent grant)
            self.assertTrue("consent" not in i.content.lower())
            self.assertTrue("grant" not in i.content.lower())
        # relationship semantics context may appear but never labelled a grant
        rel = [i for i in p.items if i.source_type == "RELATIONSHIP"]
        for i in rel:
            self.assertNotIn("grant", i.content.lower())

    # ---- #43 runtime adult authority appears only as reference ------------
    def test_runtime_authority_only_reference(self):
        rp = runtime_state_path(self.base)
        p = _b(self.base, runtime_state=rp, raw_text="我喝了口水",
               observer_entity_id="E-A", scene_entity_ids=("E-A", "E-PL"))
        fp = [i for i in p.items if "SHA-256 reference" in i.content]
        self.assertTrue(fp)
        # consent/boundary content never enters any item (only runtime fp is ref)
        for i in p.items:
            self.assertNotIn("consent", i.content.lower())
            self.assertNotIn("boundaries:", i.content.lower())


class BudgetGuards(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base = build_context_base()
        self.addCleanup(self.tmp.cleanup)

    def test_soft_warm_drops_under_budget_trace(self):
        # unlimited hard+soft baseline to see warm items exist
        big = _b(self.base, raw_text="我喝了口水", observer_entity_id="E-A",
                 scene_entity_ids=("E-A",), token_budget=None)
        warm = [i for i in big.items if i.residency in ("HOT",)]
        # compute warm costs = HOT hard-only budget will leave none for WARM
        p = _b(self.base, raw_text="我喝了口水", observer_entity_id="E-A",
               scene_entity_ids=("E-A",), token_budget=big.hard_cost)
        # assert drops are traced as BUDGET_DROPPED or COLD_EXCLUDED
        self.assertTrue(p.dropped or all(i.residency == "HOT" for i in p.items))
        drop_reasons = {d.reason for d in p.dropped}
        self.assertTrue(drop_reasons & {"BUDGET_DROPPED", "COLD_EXCLUDED_IN_MODE"}
                        or not p.dropped)

    def test_hard_over_budget_blocks(self):
        # a tiny budget below the hard minimum must raise PACK_BUDGET_BLOCKED
        p = _b(self.base, raw_text="我喝了口水", observer_entity_id="E-A",
               scene_entity_ids=("E-A", "E-PL"), token_budget=4)
        self.assertEqual(p.status, PackStatus.PACK_BUDGET_BLOCKED)
        self.assertEqual(len(p.items), 0)


class SupersededAndBranch(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base = build_context_base()
        self.addCleanup(self.tmp.cleanup)

    def test_superseded_excluded_in_fast(self):
        p = _b(self.base, raw_text="我喝了口水", observer_entity_id="E-A",
               scene_entity_ids=("E-A", "E-PL"))
        content = " ".join(i.content for i in p.items)
        self.assertNotIn('"name": "OldName"', content)
        self.assertIn('"name": "NewName"', content)   # successor current

    def test_superseded_can_appear_under_evidence(self):
        p = _b(self.base, raw_text="她曾用过的旧名字原话是什么？",
               observer_entity_id="E-A", scene_entity_ids=("E-A", "E-PL"))
        self.assertEqual(p.final_mode, "EVIDENCE")
        content = " ".join(i.content for i in p.items)
        supersed = [i for i in p.items if "OldName" in i.content]
        # superseded records permitted to surface in history/evidence context
        self.assertTrue(supersed)
        for i in supersed:
            self.assertEqual(i.residency, "COLD")

    def test_wrong_branch_and_candidates_excluded(self):
        # add candidate + rejected rows on the default branch
        conn = sqlite3.connect(str(self.base / "state" / "continuity.sqlite3"))
        for fid, adm in (("F-CAND", "CANDIDATE"), ("F-REJ", "REJECTED")):
            conn.execute("INSERT INTO facts (fact_id,branch_id,subject_ref,predicate,object_json,plane,admission_state,truth_status,"
                         "valid_from_turn,invalid_at_turn,recorded_at_turn,recorded_at,provenance_json,classification) "
                         "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                         (fid, "default", "E-A", "sneaky", '{"until":"later"}', "OBJECTIVE", adm, "PENDING",
                          1, None, 1, "t", "{}", "CANDIDATE"))
        conn.commit()
        conn.close()
        p = _b(self.base, raw_text="我喝了口水", observer_entity_id="E-A",
               scene_entity_ids=("E-A", "E-PL"))
        content = " ".join(i.content for i in p.items)
        for bad in ("F-CAND", "F-REJ", "later", "FACT-BR2", "guards gate"):
            self.assertNotIn(bad, content)
        # future-recorded fact excluded at as_known_at before it was recorded
        early = _b(self.base, raw_text="我喝了口水", observer_entity_id="E-A",
                   scene_entity_ids=("E-A", "E-PL"), event_turn=30, as_known_at=30)
        self.assertNotIn("entered", " ".join(i.content for i in early.items))
        # ... yet visible once that point in world & record time is reached
        later = _b(self.base, raw_text="我喝了口水", observer_entity_id="E-A",
                   scene_entity_ids=("E-A", "E-PL"), event_turn=300, as_known_at=600)
        self.assertIn("entered", " ".join(i.content for i in later.items))


class EvidenceAndStatus(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base = build_context_base()
        self.addCleanup(self.tmp.cleanup)

    def _corrupt_history_volume(self):
        path = self.base / "history" / "EP-new.jsonl"
        if os.path.exists(path):
            os.remove(path)
        lines = [
            '{"branch_id":"default","episode_id":"EP-corrupt","transaction_id":"TXC",'
            '"runtime_pre_hash":"p","runtime_post_hash":"q","timestamp":"2026-06-01T00:00:00+00:00",'
            '"payload_classification":"HISTORICAL_EVIDENCE","source_references":[],'
            '"scene_id":"SC-X","participants":["E-A","E-PL"],"turn_start":8,"turn_end":9,'
            '"summary":"exact sapphire quote","checksum":"deadbeefbadbadbadbadbadbadbadbadbadbadbad"}'
        ]
        path.write_text("\n".join(lines), encoding="utf-8")

    def test_evidence_corrupt_sets_evidence_corrupt(self):
        self._corrupt_history_volume()
        p = _b(self.base, raw_text="她上次原话到底是什么？", observer_entity_id="E-A",
               scene_entity_ids=("E-A", "E-PL"))
        # mode EVIDENCE sees a history span whose checksum is invalid
        self.assertIn(p.status, (PackStatus.EVIDENCE_CORRUPT, PackStatus.EVIDENCE_INSUFFICIENT))
        if p.status == PackStatus.EVIDENCE_CORRUPT:
            corrupt = [i for i in p.items if "corrupt" in i.content.lower()]
            self.assertTrue(corrupt)

    def test_evidence_missing_sets_evidence_insufficient(self):
        # branch with no history volumes at all
        req = _new(self.base, raw_text="她上次原话到底是什么？", observer_entity_id="E-A",
                   scene_entity_ids=("E-A",), branch_id="no-history")
        p = _b(self.base, req)
        self.assertIn(p.status, (PackStatus.EVIDENCE_INSUFFICIENT, PackStatus.PARTIAL))
        self.assertTrue(any(i.mode_attempted == "EVIDENCE" for i in p.insufficiency)
                        or not p.items)

    def test_off_screen_npc_cards_not_loaded_in_fast(self):
        p = _b(self.base, raw_text="我喝了口水", observer_entity_id="E-A",
               scene_entity_ids=("E-A", "E-PL"))
        # E-OFF is an NPC that is NOT a current participant.
        off = [i for i in p.items if i.source_ref == "E-OFF"]
        self.assertFalse(off, "offscreen NPC cards should not be auto-loaded in FAST")


if __name__ == "__main__":
    unittest.main()


class AmbiguityStatus(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base = build_context_base()
        self.addCleanup(self.tmp.cleanup)

    def test_multiple_entity_ambiguity_yields_ambiguous(self):
        from continuity.routing import RoutingRequest
        req = RoutingRequest(query_id="q", raw_text="那人回来了，到底是谁？",
                              observer_entity_id="E-A", scene_entity_ids=("E-A",))
        p = ContextPackBuilder(self.base).build(req, detected_entities=("E-A", "E-OLD"))
        # two detected candidate identities at routing time -> AMBIGUOUS must be
        # surfaced as an insufficiency rather than silently resolved.
        self.assertEqual(p.status, PackStatus.AMBIGUOUS)
        self.assertTrue(any("ambiguous" in i.reason for i in p.insufficiency))
