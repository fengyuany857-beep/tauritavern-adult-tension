import unittest
from continuity.constants import *
from continuity.validation import assert_authority
from continuity.errors import AuthorityError
class T(unittest.TestCase):
 def test_classifications(self): self.assertEqual('AUTHORITY',Classification.AUTHORITY.value)
 def test_derived_rejected(self):
  with self.assertRaises(AuthorityError): assert_authority(Classification.DERIVED_REBUILDABLE)
