"""Phase 3B — mutation guard / contracts / disposable-path safety tests.

Covers task §32 (1,2,3,4,5,33,58,59,60,61) and the guard boundary: single-file
capability accepted, named-slot blocked, a mutation request requires an already
PREPARED transaction with concrete upstream patch evidence, player natural
language is rejected, adult-inference is rejected, and mutation tests only ever
point at disposable temp roots.
"""
from __future__ import annotations
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3b_fixture import (
    make_disposable_vendor, seed_disposable_db, simple_patch,
    current_bytes, assert_disposable_runtime_path,
)

from continuity.runtime3b.guard import (
    is_disposable_runtime, build_mutation_request, guard_unnamed_slot,
    guard_no_desired_outcome,
)
from continuity.runtime3b.contracts import MutationMode
from continuity.transactions.errors import (
    UnsupportedNamedSlot, PlayerSovereigntyViolation, InvalidArgument,
)
from continuity.transactions.contracts import TransactionState


def _prepared_row(db: Path, tx_id: str) -> dict:
    con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
    try:
        r = con.execute("SELECT * FROM transaction_journal WHERE continuity_tx_id=?",
                        (tx_id,)).fetchone()
        return dict(r) if r else {}
    finally:
        con.close()


class Phase3BContractsGuardTests(unittest.TestCase):

    def setUp(self):
        from continuity.transactions.preconditions import prepare_transaction
        self._tmp, vendor, runtime = make_disposable_vendor()
        self.tmp = self._tmp
        self.vendor = vendor
        self.runtime = runtime
        self.db = seed_disposable_db(self.tmp)
        self.patch = simple_patch()
        pe = prepare_transaction(
            vendor_dir=vendor, db_path=self.db, runtime_path=runtime,
            patch=self.patch, branch_id="default")
        self.pe = pe
        self.row = _prepared_row(self.db, pe.continuity_tx_id)

    # 2. single-file capability accepted -------------------------------
    def test_single_file_capability_accepted(self):
        # The canonical current_state single file is accepted by prepare and
        # yields a durable PREPARED with proper evidence, not a named-slot.
        self.assertEqual(self.row["state"], TransactionState.PREPARED.value)
        self.assertTrue(self.runtime.resolve().as_posix().endswith(
            "/saves/current_state.yaml"))
        proof = is_disposable_runtime(self.vendor, self.runtime)
        self.assertTrue(proof.ok)

    # 3. named-slot blocked ---------------------------------------------
    def test_named_slot_blocked(self):
        guard_unnamed_slot(self.runtime)
        slot_pairs = [
            Path(self.vendor) / "saves" / "slots" / "aaa" / "state.yaml",
            Path(self.vendor) / "saves" / "slots" / "aaa" / "manifest.yaml",
        ]
        for p in slot_pairs:
            with self.assertRaises(UnsupportedNamedSlot):
                guard_unnamed_slot(p)

    # 4 + 5. mutation request requires prepared tx + concrete patch -------
    def test_mutation_request_requires_prepared_concrete(self):
        mreq = build_mutation_request(
            tx_id=self.pe.continuity_tx_id, row=self.row,
            vendor_dir=self.vendor, runtime_path=self.runtime,
            patch_digest=self.row.get("patch_digest"),
            mode=MutationMode.ALLOW_DISPOSABLE,
            disposable_proof=is_disposable_runtime(self.vendor, self.runtime))
        self.assertEqual(mreq.continuity_tx_id, self.pe.continuity_tx_id)
        self.assertEqual(mreq.patch_digest, self.row["patch_digest"])

    def test_mutation_request_refuses_nonprepared_tx(self):
        bad = dict(self.row)
        bad["state"] = TransactionState.ABORTED_NOT_ATTEMPTED.value
        with self.assertRaises(InvalidArgument):
            build_mutation_request(tx_id=self.pe.continuity_tx_id, row=bad,
                                   vendor_dir=self.vendor, runtime_path=self.runtime,
                                   mode=MutationMode.ALLOW_DISPOSABLE,
                                   disposable_proof=is_disposable_runtime(
                                       self.vendor, self.runtime))

    # Natural-language desired outcome is never a patch (§25) --------------
    def test_player_natural_language_rejected_at_mutation_edge(self):
        with self.assertRaises(PlayerSovereigntyViolation):
            guard_no_desired_outcome({"desired_outcome": "make her believe me"})

    # 33 / 58 / 59. disposable-only guard and real-project avoidance ---------
    def test_dangerous_mutation_paths_are_foreclosed(self):
        for forbidden in ["/var/minis/workspace", "/var/minis/memory",
                          "/var/minis/shared", str(Path.home()), "/saves"]:
            with self.assertRaises(AssertionError):
                assert_disposable_runtime_path(Path(forbidden) / "x.yaml")
        # ensure the disposable fixture runtime passes the guard
        assert_disposable_runtime_path(self.runtime)

    def test_vendor_repo_and_source_after_disposable_prepare_unmutated(self):
        # prepare (this setUp) is read-only even on a disposable vendor.
        before = current_bytes(self.vendor)
        # run a guard-oriented operation only (no mutation)
        proof = is_disposable_runtime(self.vendor, self.runtime)
        self.assertTrue(proof.ok)
        self.assertEqual(current_bytes(self.vendor), before)


if __name__ == "__main__":
    unittest.main()
