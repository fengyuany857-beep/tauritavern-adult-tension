import unittest
from continuity.retrieval import LexicalRetriever, RetrievalQuery
from retrieval_seed import open_ctx, seed_base


class T(unittest.TestCase):
    def setUp(self):
        self.tmp, base = seed_base()
        self.addCleanup(self.tmp.cleanup)
        self.ctx = open_ctx(base)
        self.lex = LexicalRetriever()

    def test_lexical_retrieves_committed_active_fact(self):
        r = self.lex.retrieve(RetrievalQuery(raw_text="sapphire", query_id="q"), self.ctx)
        self.assertIn("FACT-SAP", [i.item_id for i in r.items])

    def test_lexical_excludes_candidate_and_rejected(self):
        r = self.lex.retrieve(RetrievalQuery(raw_text="sapphire", query_id="q"), self.ctx)
        ids = {i.item_id for i in r.items}
        self.assertNotIn("FACT-CAND", ids)
        self.assertNotIn("FACT-REJ", ids)

    def test_current_retrieval_excludes_superseded(self):
        r = self.lex.retrieve(RetrievalQuery(raw_text="OldName", query_id="q"), self.ctx)
        self.assertEqual([], [i for i in r.items if i.item_id == "FACT-SUP"])

    def test_historical_retrieval_can_include_superseded(self):
        r = self.lex.retrieve(RetrievalQuery(raw_text="OldName", include_superseded=True, query_id="q"), self.ctx)
        self.assertIn("FACT-SUP", [i.item_id for i in r.items])
