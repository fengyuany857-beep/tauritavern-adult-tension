"""Phase 3D P0 REPAIR 1 regression suite (independent-gate P0s A/B/C).

Verifies:
  P0-A : COMPLETED is gated on outbox/evidence delivery; a stranded PENDING
         outbox (SQLite sync committed, drain never ran) is drained on top-level
         recover/orchestrate; a drain fault or partial JSONL must NOT report
         COMPLETED; status reflects pending outbox.
  P0-B : same-tx concurrency keeps exactly one runtime attempt and one sync, never
         degrades a winning CONFIRMED_APPLIED to UNKNOWN, never lets a losing
         worker classify an outcome (no double writer / no double sync / no
         duplicate outbox).
  P0-C : no UnboundLocalError on any losing/conflict path; loser DuplicateAttempt /
         InvalidTransition return a safe conflict/in-progress status (never UNKNOWN,
         never a crash), and cannot downgrade CONFIRMED_APPLIED.

The concurrency stress is deliberately smaller here than the independent
loops the fix was validated against (they keep the suite bounded); the unit
assertions encode the same invariants.
"""
from __future__ import annotations
import sqlite3
import sys
import unittest
import contextlib
from pathlib import Path
from unittest import mock

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3b_fixture import make_disposable_vendor, simple_patch, current_bytes
from tests.phase3d_fixture import seed_disposable_db, sample_consequences
from continuity.orchestration import orchestrate, recover_orchestration
from continuity.orchestration.orchestrator import Orchestrator
from continuity.orchestration.contracts import (
    OrchestrationRequest, ConsequencePlan, OrchestrationStatus, OrchestrationStage,
)
from continuity.transactions.preconditions import prepare_transaction
from continuity.sync3c import engine as engine_mod


def _cons():
    return ConsequencePlan(consequences=sample_consequences())


def _req(vendor, runtime):
    return OrchestrationRequest(patch=simple_patch(), vendor_dir=str(vendor),
                                runtime_path=str(runtime), consequence_plan=_cons())


def _row(db, tx):
    con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
    r = con.execute("SELECT * FROM transaction_journal WHERE continuity_tx_id=?", (tx,)).fetchone()
    con.close()
    return dict(r) if r else {}


def _dbq(db, q, p=()):
    con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
    r = con.execute(q, p).fetchall(); con.close()
    return [dict(x) for x in r]


def _evidence_records(db):
    p = Path(db).parent / "history" / "VOL-001.jsonl"
    if not p.exists():
        return []
    return [ln for ln in p.read_text(errors="replace").splitlines() if ln.strip()]


def _pending(db, tx):
    return _dbq(db, "SELECT COUNT(*) c FROM history_outbox "
                    "WHERE continuity_tx_id=? AND state='PENDING'", (tx,))[0]["c"]


@contextlib.contextmanager
def _strand_at_first_drain():
    """Inject a crash (raise) on the VERY first outbox drain the engine performs.
    The atomic sync txn (effects+markers+sync_execution+outbox) commits first, so
    the durable result is exactly an F10 stranded window: row CONTINUITY_SYNCED,
    syncex=1, a PENDING outbox, and no evidence volume record yet."""
    orig = engine_mod.ContinuitySyncEngine.drain_outbox
    state = {"calls": 0}

    def boom(self, limit=250):
        state["calls"] += 1
        if state["calls"] == 1:
            raise RuntimeError("injected F10 crash between sync commit and outbox drain")
        return orig(self, limit)

    engine_mod.ContinuitySyncEngine.drain_outbox = boom
    try:
        yield state
    finally:
        engine_mod.ContinuitySyncEngine.drain_outbox = orig


def _build_stranded():
    """Full real chain ending in a stranded F10 window (durable CONTINUITY_SYNCED,
    PENDING outbox, evidence empty). Returns (db, tx, vendor, runtime)."""
    with _strand_at_first_drain():
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        o = Orchestrator(db_path=db)
        try:
            try:
                o.orchestrate(_req(vendor, runtime))
            except Exception:
                pass
        finally:
            o.close()
    rows = _dbq(db, "SELECT continuity_tx_id FROM transaction_journal "
                    "ORDER BY created_at LIMIT 1")
    return db, rows[0]["continuity_tx_id"], vendor, runtime


class Phase3dP0Fix1Core(unittest.TestCase):
    """P0-A: COMPLETED must be gated on outbox/evidence delivery."""

    def _mk_stranded_fixture(self):
        db, tx, vendor, runtime = _build_stranded()
        st = _row(db, tx)
        assert st["state"] == "CONTINUITY_SYNCED"
        assert _pending(db, tx) == 1
        assert len(_evidence_records(db)) == 0
        return db, tx, vendor, runtime, st

    def test_1_already_synced_pending_outbox_is_not_terminal_completed(self):
        db, tx, vendor, runtime, st = self._mk_stranded_fixture()
        # With a still-pending outbox the read-only status must truthfully expose
        # outbox_pending == 1 and the (non-terminal) durable CONTINUITY_SYNCED.
        from continuity.orchestration import orchestration_status
        s = orchestration_status(db_path=db, tx_id=tx)
        self.assertEqual(s["outbox_pending"], 1)
        self.assertEqual(s["state"], "CONTINUITY_SYNCED")
        self.assertNotEqual(s["state"], "COMPLETED")

    def test_2_already_synced_pending_outbox_drains_on_restart(self):
        db, tx, vendor, runtime, st = self._mk_stranded_fixture()
        r = recover_orchestration(db_path=db, tx_id=tx, consequence_plan=_cons())
        self.assertEqual(r.status, OrchestrationStatus.COMPLETED.value)
        # evidence exactly once, durable COMPLETED only post-delivery
        self.assertEqual(_pending(db, tx), 0)
        self.assertEqual(len(_evidence_records(db)), 1)
        self.assertEqual(_row(db, tx)["state"], "COMPLETED")

    def test_2b_orchestrate_restart_drains_pending_outbox(self):
        db, tx, vendor, runtime, st = self._mk_stranded_fixture()
        r = orchestrate(_req(vendor, runtime), db_path=db, tx_id_hint=tx,
                        consequence_plan=_cons())
        self.assertEqual(r.status, OrchestrationStatus.COMPLETED.value)
        self.assertEqual(_pending(db, tx), 0)
        self.assertEqual(len(_evidence_records(db)), 1)

    def test_3_outbox_drain_failure_is_not_completed(self):
        # Re-apply stranded build, then make drain KEEP failing during recovery.
        db, tx, vendor, runtime = _build_stranded()
        orig = engine_mod.ContinuitySyncEngine.drain_outbox
        def boom(self, limit=250):
            raise RuntimeError("outbox append keeps failing")
        engine_mod.ContinuitySyncEngine.drain_outbox = boom
        try:
            r = recover_orchestration(db_path=db, tx_id=tx, consequence_plan=_cons())
        finally:
            engine_mod.ContinuitySyncEngine.drain_outbox = orig
        # Must NOT be terminal COMPLETED with a pending outbox.
        self.assertNotEqual(r.status, OrchestrationStatus.COMPLETED.value)
        self.assertEqual(_pending(db, tx), 1)
        self.assertEqual(len(_evidence_records(db)), 0)

    def test_4_delivery_required_before_completed(self):
        # A durable applied+synced row with *no* outbox won't final-form; after a
        # healthy full chain delivery arrives and COMPLETED reflects it.
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        r = orchestrate(_req(vendor, runtime), db_path=db)
        self.assertEqual(r.status, OrchestrationStatus.COMPLETED.value)
        self.assertEqual(_pending(db, r.continuity_tx_id), 0)
        self.assertEqual(_row(db, r.continuity_tx_id)["state"], "COMPLETED")

    def test_5_partial_jsonl_no_false_completed(self):
        db, tx, vendor, runtime, st = self._mk_stranded_fixture()
        # Corrupt the (empty-ish) evidence volume with a partial/torn tail lines
        # does not produce a duplicate; recovery uses the strict projector.
        p = Path(db).parent / "history" / "VOL-001.jsonl"
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("w") as fh:
            fh.write('{"partial": true, "torn"')      # not a valid envelope
        r = recover_orchestration(db_path=db, tx_id=tx, consequence_plan=_cons())
        self.assertEqual(r.status, OrchestrationStatus.COMPLETED.value)
        self.assertEqual(_pending(db, tx), 0)
        self.assertEqual(len(_evidence_records(db)), 1)   # exactly one, not a dup
        for line in _evidence_records(db):
            import json
            json.loads(line)   # strict projector: every record is valid JSONL

    def test_6_status_reflects_pending_outbox_not_terminal(self):
        db, tx, vendor, runtime, st = self._mk_stranded_fixture()
        # outbox_pending() helper must truthfully report 1 while stranded.
        con = sqlite3.connect(str(db))
        con.row_factory = sqlite3.Row
        try:
            from continuity.orchestration.orchestrator import outbox_pending as op
            self.assertEqual(op(con, tx), 1)
        finally:
            con.close()


class Phase3dP0Fix1Concurrency(unittest.TestCase):
    """P0-B / P0-C: same-tx concurrency never strands, never double-writes,
    never lets a loser classify an outcome, never crashes."""

    def _race(self):
        import threading
        import concurrent.futures as cf
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        from continuity.transactions.preconditions import new_tx_id
        from continuity.orchestration.orchestrator import _validate_and_digest_plan
        tx = new_tx_id()
        pe = prepare_transaction(
            vendor_dir=vendor, db_path=db, runtime_path=runtime,
            patch=simple_patch(), tx_id=tx,
            staged_sync_digest=_validate_and_digest_plan(tx, "default", _cons()))
        res = {"writers": 0, "completed": 0, "exc": [], "statuses": []}

        def work():
            try:
                r = orchestrate(_req(vendor, runtime), db_path=db, tx_id_hint=tx,
                                consequence_plan=_cons())
                res["statuses"].append(r.status)
                if bool(r.writer_invoked):
                    res["writers"] += 1
                return r.status
            except Exception as exc:
                res["exc"].append(exc.__class__.__name__ + ": " + str(exc)[:120])
                return "EXC"

        with cf.ThreadPoolExecutor(max_workers=2) as ex:
            futs = [ex.submit(work), ex.submit(work)]
            [f.result(timeout=300) for f in futs]
        res["ac"] = int(_row(db, tx)["attempt_count"])
        res["synx"] = _dbq(db, "SELECT COUNT(*) c FROM continuity_sync_executions "
                               "WHERE continuity_tx_id=?", (tx,))[0]["c"]
        res["state"] = _row(db, tx)["state"]
        res["completed"] = sum(1 for s in res["statuses"] if s == "COMPLETED")
        res["pend"] = _pending(db, tx)
        return res, db, tx

    def test_9_loser_cannot_write_runtime_outcome(self):
        # lose scenario encoded below in test_14 loops (no durable UNKNOWN created
        # by a loser).  Direct assertion: winner/loser race never ends OUTCOME_UNKNOWN.
        for _ in range(4):
            res, db, tx = self._race()
            self.assertNotEqual(res["state"], "OUTCOME_UNKNOWN",
                                "loser must not strand an applied tx as UNKNOWN")
            self.assertLessEqual(res["ac"], 1)
            self.assertLessEqual(res["writers"], 1)

    def test_10_loser_duplicate_attempt_safe_conflict(self):
        # Deterministic: pre-consume the single attempt via the journal top-level
        # then re-orchestrate -> the call must NOT be UnboundLocalError/UNKNOWN.
        db, tx, vendor, runtime = self._mk_result_from_consumed_attempt()
        r = orchestrate(_req(vendor, runtime), db_path=db, tx_id_hint=tx,
                        consequence_plan=_cons())
        # a loser/refusal is a safe status, never a crash
        self.assertIn(r.status, (OrchestrationStatus.PENDING.value,
                                 OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value,
                                 OrchestrationStatus.COMPLETED.value,
                                 OrchestrationStatus.PRECONDITION_FAILED.value))
        self.assertNotEqual(r.runtime_outcome, "OUTCOME_UNKNOWN")
        self.assertEqual(_row(db, tx)["attempt_count"], 1)

    def _mk_result_from_consumed_attempt(self):
        root, vendor, runtime = make_disposable_vendor()
        db = seed_disposable_db(root)
        pre = prepare_transaction(vendor_dir=vendor, db_path=db, runtime_path=runtime,
                                  patch=simple_patch())
        tx = pre.continuity_tx_id
        # reserve the single attempt so a second orchestrate hits DuplicateAttempt.
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        from continuity.transactions.journal import JournalDao
        dao = JournalDao(con)
        dao.open_runtime_attempt(tx)
        con.close()
        return db, tx, vendor, runtime

    def test_11_loser_invalid_transition_safe(self):
        # orchestrator never raises UnboundLocalError / raw InvalidTransition to the
        # caller on a race in the isolated loop.
        for _ in range(4):
            res, db, tx = self._race()
            for e in res["exc"]:
                self.assertFalse(e.startswith("InvalidTransition:"),
                                 f"loser crashed raw: {e}")
                self.assertFalse(e.startswith("UnboundLocalError"),
                                 f"loser crashed unbound: {e}")

    def test_12_no_downgrade_of_confirmed_applied(self):
        for _ in range(4):
            res, db, tx = self._race()
            self.assertIn(res["state"], ("COMPLETED",))
            if res["state"] == "OUTCOME_UNKNOWN":
                self.fail("winner CONFIRMED_APPLIED downgraded by loser")

    def test_13_loser_cannot_flip_attempting_to_unknown_while_owner_live(self):
        import threading, time
        # two remote workers; verifying we never see OUTCOME_UNKNOWN final.
        for _ in range(4):
            res, db, tx = self._race()
            self.assertNotEqual(res["state"], "OUTCOME_UNKNOWN")

    def test_14_same_tx_race_stress_no_unknown_no_double(self, loops=12):
        unknowns = double_writers = double_sync = double_outbox = 0
        for _ in range(loops):
            res, db, tx = self._race()
            if res["state"] == "OUTCOME_UNKNOWN":
                unknowns += 1
            if res["writers"] > 1:
                double_writers += 1
            if res["synx"] > 1:
                double_sync += 1
            if res["pend"] > 0:
                double_outbox += 1
        self.assertEqual(unknowns, 0, "no unknown downgrade in same-tx race")
        self.assertEqual(double_writers, 0, "no double runtime writer")
        self.assertEqual(double_sync, 0, "no double sync")
        self.assertLessEqual(double_outbox, 0, "no duplicate/pending outbox")

    def test_15_no_double_writer(self):
        res, db, tx = self._race()
        self.assertLessEqual(res["writers"], 1)
        self.assertLessEqual(res["ac"], 1)

    def test_16_no_double_sync(self):
        res, db, tx = self._race()
        self.assertLessEqual(res["synx"], 1)

    def test_17_no_duplicate_outbox(self):
        res, db, tx = self._race()
        self.assertLessEqual(res["pend"], 0)

    def test_18_no_unbound_local_error_any_loser_path(self):
        # exercised deterministically: consumed attempt (DuplicateAttempt route).
        db, tx, vendor, runtime = self._mk_result_from_consumed_attempt()
        r = orchestrate(_req(vendor, runtime), db_path=db, tx_id_hint=tx,
                        consequence_plan=_cons())
        self.assertNotEqual(r.status, "EXC")
        # and real concurrent loop above never surfaces UnboundLocalError (res["exc"])
        for _ in range(3):
            res, db2, tx2 = self._race()
            for e in res["exc"]:
                self.assertFalse("UnboundLocalError" in e)


if __name__ == "__main__":
    unittest.main()
