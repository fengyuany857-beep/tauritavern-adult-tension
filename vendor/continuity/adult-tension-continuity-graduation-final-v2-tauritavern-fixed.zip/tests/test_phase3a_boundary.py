"""Phase 3A — static Phase-boundary scan (no runtime mutation machinery present).

Phase 3A executable code (the continuity/transactions package and the prepare
CLI) must NOT contain runtime mutation or outcome-synthesis machinery:
  - os.replace on a runtime file
  - commit_turn CLI invocation (main / write)
  - a runtime-file write (open for 'w' on runtime)
  - tempfile runtime mutation
  - subprocess runtime commit
  - auto Canon promotion / relationship mutation / commitment mutation / thread
    progression / adult permission inference writes
These are architectural (left for Phase 3B/3C) and any presence here is a bug.
"""
from __future__ import annotations
import ast
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TX = Path(ROOT) / "continuity" / "transactions"
CLI = Path(ROOT) / "scripts" / "prepare_transaction.py"


def _executables() -> list[Path]:
    files = [p for p in TX.rglob("*.py") if p.name != "__init__.py"]
    files.append(CLI)
    return files


class PhaseBoundaryScanTests(unittest.TestCase):
    def _tree(self, path: Path):
        return ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

    def _imports(self, path: Path):
        mods = []
        for node in ast.walk(self._tree(path)):
            if isinstance(node, ast.Import):
                for a in node.names:
                    mods.append(a.name)
            elif isinstance(node, ast.ImportFrom):
                for a in node.names:
                    mods.append(a.name)
        return mods

    def _calls(self, path: Path):
        names = []
        for node in ast.walk(self._tree(path)):
            if isinstance(node, ast.Call):
                fn = node.func
                if isinstance(fn, ast.Name):
                    names.append(fn.id)
                elif isinstance(fn, ast.Attribute):
                    names.append(fn.attr)
        return names

    def test_no_forbidden_write_apis(self):
        for path in _executables():
            imports = " ".join(self._imports(path))
            calls = " ".join(self._calls(path))
            self.assertNotIn("commit_turn.module", path.name + " " + imports)
            self.assertNotIn("subprocess", imports, path.name)
            self.assertNotIn("tempfile", imports, path.name)
            self.assertNotIn("mkstemp", calls, path.name)
            self.assertNotIn("write_bytes", calls, path.name)
            self.assertNotIn("write_text", calls, path.name)
            self.assertNotIn("Popen", calls, path.name)

    def test_no_osreplace_call_ast(self):
        for path in _executables():
            found = []
            for node in ast.walk(self._tree(path)):
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) \
                        and node.func.attr == "replace" and isinstance(node.func.value, ast.Name) \
                        and node.func.value.id == "os":
                    found.append(path.name)
            self.assertEqual([], found, f"no os.replace usage in {path.name}")

    def test_cli_never_touches_runtime_write(self):
        # The CLI is the only surface with subprocess-free prepare; ensure no
        # runtime-write call names appear in its body.
        calls = self._calls(CLI)
        for banned in ("replace", "Popen", "commit", "os.replace"):
            self.assertNotIn(banned, calls, CLI.name)

    def test_cli_documentation_is_readonly(self):
        text = CLI.read_text(encoding="utf-8")
        self.assertIn("READ-ONLY", text.upper())
        self.assertIn("no runtime writes", text.lower())


if __name__ == "__main__":
    unittest.main()
