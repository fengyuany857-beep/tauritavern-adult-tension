"""P0-fix round-1 regression tests (Phase 2B-1 P0-1/P0-2/P0-3).

These lock in the fixes for the three independently-gated P0s:
  P0-1 router honours structured turn-absence + explicit textual long-absence;
  P0-2 runtime npcs registry must NOT equal current scene participants;
  P0-3 FAST must scope offscreen canonical facts/commitments/relationships/
       threads by scene/query relevance with an explicit trace.
They are a *superset* of the independent re-gate probes and are written against
the real ContextRouter / ContextPackBuilder / retrieval engines.
"""
from __future__ import annotations
import json
import sqlite3
import sys
import unittest
from pathlib import Path

from continuity.routing import (
    ContextMode, ContextPack, ContextPackBuilder, PackStatus, ContextRouter,
    RoutingRequest,
)
from tests.context_builder_fixture import build_context_base, runtime_state_path


# --------------------------------------------------------------------------- #
# P0-1: router honours structured entity-absence turn gaps + textual long-absence
# --------------------------------------------------------------------------- #
class P0RouterTurnGap(unittest.TestCase):
    def setUp(self):
        self.r = ContextRouter(entity_turn_gap=50, text_absence_min_rounds=30)

    def decision(self, text="", *, event_turn=None, last_seen_turn=None,
                 gap_router=None):
        rr = gap_router or self.r
        return rr.decide_initial(RoutingRequest(
            query_id="p0", raw_text=text, event_turn=event_turn,
            last_seen_turn=last_seen_turn)).final_mode

    # requirement A: structured gap > threshold -> DEEP regardless of wording
    def test_structured_gap_triggers_deep(self):
        self.assertEqual(self.decision("我喝了口水。", event_turn=200, last_seen_turn=120),
                         ContextMode.DEEP)

    # requirement B: small structured gap does NOT trigger DEEP
    def test_small_gap_is_not_deep(self):
        self.assertEqual(self.decision("我喝了口水。", event_turn=200, last_seen_turn=180),
                         ContextMode.FAST)

    # plain current action stays FAST
    def test_ordinary_action_fast(self):
        self.assertEqual(self.decision("我喝了口水。"), ContextMode.FAST)

    # textual long-absence (the literal re-gate adversarial input)
    def test_textual_80_round_absence_is_deep(self):
        self.assertEqual(self.decision("那个八十回合没出现的医生走进来了。"),
                         ContextMode.DEEP)

    # low recent interval (三回合) must stay ordinary
    def test_recent_interval_is_not_deep(self):
        self.assertEqual(self.decision("三回合没出现的同伴进来了。"), ContextMode.FAST)

    # unchanged old recall / exactness behaviours
    def test_recall_coffee_deep_not_evidence(self):
        self.assertEqual(self.decision("她以前是不是说过喜欢咖啡？"), ContextMode.DEEP)
    def test_exact_quote_evidence(self):
        self.assertEqual(self.decision("她上次原话到底是什么？"), ContextMode.EVIDENCE)

    # last_seen with no current turn: no guess
    def test_last_seen_without_current_not_deep(self):
        self.assertEqual(self.decision("我喝了口水。", last_seen_turn=120), ContextMode.FAST)

    # determinism of the new gap path
    def test_gap_path_deterministic(self):
        req = RoutingRequest(query_id="g", raw_text="那个医生回来了",
                             event_turn=200, last_seen_turn=100)
        a = self.r.decide_initial(req).final_mode
        b = self.r.decide_initial(req).final_mode
        self.assertEqual(a, b)


# --------------------------------------------------------------------------- #
# P0-2: runtime npcs registry != scene participants; explicit scene wins
# --------------------------------------------------------------------------- #
def make_runtime_with_extras(base, participants=("E-A", "E-PL"), extra_npcs=("E-OFF", "E-OLD")):
    """A runtime whose current_node.participants == participants but whose
    npcs registry contains many extra NPCs (offscreen / registry-only)."""
    data = {
        "meta": {"turn": 8},
        "world": {"clock": "2026-06-01T00:00:00+00:00"},
        "current_node": {"scene_id": "SC-3", "participants": list(participants)},
        "player": {"id": "E-PL", "knowledge": []},
        "npcs": [{"id": p, "knowledge": [], "recent_memories": []}
                 for p in participants if p != "E-PL"]
                + [{"id": n, "knowledge": [], "recent_memories": []} for n in extra_npcs]
                + [{"id": "E-UNTOUCHED", "knowledge": [], "recent_memories": []}],
        "relationships": [], "consent": {"grants": []}, "boundaries": [],
        "checkpoint": {},
    }
    p = base / "state" / "rt_extras.json"
    p.write_text(json.dumps(data, sort_keys=True), encoding="utf-8")
    return p


class P0ParticipantScope(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base = build_context_base()
        self.addCleanup(self.tmp.cleanup)

    def _builder(self, *, observer="E-A", scene=("E-A", "E-PL"),
                 runtime=None, text="我喝了口水", detected=()):
        return ContextPackBuilder(self.base).build(
            RoutingRequest(query_id="p0", raw_text=text, observer_entity_id=observer,
                           scene_entity_ids=tuple(scene)),
            runtime_state=runtime, detected_entities=tuple(detected))

    def test_npcs_registry_not_scene(self):
        rt = make_runtime_with_extras(self.base)   # current_node= E-A,E-PL
        # no explicit scene on request -> runtime roster (E-A, E-PL) used only
        p = ContextPackBuilder(self.base).build(
            RoutingRequest(query_id="x", raw_text="我喝了口水", observer_entity_id="E-A"),
            runtime_state=rt)
        # registry-only E-UNTOUCHED / E-OFF / E-OLD must NOT become HOT participants
        ent = [i.source_ref for i in p.items if i.source_type == "ENTITY"]
        self.assertNotIn("E-UNTOUCHED", ent)
        self.assertNotIn("E-OFF", ent)
        self.assertNotIn("E-OLD", ent)

    def test_explicit_scene_wins_over_npc_registry(self):
        rt = make_runtime_with_extras(self.base)
        # explicit scene has ONLY E-A -> E-OLD not treated as scene participant
        p = self._builder(scene=("E-A",), runtime=rt)
        ent = {i.source_ref for i in p.items if i.source_type == "ENTITY"}
        self.assertNotIn("E-OLD", ent)
        self.assertNotIn("E-UNTOUCHED", ent)

    def test_missing_participants_no_fallback_to_all_npcs(self):
        # runtime snapshot missing current_node entirely
        data = {"meta": {"turn": 8}, "player": {"id": "E-PL"},
                "npcs": [{"id": "E-A"}, {"id": "E-OFF"}, {"id": "E-OLD"}]}
        pth = self.base / "state" / "rt_noparticipants.json"
        pth.write_text(json.dumps(data), encoding="utf-8")
        p = ContextPackBuilder(self.base).build(
            RoutingRequest(query_id="x", raw_text="我喝了口水",
                           observer_entity_id="E-A"), runtime_state=pth)
        ent = {i.source_ref for i in p.items if i.source_type == "ENTITY"}
        # without a participant list we fail closed: registry NPCs are not HOT
        self.assertNotIn("E-OFF", ent)
        self.assertNotIn("E-OLD", ent)
        self.assertNotIn("E-A", ent)  # no authoritative roster at all


# --------------------------------------------------------------------------- #
# P0-3: FAST scope offscreen canonical leakage with explicit trace
# --------------------------------------------------------------------------- #
CON = "state/continuity.sqlite3"


def _add_rows(base):
    """Add explicitly-remote relationship / commitment / thread rows involving
    two offscreen NPCs (E-OFF & E-OLD) that MUST NOT leak into a FAST pack for a
    scene of {E-A, E-PL}, plus one on-scene thread that stays."""
    con = sqlite3.connect(str(base / CON))
    cur = con.cursor()
    # remote relationship E-OFF <-> E-OLD (both offscreen)
    cur.execute("INSERT INTO relationships (relationship_id,branch_id,source_ref,target_ref,"
                "runtime_refs_json,public_surface,actual_relation,phase,provenance_json) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                ("REL-REMO", "default", "E-OFF", "E-OLD", "[]", "warm", "allies",
                 "rival", "{}"))
    # remote commitment E-OFF -> E-OLD (offscreen->offscreen) due
    cur.execute("INSERT INTO commitments (commitment_id,branch_id,kind,issuer_ref,"
                "beneficiary_refs_json,content,status,runtime_event_ref,provenance_json) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                ("COM-REMO", "default", "promise", "E-OFF", '["E-OLD"]',
                 "prosecute the old debt", "open", None, "{}"))
    # remote thread with no guard/reveal on scene and no participant link
    cur.execute("INSERT INTO threads (thread_id,branch_id,status,author_state,objective_state,"
                "player_visible_state,reveal_gate_json,presentation_json,provenance_json) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                ("TH-REMO", "default", "active", "a", "remote vault plot", "p",
                 "{}", "{}", "{}"))
    # one *on-scene* relationship already in the SDK fixture (E-A <-> E-PL):
    # REL-A exists in build_context_base.  Leave.
    con.commit()
    con.close()


class P0OffscreenScope(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base = build_context_base()
        self.addCleanup(self.tmp.cleanup)
        _add_rows(self.base)

    def _build(self, *, text="我喝了口水", observer="E-A", scene=("E-A", "E-PL"),
               mode=None):
        req = RoutingRequest(query_id="p0", raw_text=text, observer_entity_id=observer,
                             scene_entity_ids=tuple(scene), mode_override=mode)
        return ContextPackBuilder(self.base).build(req)

    def _content(self, p):
        return " ".join(i.content for i in p.items)

    # offscreen NPC fact excluded from FAST
    def test_offscreen_fact_excluded_fast(self):
        p = self._build()
        self.assertEqual(p.final_mode, ContextMode.FAST)
        # SDK canonical fact for E-OFF has object {"site": "vault"}
        self.assertNotIn("vault", self._content(p))
        self.assertNotIn("F-OFF", self._content(p))
        reasons = {d.reason for d in p.scope_drops}
        self.assertTrue(reasons & {"FAST_SCOPE_OFFSCREEN", "FAST_SCOPE_UNRELATED_ENTITY"})

    # offscreen NPC commitment excluded from FAST
    def test_offscreen_commitment_excluded_fast(self):
        p = self._build()
        self.assertNotIn("COM-REMO", self._content(p))
        self.assertNotIn("prosecute the old debt", self._content(p))

    # offscreen NPC relationship excluded from FAST
    def test_offscreen_relationship_excluded_fast(self):
        # REL-REMO (E-OFF <-> E-OLD) is created in this setUp; with an on-scene
        # observer for {E-A,E-PL}, that pair is entirely offscene and must stay
        # out of the FAST pack.
        p = self._build()
        self.assertNotIn("REL-REMO", self._content(p))
        self.assertNotIn("E-OFF->E-OLD", self._content(p).replace("relationship ", ""))

    # offscreen thread excluded from FAST
    def test_offscreen_thread_excluded_fast(self):
        p = self._build()
        self.assertNotIn("TH-REMO", self._content(p))
        self.assertNotIn("remote vault plot", self._content(p))

    # participant-related fact included FAST
    def test_participant_related_fact_included_fast(self):
        p = self._build()
        self.assertIn("E-A works", self._content(p))    # SDK F-EA-CANON (subject E-A)

    # participant-related due commitment included FAST
    def test_participant_due_commitment_included(self):
        p = self._build()
        cms = [i for i in p.items if i.source_type == "COMMITMENT"]
        cm_ids = {i.source_ref for i in cms}
        self.assertIn("COM-A", cm_ids)          # E-A -> E-PL open promise kept
        self.assertNotIn("COM-REMO", cm_ids)    # E-OFF -> E-OLD remote kept out

    # FAST trace explicit for excluded item
    def test_fast_exclusion_trace_explicit(self):
        p = self._build()
        drops = {d.source_ref: d.reason for d in p.scope_drops}
        # the SDK off-screen NPC's canonical fact F-OFF must be traced, not silent
        self.assertIn(drops.get("F-OFF"), ("FAST_SCOPE_OFFSCREEN", "FAST_SCOPE_UNRELATED_ENTITY"))

    # old NPC mention routes DEEP and relevant context becomes available
    def test_old_mention_deep_loads_context(self):
        p = self._build(text="那个很久没见的 E-OFF 回来了，他守的地方最近怎样？")
        self.assertEqual(p.final_mode, ContextMode.DEEP)   # recall/return -> DEEP
        content = self._content(p)
        self.assertIn("E-OFF", content)   # E-OFF can re-enter under DEEP recall

    # DEEP still keeps broad recall (not over-scoped by the FAST filter)
    def test_deep_keeps_broader_recall(self):
        p_fast = self._build(text="我喝了口水.")
        p_deep = self._build(text="那个很久没见的医生回来了。")
        self.assertEqual(p_fast.final_mode, ContextMode.FAST)
        self.assertEqual(p_deep.final_mode, ContextMode.DEEP)
        # DEEP is not filtered by the FAST relevance scope
        self.assertGreaterEqual(len(p_deep.items), len(p_fast.items))

    # global facts do not trigger a full canon dump in FAST (regression):
    # only scene-relevant objective facts may enter; offscreen must not.
    def test_no_full_canon_dump_fast(self):
        p = self._build()
        con = sqlite3.connect(str(self.base / CON))
        con.row_factory = sqlite3.Row
        facts = [i for i in p.items if i.source_type == "FACT"]
        self.assertTrue(facts)
        for i in facts:
            row = con.execute(
                "SELECT subject_ref FROM facts WHERE fact_id=? AND branch_id=?",
                (i.source_ref, "default")).fetchone()
            self.assertIsNotNone(row, i.source_ref)
            self.assertIn(row["subject_ref"], {"E-A", "E-PL"},
                          f"{i.source_ref}: offscreen subject {row['subject_ref']} in FAST")
        con.close()
        # confirm the known-offscreen fact was shut out with a trace
        reasons = {d.reason for d in p.scope_drops if d.source_ref == "F-OFF"}
        self.assertTrue(reasons & {"FAST_SCOPE_OFFSCREEN", "FAST_SCOPE_UNRELATED_ENTITY"})

    # offscreen NPC card does not become a HOT item in FAST
    def test_offscreen_npc_card_not_hot_fast(self):
        p = self._build()
        hot = {i.source_ref for i in p.items if i.residency == "HOT"}
        self.assertNotIn("E-OFF", hot)
        self.assertNotIn("E-OLD", hot)

    # no authority mutation through all these FAST/DEEP builds
    def test_no_authority_mutation(self):
        def snap():
            con = sqlite3.connect(str(self.base / CON))
            con.row_factory = sqlite3.Row
            dct = {}
            for t in ("entities", "facts", "knowledge", "relationships",
                      "relationship_dimensions", "commitments", "threads",
                      "thread_requires", "thread_anti_merge", "thread_links",
                      "episodes", "continuity_transactions",
                      "admission_candidates", "admission_decisions"):
                dct[t] = [dict(r) for r in con.execute(f"SELECT * FROM {t}")]
            con.close()
            return dct
        before = snap()
        self._build(text="我喝了口水")
        self._build(text="那个很久没见的医生回来了")
        after = snap()
        for t in before:
            self.assertEqual(before[t], after[t], t)


if __name__ == "__main__":
    unittest.main()
