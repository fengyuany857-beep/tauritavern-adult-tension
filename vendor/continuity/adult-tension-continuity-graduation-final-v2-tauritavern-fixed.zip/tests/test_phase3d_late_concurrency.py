"""Phase 3D — late-recovery + concurrent/re-entry orchestration (§44, §27).

Demonstrates that recovery of an *applied-but-unsynced* tx works even when the
runtime has since advanced to a later turn (no runtime equality required): the
sidecar uses only the durable immediate post evidence captured at the crash
window, never the current runtime bytes.

Also asserts two Orchestrator calls on the SAME tx never produce a second runtime
attempt (attempt stays 1) — the atomic attempt reservation and durable-state
re-entry guarantee single-attempt even under concurrent/re-issued calls.
"""
from __future__ import annotations
import sqlite3
import sys
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3b_fixture import make_disposable_vendor, simple_patch, \
    current_bytes, runtime_path_of
from tests.phase3d_fixture import sample_consequences, seed_disposable_db
from continuity.orchestration import orchestrate, \
    recover_orchestration, orchestration_status
from continuity.orchestration.contracts import (
    OrchestrationRequest, ConsequencePlan, OrchestrationStatus,
)
from continuity.transactions.preconditions import prepare_transaction
from continuity.runtime3b.execute import commit_single_file


def _cons():
    return ConsequencePlan(consequences=sample_consequences())


def _req(vendor, runtime):
    return OrchestrationRequest(patch=simple_patch(), vendor_dir=str(vendor),
                                runtime_path=str(runtime), consequence_plan=_cons())


def _db_of(root):
    return seed_disposable_db(root)


class Phase3dLateConcurrencyTest(unittest.TestCase):
    def test44_late_recovery_after_runtime_advanced(self):
        """A tx applied (but not synced) is recovered AFTER the runtime advanced:
        no runtime rollback / equality, sidecar uses durable post evidence."""
        root, vendor, runtime = make_disposable_vendor()
        db = _db_of(root)

        # tx A: prepare + single-file commit on the disposable runtime -> applied
        con = sqlite3.connect(str(db)); con.close()
        from continuity.transactions.preconditions import new_tx_id
        from continuity.orchestration.orchestrator import _validate_and_digest_plan
        tx_a = new_tx_id()
        peA = prepare_transaction(
            vendor_dir=vendor, db_path=db, runtime_path=runtime,
            patch=simple_patch(), tx_id=tx_a,
            staged_sync_digest=_validate_and_digest_plan(tx_a, "default", _cons()))
        envA = commit_single_file(db_path=db, vendor_dir=vendor, runtime_path=runtime,
                                  tx_id=peA.continuity_tx_id, patch=simple_patch())
        postA = current_bytes(vendor)
        rowA = _row(db, peA.continuity_tx_id)
        self.assertIn(rowA["state"], ("DURABILITY_PENDING", "CONFIRMED_APPLIED"))

        # runtime advances to a LATER turn through a legitimate NEW tx B
        tx_b = new_tx_id()
        peB = prepare_transaction(
            vendor_dir=vendor, db_path=db, runtime_path=runtime,
            patch=simple_patch(), tx_id=tx_b,
            staged_sync_digest=_validate_and_digest_plan(tx_b, "default", _cons()))
        commit_single_file(db_path=db, vendor_dir=vendor, runtime_path=runtime,
                           tx_id=peB.continuity_tx_id, patch=simple_patch())
        postB = current_bytes(vendor)
        self.assertNotEqual(postA, postB, "runtime advanced to a later state")

        # recover OLD tx A (unsynced) -> sidecar finalises from durable post evid.
        rec = recover_orchestration(db_path=db, tx_id=peA.continuity_tx_id,
                                    consequence_plan=_cons())
        self.assertEqual(rec.status, OrchestrationStatus.COMPLETED.value)
        # runtime must be UNTOUCHED by recovery of A (still B content)
        self.assertEqual(current_bytes(vendor), postB,
                         "recovery of an old tx must not roll back / rewrite runtime")

    def test_same_tx_two_orchestrate_calls_single_attempt(self):
        """Re-issuing orchestrate on the same tx never yields a second attempt."""
        root, vendor, runtime = make_disposable_vendor()
        db = _db_of(root)
        out1 = orchestrate(_req(vendor, runtime), db_path=db)
        self.assertEqual(out1.status, OrchestrationStatus.COMPLETED.value)
        ac = dict(_row(db, out1.continuity_tx_id))
        con = sqlite3.connect(str(db))
        ac2 = con.execute("SELECT attempt_count FROM transaction_journal "
                          "WHERE continuity_tx_id=?",
                          (out1.continuity_tx_id,)).fetchone()[0]
        con.close()
        self.assertEqual(int(ac2), 1)
        # concurrent-ish second full run (fresh root impossible same tx) -> terminal no-op
        for _ in range(2):
            r2 = recover_orchestration(db_path=db, tx_id=out1.continuity_tx_id,
                                       consequence_plan=_cons())
            self.assertEqual(r2.status, OrchestrationStatus.COMPLETED.value)

    def test27_same_tx_two_concurrent_orchestrators_single_attempt(self):
        """Two orchestrators racing on the same CONTINUITY_TX_ID: no duplicate
        runtime attempt (attempt_count==1) and no double sync."""
        import threading
        import concurrent.futures as cf
        root, vendor, runtime = make_disposable_vendor()
        db = _db_of(root)
        req = _req(vendor, runtime)
        # Pre-create the tx so both workers race on the SAME id from PREPARED.
        from continuity.transactions.preconditions import prepare_transaction
        from continuity.transactions.preconditions import new_tx_id
        from continuity.orchestration.orchestrator import _validate_and_digest_plan
        tx_id = new_tx_id()
        pe = prepare_transaction(
            vendor_dir=vendor, db_path=db, runtime_path=runtime,
            patch=simple_patch(), tx_id=tx_id,
            staged_sync_digest=_validate_and_digest_plan(tx_id, "default", _cons()))
        results = {}

        def work():
            try:
                r = orchestrate(_req(vendor, runtime), db_path=db,
                                tx_id_hint=tx_id, consequence_plan=_cons())
                return ("result", r.status, bool(r.writer_invoked))
            except Exception as exc:  # a loser may surface a safe DB conflict
                return ("conflict", exc.__class__.__name__, False)

        with cf.ThreadPoolExecutor(max_workers=2) as ex:
            futs = [ex.submit(work), ex.submit(work)]
            outs = [f.result(timeout=240) for f in futs]
        con = sqlite3.connect(str(db))
        ac = con.execute("SELECT attempt_count FROM transaction_journal "
                         "WHERE continuity_tx_id=?", (tx_id,)).fetchone()[0]
        synx = con.execute("SELECT COUNT(*) FROM continuity_sync_executions "
                           "WHERE continuity_tx_id=?", (tx_id,)).fetchone()[0]
        con.close()
        self.assertEqual(int(ac), 1, "exactly one runtime attempt despite concurrency")
        self.assertEqual(int(synx), 1, "continuity sync ran logically once")
        # exactly one of the racing calls may report writer_invoked=True; the
        # other must be a safe non-write (NOT_ELIGIBLE/conflict), never two writers.
        writers = sum(1 for o in outs if o and o[0] == "result" and o[2])
        completed = sum(1 for o in outs if o and o[0] == "result" and o[1] == "COMPLETED")
        self.assertLessEqual(writers, 1, "never two runtime writers for one tx")
        self.assertGreaterEqual(completed, 1, "at least one caller sees COMPLETED")

    def test_recover_unknown_requires_new_tx(self):
        from tests.phase3d_fixture import build_journal_state
        root, vendor, runtime = make_disposable_vendor()
        db = _db_of(root)
        _, _, _, tx = build_journal_state(vendor=vendor, db=db, runtime=runtime,
                                          state="OUTCOME_UNKNOWN")
        out = recover_orchestration(db_path=db, tx_id=tx, consequence_plan=_cons())
        self.assertTrue(out.manual_review_required)
        self.assertTrue(out.retry_requires_new_tx)


def _row(db, tx):
    con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
    r = con.execute("SELECT * FROM transaction_journal WHERE continuity_tx_id=?",
                    (tx,)).fetchone()
    con.close()
    return dict(r) if r else {}


if __name__ == "__main__":
    unittest.main()
