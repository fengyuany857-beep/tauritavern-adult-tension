import sqlite3, unittest
from continuity.constants import Plane, AdmissionState, TruthStatus
from continuity.errors import AuthorityError
from continuity.models import FactInput
from continuity.validation import insert_fact
from util import tmpdb
class T(unittest.TestCase):
 def test_high_trust_attraction_has_no_permission_write_path(self):
  d,c=tmpdb(); self.addCleanup(d.cleanup)
  c.execute("insert into relationships (relationship_id,branch_id,source_ref,target_ref,runtime_refs_json,public_surface,actual_relation,phase,provenance_json) values('R','default','E1','E2','[]','high','high','phase','{}')")
  c.execute("insert into relationship_dimensions values('D','R','trust','\"high\"','AUTHORITY')")
  c.execute("insert into relationship_dimensions values('A','R','attraction','\"high\"','AUTHORITY')")
  for predicate in ('consent.current','consent.grants','grant.current','boundary.current','safety.current','sexuality_profile.current','intimacy.permission'):
   f=FactInput('F-'+predicate,'E1',predicate,'{}',Plane.OBJECTIVE,AdmissionState.COMMITTED,TruthStatus.ACTIVE,1,None,1,'{"source":"relationship"}')
   with self.assertRaises(AuthorityError): insert_fact(c,f)
  self.assertEqual(0,c.execute("select count(*) from facts").fetchone()[0])
 def test_historical_reference_not_current_permission(self):
  d,c=tmpdb(); self.addCleanup(d.cleanup)
  c.execute("insert into relationships (relationship_id,branch_id,source_ref,target_ref,runtime_refs_json,public_surface,actual_relation,phase,provenance_json) values('R','default','E1','E2','[{\"kind\":\"historical_consent\",\"ref\":\"EP-1\"}]','high','high','phase','{}')")
  self.assertEqual(0,c.execute("select count(*) from facts where predicate like 'consent.%' or predicate like 'intimacy.%'").fetchone()[0])
