"""P0 regression: objective-fact record-time (as_known_at) bitemporal visibility.

Core rule under test:
    Objective facts must be gated by recorded_at_turn <= as_known_at whenever the
    query supplies as_known_at.  This gate is INDEPENDENT of event validity
    (valid_from..invalid_at).  In particular it must NOT become
    recorded_at_turn <= as_of_event, which would wrongly hide retrospectively
    recorded facts from a world-time query made after they became known.

Facts route through the shared hard-filter pipeline (Temporal / Lexical / Ledger
so HybridRetriever too), so the gate lives in apply_hard_filters and every path
that could surface a FACT enforces it.
"""
from __future__ import annotations
import json
import tempfile
import unittest
from pathlib import Path

from continuity.db import connect
from continuity.retrieval import (
    Context, HybridRetriever, LedgerRetriever, LexicalRetriever,
    RetrievalQuery, TemporalRetriever,
)
from tests.retrieval_seed import open_ctx


def build_fixture() -> tuple[tempfile.TemporaryDirectory, Path]:
    """Minimal self-contained fixture around the one P0 example fact (F-RETRO)
    plus neighbours needed to prove we did not regress event-validity,
    supersession, wrong-branch and character-knowledge behaviour."""
    tmp = tempfile.TemporaryDirectory()
    base = Path(tmp.name)
    (base / "state").mkdir()
    (base / "indexes").mkdir()
    (base / "manifests").mkdir()
    conn = connect(base / "state" / "continuity.sqlite3")
    cur = conn.cursor()

    def fact(fid, branch, truth, vf, inv, rec):
        cur.execute(
            "INSERT INTO facts (fact_id,branch_id,subject_ref,predicate,object_json,plane,admission_state,truth_status,"
            "valid_from_turn,invalid_at_turn,recorded_at_turn,recorded_at,provenance_json,classification) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (fid, branch, "E-C", "holds", json.dumps({"v": 1}), "OBJECTIVE", "COMMITTED", truth,
             vf, inv, rec, "2026-01-01T00:00:00+00:00", json.dumps({"source": "f"}),
             "AUTHORITY" if truth != "SUPERSEDED" else "AUTHORITY_REFERENCE"))

    # The P0 example: world-true from 120, but only recorded at 500.
    fact("F-RETRO", "default", "ACTIVE", 120, None, 500)
    # Finite world interval, still retrospectively recorded: valid 120..300 rec 500.
    fact("F-FIN", "default", "ACTIVE", 120, 300, 500)
    # Same interval form as F-RETRO for the world-validity / record-separation pair.
    fact("F-SINGLE", "default", "ACTIVE", 120, None, 500)
    # Current, recorded early (control that should always show while valid).
    fact("F-EARLY", "default", "ACTIVE", 1, None, 1)
    # Superseded lineage so T8 can prove the gate does not bypass supersession.
    fact("F-SUP", "default", "SUPERSEDED", 1, 30, 30)
    fact("F-SUP2", "default", "ACTIVE", 30, None, 30)
    # Wrong branch control (T9).
    fact("F-ALT", "alt", "ACTIVE", 1, None, 1)

    # Character knowledge uses its own turn (record/promotion) semantics.
    def know(kid, subject, state, turn):
        cur.execute(
            "INSERT INTO knowledge (knowledge_id,branch_id,subject_ref,proposition_ref,state,plane,source,promotion_basis,turn,provenance_json) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (kid, "default", subject, f"PROP-{kid}", state, "CHARACTER", "witnessed", "witnessed", turn, "{}"))

    know("K-NOW", "E-C", "knows", 100)        # current knowledge, recorded turn 100
    know("K-FUT", "E-C", "knows", 400)        # promoted turn 400 -> future at ak=200 (T6)
    know("K-FBFUT", "E-C", "false_belief", 400)  # future false belief (T7)
    conn.commit()
    conn.close()
    return tmp, base


class T(unittest.TestCase):
    def setUp(self):
        self.tmp, base = build_fixture()
        self.addCleanup(self.tmp.cleanup)
        self.ctx = open_ctx(base)
        self.temporal = TemporalRetriever()
        self.hybrid = HybridRetriever([TemporalRetriever(), LexicalRetriever(), LedgerRetriever()])

    def fact_ids(self, retriever, query) -> list[str]:
        return [i.item_id for i in retriever.retrieve(query, self.ctx).items]

    def included(self, retriever, qk: str, fid: str, **kw) -> bool:
        q = RetrievalQuery(query_id=qk, **kw)
        ids = self.fact_ids(retriever, q)
        return fid in ids

    def traces_for(self, retriever, qk: str, fid: str, **kw):
        r = retriever.retrieve(RetrievalQuery(query_id=qk, **kw), self.ctx)
        return [tr for tr in r.traces if tr.candidate_item_id == fid]

    # ---- T1 / T2 : the exact P0 example --------------------------------
    def test_T1_fact_recorded_after_but_knowable_later_is_included(self):
        # valid_from=120 recorded_at=500 ; as_of_event=200 as_known_at=600 -> INCLUDED
        self.assertTrue(self.included(self.temporal, "T1", "F-RETRO", event_turn=200, as_known_at=600))

    def test_T2_fact_not_yet_recorded_at_as_known_is_excluded_with_clear_trace(self):
        # valid_from=120 recorded_at=500 ; as_of_event=200 as_known_at=200 -> EXCLUDED
        self.assertFalse(self.included(self.temporal, "T2", "F-RETRO", event_turn=200, as_known_at=200))
        tr = self.traces_for(self.temporal, "T2", "F-RETRO", event_turn=200, as_known_at=200)
        self.assertTrue(tr and all(not t.included for t in tr), "FACT-RETRO must be hard-excluded")
        # the trace must name the transaction/record-time gate, not a vague mismatch
        self.assertTrue(any("recorded" in (t.exclusion_reason or "") for t in tr))
        self.assertTrue(any("recorded_visibility" in (t.filters_applied) for t in tr))

    # ---- T3 : event validity, not record time --------------------------
    def test_T3_event_validity_not_started_excludes_even_with_later_known(self):
        # as_of_event=100 (< valid_from=120) and as_known_at=600 -> EXCLUDED (never valid at 100)
        self.assertFalse(self.included(self.temporal, "T3", "F-SINGLE", event_turn=100, as_known_at=600))
        self.assertFalse(self.included(self.temporal, "T3", "F-RETRO", event_turn=100, as_known_at=600))

    def test_T3b_same_question_but_world_valid_sees_it(self):
        # sanity: identical record-window but event turn inside validity -> INCLUDED
        self.assertTrue(self.included(self.temporal, "T3b", "F-SINGLE", event_turn=200, as_known_at=600))

    # ---- T4 / T5 : finite world interval closed before as_known_at ------
    def test_T4_fact_invalidated_excluded_at_later_event(self):
        # F-FIN valid 120..300 recorded 500 ; as_of_event=350 as_known_at=600 -> EXCLUDED (already invalid in-world)
        self.assertFalse(self.included(self.temporal, "T4", "F-FIN", event_turn=350, as_known_at=600))

    def test_T5_fact_inside_finite_interval_included(self):
        # as_of_event=200 as_known_at=600 -> INCLUDED (both valid in-world and recorded)
        self.assertTrue(self.included(self.temporal, "T5", "F-FIN", event_turn=200, as_known_at=600))

    # ---- T6 / T7 : character knowledge gates intact ---------------------
    def test_T6_character_future_knowledge_remains_excluded(self):
        got = self.fact_ids(self.temporal, RetrievalQuery(event_turn=200, as_known_at=200, observer_entity_id="E-C", query_id="T6"))
        self.assertNotIn("K-FUT", got)  # promotion turn 400 > as_known_at 200
        got_later = self.fact_ids(self.temporal, RetrievalQuery(event_turn=450, as_known_at=450, observer_entity_id="E-C", query_id="T6b"))
        self.assertIn("K-FUT", got_later)

    def test_T7_future_false_belief_does_not_leak_character_plane(self):
        got_early = self.fact_ids(self.temporal, RetrievalQuery(event_turn=200, as_known_at=200, observer_entity_id="E-C", query_id="T7"))
        self.assertNotIn("K-FBFUT", got_early)          # promoted turn 400 still in the future
        got_later = self.fact_ids(self.temporal, RetrievalQuery(event_turn=450, as_known_at=450, observer_entity_id="E-C", query_id="T7b"))
        self.assertIn("K-FBFUT", got_later)             # becomes knowable once observed

    # ---- T8 : supersession is not bypassed by the recorded gate ----------
    def test_T8_superseded_still_excluded_under_current_query(self):
        got = self.fact_ids(self.temporal, RetrievalQuery(event_turn=30, as_known_at=600, query_id="T8"))
        self.assertNotIn("F-SUP", got)                  # SUPERSEDED excluded even if recorded <= known
        self.assertIn("F-SUP2", got)

    # ---- T9 : wrong branch stays excluded --------------------------------
    def test_T9_wrong_branch_still_excluded(self):
        got = self.fact_ids(self.temporal, RetrievalQuery(event_turn=1, as_known_at=600, query_id="T9"))
        self.assertNotIn("F-ALT", got)

    # ---- T10 : hybrid cannot resurrect a hard-filtered fact --------------
    def test_T10_hybrid_cannot_resurrect_not_yet_recorded_fact(self):
        got = self.fact_ids(self.hybrid, RetrievalQuery(raw_text="holds", event_turn=200, as_known_at=200, observer_entity_id="E-C", query_id="T10"))
        self.assertNotIn("F-RETRO", got)
        # ... yet IS reachable once known.
        got_later = self.fact_ids(self.hybrid, RetrievalQuery(raw_text="holds", event_turn=200, as_known_at=600, observer_entity_id="E-C", query_id="T10b"))
        self.assertIn("F-RETRO", got_later)

    # ---- as_known_at=None keeps unfrozen (no row-time gate) default ------
    def test_no_as_known_at_leaves_record_time_open(self):
        self.assertTrue(self.included(self.temporal, "NAK", "F-RETRO", event_turn=200))


if __name__ == "__main__":
    unittest.main()
