import unittest
from continuity.constants import *
from continuity.validation import add_knowledge
from continuity.errors import ValidationError
from util import tmpdb
class T(unittest.TestCase):
 def test_absence_not_does_not_know(self):
  d,c=tmpdb();self.addCleanup(d.cleanup);self.assertEqual(0,c.execute('select count(*) from knowledge').fetchone()[0])
 def test_suspects_requires_real_basis(self):
  d,c=tmpdb();self.addCleanup(d.cleanup);add_knowledge(c,knowledge_id='K1',subject_ref='E',proposition_ref='P',state=KnowledgeState.SUSPECTS,source='s',promotion_basis='witnessed',turn=1,provenance={'e':1})
  with self.assertRaises(ValidationError):add_knowledge(c,knowledge_id='K2',subject_ref='E',proposition_ref='P',state=KnowledgeState.KNOWS,source='s',promotion_basis='automatic',turn=2,provenance={'e':2},previous=KnowledgeState.SUSPECTS)
 def test_player_visible_not_character(self):
  d,c=tmpdb();self.addCleanup(d.cleanup);add_knowledge(c,knowledge_id='K',subject_ref='player',proposition_ref='P',state=KnowledgeState.KNOWS,source='shown',promotion_basis='shown',turn=1,provenance={'x':1},plane=Plane.PLAYER_VISIBLE);self.assertEqual('PLAYER_VISIBLE',c.execute('select plane from knowledge').fetchone()[0])
