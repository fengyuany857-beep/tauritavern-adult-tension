import sys,tempfile,json
from pathlib import Path
ROOT=Path(__file__).parents[1]; sys.path.insert(0,str(ROOT))
def tmpdb():
 from continuity.db import connect
 d=tempfile.TemporaryDirectory(); return d,connect(Path(d.name)/'db.sqlite3')
def runtime_state(): return {'meta':{'turn':1},'world':{'clock':'2026-01-01T00:00:00+00:00'},'current_node':{'scene_id':'scene-001','participants':['player-001']},'player':{'id':'player-001','knowledge':[]},'npcs':[{'id':'npc-002','name':'Same','role_level':'important_supporting','knowledge':[],'recent_memories':[]}],'relationships':[],'events':[],'boundaries':[],'consent':{'grants':[]},'checkpoint':{}}
def fixture(path): path.write_text(json.dumps(runtime_state(),sort_keys=True),encoding='utf-8')
