"""Phase 3D — path/crash-window disposition and fail-closed tests
(§12-14, §15-20, §39, §40, §41, §24 status) .

Builds a real disposable PREPARED transaction and then, in several ways, shows
how the Orchestrator classifies each crash/durable window:
  - PRECONDITION_FAILED (external writer changed bytes before commit): writer=0;
  - OUTCOME_UNKNOWN                 -> no sync, manual, no same-tx retry;
  - CONCURRENT_DIVERGENCE            -> no sync, manual, no same-tx retry;
  - CONFIRMED_NOT_APPLIED            -> no sync, terminal (aborted-not-attempted?);
  - RUNTIME_ATTEMPTING (F3-F6 crash) -> manual, no auto-retry;
  - COMPLETED                        -> re-entry no-op.
"""
from __future__ import annotations
import sqlite3
import sys
import unittest
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from tests.phase3b_fixture import make_disposable_vendor, simple_patch, \
    current_bytes, runtime_path_of
from tests.phase3d_fixture import build_journal_state, sample_consequences, seed_disposable_db
from continuity.orchestration import orchestrate, orchestration_status, \
    recover_orchestration, scan_recoverable
from continuity.orchestration.contracts import (
    OrchestrationRequest, ConsequencePlan, OrchestrationStatus,
)

ROOT = Path(__file__).resolve().parents[1]


def _disposable():
    """A disposable vendor + db with an empty phase-3 DB."""
    import tempfile
    root, vendor, runtime = make_disposable_vendor()
    db = seed_disposable_db(root)
    db.parent.mkdir(parents=True, exist_ok=True)
    from continuity.migrations import migrate
    return root, vendor, runtime, db


def _cons():
    return ConsequencePlan(consequences=sample_consequences())


def _req(vendor, runtime, patch=None):
    return OrchestrationRequest(
        patch=patch or simple_patch(), vendor_dir=str(vendor),
        runtime_path=str(runtime), consequence_plan=_cons())


def _state(db, tx):
    con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
    row = con.execute("SELECT state, attempt_count, runtime_outcome_class, "
                      "continuity_sync_state FROM transaction_journal "
                      "WHERE continuity_tx_id=?", (tx,)).fetchone()
    con.close()
    return dict(row) if row else None


class Phase3dCrashWindowTest(unittest.TestCase):
    def test20_precondition_fail_writer_zero(self):
        """External writer changes bytes before commit => PRECONDITION_FAILED,
        writer invocation = 0, attempt stays 0, no sync."""
        root, vendor, runtime, db = _disposable()
        con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
        from continuity.transactions.preconditions import prepare_transaction, new_tx_id
        from continuity.orchestration.orchestrator import _validate_and_digest_plan
        tx_id = new_tx_id()
        pe = prepare_transaction(
            vendor_dir=vendor, db_path=db, runtime_path=runtime,
            patch=simple_patch(), tx_id=tx_id,
            staged_sync_digest=_validate_and_digest_plan(tx_id, "default", _cons()))
        # external writer mutates runtime bytes AFTER prepare
        cap = runtime.read_bytes() + b"# external-drift\n"
        runtime.write_bytes(cap)
        out = orchestrate(_req(vendor, runtime), db_path=db,
                          tx_id_hint=pe.continuity_tx_id, consequence_plan=_cons())
        self.assertEqual(out.status, OrchestrationStatus.PRECONDITION_FAILED.value)
        self.assertFalse(out.writer_invoked)
        self.assertFalse(out.runtime_attempted)
        st = _state(db, pe.continuity_tx_id)
        self.assertEqual(st["state"], "PRECONDITION_FAILED")
        self.assertEqual(st["attempt_count"], 0)

    def test_unknown_no_sync_manual(self):
        root, vendor, runtime, db = _disposable()
        _, _, _, tx = build_journal_state(vendor=vendor, db=db, runtime=runtime,
                                          state="OUTCOME_UNKNOWN")
        out = orchestrate(_req(vendor, runtime), db_path=db, tx_id_hint=tx,
                          consequence_plan=_cons())
        self.assertEqual(out.status, OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value)
        self.assertTrue(out.manual_review_required)
        self.assertTrue(out.retry_requires_new_tx)
        # durable must show no history sync rows created for an unknown outcome
        con = sqlite3.connect(str(db))
        n = con.execute("SELECT COUNT(*) c FROM continuity_effect_markers "
                        "WHERE continuity_tx_id=?", (tx,)).fetchone()[0]
        m = con.execute("SELECT COUNT(*) c FROM continuity_sync_executions "
                        "WHERE continuity_tx_id=?", (tx,)).fetchone()[0]
        con.close()
        self.assertEqual(int(n) + int(m), 0, "UNKNOWN must never sync historical effects")

    def test_divergence_no_sync(self):
        root, vendor, runtime, db = _disposable()
        _, _, _, tx = build_journal_state(vendor=vendor, db=db, runtime=runtime,
                                          state="CONCURRENT_DIVERGENCE")
        out = orchestrate(_req(vendor, runtime), db_path=db, tx_id_hint=tx,
                          consequence_plan=_cons())
        self.assertEqual(out.status, OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value)
        self.assertTrue(out.manual_review_required)

    def test_not_applied_no_sync_terminal(self):
        root, vendor, runtime, db = _disposable()
        _, _, _, tx = build_journal_state(vendor=vendor, db=db, runtime=runtime,
                                          state="CONFIRMED_NOT_APPLIED")
        out = orchestrate(_req(vendor, runtime), db_path=db, tx_id_hint=tx,
                          consequence_plan=_cons())
        self.assertEqual(out.status, OrchestrationStatus.ABORTED_NOT_ATTEMPTED.value)
        # no historical sidecar sync occurred
        con = sqlite3.connect(str(db))
        n = con.execute("SELECT COUNT(*) c FROM continuity_effect_markers").fetchone()[0]
        con.close()
        self.assertEqual(int(n), 0)

    def test_runtime_attempting_manual_new_tx(self):
        """F3-F6 crash leaving RUNTIME_ATTEMPTING => manual, never auto-retry."""
        root, vendor, runtime, db = _disposable()
        _, _, _, tx = build_journal_state(vendor=vendor, db=db, runtime=runtime,
                                          state="RUNTIME_ATTEMPTING")
        out = orchestrate(_req(vendor, runtime), db_path=db, tx_id_hint=tx,
                          consequence_plan=_cons())
        self.assertEqual(out.status, OrchestrationStatus.MANUAL_REVIEW_REQUIRED.value)
        self.assertTrue(out.manual_review_required)
        self.assertTrue(out.retry_requires_new_tx)

    def test_precondition_restart_no_sync_and_new_tx_required(self):
        root, vendor, runtime, db = _disposable()
        # durable PRECONDITION_FAILED -> orchestrator aborts/terminal
        _, _, _, tx = build_journal_state(vendor=vendor, db=db, runtime=runtime,
                                          state="PRECONDITION_FAILED")
        rec = recover_orchestration(db_path=db, tx_id=tx,
                                    consequence_plan=_cons())
        self.assertEqual(rec.status, OrchestrationStatus.PRECONDITION_FAILED.value)

    def test_unknown_restart_does_not_retry(self):
        root, vendor, runtime, db = _disposable()
        _, _, _, tx = build_journal_state(vendor=vendor, db=db, runtime=runtime,
                                          state="OUTCOME_UNKNOWN")
        rec = recover_orchestration(db_path=db, tx_id=tx, consequence_plan=_cons())
        self.assertTrue(rec.manual_review_required)
        self.assertTrue(rec.retry_requires_new_tx)
        # after recovery still no sync execution row
        con = sqlite3.connect(str(db))
        n = con.execute("SELECT COUNT(*) c FROM continuity_sync_executions").fetchone()[0]
        con.close()
        self.assertEqual(int(n), 0)


if __name__ == "__main__":
    unittest.main()
