"""Phase 3A — prepare / precondition / read-only & guard integration tests.

These exercise prepare_transaction (P1-P7) and verify_prewrite_precondition (P8)
against a real vendor runtime state.  They assert that Phase 3A NEVER mutates
the runtime, never invokes commit_turn's file writer, and never writes a temp
runtime file, and that authority/history tables are unchanged.
"""
from __future__ import annotations
import hashlib
import json
import shutil
import sqlite3
import tempfile
import unittest
import subprocess
import sys
from pathlib import Path

from tests import phase3a_fixture as PF
from continuity.transactions.preconditions import (
    prepare_transaction, verify_prewrite_precondition, require_concrete_patch,
)
from continuity.transactions.errors import (
    PatchRequired, PlayerSovereigntyViolation, AdultAuthorityViolation,
    UnsupportedNamedSlot, InvalidArgument, UnsupportedRuntimeIdentity,
    RuntimeParseError, RuntimeNotFound, RuntimeValidationError,
    CandidateValidationError,
)
from continuity.transactions.journal import AUTHORITY_TABLES


def _table_hash(con, table: str) -> str:
    rows = con.execute(f"SELECT * FROM {table} ORDER BY rowid").fetchall()
    return hashlib.sha256(repr(rows).encode("utf-8")).hexdigest()


def _snapshot_authority(db: Path) -> dict[str, str]:
    out = {}
    conn = sqlite3.connect(str(db))
    try:
        for t in AUTHORITY_TABLES:
            try:
                out[t] = _table_hash(conn, t)
            except sqlite3.OperationalError:
                out[t] = "absent"
    finally:
        conn.close()
    return out


class Phase3APrepareTests(unittest.TestCase):
    """Shared fixtures via setUpClass (isolated vendor clone + full state)."""
    _vendor_root = None
    _runtime_bytes = None

    @classmethod
    def setUpClass(cls):
        vendor = PF.make_vendor_runtime(None)  # tmp vendor with current_state.yaml
        cls._vendor_root = vendor
        cls._runtime_bytes = (vendor / "saves" / "current_state.yaml").read_bytes()

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        # isolated vendor per test (so mutations never leak)
        self.vendor = base / "vendor"
        shutil.copytree(self._vendor_root, self.vendor)
        self.runtime = self.vendor / "saves" / "current_state.yaml"
        self.db = base / "state" / "continuity.sqlite3"
        self.db.parent.mkdir(parents=True, exist_ok=True)
        from continuity.migrations import migrate
        con = sqlite3.connect(str(self.db))
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        migrate(con)
        con.close()

    def tearDown(self):
        self.tmp.cleanup()

    # ------------------------------------------------------------------ #
    def test_prepare_persists_prepared_and_evidence(self):
        snap_before = _snapshot_authority(self.db)
        rb = self.runtime.read_bytes()
        pe = prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 5, "last_committed_result": "fine."},
            branch_id="default",
            request_provenance={"source": "auto", "id": "req-1"})
        row = self._row(pe.continuity_tx_id)
        self.assertEqual(row["state"], "PREPARED")
        self.assertEqual(row["attempt_count"], 0)
        self.assertEqual(row["runtime_pre_sha256"], pe.runtime_pre_sha256)
        # runtime exactly unchanged (no write by prepare)
        self.assertEqual(self.runtime.read_bytes(), rb)
        self.assertEqual(_snapshot_authority(self.db), snap_before)

    def _row(self, tx_id):
        con = sqlite3.connect(str(self.db)); con.row_factory = sqlite3.Row
        try:
            return con.execute("SELECT * FROM transaction_journal WHERE "
                               "continuity_tx_id=?", (tx_id,)).fetchone()
        finally:
            con.close()

    def test_exact_raw_sha_prefix_and_not_revision_field(self):
        pe = prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 1})
        # raw sha is an exact fingerprint of observed bytes at a path/time
        expect = hashlib.sha256(self.runtime.read_bytes()).hexdigest()
        self.assertEqual(pe.runtime_pre_sha256, expect)
        # it is exposed as raw_sha256 evidence only. Verify no column named
        # runtime_revision anywhere in the journal schema.
        con = sqlite3.connect(str(self.db))
        cols = [r[1] for r in con.execute("pragma table_info(transaction_journal)")]
        self.assertNotIn("runtime_revision", cols)
        con.close()

    def test_same_second_read_precondition_ok(self):
        pe = prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 3})
        out = verify_prewrite_precondition(self.db, self.vendor, self.runtime,
                                           pe.continuity_tx_id)
        self.assertEqual(out["precondition_status"], "PRECONDITION_OK")
        self.assertEqual(self._row(pe.continuity_tx_id)["state"], "PREPARED")
        self.assertEqual(self._row(pe.continuity_tx_id)["precondition_status"],
                         "PRECONDITION_OK")

    def test_second_read_h_changed_precondition_failed_no_write_no_rebase(self):
        pe = prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 4})
        # mutate observed bytes (append a YAML comment) — semantic unchanged,
        # raw changes, exemplifying observed-hash mismatch.
        before = self.runtime.read_bytes()
        self.runtime.write_bytes(before + b"\n# external writer touched the file\n")
        out = verify_prewrite_precondition(self.db, self.vendor, self.runtime,
                                           pe.continuity_tx_id)
        self.assertEqual(out["state"], "PRECONDITION_FAILED")
        # runtime is NOT rewritten back, nothing rebased, no new candidate.
        self.assertEqual(self.runtime.read_bytes(), before + b"\n# external writer touched the file\n")
        row = self._row(pe.continuity_tx_id)
        self.assertEqual(row["runtime_outcome_class"], "PRECONDITION_FAILED")
        self.assertEqual(row["last_error_class"], "PRECONDITION_HASH_MISMATCH")

    def test_mismatch_creates_no_history_fact(self):
        pe = prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 4})
        snap = _snapshot_authority(self.db)
        self.runtime.write_bytes(self.runtime.read_bytes() + b"\n# x\n")
        verify_prewrite_precondition(self.db, self.vendor, self.runtime, pe.continuity_tx_id)
        self.assertEqual(_snapshot_authority(self.db), snap)

    def test_prepared_creates_no_episode_or_history_before_runtime_confirmed(self):
        pe = prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 4})
        con = sqlite3.connect(str(self.db))
        self.assertEqual(con.execute("select count(*) from episodes").fetchone()[0], 0)
        con.close()

    def test_prepare_no_runtime_write_commit_turn_never_invoked(self):
        rb_before = self.runtime.read_bytes()
        pe = prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 5})
        # exact bytes unchanged
        self.assertEqual(self.runtime.read_bytes(), rb_before)
        self.assertEqual(pe.to_dict()["runtime_attempted"], False)
        self.assertEqual(pe.to_dict()["runtime_outcome"], "RUNTIME_NOT_ATTEMPTED")

    def test_pure_vendor_candidate_no_file_write(self):
        # Candidate generation is in-memory: prepare must not create any new
        # file (in particular no temp runtime / candidate file on disk).
        def list_all(root: str):
            return {str(p) for p in Path(root).rglob("*") if p.is_file()}
        before = list_all(self.tmp.name)
        prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 5})
        after = list_all(self.tmp.name)
        added = after - before
        self.assertEqual(added, set(),
                         "prepare must not write any file (no temp candidate).")

    # ------------------------------------------------------------------ #
    def test_semantic_digest_stable_and_candidate_ignores_yaml_format(self):
        # Two selects in a row yield the same semantic for identical runtime+
        # patch (deterministic prepare fingerprints, §22)
        pe1 = prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 5})
        pe2 = prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 5})
        self.assertEqual(pe1.runtime_pre_semantic_digest, pe2.runtime_pre_semantic_digest)
        self.assertEqual(pe1.expected_candidate_digest, pe2.expected_candidate_digest)
        self.assertEqual(pe1.patch_digest, pe2.patch_digest)

    def test_raw_sha_and_semantic_are_distinct(self):
        pe = prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 5})
        self.assertNotEqual(pe.runtime_pre_sha256, pe.runtime_pre_semantic_digest)

    # ------------------------------------------------------------------ #
    def test_named_slot_blocked(self):
        with self.assertRaises(UnsupportedNamedSlot):
            prepare_transaction(
                vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
                patch={"delta_minutes": 5}, reject_named_slot=True)

    def test_ambiguous_path_rejected(self):
        other = Path(self.tmp.name) / "other.yaml"
        other.write_text("not the canonical path")
        with self.assertRaises(UnsupportedRuntimeIdentity):
            prepare_transaction(vendor_dir=self.vendor, db_path=self.db,
                                runtime_path=other, patch={"delta_minutes": 2})
        self.assertTrue(self.db.exists())

    # ------------------------------------------------------------------ #
    def test_concrete_patch_required(self):
        with self.assertRaises(PatchRequired):
            prepare_transaction(
                vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
                patch={})
        with self.assertRaises(InvalidArgument):
            require_concrete_patch(None)

    def test_player_natural_language_cannot_become_npc_belief_patch(self):
        # "make her believe me" is an attempt, not a patch.
        with self.assertRaises(PlayerSovereigntyViolation):
            prepare_transaction(
                vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
                patch={"desired_outcome": "make her believe me"})

    def test_adult_inference_blocked(self):
        with self.assertRaises(AdultAuthorityViolation):
            prepare_transaction(
                vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
                patch={"continuity_consent": {"alice": "granted"}})

    # ------------------------------------------------------------------ #
    def test_runtime_parse_failure_blocks(self):
        # Valid YAML header but corrupted tail => parse error, no PREPARED
        self.runtime.write_bytes(b"a: 1\n  - broken: [\n")
        with self.assertRaises(RuntimeParseError):
            prepare_transaction(
                vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
                patch={"delta_minutes": 2})

    def test_runtime_validation_failure_blocks(self):
        # parses to a mapping but fails the full validator
        self.runtime.write_text("b: c\nnested: {}\n", encoding="utf-8")
        from continuity.transactions.errors import RuntimeValidationError
        with self.assertRaises(RuntimeValidationError):
            prepare_transaction(
                vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
                patch={"delta_minutes": 2})

    def test_runtime_missing_blocks(self):
        missing = self.vendor / "saves" / "current_state.yaml"
        missing.unlink()
        from continuity.transactions.errors import RuntimeNotFound
        with self.assertRaises(RuntimeNotFound):
            prepare_transaction(
                vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
                patch={"delta_minutes": 2})

    def test_candidate_validation_failure_blocks(self):
        # A patch the vendor validator will reject (e.g. semantic conflicts)
        # must block and leave no PREPARED row.
        patch = {"events_resolve": ["evt-NOT-PRESENT-0000"]}
        from continuity.transactions.errors import CandidateValidationError
        with self.assertRaises(CandidateValidationError):
            prepare_transaction(
                vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
                patch=patch)

    def test_high_trust_attraction_history_do_not_alter_patch(self):
        # A legal runtime-authority patch stays byte-for-byte identical; integration
        # never infers/improves/broadens it from trust/attraction/historical consent.
        import copy as _copy
        patch = {"delta_minutes": 5, "last_committed_result": "scene continued"}
        original = _copy.deepcopy(patch)
        prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch=patch, request_provenance={"reasoner": "history/trust==present"})
        self.assertEqual(patch, original)

    def test_journal_never_shadow_stores_adult_marker(self):
        # The journal stores hashes/digests/refs only; even a runtime-authority
        # outcome that legitimately reaches the runtime is never copied into the
        # sidecar as a payload / shadow of current state.
        marker = "TOP-SECRET-ALICE-INTIMACY-MARKER-9f2b"
        prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 5, "last_committed_result": marker})
        con = sqlite3.connect(str(self.db))
        rows = con.execute("SELECT * FROM transaction_journal").fetchall()
        blob = repr(rows)
        self.assertNotIn("TOP-SECRET-ALICE-INTIMACY-MARKER", blob)
        self.assertNotIn("secret_door", blob)
        con.close()

    def test_authority_immutable_across_run(self):
        # prepare + precondition verify change only journal tables.
        snap = _snapshot_authority(self.db)
        pe = prepare_transaction(
            vendor_dir=self.vendor, db_path=self.db, runtime_path=self.runtime,
            patch={"delta_minutes": 5})
        verify_prewrite_precondition(self.db, self.vendor, self.runtime, pe.continuity_tx_id)
        self.assertEqual(_snapshot_authority(self.db), snap)

    def test_prepare_twice_runtime_bytes_unchanged(self):
        rb = self.runtime.read_bytes()
        prepare_transaction(vendor_dir=self.vendor, db_path=self.db,
                            runtime_path=self.runtime, patch={"delta_minutes": 3})
        prepare_transaction(vendor_dir=self.vendor, db_path=self.db,
                            runtime_path=self.runtime, patch={"delta_minutes": 3})
        self.assertEqual(self.runtime.read_bytes(), rb)
        con = sqlite3.connect(str(self.db))
        rows = con.execute("SELECT * FROM transaction_journal").fetchall()
        self.assertGreaterEqual(len(rows), 2)
        con.close()
