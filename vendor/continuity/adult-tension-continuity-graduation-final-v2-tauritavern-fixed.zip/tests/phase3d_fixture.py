"""Hermetic Phase 3D fixture factory.

Builds a disposable prepared transaction (Phase 3A), a disposable vendor clone
(Phase 3B), and drives the REAL pinned vendor single-file writer once, then
hands back to the Orchestrator to sync + finalise.  This fixture exists purely
so Phase 3D tests can exercise the *composition* (Orchestrator re-using 3A/3B/3C)
against a throwaway /tmp copy — exactly as Phase 3B tests already mutate only a
provably disposable vendor.
"""
from __future__ import annotations
import sqlite3
import sys
import tempfile
from pathlib import Path
from typing import Any

from tests.phase3b_fixture import make_disposable_vendor, simple_patch, current_bytes

_DEV_VENDOR = Path("/var/minis/workspace/vendor/dsh-adult-tension")

__all__ = [
    "make_disposable_vendor", "seed_disposable_db", "current_bytes",
    "simple_patch", "sample_consequences",
]


def seed_disposable_db(root: Path, name: str = "continuity.sqlite3") -> Path:
    db = root / "state" / name
    db.parent.mkdir(parents=True, exist_ok=True)
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    from continuity.migrations import migrate
    con = sqlite3.connect(str(db))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    migrate(con)
    con.close()
    return db


def build_journal_state(*, vendor: Path, db: Path, runtime: Path, state: str,
                        tx_id: str | None = None):
    """Create a REAL disposable PREPARED row (Phase 3A prepare on the disposable
    vendor/runtime) and then journal-only advance it to `state`.

    Used to test the Orchestrator's durable-state disposition for crash windows
    that a process restart would observe (UNKNOWN / DIVERGENCE / NOT_APPLIED /
    PRECONDITION_FAILED / RUNTIME_ATTEMPTING).  For the mutation-outcome rows we
    reserve the single attempt in the journal (durable attempt_count 1) and set
    the exact durable outcome class those windows would persist; the Orchestrator
    must therefore handle them fail-closed, never running the writer again.

    Returns (vendor, db, runtime, tx_id).
    """
    import sqlite3
    from continuity.transactions.preconditions import prepare_transaction
    from continuity.transactions.journal import JournalDao
    from continuity.transactions.contracts import TransactionState

    from continuity.orchestration.contracts import ConsequencePlan
    from continuity.orchestration.orchestrator import _validate_and_digest_plan
    from continuity.transactions.preconditions import new_tx_id
    tx_id = tx_id or new_tx_id()
    plan = ConsequencePlan(consequences=sample_consequences())
    pre = prepare_transaction(
        vendor_dir=vendor, db_path=db, runtime_path=runtime,
        patch=simple_patch(), branch_id="default", tx_id=tx_id,
        staged_sync_digest=_validate_and_digest_plan(tx_id, "default", plan))
    tx = pre.continuity_tx_id
    con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    dao = JournalDao(con)
    if state == "PRECONDITION_FAILED":
        dao.record_precondition_failure(tx, "pytest simulated second-H0 mismatch")
    elif state in ("OUTCOME_UNKNOWN", "CONCURRENT_DIVERGENCE",
                   "CONFIRMED_NOT_APPLIED"):
        dao.open_runtime_attempt(tx)   # consume the single attempt slot (journal)
        dao.record_runtime_outcome(tx, to_state=state, outcome_class=state,
                                   durability_status="DIR_FSYNC_OK",
                                   manual_review_required=(state != "CONFIRMED_NOT_APPLIED"))
    elif state == "RUNTIME_ATTEMPTING":
        dao.open_runtime_attempt(tx)
    con.close()
    return vendor, db, runtime, tx


def sample_consequences() -> list[dict[str, Any]]:
    """A small, valid, authority-safe consequence plan (episode memory only)."""
    return [
        {"kind": "EPISODE_APPEND",
         "payload": {"summary": "phase3d orchestrated episode",
                     "scene_ref": "3D-SC", "runtime_pre_hash": None,
                     "runtime_post_hash": None}},
    ]
