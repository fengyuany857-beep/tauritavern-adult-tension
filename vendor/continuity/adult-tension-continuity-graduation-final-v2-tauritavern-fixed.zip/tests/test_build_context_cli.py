"""Phase 2B-1 read-only CLI acceptance tests."""
from __future__ import annotations
import json
import sqlite3
import subprocess
import sys
import unittest
from pathlib import Path

from tests.context_builder_fixture import build_context_base, runtime_state_path

ROOT = Path(__file__).parents[1]
CLI = ROOT / "scripts" / "build_context.py"


def _db_snapshot(base: Path) -> str:
    c = sqlite3.connect(str(base / "state" / "continuity.sqlite3"))
    parts = []
    tables = ["facts", "knowledge", "relationships", "commitments", "threads",
              "episodes", "admission_candidates", "admission_decisions",
              "continuity_transactions"]
    for t in tables:
        rows = [tuple(r) for r in c.execute(f"SELECT * FROM {t}")]
        parts.append(t + "=" + json.dumps(rows, sort_keys=True))
    c.rollback()
    c.close()
    return "|".join(parts)


class CliReadonly(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base = build_context_base()
        self.addCleanup(self.tmp.cleanup)

    def _run(self, *extra):
        rp = runtime_state_path(self.base)
        cmd = [sys.executable, str(CLI), "--base", str(self.base), "--scene", "E-A"] \
            + list(extra)
        return subprocess.run(cmd, capture_output=True, text=True)

    def test_plain_runs_and_is_query_only(self):
        before = _db_snapshot(self.base)
        proc = self._run("--text", "我喝了口水", "--observer", "E-A",
                         "--json", "--runtime", str(runtime_state_path(self.base)))
        self.assertEqual(proc.returncode, 0, proc.stderr)
        after = _db_snapshot(self.base)
        self.assertEqual(before, after, "CLI must not mutate authority")

    def test_explain_mode_is_json_feedable(self):
        proc = self._run("--text", "她以前是不是说过喜欢咖啡？", "--budget", "4000", "--json")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        data = json.loads(proc.stdout)
        self.assertIn("final_mode", data)
        self.assertTrue(data["items"])

    def test_mode_override_debug(self):
        proc = self._run("--text", "我喝了口水", "--mode", "EVIDENCE", "--json")
        self.assertEqual(proc.returncode, 0)
        data = json.loads(proc.stdout)
        self.assertEqual(data["final_mode"], "EVIDENCE")


if __name__ == "__main__":
    unittest.main()
