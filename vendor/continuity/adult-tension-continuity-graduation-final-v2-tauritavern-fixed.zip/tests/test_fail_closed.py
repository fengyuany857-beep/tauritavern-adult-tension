import unittest
from continuity.constants import *
from continuity.models import FactInput
from continuity.validation import insert_fact
from continuity.errors import AuthorityError
from util import tmpdb
class T(unittest.TestCase):
 def test_runtime_predicates_rejected(self):
  d,c=tmpdb();self.addCleanup(d.cleanup)
  f=FactInput('F','E','consent.grants','{}',Plane.OBJECTIVE,AdmissionState.COMMITTED,TruthStatus.ACTIVE,1,None,1,'{}')
  with self.assertRaises(AuthorityError):insert_fact(c,f)
 def test_restore_and_fork_closed(self):
  from continuity.validation import unsupported_fork,unsupported_restore
  with self.assertRaises(Exception): unsupported_fork()
  with self.assertRaises(Exception): unsupported_restore()
