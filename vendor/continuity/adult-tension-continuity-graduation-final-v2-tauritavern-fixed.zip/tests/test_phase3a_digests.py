"""Phase 3A — canonical / raw / patch digest determinism unit tests (pure)."""
from __future__ import annotations
import unittest

from continuity.transactions.digests import (
    canonical, canonical_semantic_digest, patch_digest, raw_sha256_bytes,
)


class SemanticDigestTests(unittest.TestCase):
    def test_same_semantic_state_same_digest_order_independent(self):
        a = {"z": 1, "a": {"y": [2, {"x": "你"}], "b": True}, "f": 1.0}
        b = {"f": 1.0, "a": {"b": True, "y": [2, {"x": "你"}]}, "z": 1}
        self.assertEqual(canonical_semantic_digest(a), canonical_semantic_digest(b))

    def test_formatting_irrelevant_digest(self):
        import yaml
        text1 = "a: 1\nb:\n  - x\n  - y: 你\n"
        text2 = "a: 1\nb:\n - x\n - y:  你\n"
        m1, m2 = yaml.safe_load(text1), yaml.safe_load(text2)
        self.assertEqual(canonical_semantic_digest(m1), canonical_semantic_digest(m2))

    def test_recursive_sorting(self):
        self.assertEqual(canonical({"b": [2, {"z": 1, "a": 3}]}),
                         canonical({"b": [2, {"a": 3, "z": 1}]}))

    def test_different_state_digest_differs(self):
        self.assertNotEqual(canonical_semantic_digest({"x": 1}), canonical_semantic_digest({"x": 2}))
        self.assertNotEqual(canonical_semantic_digest({"x": [1]}), canonical_semantic_digest({"x": [1, 1]}))

    def test_patch_digest_key_order_stable(self):
        p1 = {"npcs_add": [{"id": "a", "name": "你"}]}
        p2 = {"npcs_add": [{"name": "你", "id": "a"}]}
        self.assertEqual(patch_digest(p1), patch_digest(p2))

    def test_patch_key_order_top_level_stable(self):
        self.assertEqual(patch_digest({"b": 2, "a": 1}), patch_digest({"a": 1, "b": 2}))

    def test_different_patch_digest_differs(self):
        self.assertNotEqual(patch_digest({"a": 1}), patch_digest({"a": 2}))
        self.assertNotEqual(patch_digest({"a": 1}), patch_digest({"b": 1}))

    def test_raw_sha256_exact_bytes(self):
        # byte-different texts (same parsed semantics!) differ in raw digest,
        # proving raw != semantic.
        t1 = "a: 1\nb: 2\n".encode()
        t2 = "a: 1\nb:  2\n".encode()
        self.assertNotEqual(raw_sha256_bytes(t1), raw_sha256_bytes(t2))
        self.assertEqual(raw_sha256_bytes(t1), raw_sha256_bytes(t1))


if __name__ == "__main__":
    unittest.main()
