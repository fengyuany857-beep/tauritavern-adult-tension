"""Phase 2B-2 CLI tests (scripts/plan_reentry.py) — read-only, rc==0."""
from __future__ import annotations
import hashlib
import json
import sqlite3
import subprocess
import sys
import unittest
from pathlib import Path

from tests import reentry_fixture as F

ROOT = Path(__file__).parents[1]
CLI = ROOT / "scripts" / "plan_reentry.py"


def _run(args, env=None):
    base_env = {k: v for k, v in dict(__import__("os").environ).items()}
    if env:
        base_env.update(env)
    return subprocess.run([sys.executable, str(CLI)] + args,
                          capture_output=True, text=True,
                          cwd=str(ROOT), env=base_env, timeout=120)


def _table_hashes(base):
    con = sqlite3.connect(str(base / "state" / "continuity.sqlite3"))
    seen = {}
    for t, in con.execute("SELECT name FROM sqlite_master WHERE type='table'"):
        rows = con.execute(f"SELECT * FROM {t} ORDER BY rowid").fetchall()
        seen[t] = hashlib.sha256(repr(rows).encode("utf-8")).hexdigest()
    con.close()
    return seen


class PlanReentryCli(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base, self.cards = F.build()
        self.snap = F.make_runtime(self.base, roster=("ALEX", "PLR"))

    def tearDown(self):
        try:
            self.tmp.cleanup()
        except Exception:
            pass

    def test_json_output_read_only_rc0(self):
        before = _table_hashes(self.base)
        r = _run(["--base", str(self.base), "--runtime", str(self.snap),
                  "--runtime-npc", "alex-x", "--mode", "DEEP", "--json"])
        self.assertEqual(r.returncode, 0, r.stderr)
        payload = json.loads(r.stdout)
        self.assertEqual(payload["target_entity_id"], "ALEX")
        self.assertEqual(payload["status"], "OK")
        self.assertIn("entity_anchor_refs", payload)
        after = _table_hashes(self.base)
        self.assertEqual(before, after)

    def test_explain_updates_no_db(self):
        before = _table_hashes(self.base)
        r = _run(["--base", str(self.base), "--runtime", str(self.snap),
                  "--runtime-npc", "alex-x", "--mention", "", "--explain"])
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("semantic_digest", r.stdout)
        after = _table_hashes(self.base)
        self.assertEqual(before, after)

    def test_missing_card_rc0(self):
        snap2 = F.make_runtime(self.base, roster=("NORA",))
        r = _run(["--base", str(self.base), "--runtime", str(snap2),
                  "--runtime-npc", "bina-x", "--json"])
        self.assertEqual(r.returncode, 0, r.stderr)
        payload = json.loads(r.stdout)
        self.assertEqual(payload["status"], "RUNTIME_CARD_MISSING")

    def test_no_runtime_flag_is_conservative(self):
        r = _run(["--base", str(self.base), "--runtime-npc", "alex-x", "--json"])
        self.assertEqual(r.returncode, 0, r.stderr)
        payload = json.loads(r.stdout)
        self.assertIn(payload["status"], ("RUNTIME_CARD_MISSING", "RUNTIME_HASH_CHANGED"))

    def test_pack_flag(self):
        r = _run(["--base", str(self.base), "--runtime", str(self.snap),
                  "--runtime-npc", "alex-x", "--pack"])
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("pack_status", r.stdout)


if __name__ == "__main__":
    unittest.main()
