"""Hermetic Phase 3B fixture factory.

Reuses the Phase 3A pattern but with a phase-3B disposable fixture declaration.
Each disposable vendor clone is a full copy of the pinned vendor scripts under
an OS temp root with `<root>/vendor/saves/current_state.yaml` seeded so the
canonical-path rule in runtime_observation holds.  Useful to run the REAL vendor
single-file writer against a provably disposable current runtime state.

Everything produced here lives under a temp root; a path guard refuses to write
anywhere else.
"""
from __future__ import annotations
import hashlib
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path
from typing import Any

_DEV_VENDOR = Path("/var/minis/workspace/vendor/dsh-adult-tension")
_CONT_ROOT = Path("/tmp/gate3b/continuity") if Path("/tmp/gate3b/continuity").exists() \
    else Path(__file__).resolve().parents[1]

# Declared mutation-test roots: ONLY these temp paths may be used for real
# runtime mutation in Phase 3B tests (§33).  Anything else => refuse.
DISPOSABLE_MUTATION_ROOTS = {str(tempfile.gettempdir())}
# These are explicitly NOT disposable targets for mutation.  (The dev continuity
# tree on a gate machine may itself sit under an OS temp root; mutation targets
# are further enforced to be freshly minted phase3b_disp_* vendor clones, so the
# production/source sentinels below are the correct disallowances.)
NON_DISPOSABLE = [
    _DEV_VENDOR,            # vendor repo install / saves
    Path("/var/minis"),     # shared app artifacts / memory / bundles
    Path.home() / "saves",  # hypothetical user archive
]

__all__ = [
    "make_disposable_vendor", "seed_disposable_db", "DISPOSABLE_MUTATION_ROOTS",
    "NON_DISPOSABLE", "assert_disposable_runtime_path", "current_bytes",
    "runtime_path_of", "simple_patch",
]


def simple_patch() -> dict[str, Any]:
    """A small, safe, upstream-concrete runtime delta (opening-compatible)."""
    return {"delta_minutes": 5, "last_committed_result": "scene continued"}


def _copy_vendor_to(tmp_root: Path) -> Path:
    vendor = tmp_root / "vendor"
    shutil.copytree(_DEV_VENDOR, vendor,
                    ignore=shutil.ignore_patterns(".git", "__pycache__", ".pytest_cache"))
    (vendor / "saves").mkdir(exist_ok=True)
    seed_src = _DEV_VENDOR / "tests" / "fixtures" / "_opening_synthetic_v3.yaml"
    if not seed_src.exists():
        raise RuntimeError(f"vendor opening seed not found: {seed_src}")
    shutil.copy(seed_src, vendor / "saves" / "current_state.yaml")
    return vendor


def make_disposable_vendor() -> tuple[Path, Path, Path]:
    """Return (temp_root, vendor_dir, runtime_path) under an OS temp root.

    The returned runtime file is a disposable real runtime state the vendor
    writer may genuinely mutate.  A tempfile.mkdtemp root guarantees it."""
    root = Path(tempfile.mkdtemp(prefix="phase3b_disp_"))
    vendor = _copy_vendor_to(root)
    runtime = vendor / "saves" / "current_state.yaml"
    assert_disposable_runtime_path(runtime)
    return root, vendor, runtime


def runtime_path_of(vendor: Path) -> Path:
    return vendor / "saves" / "current_state.yaml"


def current_bytes(vendor: Path) -> bytes:
    return runtime_path_of(vendor).read_bytes()


def seed_disposable_db(root: Path, name: str = "continuity.sqlite3") -> Path:
    db = root / "state" / name
    db.parent.mkdir(parents=True, exist_ok=True)
    _ = sys.path  # keep continuity import root on sys.path
    sys.path.insert(0, str(_CONT_ROOT))
    from continuity.migrations import migrate
    con = sqlite3.connect(str(db))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    migrate(con)
    con.close()
    return db


def assert_disposable_runtime_path(runtime: Path | str) -> None:
    """Hard guard (§33): refuse any mutation path that is not under an OS temp
    disposable root AND not the canonical vendor saves current_state.yaml."""
    runtime = Path(runtime).resolve()
    root_tmp = Path(tempfile.gettempdir()).resolve()
    try:
        under_tmp = str(runtime).startswith(str(root_tmp))
    except OSError:
        under_tmp = False
    for non in NON_DISPOSABLE:
        try:
            if str(runtime).startswith(str(Path(non).resolve())):
                raise AssertionError(
                    f"mutation path resolves under forbidden root {non}")
        except OSError:
            pass
    if not under_tmp:
        raise AssertionError(
            f"mutation path is NOT under the disposable temp root: {runtime}")
    if not runtime.as_posix().endswith("/saves/current_state.yaml"):
        raise AssertionError(
            f"mutation target is not the canonical single current_state.yaml: {runtime}")


def sha256_of(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def expect(raw_32: bytes) -> str:  # placeholder for symmetric helper names
    return hashlib.sha256(raw_32).hexdigest()
