import unittest
from continuity.retrieval import EntityRetriever, RetrievalQuery, RetrievalStatus
from retrieval_seed import open_ctx, seed_base


class T(unittest.TestCase):
    def setUp(self):
        self.tmp, base = seed_base()
        self.addCleanup(self.tmp.cleanup)
        self.ctx = open_ctx(base)
        self.ent = EntityRetriever()

    def ids(self, q):
        return [i.item_id for i in self.ent.retrieve(q, self.ctx).items]

    def test_stable_id_exact_match(self):
        got = self.ids(RetrievalQuery(entity_ids=("E-C",), query_id="q"))
        self.assertIn("E-C", got)

    def test_alias_resolves_confirmed(self):
        self.assertIn("E-C", self.ids(RetrievalQuery(raw_text="Mystery", query_id="q")))

    def test_same_name_entities_return_ambiguity(self):
        r = self.ent.retrieve(RetrievalQuery(raw_text="Lin", query_id="q"), self.ctx)
        got = [i.item_id for i in r.items if i.item_id in ("E-A", "E-B")]
        self.assertEqual(2, len(got))
        self.assertEqual(RetrievalStatus.AMBIGUOUS, r.status)

    def test_merge_candidate_not_confirmed(self):
        r = self.ent.retrieve(RetrievalQuery(raw_text="Ghost", query_id="q"), self.ctx)
        confirmed = [i for i in r.items if i.classification != "CANDIDATE"]
        self.assertEqual([], confirmed)

    def test_entity_participant_lookup_from_episode(self):
        got = self.ids(RetrievalQuery(entity_ids=("E-A",), participant_id="E-A", query_id="q"))
        self.assertIn("EP-1", got)
