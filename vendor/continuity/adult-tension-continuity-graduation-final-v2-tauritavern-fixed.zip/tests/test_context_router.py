"""Phase 2B-1 router unit tests.

Covers the numbered requirements 1-7 + adversarial target precision (sec. 26)
and determinism aspects that belong to the Router layer.
"""
from __future__ import annotations
import unittest

from continuity.routing import ContextMode, ContextRouter, RoutingDecision, RoutingRequest
from continuity.routing.features import QueryFeatures


class RoutingProblem(unittest.TestCase):
    def setUp(self):
        self.r = ContextRouter()

    def mode_of(self, text: str, **extra) -> ContextMode:
        req = RoutingRequest(raw_text=text, **extra)
        return self.r.decide_initial(req).final_mode

    # ---- #1 ordinary -> FAST # --------------------------------------------
    def test_ordinary_turn_is_fast(self):
        self.assertEqual(self.mode_of("我喝了口水。"), ContextMode.FAST)
        self.assertEqual(self.mode_of("E-PL looks at the rain and sighs."),
                         ContextMode.FAST)

    # ---- adversarial guard: "以前" is not a mechanical EVIDENCE trigger -----
    def test_recall_about_coffee_is_deep_not_evidence(self):
        # sec.26 adversarial example 1
        self.assertEqual(self.mode_of("她以前是不是说过喜欢咖啡？"), ContextMode.DEEP)

    # ---- #2 old leading entity mention -> DEEP -----------------------------
    def test_old_entity_mention_is_deep(self):
        self.assertEqual(self.mode_of("那个很久没见的医生走进来了。"), ContextMode.DEEP)

    # ---- #3 exact-verbatim quote -> EVIDENCE -------------------------------
    def test_exact_quote_is_evidence(self):
        self.assertEqual(self.mode_of("她上次原话到底是什么？"), ContextMode.EVIDENCE)

    # ---- #4 exact timestamp / turn-number -> EVIDENCE ----------------------
    def test_exact_timestamp_is_evidence(self):
        self.assertEqual(self.mode_of("具体是哪一回合说的？"), ContextMode.EVIDENCE)
        self.assertEqual(self.mode_of("On which turn did she say that? (exact turn)"),
                         ContextMode.EVIDENCE)

    # provenance + who-knew variants route EVIDENCE too
    def test_provenance_and_who_knew_route_evidence(self):
        self.assertEqual(self.mode_of("这句话的出处是哪里？"), ContextMode.EVIDENCE)
        self.assertEqual(self.mode_of("当时谁已经知道这件事？"), ContextMode.EVIDENCE)

    # ---- #7 no infinite escalation loop ------------------------------------
    def test_escalation_is_single_side_chain_capped_at_evidence(self):
        fast = self.r.decide_initial(RoutingRequest(raw_text="我喝了口水。"))
        deep = self.r.escalate(fast, True, "temporal partial")
        self.assertEqual(deep.final_mode, ContextMode.DEEP)
        self.assertEqual(deep.initial_mode, ContextMode.FAST)
        ev = self.r.escalate(deep, True, "precision required")
        self.assertEqual(ev.final_mode, ContextMode.EVIDENCE)
        ev2 = self.r.escalate(ev, True, "still lacking")    # ceiling: no loop
        self.assertEqual(ev2.final_mode, ContextMode.EVIDENCE)
        self.assertFalse(ev2.escalation_allowed)
        # escalation reasons preserved & bounded
        self.assertLessEqual(len(ev2.escalation_reasons), 2)

    # ---- #5 FAST insufficiency escalates DEEP ------------------------------
    def test_fast_insufficiency_escalates_deep(self):
        decision = self.r.decide_initial(RoutingRequest(raw_text="我喝了口水。"))
        escalated = self.r.escalate(decision, True,
                                    "scene continuity gap: PARTIAL")
        self.assertEqual(escalated.final_mode, ContextMode.DEEP)
        self.assertIn("FAST -> DEEP", " ".join(escalated.escalation_reasons))

    # ---- #6 DEEP precision insufficiency escalates EVIDENCE -----------------
    def test_deep_precision_insufficiency_escalates_evidence(self):
        decision = self.r.decide_initial(RoutingRequest(raw_text="她以前是不是去过那边？"))
        self.assertEqual(decision.final_mode, ContextMode.DEEP)
        escalated = self.r.escalate(decision, True, "exact wording required")
        self.assertEqual(escalated.final_mode, ContextMode.EVIDENCE)
        self.assertTrue(escalated.evidence_required)


class RouterDeterminism(unittest.TestCase):
    def test_same_text_same_decision_twice(self):
        r = ContextRouter()
        a = r.decide_initial(RoutingRequest(raw_text="她上次原话到底是什么？"))
        b = r.decide_initial(RoutingRequest(raw_text="她上次原话到底是什么？"))
        self.assertEqual(a, b)

    def test_mode_override_is_debug_only(self):
        r = ContextRouter()
        d = r.decide_initial(RoutingRequest(raw_text="我喝了口水。", mode_override=ContextMode.EVIDENCE))
        self.assertEqual(d.final_mode, ContextMode.EVIDENCE)
        self.assertTrue(any("mode_override" in x for x in d.reasons))


if __name__ == "__main__":
    unittest.main()
