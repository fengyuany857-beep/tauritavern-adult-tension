import sqlite3,tempfile,unittest
from pathlib import Path
from continuity.constants import MIGRATION_VERSION
from continuity.migrations import migrate
from continuity.errors import MigrationError
class T(unittest.TestCase):
 def test_migration_idempotent(self):
  with tempfile.TemporaryDirectory() as d:
   c=sqlite3.connect(Path(d)/'x.db');migrate(c);migrate(c);self.assertEqual(str(MIGRATION_VERSION),c.execute("select value from schema_meta where key='migration_version'").fetchone()[0])
 def test_upgrade_v1_to_v2_adds_branch_columns(self):
  from continuity import migrations as m
  import re
  legacy = re.sub(r"branch_id TEXT NOT NULL DEFAULT 'default', ", "", m.DDL)
  with tempfile.TemporaryDirectory() as d:
   c=sqlite3.connect(Path(d)/'x.db')
   for statement in (item.strip() for item in legacy.split(';')):
    if statement: c.execute(statement)
   c.execute("insert into schema_meta values('schema_version','1')"); c.execute("insert into schema_meta values('migration_version','1')"); c.commit()
   migrate(c)
   self.assertEqual('2',c.execute("select value from schema_meta where key='migration_version'").fetchone()[0])
   cols=[r[1] for r in c.execute('pragma table_info(facts)')]
   self.assertIn('branch_id', cols)
 def test_migration_failure_rolls_back(self):
  with tempfile.TemporaryDirectory() as d:
   c=sqlite3.connect(Path(d)/'x.db');c.execute('create table entities(x text)');c.commit()
   with self.assertRaises(MigrationError):migrate(c)
   self.assertIsNone(c.execute("select name from sqlite_master where type='table' and name='schema_meta'").fetchone())
