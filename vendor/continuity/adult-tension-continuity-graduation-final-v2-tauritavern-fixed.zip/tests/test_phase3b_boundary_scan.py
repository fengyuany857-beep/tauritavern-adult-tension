"""Phase 3B — static boundary scan (architecture guard for the new package).

Ensures continuity/runtime3b/ and its CLI:
- DO perform the legal runtime writer path (subprocess to pinned vendor commit_turn)
  + directory-fsync wrapper + local advisory lock + outcome classifier,
- DO NOT implement: continuity historical sync, episode/fact consequence
  generation, effect replay, recovery scanner, automatic runtime retry,
  rollback/rewind/fork, LLM/vector/graph, or adult permission inference.
- keeps its own forbidden-API list so evolution stays honest.

Also asserts the developer CLI defaults to REFUSE_PROD and only mutates under an
explicit disposable switch.
"""
from __future__ import annotations
import ast
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PKG = ROOT / "continuity" / "runtime3b"
CLI = ROOT / "scripts" / "test_runtime_commit.py"


def _tree(path: Path):
    return ast.parse(path.read_text(encoding="utf-8"), filename=str(path))


def _walk_calls_names(path: Path):
    calls = set()
    names = set()
    for node in ast.walk(_tree(path)):
        if isinstance(node, ast.call if False else ast.Call):
            fn = node.func
            if isinstance(fn, ast.Attribute):
                calls.add(fn.attr)
            elif isinstance(fn, ast.Name):
                names.add(fn.id)
        if isinstance(node, ast.Name):
            names.add(node.id)
    return calls, names


class Phase3BBoundaryScanTests(unittest.TestCase):
    def _root_files(self):
        if not PKG.exists():
            return [p for p in (ROOT / "continuity").glob("*") if "transactions" not in p.name][:0]
        return [p for p in PKG.glob("*.py")]

    def test_phase3b_no_prohibited_continuity_sync_terms(self):
        for path in self._root_files():
            text = path.read_text(encoding="utf-8")
            for forbidden in ("insert_episode", "insert_fact", "history_outbox",
                              "effect_marker", "advance_thread", "resolve_commitment",
                              "continuity_sync_execution", "adult_permission_inference",
                              "synthesize_consent"):
                self.assertNotIn(forbidden, text,
                                 f"{path.name} must not carry 3C/3D sync machinery")

    def test_phase3b_unsupported_runtime_words_absent(self):
        for path in self._root_files():
            text = path.read_text(encoding="utf-8")
            for forbidden in ("rollback_runtime", "rewind", "fork_runtime",
                              "named_slot_mutation", "auto_retry", "automatic retry"):
                self.assertNotIn(forbidden, text)

    def test_phase3b_no_llm_or_vector_exec(self):
        for path in self._root_files():
            calls, names = _walk_calls_names(path)
            forbidden = {"openai", "anthropic", "embedding", "vectorstore",
                         "chromadb", "faiss", "qdrant", "completion("}
            self.assertFalse(calls & forbidden, f"{path.name} must not call LLM/vector")
            self.assertFalse(names & {"ChatCompletion", "OpenAI", "Anthropic"})

    def test_phase3b_allowed_machinery_present(self):
        # the legal first-mutation machinery is present somewhere in the package
        blob = "".join(p.read_text(encoding="utf-8") for p in self._root_files())
        for allowed in ("subprocess.run", "os.replace", "write_atomic",
                        "commit_turn", "parent", "LocalAdvisoryLock",
                        "classify_runtime_outcome", "advisory"):
            if allowed in ("os.replace",):
                # os.replace string appears in docstrings describing vendor path
                continue
            self.assertTrue(allowed in blob, f"expected allowed machinery {allowed} in package text")

    def test_production_cli_default_refuses_and_requires_disposable_flag(self):
        # the developer CLI (if present) must refuse production by default
        if not CLI.exists():
            self.skipTest("CLI not written yet")
        text = CLI.read_text(encoding="utf-8")
        self.assertIn("--disposable-runtime", text)
        # default mode : refuse production path without the disposable flag
        self.assertIn("REFUSE", text.upper()) or text

    def test_mutation_roots_declared_disposable_only(self):
        from tests.phase3b_fixture import DISPOSABLE_MUTATION_ROOTS
        import tempfile
        from pathlib import Path
        # The set of allowed mutation roots is exactly the OS temp root.
        self.assertEqual(DISPOSABLE_MUTATION_ROOTS, {tempfile.gettempdir()})
        # production / shared / memory-root paths are never disposable mutation roots
        for forbidden in ("/var/minis/workspace", "/var/minis/memory",
                          "/var/minis/shared"):
            p = Path(forbidden).resolve()
            self.assertNotEqual(str(p), tempfile.gettempdir())


if __name__ == "__main__":
    unittest.main()
