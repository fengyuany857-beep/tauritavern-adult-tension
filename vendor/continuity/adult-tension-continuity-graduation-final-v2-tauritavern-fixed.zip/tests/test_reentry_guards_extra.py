"""Phase 2B-2 supplementary red-team gates.

Closes remaining gaps from the minimum-test list in deterministic ways:
  * RUNTIME_HASH_CHANGED mapping (via reader injection — the file-change race is
    a concurrency-safety path, not reproducible as a byte swap inside one read)
  * no automatic merge / entity creation
  * exclusion records carry reasons
  * hash stability / digest determinism across repeated planning
  * no runtime NPC dialogue / narrative synthesized.
"""
from __future__ import annotations
import sqlite3
import unittest
from pathlib import Path
from unittest import mock

from tests import reentry_fixture as F
import continuity.reentry.planner as P
from continuity.reentry import ReentryPlanner, ReentryRequest
from continuity.reentry.contracts import ReentryStatus


class HashChangedMapping(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base, self.cards = F.build()
        self.snap = F.make_runtime(self.base, roster=("ALEX", "PLR"))

    def tearDown(self):
        try:
            self.tmp.cleanup()
        except Exception:
            pass

    def test_runtime_hash_changed_maps_to_status(self):
        # The OS mid-read write race is exercised deterministically by injecting a
        # reader that reports 'hash_changed' (SPEC §9 path).
        req = ReentryRequest(runtime_npc_id="alex-x", branch_id="default",
                             reentry_reason="router_deep_resolved", mode="DEEP")
        with mock.patch.object(P, "_read_card",
                               return_value=P._CardRead("hash_changed", hashv="x")):
            plan = ReentryPlanner(self.base).plan(req, self.snap)
        self.assertEqual(plan.status, ReentryStatus.RUNTIME_HASH_CHANGED)
        # no mixed-timeline context was produced
        self.assertEqual(plan.knowledge_refs, ())
        self.assertEqual(plan.commitment_refs, ())
        self.assertEqual(plan.semantic_digest, "")


class NoAutoMerge(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base, self.cards = F.build()
        self.snap = F.make_runtime(self.base, roster=("ALEX", "PLR"))

    def tearDown(self):
        try:
            self.tmp.cleanup()
        except Exception:
            pass

    def test_no_entity_or_alias_created(self):
        con = sqlite3.connect(str(self.base / "state" / "continuity.sqlite3"))
        entities = con.execute("SELECT count(*) FROM entities").fetchone()[0]
        aliases = con.execute("SELECT count(*) FROM entity_aliases").fetchone()[0]
        facts = con.execute("SELECT count(*) FROM facts").fetchone()[0]
        con.close()
        req = ReentryRequest(runtime_npc_id="alex-x", branch_id="default",
                             reentry_reason="router_deep_resolved", mode="DEEP")
        ReentryPlanner(self.base).plan(req, self.snap)
        con2 = sqlite3.connect(str(self.base / "state" / "continuity.sqlite3"))
        self.assertEqual(con2.execute("SELECT count(*) FROM entities").fetchone()[0], entities)
        self.assertEqual(con2.execute("SELECT count(*) FROM entity_aliases").fetchone()[0], aliases)
        self.assertEqual(con2.execute("SELECT count(*) FROM facts").fetchone()[0], facts)
        con2.close()


class TraceCoverage(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base, self.cards = F.build()
        self.snap = F.make_runtime(self.base, roster=("ALEX", "PLR"))
        req = ReentryRequest(runtime_npc_id="alex-x", branch_id="default",
                             reentry_reason="router_deep_resolved", mode="DEEP")
        self.plan = ReentryPlanner(self.base).plan(req, self.snap)

    def tearDown(self):
        try:
            self.tmp.cleanup()
        except Exception:
            pass

    def test_every_included_entry_has_reason(self):
        for e in self.plan.activation_traces:
            if not e.reason:
                self.fail("activation without reason: " + e.activation_id)

    def test_random_activation_ids_different(self):
        ids = [e.activation_id for e in self.plan.activation_traces]
        self.assertEqual(len(ids), len(set(ids)))

    def test_digest_stable_across_runs(self):
        # same fixture yields same digest
        snap2 = F.make_runtime(self.base, roster=("ALEX", "PLR"))
        p2 = ReentryPlanner(self.base).plan(
            ReentryRequest(runtime_npc_id="alex-x", branch_id="default",
                           reentry_reason="router_deep_resolved", mode="DEEP"), snap2)
        self.assertEqual(p2.semantic_digest, self.plan.semantic_digest)


if __name__ == "__main__":
    unittest.main()
