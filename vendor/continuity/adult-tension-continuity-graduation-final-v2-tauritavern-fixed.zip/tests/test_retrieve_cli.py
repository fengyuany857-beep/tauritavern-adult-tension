import hashlib
import json
import subprocess
import sys
import unittest
from pathlib import Path

from retrieval_seed import open_ctx, seed_base

ROOT = Path(__file__).parents[1]


def dump_hash(base: Path) -> str:
    import sqlite3
    c = sqlite3.connect(str(base / "state" / "continuity.sqlite3"))
    digest = hashlib.sha256()
    for line in c.iterdump():
        digest.update(line.encode())
    c.close()
    return digest.hexdigest()


class T(unittest.TestCase):
    def setUp(self):
        self.tmp, self.base = seed_base()
        self.addCleanup(self.tmp.cleanup)
        open_ctx(self.base)  # builds the derived index only

    def run_cli(self, *extra: str):
        cmd = [sys.executable, str(ROOT / "scripts" / "retrieve.py"), "--base", str(self.base), *extra]
        return subprocess.run(cmd, capture_output=True, text=True, check=False)

    def test_cli_text_query(self):
        p = self.run_cli("--text", "sapphire", "--limit", "5")
        self.assertEqual(0, p.returncode, p.stderr)
        data = json.loads(p.stdout)
        self.assertTrue(any(i["item_id"] == "FACT-SAP" for i in data["items"]))

    def test_cli_explain_read_only(self):
        before = dump_hash(self.base)
        p = self.run_cli("--text", "sapphire", "--explain")
        self.assertEqual(0, p.returncode, p.stderr)
        self.assertIn("trace", p.stdout)
        self.assertEqual(before, dump_hash(self.base))
