# adult-tension-continuity — SPEC_LOCK

**Document state:** `PASS — SOURCE-VERIFIED V1 ARCHITECTURE LOCK`  
**Spec version:** `1.0.0-source-unlocked`  
**Audit date:** `2026-09-05`  
**Audited runtime:** `dsh-adult-tension@cbfdc623fccc91247cbb37783757fc157406c2a5`  
**Implementation authorised:** **NO**

> This document freezes a non-invasive continuity sidecar architecture against the pinned source above. It is not an implementation. No `adult-tension` source or save was modified. V1 uses only source-verified read, pure validation/preflight, commit, and observational hash capabilities; absent runtime transaction, idempotency, query, restore, and fork APIs are not assumed.

## 1. Goals

1. Add durable long-horizon RP continuity without forking or rewriting `adult-tension`.
2. Keep exactly one mutable authority per fact.
3. Preserve canon versions, provenance, bitemporal validity, epistemic separation, relationships, commitments, threads, episodes, branch history, retrieval evidence, and recovery metadata.
4. Build temporary, explainable HOT/WARM/COLD Context Packs through FAST/DEEP/EVIDENCE routing.
5. Recall important supporting characters after long absence without keeping full cards resident.
6. Detect voice/character drift and repetition without turning style observations into canon or quotas.
7. Preserve player sovereignty and NPC autonomy.
8. Treat all adult-interaction permissions and runtime decisions as exclusively owned by `adult-tension`.
9. Make partial transaction failure visible and recoverable; never pretend two stores commit atomically.
10. Remain migratable from local SQLite/JSONL to future retrieval implementations without changing Canon semantics.

## 2. Non-goals

- No modification, refactor, replacement, reinterpretation, or weakening of `adult-tension`.
- No second writable copy of runtime turn, clock, scene, location, participants, NPC runtime emotion/goal/autonomy, pending events, consent, grants, boundaries, safety, sexuality profile, intimacy, or adult-interaction state.
- No inference of current permission from historical intimacy, attraction, trust, relationship, or prior consent.
- No autonomous promotion of LLM extractions to objective Canon.
- No external graph/vector database in V1.
- No guarantee of exact recall when evidence is absent.
- No narrator control over player-character intentions, feelings, internal state, dialogue, decisions, or successful outcomes beyond the mode rules below.
- No code, migration, integration adapter, schema file, or executable is created in this phase.

## 3. Existing `adult-tension` architecture summary

### 3.1 Audited source

The complete 39-file tracked repository at `/var/minis/workspace/vendor/dsh-adult-tension` was inspected at detached `HEAD` `cbfdc623fccc91247cbb37783757fc157406c2a5`, equal to fetched `origin/main`, with a clean worktree. The audit covered all root documents, five references, nine Python scripts, eight data YAML files, seven test files, one fixture, save documentation, and agent metadata. Tests were read but not executed because this phase forbids dependency installation and repository runtime writes.

### 3.2 Runtime architecture verified from source

- The v3 YAML state file is the runtime authority. `saves/current_state.yaml` is the session working state; named slots contain `state.yaml` plus a four-field `manifest.yaml`.
- `SKILL.md` and `commands.yaml` are model-level orchestration/routing contracts; there is no programmatic intent-router API.
- `live_slice.py` is a read-only projection. It reads a state mapping and emits runtime context or human status; it does not validate or mutate state.
- `commit_turn.py` loads the full state, parses a JSON delta patch, deep-copies and mutates in memory, validates the whole candidate with `validate_state.validate_data(..., "save")`, atomically replaces one output file, then prints the new live slice.
- `validate_state.py` is a pure structural/referential validator at the `validate_data`/`validate_text` level. It does not mutate its input or write files. It is not a full semantic consent/narrative or player-intent validator.
- `_common.write_atomic` writes a same-directory temporary file, flushes and `fsync`s the file, then calls `os.replace`. It gives single-file replacement atomicity; it does not lock, compare revisions, fsync the parent directory, or coordinate a sidecar.
- `manage_saves.py` separately manages named slots under an advisory file lock. It performs optimistic conflict detection only through exact `manifest.updated_at`; obsolete revision/hash/branch fields are explicitly ignored. A slot save writes manifest first and state second, so the pair is intentionally not atomic but a crash creates a conservative conflict.
- Narrative is generated **after** successful runtime commit from the newly printed live slice. There is no pre-commit candidate narrative in the current contract.

### 3.3 Source-level state and projection limits

The runtime owns `meta`, `world`, `boundaries`, `consent`, `player`, `npcs`, `relationships`, `events`, `checkpoint`, `resolved_summary`, `current_node`, and optional runtime extensions such as `retcons`.

The live slice includes turn/mode/safety/clock/world shell/constants, current node, active grants, active boundaries, player, all main NPCs, participating non-main NPCs, the full relationship list, a capped pending-event projection, and calibration checkpoint fields. It deliberately:

- keeps at most 10 pending events plus an omission notice;
- keeps the latest 8 player/NPC knowledge strings;
- keeps only the latest 2 NPC memories;
- excludes off-scene `important_supporting` NPCs unless they are participants;
- excludes naming audits, decision cards, sexuality-development snapshots, grants archive, revoked boundaries, resolved/cancelled-event detail, and retcon history;
- retains only `sexuality_profile.baseline`, not the full profile/development structure.

This truncation is the verified read-side seam that continuity may supplement without owning runtime state.

## 4. Verified integration points

**Confirmed V1 integration points: 6.**

| Integration point | Source-verified contract | V1 use and limit |
|---|---|---|
| Runtime state read | v3 YAML authority; schema source is `validate_state.py` and `references/状态总结.md` | Read-only snapshot from configured runtime state path; continuity must never rewrite it |
| Runtime live projection | `live_slice.extract_live_slice(state) -> dict`; CLI reads a path and emits YAML/JSON/human text | Context input only; no side effects, but intentionally truncated and carries no revision |
| Pure candidate preflight | `commit_turn.load_yaml`, `load_patch`, `commit(state, patch)` / `apply_patch`; `commit` deep-copies then calls save-profile validation | V1 may invoke in-process against an already-loaded snapshot only as preflight; it must not call `main` or write a state file |
| Runtime commit | `commit_turn.py --state PATH --patch JSON [--format yaml|json] [--out PATH]`; on success atomically replaces one file then prints live slice | Exactly one call; no transaction ID/idempotency/receipt. Exit failure means no write only when process outcome is observed normally |
| Structural validation | `validate_state.validate_data(data, profile)` and `validate_text`; profiles `save|opening` | Pure structural/reference gate; does not establish narrative truth or semantic permission |
| Observational state fingerprint | Caller can hash exact state bytes before and after because the runtime stores one YAML file | Continuity-defined observation, not a runtime revision/API; record path + SHA-256 + parsed turn/clock/scene |

Additional verified orchestration facts:

- Commands and IC/meta/retcon semantics are declarative model instructions in `commands.yaml` and `SKILL.md`, not callable router endpoints.
- Normal turn order is parse → previsualise/construct patch → `commit_turn.py` validate+write → use returned new live slice to render narrative.
- `retcon_add` only appends `{turn, note}` and does not undo, restore, supersede runtime fields, or decrement the turn.
- Runtime `checkpoint` is a five-turn calibration marker and changed-field hint, not a state snapshot.
- Named-slot optimistic concurrency is available only in `manage_saves.save_slot` through advisory lock + `manifest.updated_at`; `commit_turn.py` on `current_state.yaml` has no lock or CAS.

Unsupported APIs are explicit V1 constraints: no durable runtime transaction ID, idempotent commit, outcome query, runtime receipt/diff, native revision/hash, exact checkpoint restore, or native fork. V1 does not emulate or name any such API.

## 5. Authority Map

### 5.1 `adult-tension` exclusive mutable authority (source verified)

The v3 runtime state exclusively owns:

- `meta.turn`, mode/tier/simulation, `safety_state`, power structure and narration-view flags;
- world clock, setting shell, constants, tension engines and pressure seeds;
- current scene ID, location, participants, situation and unresolved/current node;
- player runtime card, resources and flat knowledge list;
- every NPC stable ID/name/age/role level, identity/profile, location, goal, boundary, emotion, resources, flat knowledge, recent memories, decision/personality/voice anchors, autonomy, sexuality profile/development and optional intimacy state;
- top-level relationship edges (`source`, `target`, `type`, `channel`, `trust`, `last_updated_turn`, `opening`);
- events, event lifecycle, pending scheduling, resolved summaries;
- boundaries, scene consent, current grants and grants archive;
- runtime retcon notes and calibration checkpoint fields.

Continuity must not write, mirror as independently current, or reconcile any of those values. Historical copies in episodes are immutable observations keyed to a source-state fingerprint and can never be fed back as runtime patches.

### 5.2 Continuity authority after collision resolution

Continuity may own only semantic structures not present as mutable runtime authority:

- versioned long-term Canon propositions **excluding all runtime-owned field values**;
- Canon admission/status/supersession/provenance and bitemporal interpretation of continuity facts;
- external identity-resolution aliases/anti-merge metadata around runtime stable character IDs; the runtime ID remains identity authority;
- epistemic status/gating richer than runtime flat knowledge, while runtime knowledge remains authoritative for current NPC decisions;
- additional non-runtime relationship annotations (public surface, unresolved issues, interaction patterns, do-not-regress markers), never `type/channel/trust` or permission;
- continuity-only commitments that do not duplicate runtime events; any scheduled/triggerable commitment is reference-only to an adult runtime event;
- thread/reveal/presentation/anti-merge ledgers that do not duplicate current situation or event state;
- bitemporal annotations for continuity facts; runtime clock/event timing remains runtime-owned;
- exact episode/evidence archive and retrieval provenance as an observational log;
- sidecar processing/checkpoint metadata, never a runtime restore point.

### 5.3 Ownership collision audit

| Proposed continuity area | Classification | Resolution |
|---|---|---|
| Canon | `SPLIT_AUTHORITY` | Runtime-owned current values and explicit runtime retcon notes remain runtime authority; continuity Canon is limited to non-runtime propositions and version semantics |
| Entity | `REFERENCE_ONLY` | Runtime character IDs/names/role levels/cards are authoritative; continuity registry keys aliases and retrieval metadata to `(campaign_id, runtime_entity_id)` and cannot merge/change runtime entities |
| Knowledge | `SPLIT_AUTHORITY` | Runtime `player.knowledge`, `npcs[].knowledge`, decision-card knowledge and current-node knowledge gap drive current decisions; richer epistemic states are continuity-owned annotations and must never contradict/promote runtime knowledge automatically |
| Relationship semantics | `SPLIT_AUTHORITY` | Runtime owns edge identity/type/channel/trust; continuity owns only named additional semantics with runtime edge references |
| Commitments | `SPLIT_AUTHORITY` | Runtime events own every scheduled/triggerable future obligation; continuity-only conversational promises may exist, but once operationalised they reference an event and do not duplicate status/due/trigger |
| Threads | `SPLIT_AUTHORITY` | Runtime current situation/events own active operational pressure; continuity owns narrative thread semantics/gates only |
| Temporal facts | `SPLIT_AUTHORITY` | Runtime owns clock/turn/event due/status; continuity owns bitemporal metadata only for continuity-owned facts and historical observations |
| Episodes | `NO_COLLISION` | Runtime has no durable scene/episode ledger; `resolved_summary` is event summary, not episode history |
| Checkpoints | `REFERENCE_ONLY` | Runtime `checkpoint` is calibration metadata, not snapshot/restore. Sidecar processing checkpoints reference state fingerprints only |

**Initial collisions found: 7; collisions remaining after these restrictions: 0.** No “last writer wins,” reverse sync, or dual current truth is permitted.

### 5.4 Derived/rebuildable only

Embeddings, lexical/BM25 index, vector index, graph index, generated summaries, relevance/drift scores, retrieval cache, entity merge candidates, activation predictions, and working cache. Every persisted derived object carries `classification: DERIVED_REBUILDABLE`, `source_fingerprint`, and `builder_version`. It can never write back into either authority.

## 6. Data Ownership Matrix

| Datum | Mutable authority | Continuity representation | Write-back allowed? |
|---|---|---|---|
| Current consent/grant/boundary/safety/intimacy/sexuality | adult runtime | Opaque source-state/event observation only | Never |
| Historical adult interaction or old grant | adult runtime history when retained; otherwise observational episode | Hashed historical evidence, explicitly non-current | Never to permission/state |
| Turn/clock/scene/location/participants/current situation | adult runtime | State fingerprint + selected read-only references | Never |
| NPC ID/name/role/card/goal/emotion/autonomy/memory/current knowledge | adult runtime | Runtime-ID reference; optional immutable episode observation | Never |
| Player runtime card/current knowledge | adult runtime, with player sovereignty over authored internals | Reference/observation | Never |
| Relationship edge/type/channel/trust | adult runtime top-level graph | Edge reference and observed value at a fingerprint | Never |
| Extra long-term relationship annotations absent from runtime schema | continuity | Namespaced semantic records | Continuity only; no trust/permission derivation |
| Runtime event/pending obligation | adult runtime | Stable event-ID reference | Never |
| Conversational commitment with no scheduler semantics | continuity | Commitment record; becomes reference-only if linked to runtime event | Continuity only |
| Runtime character identity | adult runtime stable ID | `(campaign_id, runtime_entity_id)` registry reference | Never merge/change runtime entity |
| Alias/identity-resolution metadata | continuity | Candidate/confirmed aliases and anti-merge constraints | Continuity only |
| Current decision knowledge | adult runtime flat knowledge and knowledge gap | Reference-only | Never |
| Epistemic distinctions absent from runtime (`suspects`, `false_belief`, planes) | continuity | Observer/proposition annotation, bounded by runtime knowledge | Never auto-promote runtime knowledge |
| Current operational pressure/event/thread state | adult runtime | Event/situation references | Never |
| Long-term thread semantics/reveal gates | continuity | Namespaced semantic ledger | Continuity only; cannot resolve runtime event |
| Runtime turn/world/event time | adult runtime | Copied observation for provenance | Never |
| Bitemporal metadata for continuity facts | continuity | Versioned fact interval | Continuity only |
| Episode/evidence archive | continuity | Immutable source envelopes with pre/post fingerprints | Never replay as patch |
| Runtime checkpoint | adult runtime calibration marker | Reference only | Never treat as snapshot |
| Sidecar processing checkpoint/recovery journal | continuity | Own commit sequence + observed runtime fingerprint | Never claim runtime restore |
| Context Pack/trace/cache/index | derived | Ephemeral/rebuildable | Never |

**Collision invariant:** a continuity schema field must be namespaced and rejected if it attempts to encode a second mutable value for any adult-owned datum above. `runtime_ref` and `observed_at` are permitted; mutable mirrors are not.

## 7. Proposed directory layout

The initially suggested set of many independently mutable YAML files is rejected as V1 live authority: cross-file updates are not atomic, referential integrity is weak, and branch/recovery semantics become fragile.

```text
adult-tension-continuity/
├── SPEC_LOCK.md                 # this phase's only artifact
├── SKILL.md                     # deferred implementation phase
├── references/                  # deferred prose/schema references
├── schemas/                     # deferred JSON Schemas
├── state/
│   └── continuity.sqlite3       # proposed authoritative V1 sidecar store
├── history/
│   ├── VOL-001.jsonl            # append-only exact episode/evidence envelopes
│   └── ...
├── indexes/                     # DERIVED_REBUILDABLE lexical/vector/graph files
├── cache/
│   └── working_cache.json       # DERIVED_REBUILDABLE rolling cache
├── manifests/
│   └── manifest.json            # hashes, volume boundaries, schema/builder versions
└── scripts/                     # deferred implementation, only after unblock
```

File audit:

- `CONTINUITY.md`: redundant with a concise future `SKILL.md` plus references; do not create both.
- `canon.yaml`, `entities.yaml`, `knowledge.yaml`, `relationships.yaml`, `commitments.yaml`, `threads.yaml`: acceptable as human-reviewed import/export snapshots, **not** simultaneous live authorities. SQLite tables should be authoritative in V1.
- `scene_index.jsonl`: index is derived; authoritative scene envelopes belong in append-only history plus transactional SQLite metadata. A generated JSONL export is acceptable.
- `working_cache.yaml`: use JSON or SQLite derived cache; always disposable.
- `recovery.yaml`: reject as mutable recovery authority; transaction journal/checkpoint tables need atomic state transitions.
- `manifest.yaml`: JSON is easier to canonicalise and hash, but either format is acceptable if it is metadata, never Canon.
- `history/VOL-*.jsonl`: accepted for immutable episode/evidence envelopes with checksums and branch IDs.
- Named scripts are conceptual responsibilities, not approved runtime interfaces. `sync_turn` must consume a sidecar-staged candidate plus a verified post-commit state observation `(H0,H1)`, never scrape narrative or assume a runtime receipt.

## 8. Canon schema

Separate admission, semantic status, information plane, and temporal validity; do not overload one `status` field.

```yaml
fact_id: FACT-...
branch_id: BR-...
subject_ref: ENT-...
predicate: stable.machine.key
object: {type: scalar|entity|structured, value: ...}
plane: OBJECTIVE|AUTHOR
admission_state: CANDIDATE|COMMITTED|REJECTED
truth_status: ACTIVE|ACTIVE_INTERPRETATION|HISTORICAL_FACT|SUPERSEDED|UNRESOLVED|PENDING|AUTHOR_PLAN
valid_from: {turn: 120, world_time: optional}
invalid_at: null
recorded_at: {turn: 500, timestamp: ...}
recorded_tx: CTX-...
superseded_recorded_at: null
supersedes: [FACT-...]
provenance: [{episode_id, runtime_event_ref, source_kind, exact_pointer, hash}]
confidence: explicit|verified|contested
scope: world|entity|relationship|location|branch
```

Rules:

1. Current objective truth requires `plane=OBJECTIVE`, `admission_state=COMMITTED`, `truth_status=ACTIVE`, branch visibility, and validity at query time.
2. `ACTIVE_INTERPRETATION` is an admitted interpretation, not an objective predicate. It cannot satisfy an objective `requires` clause without an explicit gate.
3. `HISTORICAL_FACT` was true during a closed valid interval; it is not current.
4. `SUPERSEDED` records correction/retcon lineage and is preserved.
5. `UNRESOLVED` represents a recorded conflict; normal packs may include the conflict only when relevant, never select a winner.
6. `PENDING` is an unfulfilled proposed state, not truth.
7. `AUTHOR_PLAN` must have `plane=AUTHOR`; no automatic process can change it to `OBJECTIVE`.
8. `CANDIDATE` is admission state, not Canon. LLM extraction starts here.
9. A supersession operation names affected facts, relationships, knowledge records, and threads in one continuity transaction.

## 9. Entity schema

```yaml
entity_id: ENT-...
branch_scope: global|BR-...
kind: player_character|npc_main|npc_important_supporting|npc_minor|place|object|organisation
canonical_name: ...
aliases: [{value, valid_from, invalid_at, provenance}]
identity_status: confirmed|disputed|merge_candidate|split_candidate
external_runtime_ref: optional
anchors:
  identity_core: [...]
  personality_core: [...]
  normal_mode: [...]
  stress_mode: [...]
  relationship_specific_behavior: [{counterpart_ref, pattern}]
  failure_pattern: [...]
  uncertainty_behavior: [...]
  capability_limits: [...]
  explicit_non_capabilities: [...]
  voice_anchor: {features: [...], evidence_refs: [...]}
  things_they_would_not_do: [{claim, basis, strength}]
anchor_provenance: [...]
last_admitted_revision: ...
```

Identity resolution yields `resolved`, `ambiguous`, `not_found`, or `merge_candidate`. Name similarity, alias overlap, embedding similarity, and apparent shared backstory may create a candidate only. Merge requires an explicit authority decision and an auditable remap plan. `anti_merge` constraints take precedence over scoring.

Re-entry chain: mention → resolve stable ID → request runtime card through verified adapter → load hard continuity anchors → filter knowledge by subject/time/branch → load non-permission relationship semantics → load commitments → DEEP episodic retrieval → build traceable pack → allow re-entry. Any missing hard dependency is surfaced, not fabricated.

## 10. Knowledge schema

Knowledge is proposition-relative, observer-relative, time-relative, branch-relative, and evidence-backed.

```yaml
knowledge_id: KNOW-...
branch_id: BR-...
subject_ref: ENT-observer
proposition_ref: FACT-...|PROP-...
state: does_not_know|partial|suspects|knows|false_belief
belief_content: optional              # required for false_belief/partial
plane: CHARACTER
valid_from: {turn, world_time: optional}
invalid_at: null
recorded_at: {turn, timestamp}
source: witnessed|told_by|inferred|author_directive|retcon
promotion_basis: {from_state, event_ref, evidence_refs}
confidence: optional
provenance: [...]
```

Five planes are independently gated:

1. **AUTHOR:** plans and privileged design notes.
2. **OBJECTIVE:** admitted world truth.
3. **PLAYER_VISIBLE:** information shown to the human, including narration.
4. **CHARACTER:** per-character epistemic state.
5. **PRESENTATION:** permission to expose information now and in what form.

No implication exists between adjacent planes. Promotions are explicit ledger operations containing source, basis, turn, and evidence. In particular: narration shown to the player does not teach the player character; one character’s knowledge does not propagate; suspicion does not become knowledge; and knowledge does not waive a reveal gate.

`does_not_know` should usually be represented only when explicitly relevant; absence of a knowledge record means `UNKNOWN_TO_SYSTEM`, not proof that the character does not know.

## 11. Relationship schema

Continuity stores long-term semantics only where the repository audit proves no ownership collision.

```yaml
relationship_id: REL-...
branch_id: BR-...
parties: [ENT-A, ENT-B]
direction: A_to_B|B_to_A|mutual_component
runtime_refs: [{field, revision}]       # authoritative runtime relation/trust stays external
semantics:
  familiarity: qualitative|optional_scale
  affection: qualitative|optional_scale
  comfort: qualitative|optional_scale
  resentment: qualitative|optional_scale
  fear: qualitative|optional_scale
  respect: qualitative|optional_scale
  dependency: qualitative|optional_scale
  attraction: qualitative|optional_scale
public_surface: ...
actual_relation: ...
relationship_phase: ...
information_asymmetry: [KNOW-...]
unresolved_issues: [TH-...]
interaction_patterns: [{pattern, evidence_refs, confidence}]
do_not_regress_to: [{state, basis}]
last_changed_turn: ...
provenance: [...]
```

Dimensions may be qualitative, directional, sparse, and contradictory. Attraction is not consent; affection is not a grant; dependency is not permission; prior intimacy is not current permission. Relationship updates cannot call or emulate the adult state machine.

## 12. Commitment schema

Commitments are first-class and distinct from runtime `pending_events`.

```yaml
commitment_id: COM-...
branch_id: BR-...
type: promise|appointment|borrowed_object|debt|callback|unanswered_question|interrupted_conversation|future_disclosure|confidentiality|check_in|other
issuer_ref: ENT-...
beneficiary_refs: [ENT-...]
content: ...
status: open|due|fulfilled|broken|waived|cancelled|superseded
created_event_ref: ...
due: {turn: optional, world_time: optional, condition: optional}
linked_runtime_pending_event_ref: optional
resolution_event_ref: optional
known_by: [{entity_ref, knowledge_ref}]
valid_from: ...
invalid_at: null
recorded_at: ...
provenance: [...]
```

A commitment can create a runtime scheduling request only through a future verified adapter and explicit runtime validation. It never duplicates or silently alters pending-event authority. Time jumps query all branch-visible open/due commitments.

## 13. Thread schema

```yaml
thread_id: TH-...
branch_id: BR-...
title: ...
status: dormant|active|blocked|resolved|abandoned|superseded
first_turn: ...
last_turn: ...
author_state: ...
objective_state: ...
player_visible_state: ...
known_by: [{entity_ref, knowledge_ref}]
requires:
  mode: all|any
  clauses: [{ref, expected_state, plane, temporal_scope}]
possible_links: [{thread_ref, confidence, status: candidate|confirmed}]
reveal_gate: [{audience_ref, prerequisites, allowed_exposure: partial|full}]
presentation: {allowed_now, form, spoiler_level, basis}
source: [{episode_ref, fact_ref}]
anti_merge: [{other_ref|pattern, reason, authority_source}]
provenance: [...]
```

When `requires` is unsatisfied, generation may increase pressure, ambiguity, suspicion, or partial exposure only if the relevant presentation gate allows it. It may not reveal the protected proposition. Similar mysteries remain separate unless an explicit authority operation confirms a link; `anti_merge` is a hard retrieval/generation constraint.

## 14. Temporal model

The sidecar uses bitemporal semantics:

- `event_time`: when an event occurred in-world (turn range plus optional world time).
- `valid_from` / `invalid_at`: interval during which a proposition is true in-world.
- `recorded_at`: when the system learned or admitted the record.
- transaction time: immutable continuity commit sequence used for reconstruction.

Example: at Turn 500, evidence establishes a resignation occurred at Turn 120. The fact has `valid_from.turn=120`, `recorded_at.turn=500`; any pre-500 character knowledge remains unchanged unless separately promoted. A later correction closes the old fact using its world-valid interval and records a superseding version at the correction transaction. Retroactive discovery changes queryable objective history, not past presentation or past character knowledge.

All temporal queries specify:

- branch;
- objective event/world time (`as_of_event`);
- system knowledge/transaction time (`as_known_at`);
- information plane and observer, where relevant.

This prevents later knowledge from leaking into historical replay.

## 15. Scene/history schema

Do not create one large file per turn. Store append-only scene/episode envelopes in bounded volumes and transactional pointers in SQLite.

```yaml
scene_id: SCENE-...
branch_id: BR-...
turn_start: ...
turn_end: ...
world_time_start: ...
world_time_end: ...
locations: [ENT-...]
participants: [ENT-...]
summary: {text, classification: DERIVED_REBUILDABLE, builder_version}
facts_created: [FACT-...]
knowledge_changed: [KNOW-...]
relationships_changed: [REL-...]
commitments_created: [COM-...]
commitments_resolved: [COM-...]
threads_touched: [TH-...]
runtime_commit_refs: [...]
history_pointer: {volume, byte_start, byte_end, sha256}
```

The exact episode envelope preserves source type, committed runtime receipt/reference, narrative/event payload as permitted, hashes, branch ID, and transaction ID. Volume rotation uses size/scene-count boundaries and an atomic manifest update. Sensitive access restrictions from the runtime must be preserved; history storage does not broaden presentation permission.

## 16. Memory Admission policy

Admission starts only from a verified committed runtime receipt and the corresponding candidate journal. It does not scrape a possibly uncommitted final narrative.

| Candidate class | Deterministic auto-commit | LLM extract + deterministic validation | Director approval required | Never auto-promote |
|---|---|---|---|---|
| `runtime_delta` | Runtime event reference and hash only | No | For reinterpretation | Any duplicated runtime-owned current value |
| `objective_fact_candidate` | Explicit structured Director command; verified runtime event facts within ownership | Yes, as candidate | Ambiguous/new Canon, contradiction, retcon | Plans, guesses, narration embellishment |
| `character_knowledge_delta` | Direct witnessed/told structured event with named subject and gate | Yes | Ambiguous inference/high-impact secret | Cross-character propagation; suspicion→knowledge |
| `relationship_delta` | Explicit non-permission consequence under validated rules | Yes | Major phase/redefinition or collision | Consent/grant/boundary/intimacy permission |
| `commitment_delta` | Explicit promise/question/transfer from committed event | Yes | Ambiguous obligations, waiver/retcon | Invented promise or runtime event duplication |
| `thread_delta` | Touch timestamps and explicit gate satisfaction | Yes | Merge/link/reveal-authority changes | Mystery merge from similarity |
| `episodic_memory` | Scene envelope/pointer after commit | Summary may be generated as derived | No for exact envelope | Generated summary as Canon |
| `character_anchor_candidate` | Explicit Director assertion only | Yes | Always for new/changed hard anchor | Statistical drift observations |
| `discard` | Yes, retain admission decision metadata only | Optional | No | Filler/repetition as Canon |

Validation checks schema, ownership, branch, stable IDs, provenance, temporal consistency, information-plane transition, permission invariants, supersession targets, anti-merge, and runtime receipt identity. LLM output can propose candidates but cannot approve its own proposal.

## 17. Retrieval architecture

Stable interface:

```text
Retriever.retrieve(query, branch, event_time, observer, planes, budget, mode)
  -> ranked RetrievalItem[] + RetrievalTrace[] + insufficiency flags
```

V1 implementations:

- `LexicalRetriever`: SQLite FTS5 if available, otherwise deterministic token/BM25-compatible index.
- `EntityRetriever`: IDs, aliases, participants, relationships, commitments.
- `TemporalRetriever`: valid interval, recency, turn/scene range.
- `LedgerRetriever`: facts, knowledge, threads, gates, anti-merge.
- `EvidenceRetriever`: exact append-only history pointers and hashes.
- `HybridRetriever`: weighted reciprocal-rank fusion; no score changes authority.

Future `VectorRetriever` and `GraphRetriever` plug into the interface. Their outputs remain candidates for activation, never truth. Negative filters remove wrong branch, superseded-as-current, wrong observer/plane, disallowed presentation, anti-merge conflicts, expired records, and runtime-owned duplicates.

## 18. FAST / DEEP / EVIDENCE routing

- **FAST:** default ordinary turn. Hard-pin live runtime snapshot references, participants’ hard anchors, current non-permission relationship constraints, open/due commitments, and directly active threads. Add small recent episodic window.
- **DEEP:** trigger on supporting-character return, long time jump, identity/secret/thread mention, major relationship change, ambiguity, contradiction, low entity resolution confidence, or explicit recall. Expand entity, temporal, commitments, knowledge, and episodes.
- **EVIDENCE:** trigger on exact quote/action/object/time/source/old promise requests, contested Canon, retcon impact analysis, or low-confidence precision. Retrieve exact hashed source spans.

A query may escalate FAST → DEEP → EVIDENCE based on insufficiency. Exact claims require evidence. EVIDENCE miss returns `EVIDENCE_INSUFFICIENT`; generation must state uncertainty or ask for clarification and must not manufacture detail.

## 19. Context Pack schema

Context Pack is ephemeral, immutable for one decision, and non-authoritative.

```yaml
pack_id: CP-...
branch_id: BR-...
runtime_state_sha256: ...
query_turn: ...
mode: FAST|DEEP|EVIDENCE
budget: {max_tokens, used_tokens}
sections:
  - item_id: ...
    classification: AUTHORITY_REFERENCE|HISTORICAL_EVIDENCE|DERIVED_REBUILDABLE
    source_ref: ...
    activation_reason: ...
    priority: integer
    token_cost: integer
    confidence: ...
    inclusion: hard|soft
    plane: ...
    observer_scope: ...
    temporal_scope: ...
    negative_filters_passed: [...]
    content: ...
retrieval_trace_ids: [...]
insufficiency: [{claim, mode_attempted, reason}]
```

Hard inclusion means “must be presented to the decision model,” not “is automatically objective.” Runtime adult-safety/permission references have highest precedence but their internal values and interpretation remain controlled by the runtime contract.

## 20. Retrieval Trace schema

```yaml
trace_id: RT-...
pack_id: CP-...
item_id: FACT-081
retriever: EntityRetriever|LexicalRetriever|TemporalRetriever|EvidenceRetriever|...
activation_reason: "TH-004 requires"
scores: {semantic: null, lexical: 0.71, entity: 1.0, temporal: 0.8}
hard_pin: false
source_refs: [...]
filters_applied: [branch, validity, plane, presentation, anti_merge]
decision: included|excluded|budget_dropped|insufficient
rank: 3
token_cost: 42
builder_version: ...
```

Traces allow diagnosis of retrieval miss versus model non-compliance. They are derived audit records and cannot establish truth.

## 21. Transaction model

### 21.1 Source-verified runtime path

The runtime path is:

```text
user input
→ model interprets commands using commands.yaml/SKILL.md
→ read prior committed live slice
→ model previsualises result and constructs JSON delta patch
→ commit_turn loads full YAML
→ load/parse patch
→ deepcopy + ordered in-memory mutation
→ validate_state.validate_data(candidate, "save")
→ same-directory tempfile write + file fsync + os.replace of one state file
→ extract and print new live slice
→ model writes narrative from that committed slice
```

The patch mutation order is verified as: turn/meta and clock → grant withdrawal/addition → scene/location/participants and grant archive/inheritance → current-node fields → player knowledge/location → NPC fields/knowledge/memory/autonomy and NPC addition → relationship edge → retcon note → event resolve/add/update/cancel plus due expiration → boundaries → calibration checkpoint → whole-state validation → one-file replacement → live-slice output.

### 21.2 V1 fail-closed sidecar protocol

V1 must adapt to the absence of distributed-transaction support. It therefore uses **post-commit observational synchronisation**, not a two-authority atomic commit and not a runtime rollback saga:

```text
1  Parse IC/meta/retcon according to existing model contract.
2  Read exact runtime YAML bytes R0 once; compute H0=SHA-256(R0); parse and save turn/clock/scene.
3  Build continuity Context Pack against the last sidecar sync whose runtime hash is H0.
   If no matching baseline exists, enter READ_ONLY_DEGRADED and do not admit Canon.
4  Produce the runtime patch and optional continuity candidates in memory.
5  Pure preflight: run commit_turn.commit(parsed_R0, patch) and continuity/player/adult invariant gates.
   Compare the candidate's structural result only; do not write a runtime file.
6  Durably insert a sidecar PREPARED WAL row containing H0, patch hash, deterministic candidate-state hash,
   candidate admissions, and Context Pack/trace hashes. If this staging fails, do not invoke runtime commit.
7  Immediately re-read the runtime path. If its bytes no longer hash to H0, mark STALE_BASE and abort.
8  Invoke the real commit_turn CLI exactly once. Do not use --out to redirect authority.
9  A normal nonzero exit means runtime not written because all handled load/patch/validation errors precede write.
10 A normal zero exit means replacement returned and stdout is the new live slice. Re-read exact bytes R1,
   validate them, compute H1, and require expected turn/clock/scene plus deterministic candidate-state equality.
11 Only after step 10, finalise episode/admission/trace/sync metadata in one sidecar SQLite transaction keyed
   uniquely by `(H0,H1)`; update the PREPARED WAL row rather than creating a second logical operation.
12 Render/release narrative from the verified committed R1/live slice. Sidecar finalisation failure does not undo
   R1; it suppresses Canon admission, leaves the durable PREPARED row for forward recovery, and permits runtime
   narrative only with an explicit continuity-degraded marker in orchestration state.
```

Because `commit_turn.py` has no CAS/lock, steps 2–7 cannot prevent another direct runtime writer between the second hash check and `os.replace`. V1 deployment is therefore **single-writer only**: while continuity orchestration owns a turn, no other process may invoke `commit_turn.py` or write `current_state.yaml`. This is an operational precondition, not a fabricated runtime feature. If exclusive-writer control cannot be established, V1 must remain read-only and refuse continuity-coupled commits.

### 21.3 Unknown outcome and recovery

- If the commit process exits normally, use its exit code and post-read verification.
- If the caller crashes, is killed, loses the process result, or the file read becomes unavailable during/after replacement, classify `RUNTIME_OUTCOME_UNKNOWN`.
- There is no safe automatic retry because the runtime is not idempotent and a repeated patch normally advances turn/time again.
- On next recovery, compare the actual runtime bytes against H0 and the exact preflight candidate bytes/state:
  - actual hash/state equals H0 → commit did not become visible; mark aborted; a user may explicitly retry as a new operation;
  - actual parsed state equals the deterministic candidate (even if serialised bytes differ) → runtime committed; sync sidecar forward once under unique `(H0,H1)`;
  - neither → `MANUAL_RECONCILIATION_REQUIRED`; do not apply the patch, admit memory, or guess an outcome.
- Runtime commit success with sidecar failure is recoverable forward from verified R1 because the staged continuity candidate bundle and H0/H1 evidence remain in the sidecar WAL. If the WAL itself was never durably staged, continuity performs evidence-only rescan and requires review for semantic admissions.
- Narrative delivery failure after both commits may replay the exact stored candidate narrative only if it was generated from R1 and content-hashed; it must never recommit the turn.

### 21.4 Atomicity statement

`_common.write_atomic` provides atomic replacement of the single runtime YAML file on the same filesystem after file `fsync`. It does **not** provide optimistic concurrency, a runtime lock, a transaction ID, idempotency, an outcome query, a commit receipt, a native revision/hash/diff, parent-directory `fsync`, or cross-store atomicity. Named-slot `manage_saves.py` has an advisory lock and `updated_at` CAS, but that protection does not apply to `commit_turn.py` and is not the ordinary turn integration point.

## 22. Checkpoint / branch / recovery model

### 22.1 Runtime checkpoint truth

The runtime `checkpoint` object contains `last_full_turn`, `next_full_turn`, `changed`, `force_full`, `force_reason`, and two true invariants. It is a periodic/deep-calibration marker and a small changed-field list. It has no checkpoint ID, parent, saved state body, revision, hash, restore operation, replay operation, or fork operation. `retcon_add` appends a note and advances according to the patch; it does not restore history.

Therefore V1 renames its own record to **sidecar processing checkpoint** to avoid semantic collision:

```yaml
sync_id: CSYNC-...
campaign_id: ...
continuity_branch_id: CBR-...
parent_sync_id: CSYNC-...|null
runtime_path: ...
runtime_pre_sha256: ...
runtime_post_sha256: ...
runtime_turn: ...
runtime_clock: ...
runtime_scene_id: ...
continuity_tx_seq: ...
continuity_hash: ...
transaction_state: PREPARED|RUNTIME_VERIFIED|COMMITTED|RUNTIME_OUTCOME_UNKNOWN|MANUAL_REVIEW|ABORTED
validation_state: VALID|INVALID|PENDING
created_at: ...
```

This record proves what sidecar version was synchronised to an observed runtime file; it cannot restore runtime state.

### 22.2 V1 operation boundaries

- **Rewind:** historical read/query only. It may build an EVIDENCE pack as-of an old sidecar sync. It does not move or mutate runtime.
- **Fork:** not a native V1 runtime operation. Named save slots can preserve separately named state copies through explicit existing save commands, but they expose no lineage/parent semantics and continuity must not call that a runtime fork. Automated coordinated fork is Deferred V2.
- **Retcon:** uses the existing Director-style language contract and runtime `retcon_add` note plus the actual runtime patch needed for the new current result. Continuity records supersession only for continuity-owned records. It cannot claim the runtime rewound or preserved a restorable old branch.
- **Supersession:** continuity record-version operation only; runtime field replacement remains a new runtime commit.

A request such as “刚才那段不算，从进门以前重新来” cannot be implemented as an exact runtime fork or restore by current APIs. In V1 it must either: (a) use the existing retcon semantics without pretending to rewind, after clearly routing as an explicit rewrite; or (b) fail closed when the user specifically requires exact branch/restore semantics. Old exact state can be evidence in continuity only if it was previously archived; it is not a runtime restore point.

### 22.3 Recovery status

V1 recovery is forward-only observational reconciliation as specified in §21. It can recover sidecar-behind after a uniquely identified H0→H1 runtime transition. It cannot automatically resolve a state that matches neither H0 nor the deterministic candidate, and it never rolls runtime back. Exact restore/fork, durable runtime transaction identity, idempotent retry, and native outcome query are Deferred V2 runtime capabilities, not V1 blockers because V1 explicitly refuses operations that need them.

## 23. Adult compatibility invariants

1. Continuity never creates, changes, clears, infers, promotes, validates, or overrides consent, grants, boundaries, safety, sexuality profile, intimacy permission, or current adult-interaction state.
2. Historical consent is never current consent. Historical adult interaction is never a current grant.
3. Attraction, trust, affection, dependency, familiarity, relationship phase, and memories cannot satisfy adult runtime permission checks.
4. All current adult interaction decisions are delegated to the runtime authority using a verified committed snapshot.
5. A Context Pack may reference the runtime authority but cannot cache its permission result across turns/revisions.
6. Adult historical events retain provenance and access/presentation restrictions; retrieval does not broaden permission.
7. Continuity validation fails closed on ownership collision or stale runtime revision.
8. No recovery, retcon, rewind, or fork is complete unless runtime and sidecar refer to the same branch/checkpoint semantics.
9. Sidecar failure never triggers a guessed adult runtime rollback or a second commit.
10. Neither narrative generation nor memory admission is an alternative adult-state transition path.

## 24. Player sovereignty invariants

1. Default mode is IC/ROLEPLAY. User input expresses the player character’s dialogue, actions/attempts, explicit feelings, intentions, internal state, and decisions; it does not force world outcomes or NPC belief/reaction.
2. NPC minds, beliefs, feelings, judgement, and responses follow NPC state, evidence, knowledge, motives, boundaries, and autonomy.
3. DIRECTOR/AUTHOR mode requires explicit routing and confirmation for ambiguous high-impact commands; it may alter Canon/history/results only through versioned authority operations.
4. The model cannot invent player-character internal state (for example, declaring love or jealousy) without explicit user content or enabled narrator-assist.
5. Player-visible narration is not player-character knowledge.
6. Author intent is not objective truth; requested outcomes remain plans until explicitly committed through Director authority.
7. IC attempts cannot be silently reclassified as Director commands.
8. Fork/retcon requests preserve branch evidence and require explicit scope.

## 25. Failure modes

| Failure | Required response |
|---|---|
| Repository/API absent or schema unknown | Block integration; do not infer fields |
| Runtime revision changes during generation | Discard DecisionBundle and rebuild |
| Entity resolution ambiguous | Surface ambiguity; no merge/no hard facts |
| Retrieval misses a needed exact fact | Escalate to EVIDENCE, then report insufficiency |
| Superseded fact retrieved as current | Validation failure; remove and rebuild index/pack |
| Plane leak | Block item, record failed gate, invalidate pack |
| `suspects` used as `knows` | Validation failure |
| Thread prerequisite unmet | Restrict to allowed pressure/partial exposure |
| LLM candidate conflicts with Canon | Keep candidate/unresolved; authority review |
| Runtime commit succeeds, sidecar fails | `NEEDS_RECOVERY_RUNTIME_AHEAD`; reconcile forward |
| Runtime commit outcome unknown | Query by transaction identity; never blind retry |
| Sidecar commits, narrative delivery fails | Replay exact committed output; no second commit |
| Manifest/index corrupt | Rebuild derived data from SQLite + verified history; do not rewrite Canon |
| History volume hash mismatch | Quarantine affected evidence range; manual review |
| Branch contamination | Block query, rebuild scoped indexes, preserve audit evidence |
| Adult ownership collision | Reject continuity mutation |
| Player sovereignty violation | Reject candidate narrative before commit |
| Token budget overflow | Drop lowest-priority soft items; never hard constraints |
| Voice/drift false positive | Advisory only; never mutate anchors automatically |

### Voice/character drift and human texture

A disposable rolling cache may track recent lines, actions, emotion outlets, initiative distribution, syntactic/lexical voice features, and plot-function concentration. It produces warnings such as repetition, voice convergence, tag over-execution, or one-character initiative monopoly. Warnings are `DERIVED_REBUILDABLE`, never Canon, never hard quotas, and never an instruction to violate runtime autonomy.

Human texture is an allowed distribution, not a checklist: characters may be bored, tired, hungry, sleepy, unwilling to discuss, mistaken about small things, unsuccessful at jokes, unhelpful, occupied with ordinary preferences, or resistant to plot efficiency. Character anchors constrain identity without making traits absolute. Hard impossibilities must be distinguished from tendencies and evidence-backed “would not normally” anchors.

## 26. P0 regression tests

All tests require fixtures proven against the real runtime adapter. Current status is `DESIGNED / NOT RUN`.

| ID | Scenario | Required assertion |
|---|---|---|
| P0-01 | Important supporting NPC returns after 150 turns | Stable ID, anchors, scoped knowledge/relationship/commitments and relevant episode retrieved via DEEP |
| P0-02 | A knows a secret; B does not | B’s pack/presentation never uses A’s knowledge after long gap |
| P0-03 | Suspicion persists | `suspects` never auto-promotes to `knows` |
| P0-04 | Current fact superseded | Ordinary current Context Pack excludes old value; EVIDENCE can retrieve lineage |
| P0-05 | Fork after retcon/rewind | Old branch cannot contaminate new branch indexes, packs, or admissions |
| P0-06 | Same-name NPCs | Resolver returns ambiguity; no automatic merge |
| P0-07 | Alias/fake identity | Only merge candidate created; authority gate required |
| P0-08 | Promise over long time jump | Commitment remains open/due and is retrieved |
| P0-09 | Adult interaction history | History can be retrieved but no consent/grant/boundary/safety/intimacy mutation is emitted |
| P0-10 | Player sees NPC inner narration | No player-character knowledge promotion |
| P0-11 | Exact historical question | Router escalates to EVIDENCE |
| P0-12 | Exact evidence unavailable | Emits insufficiency; no fabricated quote/action/time/object |
| P0-13 | Runtime succeeds, sidecar sync fails | Durable `NEEDS_RECOVERY_RUNTIME_AHEAD`, idempotent forward recovery, no duplicate runtime commit |
| P0-14 | Retrieval explanation | Every important pack item has source, reason, filters, rank and token cost |
| P0-15 | Nuanced personality | Anchors persist while ordinary moods, mistakes, and non-useful behaviour remain possible |
| P0-16 | Voice separation | Long-run fixtures detect convergence without automatically rewriting character voice |
| P0-17 | Historical consent/current permission | Prior consent and intimacy cannot satisfy current runtime permission |
| P0-18 | Relation/current permission | High trust/attraction cannot create consent or grant |
| P0-19 | Author plan separation | AUTHOR_PLAN never appears as objective current fact |
| P0-20 | Objective/player-visible separation | Hidden objective fact is not exposed without presentation gate |
| P0-21 | Player-visible/character separation | Narration visibility does not create any character knowledge record |
| P0-22 | Per-character promotion provenance | Every knowledge promotion records source, basis, turn, evidence |
| P0-23 | Retroactive discovery | Fact valid from Turn 120, recorded at Turn 500; past knowledge/presentation unchanged |
| P0-24 | Later correction | Old record preserved; supersession and affected-record ledger complete |
| P0-25 | Unmet thread `requires` | Only permitted pressure/suspicion/partial exposure occurs; no reveal |
| P0-26 | Thread anti-merge | Similar clues remain separate when hard anti-merge applies |
| P0-27 | Runtime revision race | Stale pack/DecisionBundle rejected before commit |
| P0-28 | Ambiguous IC command | “我要让她相信我” becomes attempt, not forced NPC belief |
| P0-29 | Player internal state | Model cannot invent feelings/intentions without narrator-assist |
| P0-30 | Explicit Director retcon | Versioned affected facts/relationships/knowledge/threads and provenance recorded |
| P0-31 | Commit failure before runtime write | No continuity authority mutation and no narrative release |
| P0-32 | Runtime outcome unknown | No blind retry; reconciliation by transaction identity |
| P0-33 | Delivery failure after commit | Exact output replay; no new decision or second commit |
| P0-34 | Context budget pressure | Hard authority constraints retained; only soft items dropped traceably |
| P0-35 | Derived index corruption | Rebuild reproduces authority-visible results; cannot overwrite Canon |
| P0-36 | Evidence hash mismatch | Evidence quarantined and exact claim blocked |
| P0-37 | Cross-branch exact evidence | Evidence retrieval honours branch and historical query time |
| P0-38 | Missing knowledge row | Treated as unknown-to-system, not `does_not_know` |
| P0-39 | Commitment vs pending event | Link is by reference; no duplicate mutable scheduler state |
| P0-40 | Sidecar ownership collision | Mutation rejected whenever audited runtime already owns datum |
| P0-41 | Re-entry missing runtime card | No fabricated card; degrade or block with explicit insufficiency |
| P0-42 | Retrieval versus adherence diagnosis | Trace distinguishes absent item from included-but-ignored item |
| P0-43 | Retcon does not erase evidence | Prior branch/version remains discoverable only in authorised historical mode |
| P0-44 | Adult state cache staleness | Permission reference cannot be reused across runtime revision |
| P0-45 | LLM memory extractor | Output remains candidate until independent validation/authority gate |
| P0-46 | False belief | Character can hold false belief without changing Objective plane |
| P0-47 | Runtime checkpoint mismatch | Fork/rewind operation blocks rather than creating sidecar-only illusion |
| P0-48 | Human texture guard | No mechanical quota; boredom/error/mundane action remains compatible with anchors |

## 27. Deferred V2 features

- Runtime changes, only in a separately approved adult-tension version, to add durable transaction ID, idempotent commit, outcome query, native revision/hash/diff receipt, and commit-time CAS/lock.
- Exact runtime snapshot restore, lineage-aware checkpointing, coordinated rewind/fork, and branch-aware save schema.
- Atomic or journaled named-slot state+manifest pair with directory durability guarantees.
- Optional embeddings and `VectorRetriever`.
- Derived temporal knowledge graph and `GraphRetriever`.
- External Graphiti/Mem0-compatible adapters without authority transfer.
- Cross-campaign entity federation.
- Automated contradiction explanation and retcon impact visualisation.
- Learned activation/reranking under deterministic gate filters.
- Rich authoring UI, branch visualiser, evidence browser, and relationship timelines.
- Cryptographic volume signing/remote archival beyond V1 checksums.
- Multi-process coordinator; V1 instead requires exclusive single-writer orchestration or degrades read-only.

## 28. Open questions and P0 resolution

The original 12 source-availability/runtime-contract questions are closed for architecture purposes:

1. Repository and revision are pinned in §31.
2. Save schema and ownership are mapped in §§3, 5, and 6.
3. Snapshot, validation, patch, write, and output contracts are mapped in §§4 and 21.
4. Runtime commit has no ID, idempotency, receipt, revision, outcome query, lock, or CAS; V1 no longer requires or assumes them.
5. Runtime checkpoint has no restore/fork semantics; exact restore/fork is deferred and V1 fails closed.
6. Narrative is source-contractually rendered after commit from the returned live slice.
7. Pure in-memory preflight exists through `commit(state, patch)`; it validates a deep-copied candidate but is not a runtime service API.
8. Consent/grant/boundary/safety/sexuality/intimacy ownership and schemas are runtime-exclusive.
9. IC/meta/retcon routing is a model-level contract in `SKILL.md`/`commands.yaml`, not a callable router.
10. The ordinary runtime state write is one-file atomic replacement without concurrency protection; V1 requires exclusive writer control or read-only degradation.
11. Runtime authorities versus derived projections are mapped; live slice is a non-authoritative read projection.
12. Adult history does not carry a separate machine access-control schema; continuity still preserves presentation gates and never converts history into permission.

**Unresolved P0 architecture issues: 0.** This does not imply that absent runtime features exist. V1's reduced contract excludes exact restore/fork, automatic retry of unknown outcomes, concurrent writers, and any continuity write-back to runtime. If the implementation environment cannot enforce the exclusive-writer precondition, continuity runs read-only and refuses coupled mutation; this is a defined fail-closed mode, not an unresolved architecture dependency.

Non-blocking implementation choices remain deferred: SQLite FTS5 availability/tokenizer, history-volume threshold, context budgets/ranking weights, campaign ID bootstrap, and narrator-assist UI wording.

## 29. ASSUMPTION_INVALID findings

Before source audit: **8**. After source audit: **11 verified corrections** (the count grows because source inspection exposed additional invalid assumptions; none remains an unresolved V1 dependency).

1. **ASSUMPTION_INVALID (closed):** the repository was unavailable. It is now pinned and fully readable at the audited SHA.
2. **ASSUMPTION_INVALID (closed):** `live_slice.py` was unverified. It is a pure, truncated projection with no revision/hash and explicit caps (pending 10, knowledge 8, recent memories 2).
3. **ASSUMPTION_INVALID (closed):** `commit_turn.py` transaction semantics were unknown. It deep-copies, mutates in fixed order, validates, replaces one YAML file atomically, and then prints a live slice.
4. **ASSUMPTION_INVALID (closed):** `validate_state.py` might be a general side-effect-free policy validator. Its functions are pure structural/referential validation, but they do not decide semantic consent, Canon truth, narrative adherence, or all player-sovereignty rules.
5. **ASSUMPTION_INVALID (closed):** proposed continuity Entity ownership was collision-free. Runtime owns stable character IDs and cards; continuity is reference/alias/anti-merge metadata only.
6. **ASSUMPTION_INVALID (closed):** proposed continuity Knowledge ownership was collision-free. Runtime owns flat player/NPC knowledge and current knowledge gap; continuity owns only richer annotations constrained by runtime state.
7. **ASSUMPTION_INVALID (closed):** proposed long-term Relationship ownership was collision-free. Runtime owns type/channel/trust edges; continuity owns only non-overlapping annotations.
8. **ASSUMPTION_INVALID (closed):** runtime `checkpoint` supports checkpoint/restore/fork. It is calibration metadata only; no restore or fork exists.
9. **ASSUMPTION_INVALID (closed):** a runtime commit receipt, durable transaction ID, idempotency, outcome query, revision/hash/diff, or current-state optimistic concurrency exists. None exists. V1 uses single-writer observational hashes and never blindly retries.
10. **ASSUMPTION_INVALID (closed):** the earlier saga could hold candidate narrative and commit runtime under a shared idempotency key. The source order commits runtime before narrative generation and accepts no key; V1 is changed to post-commit sidecar sync.
11. **ASSUMPTION_INVALID (closed):** off-scene `important_supporting` receives native re-entry retrieval. It remains in full state but is excluded from live slice unless participating; no recall API exists. Continuity DEEP retrieval supplies history/annotations while the orchestration must read the authoritative full NPC by stable ID at re-entry without copying it into sidecar authority.

Independent YAML authority files remain rejected as in the original design; that was a design correction, not a claim about an existing runtime API.

## 30. SPEC_LOCK acceptance checklist

### Design consistency

- [x] Goals and non-goals defined.
- [x] Single-authority rule stated and collision rule fail-closed.
- [x] Runtime-owned adult state excluded from continuity write authority.
- [x] Canon, entity, knowledge, relationship, commitment, thread, temporal, history, Context Pack, and retrieval-trace schemas specified.
- [x] Candidate-only LLM extraction and admission gates specified.
- [x] FAST/DEEP/EVIDENCE and evidence insufficiency specified.
- [x] HOT/WARM/COLD residency specified below.
- [x] Bitemporal semantics and information planes separated.
- [x] Post-commit observational/WAL recovery handles every source-supported partial-outcome class without assuming runtime rollback or retry.
- [x] Rewind, fork, retcon, and supersession distinguished.
- [x] Adult compatibility and player sovereignty invariants enumerated.
- [x] P0 regression matrix contains 48 cases.
- [x] No implementation code or adult Skill mutation performed.

### Required evidence before PASS

- [x] Actual `adult-tension` repository/revision inspected in full.
- [x] All requested files, scripts, references, tests, schemas, and transaction paths audited statically.
- [x] Ownership collisions resolved against source evidence.
- [x] Runtime snapshot/commit/failure capabilities confirmed; absent receipt/retry/fork capabilities explicitly excluded from V1.
- [x] Adult compatibility mapped to actual schema and patch channels.
- [x] Player mode routing mapped to the actual model-level command contract.
- [x] P0 integration issues reduced to zero through verified contracts or fail-closed V1 downgrade.

### Context residency

- **HOT:** current runtime live-slice reference; exact observed runtime state fingerprint; current participants’ hard anchors/capability limits; current non-permission relationship hard constraints; current critical commitments; active reveal/anti-merge gates; adult runtime authority reference. Hard-pinned and budget-protected.
- **WARM:** likely entrants; active/dormant relevant threads; observer-scoped knowledge; nearby/open commitments; relevant relationship semantics; recent episodes; candidate re-entry context. Activated by entity/keyword/semantic/temporal signals.
- **COLD:** exact old scenes/dialogue/actions; resolved/superseded records; old branches; archival episodes. Loaded only by DEEP/EVIDENCE or explicit historical inspection.

Residency is a retrieval policy, not truth status. Promotion between tiers changes only context presence, never authority.

## Internal consistency audit

Audit method: cross-reference the pinned source path, schema ownership, patch mutation order, write/failure paths, live-slice omissions, five information planes, sidecar branch scoping, retrieval filters, adult invariants, player invariants, and all 48 proposed P0 scenarios.

Results:

- Internal schema contradictions after source corrections: **0**.
- Ownership collisions found: **7**; resolved by `REFERENCE_ONLY`/`SPLIT_AUTHORITY` restrictions: **7**; remaining: **0**.
- Duplicated mutable authority: **0**.
- Adult compatibility violations: **0**.
- Player sovereignty architecture violations: **0**.
- Invented runtime API dependencies: **0**.
- Unresolved P0 architecture issues: **0**.
- Recovery model status: **PASS — source-adapted, fail-closed**. Automatic retry/rollback/fork are prohibited; single-writer observational H0→H1 reconciliation is the V1 boundary.
- Regression matrix count: **48**.
- Existing test suite inspected: **7 files / 129 tests**. No tests were run and no fixtures were modified.

### Existing test coverage classification

Counts below classify each existing test by primary purpose; categories are disjoint and total 129:

| Category | Tests | Existing files/fixtures reusable by future continuity P0 tests |
|---|---:|---|
| State validation | 20 | `test_validate_state.valid_save`, synthetic v3 fixture |
| Commit/patch lifecycle | 23 | `CommitTurnLifecycleTests` state factory and pure `COMMIT.commit` path |
| Live slice | 8 | `LiveSliceTests` and generated opening state |
| Consent/boundary/safety (subset of validation+commit, not additional to total) | 12 | Scene binding, scope/withdrawal, supporting-intimacy upgrade, pause, grant inheritance/reset/archive, boundary revoke |
| Save/concurrency/recovery | 10 | 9 `test_manage_saves` plus build-opening slot lifecycle |
| NPC/relationship/event (subset of validation+commit, not additional to total) | 19 | Stable-ID guards, relation delta/edge validation, knowledge cap, NPC presence, event lifecycle/dedup/source/time |
| Opening/build | 13 | Opening skeleton/fill/slot/fixture paths; excludes the one slot lifecycle test counted under save |
| Content integrity | 6 | Data/voice/command fingerprints and content checks |
| Opening roll/data | 49 | Deterministic pools, locks, reconciliation and metadata |

Reusable fixtures provide valid runtime state, event/consent/relationship edges, supporting-NPC upgrade checks, and live-slice truncation. They do **not** provide 150-turn re-entry, epistemic planes, continuity branches, evidence retrieval, sidecar recovery, or voice-drift longitudinal fixtures; future implementation must add those tests, but their absence is not an architecture blocker.

## 31. SOURCE AUDIT EVIDENCE — dsh-adult-tension

This section records the complete source-level integration audit. It supersedes the earlier acquisition-only interpretation while preserving the repository evidence.

- Repository path: `/var/minis/workspace/vendor/dsh-adult-tension`
- Remote origin: `https://github.com/daha1216/dsh-adult-tension.git`
- Audited ref: detached `HEAD` `cbfdc623fccc91247cbb37783757fc157406c2a5`
- `origin/main`: `cbfdc623fccc91247cbb37783757fc157406c2a5`
- Worktree: clean before and after audit
- Files inspected: **39 tracked files**
- Tests inspected: **7 files / 129 test methods**, plus `tests/fixtures/_opening_synthetic_v3.yaml`
- No dependency install, test execution, opening generation, turn submission, save mutation, continuity implementation, or `/var/minis/skills` modification occurred.

### Inspected source set

- Root/control: `SKILL.md`, `commands.yaml`, `requirements.txt`, `README.md`, `PROGRESS.md`, `.gitignore`, `.gitattributes`, `agents/openai.yaml`, `saves/README.md`.
- References: all five files — `世界运转.md`, `加内容.md`, `开局流程.md`, `状态总结.md`, `角色设计.md`.
- Scripts: all nine Python modules — `_common.py`, `build_opening.py`, `check_content.py`, `commit_turn.py`, `fill_opening.py`, `live_slice.py`, `manage_saves.py`, `roll_opening.py`, `validate_state.py`.
- Data: all eight YAML files — `character_meta.yaml`, `character_pools.yaml`, `identities.yaml`, `locations.yaml`, `names.yaml`, `pools.yaml`, `templates.yaml`, `twists.yaml`.
- Tests: all seven `test_*.py` files and the sole tracked opening fixture.

### Key file SHA-256

| File | SHA-256 |
|---|---|
| `SKILL.md` | `abd0551b97310d635f1d5febbf5f767bbad7c50d94831e64575cad4a319dbcf1` |
| `commands.yaml` | `5f2a7203bac7c5602382ed24bdd3c49310b5b920e659c24ea3ac63505f04f0a4` |
| `scripts/_common.py` | `a3cd50df2fa47272e6318cbfd59af5a94eee5bb13c7bce372c1e48443c8a299b` |
| `scripts/build_opening.py` | `7771ef25c56233bd824ad96aeb4bef5c5f95f733144d830d86f4910d1455c4f0` |
| `scripts/commit_turn.py` | `1733da744c59bc227008b72097f07061bee56c11f5f45d2f8532ced70c7db51e` |
| `scripts/fill_opening.py` | `62a46852947b993e4fc12aec20f53faedd3c3dd06af4ef394309da64eac8cca2` |
| `scripts/live_slice.py` | `ca90001b3b7881a990083ef0f754d2b0d955dc451773a2f82e0a25110fd1ce16` |
| `scripts/manage_saves.py` | `58ddfe38ebce0ab33727dc68370f01123f48a487e51c7828e4f7c91f1651fd8c` |
| `scripts/validate_state.py` | `0f059feddbcafab463dd86b78192b83c9bff810c65cf551a5c57366052248dbd` |
| `references/世界运转.md` | `03041420cff9e679522043cf92bacc1791d339d4d14edbaf5712e488a944759c` |
| `references/状态总结.md` | `ac3e13b49815844357390d74971ac34ddef4ea64e74722aaae65e2ccf762a58e` |
| `references/角色设计.md` | `133304794169f7312329b6004e2fd89d4c89cfe09abdcce998e4d8bb93ba8883` |

### Verified contracts and unsupported capabilities

- Verified: v3 YAML ownership, stable runtime character/event/grant/boundary IDs, flat knowledge, top-level relationship graph, current situation, consent/grant schemas, patch keys/order, pure candidate validation, one-file atomic replacement, returned live slice, named-slot `updated_at` conflict protection, and post-commit narrative order.
- Unsupported: runtime transaction ID, idempotency, commit outcome query, commit receipt/diff, native revision/hash, current-state optimistic concurrency, exact checkpoint restore, and fork lineage.
- Important-supporting re-entry: **partial native support** — the full card persists in `npcs` with stable ID, but off-scene important-supporting entries are omitted from `live_slice`; no recall/re-entry API exists. V1 continuity uses the stable runtime ID and read-only full-state lookup plus DEEP retrieval, without owning or duplicating the card.

## Final lock verdict

`SPEC_LOCK status: PASS`

All architecture-level P0 assumptions are either verified against source or removed from V1. The remaining absent runtime capabilities are explicitly deferred, and V1 fails closed through read-only degradation, exclusive single-writer precondition, pre/post observational hashes, deterministic candidate comparison, no blind retry, no rollback claim, and no exact fork/restore claim. Duplicated mutable authority, adult compatibility violations, player-sovereignty architecture violations, invented API dependencies, and unresolved P0 architecture issues are all zero.
