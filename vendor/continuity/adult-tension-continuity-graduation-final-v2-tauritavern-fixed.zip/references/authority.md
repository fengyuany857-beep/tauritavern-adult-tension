# Authority

`adult-tension` owns all runtime YAML fields. The sidecar rejects predicates rooted at runtime keys, including consent, boundaries, safety, sexuality, intimacy, runtime NPC cards, relationship trust, events, and checkpoints. Observations and runtime references are immutable evidence, not second authority.
