# Retrieval

Phase 1 implements no retrieval or Context Pack builder. Derived indexes remain rebuildable and cannot write authority. Future retrieval must retain provenance and presentation gates.
