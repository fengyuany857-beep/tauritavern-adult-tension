# Storage

SQLite is the single sidecar authority. Migrations run transactionally with foreign keys enabled and are version-checked. JSONL history is append-only evidence; manifests are checksummed metadata and never Canon.
