# Runtime adapter

`runtime_readonly.py` reads a runtime state, computes an `OBSERVED_RUNTIME_STATE` SHA-256, invokes only `live_slice` projection and pure validation, and can retrieve an NPC card by existing runtime ID. It never imports `commit_turn`, patches state, or writes a save. The observed hash is not a runtime revision.
