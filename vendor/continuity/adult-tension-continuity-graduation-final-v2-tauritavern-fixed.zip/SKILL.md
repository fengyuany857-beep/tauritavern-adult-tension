---
name: adult-tension-continuity
description: "Host-neutral continuity sidecar for long-running adult-tension roleplay: authoritative continuity storage, deterministic retrieval/context routing, NPC re-entry, and fail-closed transaction/sync/recovery. It never owns current runtime permission, player internal state, or upstream runtime authority."
---
# adult-tension-continuity

A non-invasive companion to `adult-tension`, not a replacement. The continuity sidecar owns only continuity-native Canon/history metadata, knowledge, commitments, threads, evidence, retrieval indexes, and its own transaction journal. Upstream `adult-tension` remains the sole authority for current runtime state and current permission/safety fields it already owns.

## Current capabilities

- SQLite continuity authority store and append-only evidence history.
- Bitemporal facts, character knowledge, relationships, commitments, threads, and episodes.
- Deterministic FAST / DEEP / EVIDENCE retrieval and ContextPack construction.
- Important-NPC re-entry planning with stable identity, reveal gates, and anti-merge constraints.
- Phase 3 transaction orchestration: durable PREPARED intent, one runtime mutation attempt, post-write classification, continuity sync/outbox, and fail-closed recovery.
- Structural authority/player-sovereignty validation at planning, writing, and retrieval boundaries.

## Safety / host boundary

- Observed runtime SHA-256 is evidence about exact bytes, never a runtime revision or CAS identity.
- Runtime + SQLite + JSONL are not one atomic transaction.
- UNKNOWN, divergence, unsupported/failed durability, or manual-review states never auto-retry the same runtime transaction.
- Runtime mutation is guarded and development tests use disposable fixtures only. A production host adapter must preserve the same contracts and must not bypass the transaction/sync pipeline.
- This package is not a TauriTavern/iOS adapter by itself. Host integration belongs in a separate adapter layer.

## Core utilities

- `python scripts/init_continuity.py --vendor <pinned-repo>`
- `python scripts/validate_continuity.py`
- `python scripts/doctor.py --vendor <pinned-repo>`
- retrieval/context and orchestration CLIs under `scripts/` where present

Unsupported merge/fork/exact runtime restore remain fail-closed unless a future formally specified host capability provides them.
