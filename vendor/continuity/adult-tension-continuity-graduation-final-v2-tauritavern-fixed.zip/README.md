# adult-tension-continuity

Host-neutral continuity sidecar for long-running `adult-tension` roleplay.

The current graduation baseline contains the full continuity stack: SQLite authority/history storage, deterministic retrieval and ContextPack routing, important-NPC re-entry, Phase 3 transaction orchestration, continuity sync/outbox, and crash/recovery handling.

It is deliberately separate from host-specific integration. `adult-tension` keeps current runtime authority; this project records and retrieves continuity without inferring current permission or player internal state from historical context.

## Development / validation

Use the repository test suite and validation scripts from the repository root. Vendor paths are supplied explicitly by the caller or test harness; `/var/minis/...` is an Open Minis development environment detail, not a canonical host path.

## Host integration

Open Minis, TauriTavern/iOS, and other hosts should connect through thin adapters that preserve the existing contracts. Do not bypass the PREPARED → one-attempt runtime outcome → continuity sync → evidence/recovery pipeline, and do not replace the continuity database with a host journal.
