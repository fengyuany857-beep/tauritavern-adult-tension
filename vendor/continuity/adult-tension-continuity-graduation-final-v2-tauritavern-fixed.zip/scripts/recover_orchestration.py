"""Phase 3D — orchestration recovery CLI (reprocess-restart recovery).

Resumes a durable orchestration saga (applied-but-unsynced) forward-only.
REQUIRES re-offering the identical digest-stable consequence plan to recover a
sync (Phase 3C request-provider model).  It never writes the runtime, never
retries a run attempt, never rolls back, never infers consequences.

For UNKNOWN / DIVERGENCE / NOT_APPLIED / PRECONDITION_FAILED / MANUAL_REVIEW it
only reports the durable state (no sync, no retry, no override).
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from continuity.orchestration.recovery import (
    recover_orchestration, scan_recoverable_orchestrations,
)
from continuity.orchestration.errors import UnknownOrchestration
from continuity.orchestration.contracts import ConsequencePlan


def _load_plan(path: Path | None, no_cons: bool) -> ConsequencePlan | None:
    if path is None and not no_cons:
        return None
    if no_cons:
        return ConsequencePlan(branch_id="default", consequences=[])
    data = json.loads(Path(path).read_text())
    cons = data if isinstance(data, list) else data.get("consequences", [])
    return ConsequencePlan(
        branch_id=data.get("branch_id", "default") if isinstance(data, dict) else "default",
        consequences=cons)


def main() -> int:
    ap = argparse.ArgumentParser(description="orchestration recovery")
    ap.add_argument("--db", type=Path, required=True)
    ap.add_argument("--tx", default=None)
    ap.add_argument("--scan", action="store_true")
    ap.add_argument("--consequences", type=Path, default=None)
    ap.add_argument("--no-consequences", action="store_true")
    a = ap.parse_args()
    if a.scan:
        print(json.dumps(scan_recoverable_orchestrations(db_path=a.db), indent=2))
        return 0
    if not a.tx:
        raise SystemExit("--tx (or --scan) is required")
    plan = _load_plan(a.consequences, a.no_consequences)
    try:
        res = recover_orchestration(db_path=a.db, tx_id=a.tx, consequence_plan=plan)
    except UnknownOrchestration:
        print(json.dumps({"continuity_tx_id": a.tx, "error": "not_found"}))
        return 1
    print(json.dumps(res.as_dict(), indent=2))
    return 0 if res.status in ("COMPLETED", "PENDING") else (
        2 if res.status == "MANUAL_REVIEW_REQUIRED" else 3)


if __name__ == "__main__":
    raise SystemExit(main())
