from __future__ import annotations
import argparse,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]))
from continuity.doctor import check

def main()->int:
 p=argparse.ArgumentParser(); p.add_argument('--base',type=Path,default=Path(__file__).parents[1]); p.add_argument('--vendor',type=Path,required=True); a=p.parse_args(); status,notes=check(a.base,a.vendor); print(status+': '+'; '.join(notes)); return 0 if status in {'PASS','WARN'} else 1
if __name__=='__main__': raise SystemExit(main())
