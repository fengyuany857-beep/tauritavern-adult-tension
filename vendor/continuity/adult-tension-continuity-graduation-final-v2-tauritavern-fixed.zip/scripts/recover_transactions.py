"""Phase 3C — developer recovery scanner CLI (NO RUNTIME WRITE).

Reads the nonterminal journal, classifies each row (A-H), drains any pending
outbox and can emit a manual-review packet for rows automation cannot safely
continue.  Recovery only ever replays sidecar consequences forward; it never
calls commit_turn / os.replace / retries a runtime mutation and never exposes
runtime-retry / rollback / commit flags.
"""
from __future__ import annotations
import argparse
import json
import sqlite3
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from continuity.sync3c.recovery import RecoveryScanner, RecoveryAction
from continuity.sync3c.manual_packet import build_manual_packet


def _connect(db: Path) -> sqlite3.Connection:
    con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--db", type=Path, required=True)
    p.add_argument("--emit-manual", type=Path, default=None,
                   help="write manual-review packets here")
    p.add_argument("--limit", type=int, default=100)
    a = p.parse_args()

    con = _connect(a.db)
    hist = a.db.parent / "history" / "VOL-001.jsonl"
    sc = RecoveryScanner(con, evidence_path=hist, request_provider=None)
    observations = sc.scan(limit=a.limit)
    # outbox-projection step for rows whose authority is done but JSONL pending.
    drained = 0
    pending = con.execute(
        "SELECT continuity_tx_id FROM history_outbox WHERE state='PENDING'").fetchall()
    if pending and hist:
        from continuity.sync3c.projector import EvidenceProjector
        proj = EvidenceProjector(con, hist)
        drained = proj.drain()["drained"]
    if a.emit_manual:
        packets = [o for o in observations if o["manual_review_json"]]
        Path(a.emit_manual).write_text(
            json.dumps(packets, indent=2, ensure_ascii=False))
    print(json.dumps({"observations": observations,
                      "outbox_drained": drained}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
