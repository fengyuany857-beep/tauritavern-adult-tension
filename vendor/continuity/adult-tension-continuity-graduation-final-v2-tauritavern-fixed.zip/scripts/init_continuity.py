from __future__ import annotations
import argparse
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parents[1]))
from continuity.db import connect
from continuity.hashing import sha256_file
from continuity.manifest import build,write

def main() -> int:
 p=argparse.ArgumentParser(); p.add_argument('--base',type=Path,default=Path(__file__).parents[1]); p.add_argument('--vendor',type=Path,required=True); a=p.parse_args()
 db=a.base/'state'/'continuity.sqlite3'; c=connect(db); c.close()
 keys=['SKILL.md','commands.yaml','scripts/commit_turn.py','scripts/live_slice.py','scripts/validate_state.py']
 hashes={x:sha256_file(a.vendor/x) for x in keys}
 write(a.base/'manifests'/'manifest.json',build(db,a.base/'history'/'VOL-001.jsonl',hashes)); print('PASS: initialized authority DB and manifest'); return 0
if __name__=='__main__': raise SystemExit(main())
