from __future__ import annotations
import argparse,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]))
from continuity.db import connect,integrity

def main()->int:
 p=argparse.ArgumentParser(); p.add_argument('--db',type=Path,default=Path(__file__).parents[1]/'state'/'continuity.sqlite3'); a=p.parse_args()
 c=connect(a.db); print('PASS' if integrity(c)=='ok' else 'BLOCKED'); return 0 if integrity(c)=='ok' else 1
if __name__=='__main__': raise SystemExit(main())
