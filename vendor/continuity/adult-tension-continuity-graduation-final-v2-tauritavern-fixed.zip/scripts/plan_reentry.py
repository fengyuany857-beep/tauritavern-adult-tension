"""Phase 2B-2 read-only Important-NPC Re-entry Planner CLI.

Developer-facing, never writes authority or runtime and never triggers model /
LLM calls.  Given a returning / recalled runtime NPC (stable runtime id or a
mention) it produces a ReentryPlan ledger and optionally the ContextPack that a
global decision model would see (reusing the Phase 2B-1 ContextPackBuilder).

Typical usage (against a base with state/continuity.sqlite3 sidecar):

    python scripts/plan_reentry.py --runtime-npc alex-r \
        --runtime <rt.json> --query-id cli --explain --json

Options:
  * --runtime-npc <id>              stable runtime NPC id (preferred)
  * --mention <name>                free-text, resolved via confirmed aliases
  * --branch default
  * --observer <continuity entity>  observer entity id (unused for target recall)
  * --text <query text>             for routing/pack context
  * --mode FAST|DEEP|EVIDENCE       controller mode (default autodetect)
  * --budget <tokens>               deterministic token budget
  * --pack                          also build the read-only ContextPack
  * --explain / --json
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1]))

from continuity.routing import (  # noqa: E402
    ContextPackBuilder, RoutingRequest,
)
from continuity.reentry import (  # noqa: E402
    ReentryPlanner, ReentryRequest, plan_to_reentry_candidates,
)
from continuity.reentry.planner import to_card_candidate  # noqa: E402


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="read-only re-entry planner (no writes)")
    p.add_argument("--base", type=Path, default=Path(__file__).parents[1],
                   help="continuity base dir holding state/continuity.sqlite3")
    p.add_argument("--runtime-npc", default=None, help="stable runtime NPC id")
    p.add_argument("--mention", default=None, help="display name / confirmed alias")
    p.add_argument("--branch", default="default")
    p.add_argument("--observer", default=None, help="observer entity id")
    p.add_argument("--runtime", type=Path, default=None,
                   help="JSON-subset runtime snapshot (full registry, read-only)")
    p.add_argument("--text", default="", help="query text (drives context/pack)")
    p.add_argument("--mode", choices=("FAST", "DEEP", "EVIDENCE"), default="DEEP")
    p.add_argument("--last-seen", type=int, default=None,
                   help="turn when this NPC was last seen (absence calc)")
    p.add_argument("--event-turn", type=int, default=None,
                   help="current scene/event turn (absence calc)")
    p.add_argument("--budget", type=int, default=None, dest="budget")
    p.add_argument("--pack", action="store_true",
                   help="also assemble the read-only ContextPack for this re-entry")
    p.add_argument("--query-id", default="cli")
    p.add_argument("--explain", action="store_true")
    p.add_argument("--json", dest="as_json", action="store_true")
    return p


def _status(o) -> str:
    return o.value if hasattr(o, "value") else str(o)


def main() -> int:
    args = build_parser().parse_args()
    if not (args.runtime_npc or args.mention):
        print("error: provide --runtime-npc or --mention", file=sys.stderr)
        return 2
    req = ReentryRequest(
        runtime_npc_id=args.runtime_npc, mention_text=args.mention,
        branch_id=args.branch, observer_entity_id=args.observer,
        query_text=args.text or "", reentry_reason="explicit_historical_recall"
        if False else None, last_seen_turn=args.last_seen,
        event_turn=args.event_turn, mode=args.mode, query_id=args.query_id,
        token_budget=args.budget,
    )
    planner = ReentryPlanner(args.base)
    plan = planner.plan(req, args.runtime)
    if args.as_json:
        print(json.dumps(plan.as_dict(), ensure_ascii=False, sort_keys=True))
    else:
        print("resolution_status :", _status(plan.resolution_status))
        print("reentry_status    :", _status(plan.status))
        print("runtime_npc_id    :", plan.runtime_npc_id)
        print("target_entity_id  :", plan.target_entity_id)
        print("npc_class         :", plan.npc_class)
        print("absence_turns     :", plan.absence_turns)
        print("runtime_card_ref  :", plan.runtime_card_ref)
        print("observed_sha      :", (plan.runtime_observed_sha256[:8] + "…")
              if plan.runtime_observed_sha256 else None)
        print("anchors           :", ", ".join(plan.entity_anchor_refs) or "-")
        print("knowledge_refs    :", ", ".join(plan.knowledge_refs) or "-")
        print("relationship_refs :", ", ".join(plan.relationship_refs) or "-")
        print("commitment_refs   :", ", ".join(plan.commitment_refs) or "-")
        print("thread_refs       :", ", ".join(plan.thread_refs) or "-")
        print("episode_refs      :", ", ".join(plan.episode_refs) or "-")
        print("guard_refs        :", ", ".join(plan.guard_refs) or "-")
        print("semantic_digest   :", plan.semantic_digest[:24] + ("…" if len(plan.semantic_digest) > 24 else ""))
        if args.explain:
            print("--- activation traces ---")
            for e in plan.activation_traces:
                mark = "" if e.included else (" [EXCLUDED:%s]" % (e.exclusion_reason or "?"))
                print(f"  [{e.activation_type.value}] {e.source_ref} hard={e.hard_or_soft.value}"
                      f" {e.reason}{mark}")

    if args.pack:
        cands = plan_to_reentry_candidates(plan)
        card_cand = to_card_candidate(plan)
        if card_cand is not None:
            cands = tuple([card_cand] + list(cands))
        ruse = RoutingRequest(
            query_id=args.query_id or "reentry-pack",
            raw_text=args.text or "",
            branch_id=args.branch, observer_entity_id=args.observer,
            mode_override=None, token_budget=args.budget,
        )
        builder = ContextPackBuilder(args.base)
        pack = builder.build(ruse, runtime_state=args.runtime,
                             reentry_candidates=cands)
        if args.as_json:
            print("PACK_JSON " + json.dumps(pack.as_dict(), ensure_ascii=False,
                                            sort_keys=True))
        else:
            print("pack_status  :", _status(pack.status))
            print("pack_mode    :", pack.mode, "items:", len(pack.items),
                  "budget:", pack.token_budget)
            for it in pack.items:
                if it.source_type in ("ENTITY", "KNOWLEDGE", "RELATIONSHIP",
                                      "COMMITMENT", "EPISODE", "GUARD", "THREAD") \
                        and "reentry" in it.activation_reason.lower() \
                        or it.residency in ("HOT", "WARM") and it.source_type == "ENTITY":
                    print("   pack-item", it.item_id, it.residency, it.source_type)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
