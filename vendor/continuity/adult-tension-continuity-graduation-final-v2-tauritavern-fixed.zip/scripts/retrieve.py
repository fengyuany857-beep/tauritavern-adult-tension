"""Phase 2A read-only retrieval CLI.

Usage examples:
  python scripts/retrieve.py --base /path --text "sapphire" --explain
  python scripts/retrieve.py --base /path --entity E-C
  python scripts/retrieve.py --base /path --retriever evidence --scene SC-1
No authority or runtime mutation occurs.
"""
from __future__ import annotations
import argparse
import json
from dataclasses import replace
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parents[1]))

from continuity.retrieval import (  # noqa: E402
    ApproximateTokenEstimator, Context, EntityRetriever, EvidenceRetriever,
    HybridRetriever, LedgerRetriever, LexicalRetriever, RetrievalQuery,
    TemporalRetriever,
)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="read-only continuity retrieval")
    p.add_argument("--base", type=Path, default=Path(__file__).parents[1])
    p.add_argument("--text", default="")
    p.add_argument("--entity", action="append", default=[])
    p.add_argument("--fact", action="append", default=[])
    p.add_argument("--thread", action="append", default=[])
    p.add_argument("--commitment", action="append", default=[])
    p.add_argument("--branch", default="default")
    p.add_argument("--observer", default=None)
    p.add_argument("--turn", type=int, default=None)
    p.add_argument("--known-at", type=int, default=None)
    p.add_argument("--scene", default=None)
    p.add_argument("--episode", default=None)
    p.add_argument("--retriever", choices=("lexical", "entity", "temporal", "ledger", "evidence", "hybrid"), default="hybrid")
    p.add_argument("--limit", type=int, default=10)
    p.add_argument("--include-historical", action="store_true")
    p.add_argument("--include-superseded", action="store_true")
    p.add_argument("--evidence", action="store_true", dest="exact_evidence_required")
    p.add_argument("--explain", action="store_true")
    return p


def main() -> int:
    args = build_parser().parse_args()
    ctx = Context.open(args.base)
    q = RetrievalQuery(
        raw_text=args.text, branch_id=args.branch, observer_entity_id=args.observer,
        entity_ids=tuple(args.entity), fact_ids=tuple(args.fact),
        thread_ids=tuple(args.thread), commitment_ids=tuple(args.commitment),
        event_turn=args.turn, as_known_at=args.known_at, scene_id=args.scene,
        episode_id=args.episode, include_historical=args.include_historical,
        include_superseded=args.include_superseded,
        exact_evidence_required=args.exact_evidence_required, limit=args.limit,
        query_id="cli", token_budget=None,
    )
    estimator = ApproximateTokenEstimator()
    retriever = {
        "lexical": LexicalRetriever(), "entity": EntityRetriever(),
        "temporal": TemporalRetriever(), "ledger": LedgerRetriever(),
        "evidence": EvidenceRetriever(),
        "hybrid": HybridRetriever([LexicalRetriever(), LedgerRetriever(), TemporalRetriever(), EntityRetriever()]),
    }[args.retriever]
    result = retriever.retrieve(q, ctx)
    items = []
    for item in result.items:
        items.append({
            "item_id": item.item_id, "source_type": item.source_type.value,
            "classification": item.classification, "current_or_historical": item.current_or_historical,
            "estimated_token_cost": estimator.estimate(item.content),
            "content": item.content[:300],
        })
    print(json.dumps({"status": result.status.value, "query_id": result.query_id,
                      "items": items, "insufficiency": list(result.insufficiency)}, ensure_ascii=False, indent=2))
    if args.explain:
        for trace in result.traces:
            if trace.included or trace.exclusion_reason:
                print(f"trace {trace.retriever} {trace.candidate_item_id} included={trace.included} "
                      f"reason={trace.exclusion_reason or '-'} filters={','.join(trace.filters_applied)} final={trace.final_rank}")
    ctx.conn.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
