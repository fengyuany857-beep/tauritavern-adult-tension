"""Phase 3D — orchestration status CLI (read-only; never writes).

Query the durable table for one (or many) orchestration txs: tx id, state,
runtime outcome, attempt_count, writer_invoked, pre/post fingerprints, sync
state, outbox pending, manual-review flag and retry_requires_new_tx.

Never exposes full adult current-permission payload or chain-of-thought.
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from continuity.orchestration.status import orchestration_status, scan_recoverable
from continuity.orchestration.errors import UnknownOrchestration


def main() -> int:
    ap = argparse.ArgumentParser(description="orchestration status (read-only)")
    ap.add_argument("--db", type=Path, required=True)
    ap.add_argument("--tx", default=None)
    ap.add_argument("--scan-recoverable", dest="recoverable", action="store_true")
    a = ap.parse_args()
    if a.recoverable:
        print(json.dumps(scan_recoverable(a.db), indent=2))
        return 0
    if not a.tx:
        raise SystemExit("--tx is required (or --scan-recoverable)")
    try:
        st = orchestration_status(db_path=a.db, tx_id=a.tx)
    except UnknownOrchestration:
        print(json.dumps({"continuity_tx_id": a.tx, "error": "not_found"}))
        return 1
    print(json.dumps(st, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
