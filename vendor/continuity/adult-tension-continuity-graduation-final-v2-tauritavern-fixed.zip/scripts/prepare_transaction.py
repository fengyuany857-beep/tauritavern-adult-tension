"""Phase 3A developer pre-condition / prepare CLI (READ-ONLY w.r.t. runtime).

Prepares a safe continuity transaction and, optionally, runs the second H0
re-check (the P8 prewrite pre-condition).  It NEVER:
  - writes / replaces / calls commit_turn on the runtime,
  - creates a temp runtime file,
  - performs a runtime mutation,
  - runs any LLM / vector / graph model,
  - generates an outcome from a player's natural-language request.

It only:
  - reads+parses+validates the canonical current runtime state,
  - computes raw/semantic/patch digests,
  - runs the PURE vendor commit in memory and validates,
  - persists a durable PREPARED saga row (attempt_count=0) in the sidecar,
  - optionally re-reads the same runtime file to verify the pre-condition.

Usage examples:
    python scripts/prepare_transaction.py \\
        --vendor /path/to/vendor/dsh-adult-tension \\
        --runtime /path/.../current_state.yaml \\
        --patch-file /tmp/patch.json  --json
    python scripts/prepare_transaction.py \\    # second H0 check (same tx)
        --check --tx <continuity_tx_id> --runtime ... --json
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from continuity.transactions.preconditions import (
    prepare_transaction,
    verify_prewrite_precondition,
)
from continuity.transactions.errors import TxError


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="read-only safe-transaction prepare (no runtime writes)")
    p.add_argument("--base", type=Path, default=Path(__file__).resolve().parents[1],
                   help="continuity base holding state/continuity.sqlite3")
    p.add_argument("--vendor", type=Path, default=None,
                   help="pinned vendor repo (must contain the canonical runtime file)")
    p.add_argument("--runtime", type=Path, default=None,
                   help="canonical V1 current runtime state file (defaults to "
                        "<vendor>/saves/current_state.yaml)")
    p.add_argument("--patch-file", type=Path, default=None,
                   help="JSON patch file (concrete upstream runtime delta)")
    p.add_argument("--patch", default=None,
                   help="inline JSON patch string (concrete upstream runtime delta)")
    p.add_argument("--branch", default="default")
    p.add_argument("--operation", default="prepare_turn")
    p.add_argument("--check", action="store_true",
                   help="run the second (P8) H0 re-check against the given --tx")
    p.add_argument("--tx", default=None,
                   help="continuity_tx_id to check (used with --check)")
    p.add_argument("--request-id", default="cli")
    p.add_argument("--reject-named-slot", action="store_true",
                   help="force unsupported-named-slot rejection (safety demo)")
    p.add_argument("--json", dest="as_json", action="store_true")
    return p


def _rt(vendor: Path, runtime: Path | None) -> Path:
    if runtime is not None:
        return runtime
    return vendor / "saves" / "current_state.yaml"


def main() -> int:
    args = build_parser().parse_args()
    vendor = args.vendor
    if vendor is None:
        print("error: --vendor is required", file=sys.stderr)
        return 2
    vendor = Path(vendor)
    try:
        if args.check:
            if not args.tx:
                print("error: --tx required with --check", file=sys.stderr)
                return 2
            db = args.base / "state" / "continuity.sqlite3"
            out = verify_prewrite_precondition(db, vendor, _rt(vendor, args.runtime), args.tx)
            print(json.dumps(out, ensure_ascii=False, indent=2) if args.as_json else out)
            return 0

        if not (args.patch_file or args.patch):
            print("error: provide --patch or --patch-file (concrete upstream runtime delta)",
                  file=sys.stderr)
            return 2
        if args.patch_file:
            patch_text = Path(args.patch_file).read_text(encoding="utf-8")
        else:
            patch_text = args.patch
        patch = json.loads(patch_text)
        db = args.base / "state" / "continuity.sqlite3"
        pe = prepare_transaction(
            vendor_dir=vendor, db_path=db, runtime_path=_rt(vendor, args.runtime),
            patch=patch, operation=args.operation, branch_id=args.branch,
            request_provenance={"source": "CLI", "request_id": args.request_id},
            reject_named_slot=args.reject_named_slot,
        )
        payload = pe.to_dict()
        # only loop / harmless derived output; keep deterministic JSON summary
        if args.as_json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print(f"continuity_tx_id: {pe.continuity_tx_id}")
            print(f"state: {pe.state}")
            print(f"runtime_pre_sha256: {pe.runtime_pre_sha256}")
            print(f"patch_digest: {pe.patch_digest}")
            print(f"expected_candidate_digest: {pe.expected_candidate_digest}")
            print("Phase 3A: transaction PREPARED (no runtime mutation performed).")
        return 0
    except TxError as exc:
        print(f"error[{exc.class_label}]: {exc}", file=sys.stderr)
        return 1
    except (json.JSONDecodeError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:  # noqa: BLE001 - bounded CLI error
        print(f"error: unexpected {exc.__class__.__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except AttributeError:  # pragma: no cover
        pass
    raise SystemExit(main())
