"""Phase 3D — developer orchestration CLI (single-file commit + continuity sync).

Drives the *full* safe saga on a provably disposable runtime only.  The default
is fail-safe:
  - `--dry-run` validates + prints the tx & phases without any change;
  - a real mutation requires `--disposable-runtime` AND a runtime_path inside an
    OS temp disposable root (Phase 3B proof), a concrete JSON patch, and an
    explicit consequence plan file (or explicit 'empty').

Forbidden options (never implemented): --force, --ignore-precondition,
--retry-same-tx, --rollback-runtime, --assume-applied, --assume-not-applied,
--skip-outcome-check.  Production real-save mutation stays disabled.
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from continuity.orchestration import orchestrate as _orchestrate
from continuity.orchestration.contracts import (
    OrchestrationRequest, ConsequencePlan,
)
from continuity.runtime3b.guard import is_disposable_runtime


def _load_patch(path: Path) -> dict:
    data = json.loads(Path(path).read_text())
    if not isinstance(data, dict):
        raise SystemExit("patch file must contain a JSON object (concrete patch)")
    return data


def _load_consequences(path: Path | None, explicit_none: bool) -> ConsequencePlan:
    if path is None and not explicit_none:
        raise SystemExit(
            "a consequence plan (--consequences JSON) or --no-consequences is required")
    if explicit_none:
        return ConsequencePlan(branch_id="default", consequences=[])
    data = json.loads(Path(path).read_text())
    cons = data if isinstance(data, list) else data.get("consequences", [])
    return ConsequencePlan(branch_id=data.get("branch_id", "default") if isinstance(data, dict)
                           else "default", consequences=cons)


def main() -> int:
    ap = argparse.ArgumentParser(description="phase 3D orchestration CLI (fail-safe)")
    ap.add_argument("--db", type=Path, required=True)
    ap.add_argument("--vendor", "--vendor-dir", dest="vendor", type=Path, required=True)
    ap.add_argument("--runtime", "--runtime-path", dest="runtime", type=Path, required=True)
    ap.add_argument("--patch", "--patch-file", dest="patch", type=Path, required=False)
    ap.add_argument("--consequences", "--consequence-plan", dest="cons", type=Path, default=None)
    ap.add_argument("--no-consequences", dest="no_cons", action="store_true")
    ap.add_argument("--evidence", type=Path, default=None)
    ap.add_argument("--disposable-runtime", dest="disp", action="store_true")
    ap.add_argument("--dry-run", dest="dry", action="store_true")
    ap.add_argument("--json", dest="as_json", action="store_true")
    a = ap.parse_args()

    # Refuse named-slot / non-disposable before any work.
    if not a.patch and not a.dry:
        # conrete patch required unless dry-run
        raise SystemExit("a concrete --patch JSON is required (or --dry-run)")
    if not a.disp:
        raise SystemExit("REFUSE: production real-save mutation is disabled in dev; "
                         "pass --disposable-runtime on a throwaway fixture")
    proof = is_disposable_runtime(a.vendor.resolve(), a.runtime.resolve())
    if not proof.ok:
        raise SystemExit("REFUSE: runtime is not a provably disposable fixture: "
                         + proof.reason)

    patch = _load_patch(a.patch) if a.patch else {}
    if a.cons is None and not a.no_cons:
        raise SystemExit("a consequence plan (--consequences) or --no-consequences is required")
    plan = _load_consequences(a.cons, a.no_cons)
    request = OrchestrationRequest(
        patch=patch, vendor_dir=str(a.vendor), runtime_path=str(a.runtime),
        consequence_plan=plan,
        request_provenance={"cli": "orchestrate_turn"})

    if a.dry:
        print(json.dumps({
            "dry_run": True,
            "vendor": str(a.vendor.resolve()),
            "runtime": str(a.runtime.resolve()),
            "consequences": len(plan.consequences),
            "disposable_proved": True,
        }, indent=2))
        return 0

    res = _orchestrate(request, db_path=a.db, evidence_path=a.evidence,
                       consequence_plan=plan)
    print(json.dumps(res.as_dict(), indent=2))
    # brief stdout summary for non-json
    if not a.as_json:
        print(f"[summary] tx={res.continuity_tx_id} status={res.status} "
              f"runtime={res.runtime_outcome} sync={res.sync_state}")
    return 0 if res.status in ("COMPLETED", "PENDING", "MANUAL_REVIEW_REQUIRED") else 2


if __name__ == "__main__":
    raise SystemExit(main())
