"""Phase 2B-1 read-only Context Pack CLI.

Equivalent spirit to scripts/retrieve.py: a developer-facing, query-only entry
point.  It never writes authority or runtime and never triggers model calls.

Typical usage (against a base with a state/continuity.sqlite3 sidecar):

    python scripts/build_context.py --text "她上次原话到底是什么？" \
        --observer E-A --branch default --explain --json

  * --mode default|FAST|DEEP|EVIDENCE  (mode override is a debug/testing aid)
  * --runtime <path>                   JSON-subset runtime-state fixture whose
                                       fingerprint is referenced (not copied)
  * --turn / --known-at                bitemporal world/record cursor
  * --budget <tokens>                  deterministic token budget
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1]))

from continuity.routing import (  # noqa: E402
    ContextMode, ContextPackBuilder, RoutingRequest,
)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="read-only context-pack build (no writes)")
    p.add_argument("--base", type=Path, default=Path(__file__).parents[1],
                   help="continuity base dir holding state/continuity.sqlite3")
    p.add_argument("--text", default="", help="query text")
    p.add_argument("--branch", default="default")
    p.add_argument("--observer", default=None, help="observer entity id")
    p.add_argument("--scene", action="append", default=[],
                   help="scene participant entity id (repeatable)")
    p.add_argument("--turn", type=int, default=None)
    p.add_argument("--known-at", dest="known_at", type=int, default=None)
    p.add_argument("--mode", choices=("default", "FAST", "DEEP", "EVIDENCE"), default="default")
    p.add_argument("--budget", type=int, default=None, help="token budget (None=unbounded)")
    p.add_argument("--runtime", type=Path, default=None,
                   help="JSON-subset runtime fixture to reference its fingerprint")
    p.add_argument("--query-id", default="cli")
    p.add_argument("--explain", action="store_true")
    p.add_argument("--json", dest="as_json", action="store_true")
    return p


def main() -> int:
    args = build_parser().parse_args()
    mode_override = None
    if args.mode != "default":
        mode_override = ContextMode(args.mode)
    req = RoutingRequest(
        query_id=args.query_id, raw_text=args.text, branch_id=args.branch,
        observer_entity_id=args.observer, scene_entity_ids=tuple(args.scene),
        event_turn=args.turn, as_known_at=args.known_at, mode_override=mode_override,
        token_budget=args.budget,
    )
    builder = ContextPackBuilder(args.base)
    pack = builder.build(req, runtime_state=args.runtime)

    if args.as_json:
        print(json.dumps(pack.as_dict(), ensure_ascii=False, indent=2))
    else:
        print(f"pack_id      : {pack.pack_id}")
        print(f"query_id     : {pack.query_id}")
        print(f"initial/final: {pack.initial_mode} -> {pack.final_mode}")
        print(f"status       : {pack.status.value}")
        print(f"budget       : {pack.token_budget} used={pack.estimated_token_used}")
        print(f"semantic_digest: {pack.semantic_digest}")
        print(f"items        : {len(pack.items)}")
        for it in pack.items:
            print(f"  [{it.residency}/{it.hard_or_soft}] {it.source_type} {it.source_ref} "
                  f"{it.activation_reason} tok={it.estimated_token_cost}")
        if args.explain:
            print("routing reasons:")
            for r in pack.routing_reasons:
                print("   -", r)
            print("insufficiency:")
            for i in pack.insufficiency:
                print(f"   - {i.mode_attempted}: {i.reason} ({i.claim})")
            print("dropped:")
            for d in pack.dropped:
                print(f"   - {d.source_type} {d.source_ref}: {d.reason} tok={d.estimated_token_cost}")
            print("retrieval trace refs:")
            for r in pack.retrieval_trace_refs:
                print("   -", r)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
