"""Phase 3C — developer sync CLI (NO RUNTIME WRITE).

Safely syncs a durable CONFIRMED_APPLIED transaction whose digest-stable
sync-request can be re-offered, drains any pending outbox, and finalises.

Forbidden runtime-retry / rollback / commit flags and commit_turn / os.replace
or any named-slot write are intentionally NOT implemented.  This CLI never
mutates runtime.
"""
from __future__ import annotations
import argparse
import json
import sqlite3
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parents[1]
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from continuity.sync3c.engine import ContinuitySyncEngine, SyncEngineError
from continuity.sync3c.contracts import ContinuitySyncRequest


def _connect(db: Path) -> sqlite3.Connection:
    con = sqlite3.connect(str(db)); con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con


def _probe_row(con, tx):
    return con.execute(
        "SELECT state,runtime_outcome_class,runtime_post_observed_sha256,"
        " runtime_post_semantic_digest,expected_candidate_digest,branch_id,"
        " patch_digest, runtime_pre_semantic_digest, staged_sync_digest "
        " FROM transaction_journal WHERE continuity_tx_id=?", (tx,)).fetchone()


def _manual(req_json_path: str | None):
    if req_json_path and Path(req_json_path).exists():
        data = json.loads(Path(req_json_path).read_text())
        return ContinuitySyncRequest(**data)
    return None


def main() -> int:
    p = argparse.ArgumentParser(description="read-only-of-runtime continuity sync")
    p.add_argument("--db", type=Path, required=True)
    p.add_argument("--tx", required=True)
    p.add_argument("--sync-request", type=Path, default=None,
                   help="JSON file of the digest-stable ContinuitySyncRequest")
    p.add_argument("--history", type=Path, default=None,
                   help="evidence JSONL volume; else derived at <dbdir>/history/VOL-001.jsonl")
    p.add_argument("--drain-only", action="store_true",
                   help="only project pending outbox rows, never sync")
    a = p.parse_args()

    con = _connect(a.db)
    hist = a.history or (a.db.parent / "history" / "VOL-001.jsonl")
    req = None
    row = _probe_row(con, a.tx)
    if row is not None:
        if row["runtime_outcome_class"] != "CONFIRMED_APPLIED":
            sys.stderr.write("REFUSE: only CONFIRMED_APPLIED may sync (no runtime write)\n")
            return 2
        req = _manual(str(a.sync_request) if a.sync_request else None)
    eng = ContinuitySyncEngine(con, evidence_path=hist)

    if a.drain_only:
        res = eng.drain_outbox()
        print(json.dumps(res))
        return 0
    if req is None:
        sys.stderr.write("REFUSE: need a digest-stable --sync-request to rebuild the plan\n")
        return 3
    try:
        out = eng.sync_applied_transaction(req)
    except SyncEngineError as e:
        sys.stderr.write(f"BLOCKED: {e.review_reason}: {e}\n")
        return 4
    print(json.dumps(out, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
