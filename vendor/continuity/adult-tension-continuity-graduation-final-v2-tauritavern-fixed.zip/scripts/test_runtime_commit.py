#!/usr/bin/env python3
"""Phase 3B — developer test CLI for the single-file runtime commit path.

REFUSES production (real) runtime paths by default.  It will only perform a
genuine single-file runtime mutation when the operator explicitly supplies a
provably disposable runtime copy (``--disposable-runtime <canonical>``) and a
matching --vendor-dir that is a disposable clone with ``saves/current_state.yaml``.

This is NOT a user-facing "commit current save" tool; the orchestration CLI that
a production operator would use is Phase 3D's scope.

Usage examples (kept intentionally narrow):
    python3 scripts/test_runtime_commit.py --help
    # dry-run acceptance of single-file capability on a disposable runtime:
    python3 scripts/test_runtime_commit.py --disposable-runtime /tmp/x/vendor \
        --vendor-dir /tmp/x/vendor --db /tmp/x/state/c.sqlite3 develop
"""
from __future__ import annotations
import argparse
import json
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from continuity.transactions.preconditions import prepare_transaction  # noqa: E402
from continuity.runtime3b.execute import commit_single_file  # noqa: E402
from continuity.runtime3b.guard import is_disposable_runtime  # noqa: E402


def _refuse(msg: str) -> None:
    print(f"REFUSED: {msg}", file=sys.stderr)
    raise SystemExit(2)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Phase 3B single-file runtime commit test CLI")
    ap.add_argument("--disposable-runtime", help="canonical disposable current_state.yaml path")
    ap.add_argument("--vendor-dir", help="disposable vendor clone root (temp/dir)")
    ap.add_argument("--db", help="sidecar continuity DB path")
    ap.add_argument("--patch", default='{"delta_minutes":5,"last_committed_result":"dev-probe"}',
                    help="concrete upstream patch JSON (never natural language)")
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("develop", help="run a single-file mutation on a disposable runtime")
    args = ap.parse_args(argv)

    # Production refusal: the CLI never mutates a real vendor/runtime.
    if not args.disposable_runtime or not args.vendor_dir or not args.db:
        return 0 if args.cmd is None else _refuse(
            "no --vendor-dir / --disposable-runtime / --db given; refusing to guess paths")

    runtime = Path(args.disposable_runtime)
    vendor = Path(args.vendor_dir)
    db = Path(args.db)
    proof = is_disposable_runtime(vendor, runtime)
    if not proof.ok:
        return _refuse("runtime is not provably disposable: " + proof.reason)

    try:
        patch = json.loads(args.patch)
    except json.JSONDecodeError as exc:
        return _refuse(f"invalid patch JSON: {exc}")
    if not isinstance(patch, dict) or not patch:
        return _refuse("a concrete non-empty patch mapping is required")

    if args.cmd == "develop" or args.cmd is None:
        # drive one safe single-file transaction on a disposable runtime
        rt_before = runtime.read_bytes() if runtime.exists() else b""
        pe = prepare_transaction(vendor_dir=vendor, db_path=db, runtime_path=runtime,
                                 patch=patch, branch_id="default")
        env = commit_single_file(db_path=db, vendor_dir=vendor, runtime_path=runtime,
                                 tx_id=pe.continuity_tx_id, patch=patch)
        out = env.as_dict()
        try:
            out["runtime_mutated"] = runtime.read_bytes() != rt_before
        except OSError:
            out["runtime_mutated"] = False
        print(json.dumps(out, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    return _refuse("unknown subcommand")


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass
    raise SystemExit(main())
